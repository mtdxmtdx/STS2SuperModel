using System.Collections.Immutable;
using System.Diagnostics;
using System.Numerics;
using STS2BestChoice.Core.Model;

namespace STS2BestChoice.Core.Simulation;

/// <summary>
/// Exact multivariate-hypergeometric distribution for drawing from an unordered
/// semantic card multiset. Ordered/top-of-pile effects must not use this type.
/// </summary>
internal static class DrawDistribution
{
    internal const int MaximumSupportedPoolSize = 120;

    internal readonly record struct Outcome(
        ImmutableArray<CardState> Drawn,
        ImmutableArray<CardState> Remaining,
        decimal Probability);

    internal readonly record struct Result(
        ImmutableArray<Outcome> Outcomes,
        bool Exact,
        decimal ProbabilityMassCovered,
        int TotalOutcomeCount,
        int OmittedOutcomeCount);

    internal static Result Enumerate(
        IReadOnlyCollection<CardState> pool,
        int drawCount,
        int maximumBranches)
    {
        ArgumentNullException.ThrowIfNull(pool);
        if (maximumBranches <= 0)
            throw new ArgumentOutOfRangeException(nameof(maximumBranches), "Branch limit must be positive.");
        if (pool.Count > MaximumSupportedPoolSize)
            throw new ArgumentOutOfRangeException(nameof(pool),
                $"Unordered draw pools larger than {MaximumSupportedPoolSize} cards are not supported exactly.");

        var groups = pool
            .GroupBy(DeterministicSimulator.CardSemanticKey, StringComparer.Ordinal)
            .Select(group => new CardGroup(
                group.Key,
                group.OrderBy(static card => card.InstanceId, StringComparer.Ordinal).ToImmutableArray()))
            .OrderBy(static group => group.Key, StringComparer.Ordinal)
            .ToArray();
        var canonicalPool = groups.SelectMany(static group => group.Instances).ToImmutableArray();
        var actualDrawCount = Math.Clamp(drawCount, 0, canonicalPool.Length);

        if (actualDrawCount == 0)
            return Single([], canonicalPool);
        if (actualDrawCount == canonicalPool.Length)
            return Single(canonicalPool, []);

        var denominator = Combination(canonicalPool.Length, actualDrawCount);
        var selectedCounts = new int[groups.Length];
        var outcomes = new List<Outcome>();
        Visit(0, actualDrawCount, BigInteger.One);

        outcomes.Sort(CompareOutcomes);
        var totalOutcomeCount = outcomes.Count;
        var retained = outcomes.Take(maximumBranches).ToImmutableArray();
        var mass = retained.Sum(static outcome => outcome.Probability);
        var exact = retained.Length == totalOutcomeCount;
        if (exact)
        {
            // Decimal division can leave a final representation-scale residue.
            // Assign it deterministically to the last outcome so exact results
            // preserve the probability-mass invariant exactly.
            var residue = 1m - mass;
            if (residue != 0m && retained.Length > 0)
            {
                retained = retained.SetItem(retained.Length - 1,
                    retained[^1] with { Probability = retained[^1].Probability + residue });
                mass = 1m;
            }
        }

        Debug.Assert(!exact || mass == 1m);
        return new Result(retained, exact, mass, totalOutcomeCount, totalOutcomeCount - retained.Length);

        void Visit(int groupIndex, int remainingToDraw, BigInteger numerator)
        {
            if (groupIndex == groups.Length)
            {
                if (remainingToDraw != 0) return;
                var drawn = ImmutableArray.CreateBuilder<CardState>(actualDrawCount);
                var remaining = ImmutableArray.CreateBuilder<CardState>(canonicalPool.Length - actualDrawCount);
                for (var index = 0; index < groups.Length; index++)
                {
                    var instances = groups[index].Instances;
                    var selected = selectedCounts[index];
                    drawn.AddRange(instances.Take(selected));
                    remaining.AddRange(instances.Skip(selected));
                }
                outcomes.Add(new Outcome(
                    drawn.MoveToImmutable(),
                    remaining.MoveToImmutable(),
                    Divide(numerator, denominator)));
                return;
            }

            var group = groups[groupIndex];
            var remainingCapacity = 0;
            for (var index = groupIndex + 1; index < groups.Length; index++)
                remainingCapacity += groups[index].Instances.Length;
            var minimum = Math.Max(0, remainingToDraw - remainingCapacity);
            var maximum = Math.Min(group.Instances.Length, remainingToDraw);
            for (var selected = minimum; selected <= maximum; selected++)
            {
                selectedCounts[groupIndex] = selected;
                Visit(
                    groupIndex + 1,
                    remainingToDraw - selected,
                    numerator * Combination(group.Instances.Length, selected));
            }
            selectedCounts[groupIndex] = 0;
        }
    }

    private static Result Single(ImmutableArray<CardState> drawn, ImmutableArray<CardState> remaining)
    {
        var outcome = new Outcome(drawn, remaining, 1m);
        return new Result([outcome], true, 1m, 1, 0);
    }

    private static int CompareOutcomes(Outcome left, Outcome right)
    {
        var probability = right.Probability.CompareTo(left.Probability);
        if (probability != 0) return probability;
        return StringComparer.Ordinal.Compare(OutcomeKey(left), OutcomeKey(right));
    }

    private static string OutcomeKey(Outcome outcome) => string.Join('\u001f',
        outcome.Drawn.Select(DeterministicSimulator.CardSemanticKey));

    private static BigInteger Combination(int n, int k)
    {
        if (k < 0 || k > n) return BigInteger.Zero;
        k = Math.Min(k, n - k);
        var result = BigInteger.One;
        for (var index = 1; index <= k; index++)
            result = result * (n - k + index) / index;
        return result;
    }

    private static decimal Divide(BigInteger numerator, BigInteger denominator)
    {
        if (denominator.IsZero) throw new DivideByZeroException();
        // Pool sizes are bounded to 120. Converting through decimal preserves
        // substantially more precision than the 1e-9 contract requires.
        return (decimal)numerator / (decimal)denominator;
    }

    private readonly record struct CardGroup(string Key, ImmutableArray<CardState> Instances);
}
