using System.Collections.Immutable;
using System.Globalization;
using STS2BestChoice.Core.Model;

namespace STS2BestChoice.Core.Simulation;

internal sealed partial class DeterministicSimulator
{
    public ImmutableArray<ChanceBranch<MutableCombatState>> ProjectToNextPlayerTurnOutcomes(
        MutableCombatState original,
        int maximumExactBranches = 32,
        int sampleCount = 32)
    {
        var parryingTargets = original.Enemies.Where(static enemy => enemy.IsAlive).ToArray();
        var parryingShieldActive = original.Player.Block >= 10m &&
            original.Relics.Any(static relic => relic.Id.Equals("PARRYING_SHIELD", StringComparison.OrdinalIgnoreCase) && relic.IsEnabled && !relic.IsUsedUp);
        if (parryingShieldActive && parryingTargets.Length > 0 &&
            original.RngStreams.Get(RngSnapshotSet.CombatTargets) is not { IsKnown: true })
        {
            var branches = parryingTargets.SelectMany(target =>
                ProjectToNextPlayerTurnOutcomes(original, maximumExactBranches, sampleCount, target.Id)
                    .Select(outcome => outcome with
                    {
                        Probability = outcome.Probability / parryingTargets.Length,
                        Kind = OutcomeKind.Stochastic,
                        ProbabilityKnown = outcome.ProbabilityKnown,
                        RngSource = RngSnapshotSet.CombatTargets
                    })).ToImmutableArray();
            return branches;
        }

        return ProjectToNextPlayerTurnOutcomes(original, maximumExactBranches, sampleCount, null);
    }

    private ImmutableArray<ChanceBranch<MutableCombatState>> ProjectToNextPlayerTurnOutcomes(
        MutableCombatState original,
        int maximumExactBranches,
        int sampleCount,
        string? forcedParryingShieldTargetId)
    {
        // Public snapshots may have no discard pile while the current hand is
        // the only pool that will be discarded at the side-turn boundary.
        // Expand this hand-only shuffle as an explicit NOSL chance node so
        // ordinary turns receive Estimated labels instead of an unhelpful
        // `uncalculable_shuffle_order`.  States that already consumed an
        // exhaust choice stay on the existing path to avoid duplicating a
        // prior random-card-selection branch.
        var drawDemand = original.Player.CardsPerTurn +
                         GetStatusAmount(original.Player.Statuses, "HAND_DRAW_DELTA") +
                         GetStatusAmount(original.Player.Statuses, "SCHEDULED_DRAW") +
                         GetStatusAmount(original.Player.Statuses, "TURN_START_DRAW");
        var handShufflePool = original.Hand
            .Where(static card => !card.RetainAtTurnEnd && !card.ExhaustAtTurnEnd)
            .ToArray();
        if (original.DiscardPile.Count == 0 && original.UnorderedDrawPool.Count == 0 &&
            original.DrawPile.Count < Math.Max(0, drawDemand) &&
            handShufflePool.Length > 0 &&
            original.CardsExhaustedSinceSnapshot == 0 &&
            original.RngStreams.Get(RngSnapshotSet.Shuffle) is not { IsKnown: true })
        {
            if (RequiresOrderedTurnProjection(original))
                return ProjectOrderedTurnOutcomes(
                    original,
                    handShufflePool,
                    unorderedPool: false,
                    poolFromHand: true,
                    maximumExactBranches,
                    sampleCount,
                    forcedParryingShieldTargetId);
            var drawsNeededFromHandShuffle = Math.Max(0, drawDemand - original.DrawPile.Count);
            var handDraws = EnumerateDrawsOrMarkUncalculable(
                original, handShufflePool, drawsNeededFromHandShuffle, maximumExactBranches, RngSnapshotSet.Shuffle);
            if (handDraws is null)
                return [new ChanceBranch<MutableCombatState>(
                    "无序抽牌池超出精确计算范围", 1m, original.Clone(),
                    OutcomeKind.Stochastic, ProbabilityKnown: false, RngSource: RngSnapshotSet.Shuffle,
                    OutcomeQuality: "Uncalculable")];
            return handDraws.Value.Outcomes
                .Select(outcome =>
                {
                    var prepared = original.Clone();
                    var discardedIds = handShufflePool.Select(static card => card.InstanceId)
                        .ToHashSet(StringComparer.Ordinal);
                    prepared.Hand.RemoveAll(card => discardedIds.Contains(card.InstanceId));
                    LoadDrawOutcome(prepared, outcome);
                    var state = ProjectToNextPlayerTurn(prepared, forcedParryingShieldTargetId);
                    RestoreUndrawnOutcomeCards(state, outcome);
                    if (!handDraws.Value.Exact)
                    {
                        var sampleMessage = $"回合结束手牌抽取共有 {handDraws.Value.TotalOutcomeCount} 个语义结果；保留概率最高的 {handDraws.Value.Outcomes.Length} 个，覆盖质量 {handDraws.Value.ProbabilityMassCovered:P6}。";
                        state.Risks.Add(new RiskEvent(
                            PredictionRiskReason.ProbabilityMassIncomplete,
                            PredictionRiskSeverity.Estimated,
                            sampleMessage,
                            RngSnapshotSet.Shuffle));
                        state.Restrictions.Add(new RestrictionReason(
                            "truncated_draw_distribution",
                            sampleMessage,
                            RngSnapshotSet.Shuffle));
                    }
                    return new ChanceBranch<MutableCombatState>(
                        DrawLabel(outcome.Drawn),
                        outcome.Probability,
                        state,
                        OutcomeKind.Stochastic,
                        ProbabilityKnown: true,
                        RngSource: RngSnapshotSet.Shuffle,
                        OutcomeQuality: handDraws.Value.Exact ? "Exact" : "Estimated",
                        ProbabilityMassCovered: handDraws.Value.ProbabilityMassCovered,
                        EffectiveSampleSize: null,
                        RngConsumptionVector: ImmutableDictionary<string, long>.Empty
                            .Add(RngSnapshotSet.Shuffle, Math.Max(0, handShufflePool.Length - 1)));
                })
                .ToImmutableArray();
        }
        var unorderedPool = original.UnorderedDrawPool.Count > 0;
        if (!unorderedPool && !NeedsUnknownTurnStartShuffle(original))
            return [new ChanceBranch<MutableCombatState>(
                "确定结果",
                1m,
                ProjectToNextPlayerTurn(original, forcedParryingShieldTargetId),
                OutcomeKind.Deterministic)];

        var canFoldTurnEndHand = handShufflePool.All(static card =>
            card.SafeTurnEndInHandEffects.IsDefaultOrEmpty && card.HpLossAtTurnEnd == 0m);
        var foldHandIntoShuffle = !unorderedPool && canFoldTurnEndHand && handShufflePool.Length > 0;
        var pool = unorderedPool
            ? original.UnorderedDrawPool.ToArray()
            : (foldHandIntoShuffle
                ? original.DiscardPile.Concat(handShufflePool).ToArray()
                : original.DiscardPile.ToArray());
        if (RequiresOrderedTurnProjection(original))
            return ProjectOrderedTurnOutcomes(
                original,
                pool,
                unorderedPool,
                poolFromHand: foldHandIntoShuffle,
                maximumExactBranches,
                sampleCount,
                forcedParryingShieldTargetId);
        var unresolvedTurnDraws = Math.Max(0, drawDemand - original.DrawPile.Count);
        if (unorderedPool && unresolvedTurnDraws > pool.Length && canFoldTurnEndHand &&
            !original.Relics.Any(static relic =>
                relic.Id.Equals("SUNDIAL", StringComparison.OrdinalIgnoreCase) &&
                relic.IsEnabled && !relic.IsUsedUp))
        {
            return ProjectCrossShuffleBoundaryOutcomes(
                original,
                pool,
                original.DiscardPile.Concat(handShufflePool).ToArray(),
                unresolvedTurnDraws,
                maximumExactBranches,
                forcedParryingShieldTargetId);
        }
        var draws = EnumerateDrawsOrMarkUncalculable(
            original, pool, unresolvedTurnDraws, maximumExactBranches, RngSnapshotSet.Shuffle);
        if (draws is null)
            return [new ChanceBranch<MutableCombatState>(
                "无序抽牌池超出精确计算范围", 1m, original.Clone(),
                OutcomeKind.Stochastic, ProbabilityKnown: false, RngSource: RngSnapshotSet.Shuffle,
                OutcomeQuality: "Uncalculable")];

        return draws.Value.Outcomes.Select(outcome =>
        {
            var prepared = original.Clone();
            if (unorderedPool)
                prepared.UnorderedDrawPool.Clear();
            else
                prepared.DiscardPile.Clear();
            if (foldHandIntoShuffle)
            {
                var foldedIds = handShufflePool.Select(static card => card.InstanceId)
                    .ToHashSet(StringComparer.Ordinal);
                prepared.Hand.RemoveAll(card => foldedIds.Contains(card.InstanceId));
            }
            LoadDrawOutcome(prepared, outcome);
            var state = ProjectToNextPlayerTurn(prepared, forcedParryingShieldTargetId);
            RestoreUndrawnOutcomeCards(state, outcome);
            if (!draws.Value.Exact)
            {
                var sampleMessage = unorderedPool
                    ? $"无序抽牌池共有 {draws.Value.TotalOutcomeCount} 个语义结果；保留概率最高的 {draws.Value.Outcomes.Length} 个，覆盖质量 {draws.Value.ProbabilityMassCovered:P6}。"
                    : $"回合结束洗牌抽取共有 {draws.Value.TotalOutcomeCount} 个语义结果；保留概率最高的 {draws.Value.Outcomes.Length} 个，覆盖质量 {draws.Value.ProbabilityMassCovered:P6}。";
                state.Risks.Add(new RiskEvent(
                    PredictionRiskReason.ProbabilityMassIncomplete,
                    PredictionRiskSeverity.Estimated,
                    sampleMessage,
                    RngSnapshotSet.Shuffle));
                state.Restrictions.Add(new RestrictionReason(
                    "truncated_draw_distribution",
                    sampleMessage,
                    RngSnapshotSet.Shuffle));
            }

            return new ChanceBranch<MutableCombatState>(
                DrawLabel(outcome.Drawn),
                outcome.Probability,
                state,
                OutcomeKind.Stochastic,
                ProbabilityKnown: true,
                RngSource: RngSnapshotSet.Shuffle,
                OutcomeQuality: draws.Value.Exact ? "Exact" : "Estimated",
                ProbabilityMassCovered: draws.Value.ProbabilityMassCovered,
                EffectiveSampleSize: null,
                RngConsumptionVector: unorderedPool
                    ? ImmutableDictionary<string, long>.Empty
                    : ImmutableDictionary<string, long>.Empty
                        .Add(RngSnapshotSet.Shuffle, Math.Max(0, pool.Length - 1)));
        }).ToImmutableArray();
    }

    private static bool RequiresOrderedTurnProjection(MutableCombatState state) =>
        GetStatusAmount(state.Player.Statuses, "TURN_START_AUTOPLAY_TOP") > 0 ||
        GetStatusAmount(state.Player.Statuses, "TURN_START_EXHAUST_DRAW_TOP") > 0 ||
        state.Relics.Any(static relic =>
            relic.Id.Equals("TOASTY_MITTENS", StringComparison.OrdinalIgnoreCase) &&
            relic.IsEnabled && !relic.IsUsedUp) ||
        state.DrawPile.Concat(state.UnorderedDrawPool).Concat(state.DiscardPile).Concat(state.Hand)
            .Any(static card => card.Effects.Any(static effect =>
                effect.Kind == EffectKind.AutoPlaySelfFromPile &&
                effect.StatusId == "TURN_END_SELF_DRAW_TOP"));

    private ImmutableArray<ChanceBranch<MutableCombatState>> ProjectOrderedTurnOutcomes(
        MutableCombatState original,
        CardState[] pool,
        bool unorderedPool,
        bool poolFromHand,
        int maximumExactBranches,
        int sampleCount,
        string? forcedParryingShieldTargetId)
    {
        var exact = OrderedPermutationCountAtMost(pool, maximumExactBranches) > 0;
        var permutations = exact
            ? EnumerateOrderedSemanticPermutations(pool).Take(maximumExactBranches).ToArray()
            : SampleOrderedSemanticPermutations(pool, Math.Max(1, sampleCount), original.SearchBehaviorKey()).ToArray();
        if (permutations.Length == 0)
            return [new ChanceBranch<MutableCombatState>(
                "无可排序抽牌", 1m, ProjectToNextPlayerTurn(original, forcedParryingShieldTargetId),
                OutcomeKind.Deterministic)];

        var probability = 1m / permutations.Length;
        return permutations.Select(permutation =>
        {
            var prepared = original.Clone();
            if (poolFromHand)
            {
                var ids = pool.Select(static card => card.InstanceId).ToHashSet(StringComparer.Ordinal);
                prepared.Hand.RemoveAll(card => ids.Contains(card.InstanceId));
                prepared.DiscardPile.Clear();
            }
            else if (unorderedPool)
            {
                prepared.UnorderedDrawPool.Clear();
            }
            else
            {
                prepared.DiscardPile.Clear();
            }
            prepared.DrawPile.AddRange(permutation);
            var state = ProjectToNextPlayerTurn(prepared, forcedParryingShieldTargetId);
            if (!exact)
            {
                var message = $"回合投影包含抽牌堆顺序敏感效果；超过 {maximumExactBranches} 个语义排列后使用 {permutations.Length} 个确定性样本。";
                state.Risks.Add(new RiskEvent(
                    PredictionRiskReason.ChanceBranchSampled,
                    PredictionRiskSeverity.Estimated,
                    message,
                    RngSnapshotSet.Shuffle));
                state.Restrictions.Add(new RestrictionReason(
                    "sampled_ordered_turn_projection",
                    message,
                    RngSnapshotSet.Shuffle));
            }
            return new ChanceBranch<MutableCombatState>(
                ShuffleLabel(permutation, permutation.Length),
                probability,
                state,
                OutcomeKind.Stochastic,
                ProbabilityKnown: true,
                RngSource: RngSnapshotSet.Shuffle,
                OutcomeQuality: exact ? "Exact" : "Sampled",
                ProbabilityMassCovered: exact ? 1m : null,
                EffectiveSampleSize: exact ? null : permutations.Length,
                RngConsumptionVector: unorderedPool
                    ? ImmutableDictionary<string, long>.Empty
                    : ImmutableDictionary<string, long>.Empty
                        .Add(RngSnapshotSet.Shuffle, Math.Max(0, pool.Length - 1)));
        }).ToImmutableArray();
    }

    private ImmutableArray<ChanceBranch<MutableCombatState>> ProjectCrossShuffleBoundaryOutcomes(
        MutableCombatState original,
        CardState[] currentUnorderedDraw,
        CardState[] nextShufflePool,
        int unresolvedTurnDraws,
        int maximumExactBranches,
        string? forcedParryingShieldTargetId)
    {
        var secondDrawCount = Math.Max(0, unresolvedTurnDraws - currentUnorderedDraw.Length);
        var distributionState = original.Clone();
        var draws = EnumerateDrawsOrMarkUncalculable(
            distributionState,
            nextShufflePool,
            secondDrawCount,
            maximumExactBranches,
            RngSnapshotSet.Shuffle);
        if (draws is null)
            return [new ChanceBranch<MutableCombatState>(
                "跨洗牌抽牌池超出精确计算范围", 1m, distributionState,
                OutcomeKind.Stochastic, ProbabilityKnown: false, RngSource: RngSnapshotSet.Shuffle,
                OutcomeQuality: "Uncalculable")];

        var firstDraw = currentUnorderedDraw
            .OrderBy(CardSemanticKey, StringComparer.Ordinal)
            .ThenBy(static card => card.InstanceId, StringComparer.Ordinal)
            .ToImmutableArray();
        var foldedHandIds = nextShufflePool.Select(static card => card.InstanceId)
            .ToHashSet(StringComparer.Ordinal);
        return draws.Value.Outcomes.Select(outcome =>
        {
            var prepared = original.Clone();
            prepared.UnorderedDrawPool.Clear();
            prepared.DiscardPile.Clear();
            prepared.Hand.RemoveAll(card => foldedHandIds.Contains(card.InstanceId));
            var combined = outcome with { Drawn = firstDraw.AddRange(outcome.Drawn) };
            LoadDrawOutcome(prepared, combined);
            MirrorUnknownRngConsumption(prepared, RngSnapshotSet.Shuffle, Math.Max(0, nextShufflePool.Length - 1));
            var state = ProjectToNextPlayerTurn(prepared, forcedParryingShieldTargetId);
            RestoreUndrawnOutcomeCards(state, combined);
            if (!draws.Value.Exact)
            {
                var message = $"跨洗牌边界抽牌共有 {draws.Value.TotalOutcomeCount} 个语义结果；保留概率最高的 {draws.Value.Outcomes.Length} 个，覆盖质量 {draws.Value.ProbabilityMassCovered:P6}。";
                state.Risks.Add(new RiskEvent(
                    PredictionRiskReason.ProbabilityMassIncomplete,
                    PredictionRiskSeverity.Estimated,
                    message,
                    RngSnapshotSet.Shuffle));
                state.Restrictions.Add(new RestrictionReason(
                    "truncated_draw_distribution",
                    message,
                    RngSnapshotSet.Shuffle));
            }
            return new ChanceBranch<MutableCombatState>(
                DrawLabel(combined.Drawn),
                outcome.Probability,
                state,
                OutcomeKind.Stochastic,
                ProbabilityKnown: true,
                RngSource: RngSnapshotSet.Shuffle,
                OutcomeQuality: draws.Value.Exact ? "Exact" : "Estimated",
                ProbabilityMassCovered: draws.Value.ProbabilityMassCovered,
                EffectiveSampleSize: null,
                RngConsumptionVector: ImmutableDictionary<string, long>.Empty
                    .Add(RngSnapshotSet.Shuffle, Math.Max(0, nextShufflePool.Length - 1)));
        }).ToImmutableArray();
    }

    public ImmutableArray<ChanceBranch<MutableCombatState>> UsePotionOutcomes(
        MutableCombatState original,
        PotionState potion,
        string? targetId,
        int maximumExactBranches = 32,
        int sampleCount = 32)
    {
        var drawCount = DrawCount(potion.Effects);
        if (!NeedsUnknownShuffle(original, drawCount))
            return [new ChanceBranch<MutableCombatState>("确定结果", 1m, UsePotion(original, potion, targetId), OutcomeKind.Deterministic)];

        var baseState = UsePotion(original, potion with { Effects = WithoutDraw(potion.Effects) }, targetId);
        var knownDraws = Math.Min(drawCount, baseState.DrawPile.Count);
        Draw(baseState, knownDraws);
        var unresolvedDraws = drawCount - knownDraws;
        var unorderedPool = baseState.UnorderedDrawPool.Count > 0;
        var pool = unorderedPool ? baseState.UnorderedDrawPool.ToArray() : baseState.DiscardPile.ToArray();
        if (unorderedPool) baseState.UnorderedDrawPool.Clear();
        else baseState.DiscardPile.Clear();
        var draws = EnumerateDrawsOrMarkUncalculable(
            baseState, pool, unresolvedDraws, maximumExactBranches, potion.ModelId);
        if (draws is null)
            return [new ChanceBranch<MutableCombatState>(
                "无序抽牌池超出精确计算范围", 1m, baseState,
                OutcomeKind.Stochastic, ProbabilityKnown: false, RngSource: RngSnapshotSet.Shuffle,
                OutcomeQuality: "Uncalculable")];

        return draws.Value.Outcomes.Select(outcome =>
        {
            var state = baseState.Clone();
            LoadDrawOutcome(state, outcome);
            Draw(state, unresolvedDraws);
            RestoreUndrawnOutcomeCards(state, outcome);
            if (!draws.Value.Exact)
            {
                var message = $"药水抽牌共有 {draws.Value.TotalOutcomeCount} 个语义结果；保留概率最高的 {draws.Value.Outcomes.Length} 个，覆盖质量 {draws.Value.ProbabilityMassCovered:P6}。";
                state.Risks.Add(new RiskEvent(PredictionRiskReason.ProbabilityMassIncomplete, PredictionRiskSeverity.Estimated, message, potion.ModelId));
                state.Restrictions.Add(new RestrictionReason("truncated_draw_distribution", message, potion.ModelId));
            }
            return new ChanceBranch<MutableCombatState>(
                DrawLabel(outcome.Drawn),
                outcome.Probability,
                state,
                OutcomeKind.Stochastic,
                ProbabilityKnown: true,
                RngSource: RngSnapshotSet.Shuffle,
                OutcomeQuality: draws.Value.Exact ? "Exact" : "Estimated",
                ProbabilityMassCovered: draws.Value.ProbabilityMassCovered,
                EffectiveSampleSize: null,
                RngConsumptionVector: unorderedPool
                    ? ImmutableDictionary<string, long>.Empty
                    : ImmutableDictionary<string, long>.Empty
                        .Add(RngSnapshotSet.Shuffle, Math.Max(0, pool.Length - 1)));
        }).ToImmutableArray();
    }

    public ImmutableArray<ChanceBranch<MutableCombatState>> PlayCardOutcomes(
        MutableCombatState original,
        CardState card,
        string? targetId,
        ChoiceSpec? choice,
        int maximumExactBranches = 32,
        int sampleCount = 32)
    {
        var previewPlayCount = EffectivePlayCount(original, card, consumeModifiers: false);
        var hasReboot = card.Effects.Any(static effect => effect.Kind == EffectKind.Reboot) ||
                        choice is not null && choice.Effects.Any(static effect => effect.Kind == EffectKind.Reboot);
        if (hasReboot &&
            original.RngStreams.Get(RngSnapshotSet.Shuffle) is not { IsKnown: true } &&
            original.RngState == 0)
            return RebootOutcomes(
                original,
                card,
                targetId,
                choice,
                previewPlayCount,
                maximumExactBranches,
                sampleCount);
        var randomOrbEffects = card.Effects
            .Concat(choice?.Effects ?? [])
            .Where(static effect => effect.Kind == EffectKind.ChannelOrbs && effect.StatusId == "RANDOM")
            .ToImmutableArray();
        if (randomOrbEffects.Length > 0)
        {
            var randomOrbStrippedCard = card with
            {
                Effects = card.Effects.Where(static effect => !(effect.Kind == EffectKind.ChannelOrbs && effect.StatusId == "RANDOM")).ToImmutableArray()
            };
            var randomOrbStrippedChoice = choice is null ? null : choice with
            {
                Effects = choice.Effects.Where(static effect => !(effect.Kind == EffectKind.ChannelOrbs && effect.StatusId == "RANDOM")).ToImmutableArray()
            };
            var baseOutcomes = PlayCardOutcomes(original, randomOrbStrippedCard, targetId, randomOrbStrippedChoice, maximumExactBranches, sampleCount);
            var repeatedRandomOrbEffects = RepeatEffects(randomOrbEffects, previewPlayCount);
            return baseOutcomes.SelectMany(baseOutcome =>
                RandomOrbOutcomes(baseOutcome.State, repeatedRandomOrbEffects, card.ModelId, maximumExactBranches)
                    .Select(orbOutcome => CombineChance(baseOutcome, orbOutcome)))
                .ToImmutableArray();
        }

        var randomGeneratedEffects = card.Effects
            .Concat(choice?.Effects ?? [])
            .Where(static effect => effect.Kind == EffectKind.GenerateRandomCards)
            .ToImmutableArray();
        if (randomGeneratedEffects.Length > 0)
        {
            var generatedStrippedCard = card with
            {
                Effects = card.Effects.Where(static effect => effect.Kind != EffectKind.GenerateRandomCards).ToImmutableArray(),
                Choices = card.SafeChoices.Select(item => item with
                {
                    Effects = item.Effects.Where(static effect => effect.Kind != EffectKind.GenerateRandomCards).ToImmutableArray()
                }).ToImmutableArray()
            };
            var generatedStrippedChoice = choice is null
                ? null
                : generatedStrippedCard.SafeChoices.FirstOrDefault(item => item.Id == choice.Id);
            var baseOutcomes = PlayCardOutcomes(
                original,
                generatedStrippedCard,
                targetId,
                generatedStrippedChoice,
                maximumExactBranches,
                sampleCount);
            return baseOutcomes.SelectMany(baseOutcome =>
                    RandomGeneratedCardOutcomes(
                        baseOutcome.State,
                        randomGeneratedEffects,
                        card.ModelId,
                        maximumExactBranches,
                        sampleCount)
                    .Select(randomOutcome => CombineChance(baseOutcome, randomOutcome)))
                .ToImmutableArray();
        }
        var randomEffects = card.Effects
            .Concat(choice?.Effects ?? [])
            .Where(static effect => effect.Kind == EffectKind.RandomEnemyDamage && effect.UnsupportedReason is null)
            .ToImmutableArray();
        if (randomEffects.Length > 0)
        {
            var randomStrippedCard = card with
            {
                Effects = WithoutRandomTargetDamage(card.Effects),
                Choices = card.SafeChoices.Select(item => item with
                {
                    Effects = WithoutRandomTargetDamage(item.Effects)
                }).ToImmutableArray()
            };
            var randomStrippedChoice = choice is null
                ? null
                : randomStrippedCard.SafeChoices.FirstOrDefault(item => item.Id == choice.Id);
            var baseOutcomes = PlayCardOutcomes(
                original,
                randomStrippedCard,
                targetId,
                randomStrippedChoice,
                maximumExactBranches,
                sampleCount);
            var randomEnergySpent = card.CostsX
                ? original.Player.Energy
                : EnergyCostToPlay(original, card);
            var repeatedRandomEffects = ExpandRandomEffects(randomEffects, previewPlayCount, randomEnergySpent);
            return baseOutcomes.SelectMany(baseOutcome =>
                    RandomEnemyDamageOutcomes(
                        baseOutcome.State,
                        repeatedRandomEffects,
                        card.ModelId,
                        maximumExactBranches,
                        sampleCount)
                    .Select(randomOutcome => CombineChance(baseOutcome, randomOutcome)))
                .ToImmutableArray();
        }

        var randomExhaustEffects = card.Effects
            .Concat(choice?.Effects ?? [])
            .Where(static effect => effect.Kind == EffectKind.RandomExhaustCards && effect.UnsupportedReason is null)
            .ToImmutableArray();
        if (randomExhaustEffects.Length > 0)
        {
            var movementStrippedCard = card with
            {
                Effects = WithoutRandomExhaust(card.Effects),
                Choices = card.SafeChoices.Select(item => item with
                {
                    Effects = WithoutRandomExhaust(item.Effects)
                }).ToImmutableArray()
            };
            var movementStrippedChoice = choice is null
                ? null
                : movementStrippedCard.SafeChoices.FirstOrDefault(item => item.Id == choice.Id);
            var baseOutcomes = PlayCardOutcomes(
                original,
                movementStrippedCard,
                targetId,
                movementStrippedChoice,
                maximumExactBranches,
                sampleCount);
            return baseOutcomes.SelectMany(baseOutcome =>
                    RandomExhaustOutcomes(
                        baseOutcome.State,
                        randomExhaustEffects.Sum(static effect => Math.Max(0, (int)effect.Amount)) * previewPlayCount,
                        card.ModelId,
                        maximumExactBranches,
                        sampleCount)
                    .Select(randomOutcome => CombineChance(baseOutcome, randomOutcome)))
                .ToImmutableArray();
        }

        var orderedDraw = HasOrderedDrawEffects(card.Effects) ||
                          choice is not null && HasOrderedDrawEffects(choice.Effects);
        var drawCount = orderedDraw
            ? DrawCount(original, card.Effects.AddRange(choice?.Effects ?? []), cardLeavesHand: true, previewPlayCount)
            : (DrawCount(card.Effects) + (choice is null ? 0 : DrawCount(choice.Effects))) * previewPlayCount;
        if (original.Hand.Count == 1 &&
            original.Relics.Any(static relic => relic.Id.Equals("UNCEASING_TOP", StringComparison.OrdinalIgnoreCase) && relic.IsEnabled && !relic.IsUsedUp) &&
            card.Destination != CardDestination.Hand &&
            DrawCount(card.Effects) == 0 && (choice is null || DrawCount(choice.Effects) == 0))
            drawCount += 1;
        if (!NeedsUnknownShuffle(original, drawCount))
            return [new ChanceBranch<MutableCombatState>("确定结果", 1m, PlayCard(original, card, targetId, choice), OutcomeKind.Deterministic)];
        if (orderedDraw)
            return OrderedDrawShuffleOutcomes(
                original, card, targetId, choice, drawCount, maximumExactBranches, sampleCount);

        // Resolve non-draw effects first, then reproduce the unknown shuffle as a
        // chance node. Cards whose draw is interleaved with other effects are kept
        // calculable but explicitly estimated rather than silently treated as exact.
        var energySpent = card.CostsX ? original.Player.Energy : EnergyCostToPlay(original, card);
        var destinationState = original.Clone();
        var finalDestination = EffectiveCardDestination(destinationState, card, energySpent, consumeModifiers: true);
        var playCount = EffectivePlayCount(destinationState, card, consumeModifiers: true);
        static bool IsPostDrawLock(EffectSpec effect) =>
            effect.Kind == EffectKind.ApplyStatus && effect.StatusId == "CANNOT_DRAW";
        var deferredPostDrawEffects = card.Effects
            .Concat(choice?.Effects ?? [])
            .Where(IsPostDrawLock)
            .ToImmutableArray();
        var strippedCard = card with
        {
            Effects = WithoutDraw(card.Effects).Where(effect => !IsPostDrawLock(effect)).ToImmutableArray(),
            Destination = CardDestination.Remove,
            Choices = card.SafeChoices.Select(item => item with
            {
                Effects = WithoutDraw(item.Effects).Where(effect => !IsPostDrawLock(effect)).ToImmutableArray()
            }).ToImmutableArray()
        };
        var strippedChoice = choice is null
            ? null
            : strippedCard.SafeChoices.FirstOrDefault(item => item.Id == choice.Id);
        var baseState = PlayCard(destinationState, strippedCard, targetId, strippedChoice,
            finalizeDestination: false, forcedPlayCount: playCount);
        var knownDraws = Math.Min(drawCount, baseState.DrawPile.Count);
        Draw(baseState, knownDraws);
        var unresolvedDraws = drawCount - knownDraws;
        var unorderedPool = baseState.UnorderedDrawPool.Count > 0;
        var pool = unorderedPool ? baseState.UnorderedDrawPool.ToArray() : baseState.DiscardPile.ToArray();
        if (unorderedPool) baseState.UnorderedDrawPool.Clear();
        else baseState.DiscardPile.Clear();

        var draws = EnumerateDrawsOrMarkUncalculable(
            baseState, pool, unresolvedDraws, maximumExactBranches, card.ModelId);
        if (draws is null)
            return [new ChanceBranch<MutableCombatState>(
                "无序抽牌池超出精确计算范围", 1m, FinishCard(baseState, card, finalDestination),
                OutcomeKind.Stochastic, ProbabilityKnown: false, RngSource: RngSnapshotSet.Shuffle,
                OutcomeQuality: "Uncalculable")];

        var branches = ImmutableArray.CreateBuilder<ChanceBranch<MutableCombatState>>(draws.Value.Outcomes.Length);
        foreach (var outcome in draws.Value.Outcomes)
        {
            var state = baseState.Clone();
            LoadDrawOutcome(state, outcome);
            Draw(state, unresolvedDraws);
            if (!deferredPostDrawEffects.IsDefaultOrEmpty)
                ApplyEffects(
                    state,
                    deferredPostDrawEffects,
                    TargetKind.Self,
                    null,
                    card.ModelId,
                    enemyActs: false,
                    cardSource: true);
            FinishCard(state, card, finalDestination);
            RestoreUndrawnOutcomeCards(state, outcome);
            if (!draws.Value.Exact)
            {
                var message = $"无序抽牌共有 {draws.Value.TotalOutcomeCount} 个语义结果；保留概率最高的 {draws.Value.Outcomes.Length} 个，覆盖质量 {draws.Value.ProbabilityMassCovered:P6}。";
                state.Risks.Add(new RiskEvent(
                    PredictionRiskReason.ProbabilityMassIncomplete,
                    PredictionRiskSeverity.Estimated,
                    message,
                    card.ModelId));
                state.Restrictions.Add(new RestrictionReason("truncated_draw_distribution", message, card.ModelId));
            }
            else if ((HasInterleavedDraw(card.Effects) || choice is not null && HasInterleavedDraw(choice.Effects)) &&
                     card.Effects.Concat(choice?.Effects ?? [])
                         .Any(effect => effect.Kind != EffectKind.Draw && !IsPostDrawLock(effect)))
            {
                var message = "抽牌效果与其他效果交错；当前镜像按效果总量结算抽牌。";
                state.Risks.Add(new RiskEvent(
                    PredictionRiskReason.MethodMirrorIncomplete,
                    PredictionRiskSeverity.Estimated,
                    message,
                    card.ModelId));
                state.Restrictions.Add(new RestrictionReason("interleaved_draw_order", message, card.ModelId));
            }
            var label = unresolvedDraws <= 0
                ? "确定结果"
                : DrawLabel(outcome.Drawn);
            branches.Add(new ChanceBranch<MutableCombatState>(
                label,
                outcome.Probability,
                state,
                OutcomeKind.Stochastic,
                ProbabilityKnown: true,
                RngSource: RngSnapshotSet.Shuffle,
                OutcomeQuality: draws.Value.Exact ? "Exact" : "Estimated",
                ProbabilityMassCovered: draws.Value.ProbabilityMassCovered,
                EffectiveSampleSize: null,
                RngConsumptionVector: unorderedPool
                    ? ImmutableDictionary<string, long>.Empty
                    : ImmutableDictionary<string, long>.Empty
                        .Add(RngSnapshotSet.Shuffle, Math.Max(0, pool.Length - 1))));
        }
        return branches.MoveToImmutable();
    }

    private static ImmutableArray<EffectSpec> RepeatEffects(ImmutableArray<EffectSpec> effects, int count)
    {
        if (count <= 1) return effects;
        var result = ImmutableArray.CreateBuilder<EffectSpec>(effects.Length * count);
        for (var index = 0; index < count; index++)
            result.AddRange(effects);
        return result.ToImmutable();
    }

    private ImmutableArray<ChanceBranch<MutableCombatState>> RebootOutcomes(
        MutableCombatState original,
        CardState card,
        string? targetId,
        ChoiceSpec? choice,
        int playCount,
        int maximumExactBranches,
        int sampleCount)
    {
        if (playCount != 1)
        {
            var state = PlayCard(original, card, targetId, choice);
            var message = "重放重启会产生连续洗牌；当前未知 Shuffle 状态无法可靠展开多次洗牌。";
            state.Risks.Add(new RiskEvent(
                PredictionRiskReason.UnsupportedRandomSource,
                PredictionRiskSeverity.Uncalculable,
                message,
                card.ModelId));
            state.Restrictions.Add(new RestrictionReason("uncalculable_replayed_reboot", message, card.ModelId));
            return [new ChanceBranch<MutableCombatState>(
                "连续洗牌不可计算",
                1m,
                state,
                OutcomeKind.Stochastic,
                ProbabilityKnown: false,
                RngSource: RngSnapshotSet.Shuffle,
                OutcomeQuality: "Uncalculable",
                RngConsumptionVector: ImmutableDictionary<string, long>.Empty)];
        }

        var pool = original.DiscardPile
            .Concat(original.DrawPile)
            .Concat(original.UnorderedDrawPool)
            .Concat(original.Hand.Where(item => item.InstanceId != card.InstanceId))
            .ToArray();

        var strippedCard = card with
        {
            Effects = card.Effects.Where(static effect => effect.Kind != EffectKind.Reboot).ToImmutableArray(),
            Choices = card.SafeChoices.Select(item => item with
            {
                Effects = item.Effects.Where(static effect => effect.Kind != EffectKind.Reboot).ToImmutableArray()
            }).ToImmutableArray()
        };
        var strippedChoice = choice is null
            ? null
            : strippedCard.SafeChoices.FirstOrDefault(item => item.Id == choice.Id);
        var drawCount = DrawCount(strippedCard.Effects) +
                        (strippedChoice is null ? 0 : DrawCount(strippedChoice.Effects));
        var distributionState = original.Clone();
        var draws = EnumerateDrawsOrMarkUncalculable(
            distributionState, pool, drawCount, maximumExactBranches, card.ModelId);
        if (draws is null)
            return [new ChanceBranch<MutableCombatState>(
                "无序抽牌池超出精确计算范围", 1m, distributionState,
                OutcomeKind.Stochastic, ProbabilityKnown: false, RngSource: RngSnapshotSet.Shuffle,
                OutcomeQuality: "Uncalculable")];
        return draws.Value.Outcomes.Select(outcome =>
        {
            var prepared = original.Clone();
            prepared.Hand.RemoveAll(item => item.InstanceId != card.InstanceId);
            prepared.DrawPile.Clear();
            prepared.DiscardPile.Clear();
            prepared.UnorderedDrawPool.Clear();
            LoadDrawOutcome(prepared, outcome);
            MirrorUnknownRngConsumption(prepared, RngSnapshotSet.Shuffle, Math.Max(0, pool.Length - 1));
            ApplyRelicShuffleTriggers(prepared);
            var state = PlayCard(prepared, strippedCard, targetId, strippedChoice);
            RestoreUndrawnOutcomeCards(state, outcome);
            if (!draws.Value.Exact)
            {
                var message = $"重启抽牌共有 {draws.Value.TotalOutcomeCount} 个语义结果；保留概率最高的 {draws.Value.Outcomes.Length} 个，覆盖质量 {draws.Value.ProbabilityMassCovered:P6}。";
                state.Risks.Add(new RiskEvent(
                    PredictionRiskReason.ProbabilityMassIncomplete,
                    PredictionRiskSeverity.Estimated,
                    message,
                    card.ModelId));
                state.Restrictions.Add(new RestrictionReason("truncated_draw_distribution", message, card.ModelId));
            }
            return new ChanceBranch<MutableCombatState>(
                DrawLabel(outcome.Drawn),
                outcome.Probability,
                state,
                OutcomeKind.Stochastic,
                ProbabilityKnown: true,
                RngSource: RngSnapshotSet.Shuffle,
                OutcomeQuality: draws.Value.Exact ? "Exact" : "Estimated",
                ProbabilityMassCovered: draws.Value.ProbabilityMassCovered,
                EffectiveSampleSize: null,
                RngConsumptionVector: ImmutableDictionary<string, long>.Empty
                    .Add(RngSnapshotSet.Shuffle, Math.Max(0, pool.Length - 1)));
        }).ToImmutableArray();
    }

    private static ImmutableArray<EffectSpec> ExpandRandomEffects(
        ImmutableArray<EffectSpec> effects,
        int playCount,
        int energySpent)
    {
        var result = ImmutableArray.CreateBuilder<EffectSpec>();
        for (var play = 0; play < Math.Max(1, playCount); play++)
        {
            foreach (var effect in effects)
            {
                var count = effect.RepeatByEnergySpent
                    ? Math.Max(0, energySpent + effect.XBonus)
                    : Math.Max(1, effect.Repeat);
                for (var index = 0; index < count; index++)
                    result.Add(effect with { RepeatByEnergySpent = false, Repeat = 1 });
            }
        }
        return result.ToImmutable();
    }

    private static ImmutableArray<ChanceBranch<MutableCombatState>> RandomOrbOutcomes(
        MutableCombatState original,
        ImmutableArray<EffectSpec> effects,
        string sourceId,
        int maximumExactBranches)
    {
        var types = new[] { "LIGHTNING", "FROST", "DARK", "PLASMA" };
        var count = effects.Sum(static effect => Math.Max(0, (int)effect.Amount));
        if (count == 0)
            return [new ChanceBranch<MutableCombatState>("没有生成随机充能球", 1m, original.Clone(), OutcomeKind.Deterministic)];
        var stream = original.RngStreams.Get(RngSnapshotSet.CombatOrbGeneration);
        if (stream is { IsKnown: true })
        {
            var state = original.Clone();
            var labels = new List<string>(count);
            for (var index = 0; index < count; index++)
            {
                var selected = stream.NextInt(types.Length, out stream);
                labels.Add(types[selected]);
                ChannelOrbs(state, new EffectSpec(EffectKind.ChannelOrbs, 1, types[selected]), 0, sourceId);
            }
            state.RngStreams = state.RngStreams.With(stream);
            return [new ChanceBranch<MutableCombatState>(
                $"随机充能球：{string.Join("、", labels)}",
                1m,
                state,
                OutcomeKind.Deterministic,
                ProbabilityKnown: true,
                RngSource: RngSnapshotSet.CombatOrbGeneration,
                OutcomeQuality: "Exact",
                ProbabilityMassCovered: 1m,
                EffectiveSampleSize: 1m,
                RngConsumptionVector: ImmutableDictionary<string, long>.Empty
                    .Add(RngSnapshotSet.CombatOrbGeneration, count))];
        }

        var total = 1;
        for (var index = 0; index < count && total <= maximumExactBranches; index++) total *= types.Length;
        var exact = total <= maximumExactBranches;
        var sequences = exact
            ? EnumerateOrbSequences(types, count)
            : EnumerateOrbSequences(types, count).Take(maximumExactBranches);
        var sequenceArray = sequences.ToArray();
        var branches = new List<ChanceBranch<MutableCombatState>>(sequenceArray.Length);
        foreach (var sequence in sequenceArray)
        {
            var state = original.Clone();
            foreach (var type in sequence)
                ChannelOrbs(state, new EffectSpec(EffectKind.ChannelOrbs, 1, type), 0, sourceId);
            AdvanceUnknownRng(state, RngSnapshotSet.CombatOrbGeneration, count);
            if (!exact)
            {
                var message = $"随机充能球序列共有 {total} 种，保留前 {sequenceArray.Length} 个确定序列作为估计。";
                state.Risks.Add(new RiskEvent(PredictionRiskReason.ChanceBranchSampled, PredictionRiskSeverity.Estimated, message, sourceId));
                state.Restrictions.Add(new RestrictionReason("sampled_random_orbs", message, sourceId));
            }
            branches.Add(new ChanceBranch<MutableCombatState>(
                $"随机充能球：{string.Join("、", sequence)}",
                1m / sequenceArray.Length,
                state,
                OutcomeKind.Stochastic,
                ProbabilityKnown: true,
                RngSource: RngSnapshotSet.CombatOrbGeneration,
                OutcomeQuality: exact ? "Exact" : "Sampled",
                ProbabilityMassCovered: exact ? 1m : (decimal)sequenceArray.Length / total,
                EffectiveSampleSize: sequenceArray.Length,
                RngConsumptionVector: ImmutableDictionary<string, long>.Empty
                    .Add(RngSnapshotSet.CombatOrbGeneration, count)));
        }
        return branches.ToImmutableArray();
    }

    private static IEnumerable<ImmutableArray<string>> EnumerateOrbSequences(string[] types, int count)
    {
        if (count == 0)
        {
            yield return [];
            yield break;
        }
        foreach (var prefix in EnumerateOrbSequences(types, count - 1))
        foreach (var type in types)
            yield return prefix.Add(type);
    }

    private static bool NeedsUnknownShuffle(MutableCombatState state, int drawCount) =>
        drawCount > state.DrawPile.Count &&
        (state.DiscardPile.Count > 0 || state.UnorderedDrawPool.Count > 0) &&
        state.RngStreams.Get(RngSnapshotSet.Shuffle) is not { IsKnown: true } &&
        state.RngState == 0;

    private static bool NeedsUnknownTurnStartShuffle(MutableCombatState state)
    {
        if (state.DiscardPile.Count == 0 && state.UnorderedDrawPool.Count == 0 ||
            state.RngStreams.Get(RngSnapshotSet.Shuffle) is { IsKnown: true } ||
            state.RngState != 0)
            return false;

        var drawDemand = state.Player.CardsPerTurn +
                         GetStatusAmount(state.Player.Statuses, "HAND_DRAW_DELTA") +
                         GetStatusAmount(state.Player.Statuses, "SCHEDULED_DRAW") +
                         GetStatusAmount(state.Player.Statuses, "TURN_START_DRAW");
        return state.DrawPile.Count < Math.Max(0, drawDemand) ||
               state.DrawPile.Count == 0 && GetStatusAmount(state.Player.Statuses, "TURN_START_AUTOPLAY_TOP") > 0;
    }

    private ImmutableArray<ChanceBranch<MutableCombatState>> OrderedDrawShuffleOutcomes(
        MutableCombatState original,
        CardState card,
        string? targetId,
        ChoiceSpec? choice,
        int drawCount,
        int maximumExactBranches,
        int sampleCount)
    {
        var unorderedPool = original.UnorderedDrawPool.Count > 0;
        var pool = unorderedPool ? original.UnorderedDrawPool.ToArray() : original.DiscardPile.ToArray();
        var exact = OrderedPermutationCountAtMost(pool, maximumExactBranches) > 0;
        var permutations = exact
            ? EnumerateOrderedSemanticPermutations(pool).Take(maximumExactBranches).ToArray()
            : SampleOrderedSemanticPermutations(pool, Math.Max(1, sampleCount), original.SearchBehaviorKey()).ToArray();
        if (permutations.Length == 0)
            return [new ChanceBranch<MutableCombatState>(
                "无可抽取卡牌", 1m, PlayCard(original, card, targetId, choice), OutcomeKind.Deterministic)];

        var unresolvedDraws = Math.Max(0, drawCount - original.DrawPile.Count);
        var probability = 1m / permutations.Length;
        return permutations.Select(permutation =>
        {
            var prepared = original.Clone();
            prepared.DrawPile.AddRange(permutation);
            if (unorderedPool) prepared.UnorderedDrawPool.Clear();
            else prepared.DiscardPile.Clear();
            var state = PlayCard(prepared, card, targetId, choice);
            if (!exact)
            {
                var message = $"未知洗牌共有超过 {maximumExactBranches} 个排列，使用 {permutations.Length} 个确定性样本估计。";
                state.Risks.Add(new RiskEvent(
                    PredictionRiskReason.ChanceBranchSampled,
                    PredictionRiskSeverity.Estimated,
                    message,
                    card.ModelId));
                state.Restrictions.Add(new RestrictionReason("sampled_shuffle", message, card.ModelId));
            }
            return new ChanceBranch<MutableCombatState>(
                ShuffleLabel(permutation, unresolvedDraws),
                probability,
                state,
                OutcomeKind.Stochastic,
                ProbabilityKnown: true,
                RngSource: RngSnapshotSet.Shuffle,
                OutcomeQuality: exact ? "Exact" : "Sampled",
                ProbabilityMassCovered: exact ? 1m : null,
                EffectiveSampleSize: exact ? permutations.Length : sampleCount,
                RngConsumptionVector: unorderedPool
                    ? ImmutableDictionary<string, long>.Empty
                    : ImmutableDictionary<string, long>.Empty
                        .Add(RngSnapshotSet.Shuffle, Math.Max(0, pool.Length - 1)));
        }).ToImmutableArray();
    }

    private static bool HasOrderedDrawEffects(ImmutableArray<EffectSpec> effects) => effects.Any(static effect =>
        effect.Kind is EffectKind.DrawToHandSize or EffectKind.DrawUntilNonAttack ||
        effect.Condition == "LAST_DRAWN_CARD_SKILL");

    private static int DrawCount(
        MutableCombatState state,
        ImmutableArray<EffectSpec> effects,
        bool cardLeavesHand,
        int playCount)
    {
        var handCount = Math.Max(0, state.Hand.Count - (cardLeavesHand ? 1 : 0));
        var drawOffset = 0;
        var total = 0;
        foreach (var effect in effects)
        {
            int count;
            switch (effect.Kind)
            {
                case EffectKind.Draw:
                    count = Math.Max(0, (int)effect.Amount) * Math.Max(1, playCount);
                    break;
                case EffectKind.DrawToHandSize:
                    count = Math.Max(0, (int)effect.Amount - handCount);
                    break;
                case EffectKind.DrawUntilNonAttack:
                    var capacity = Math.Max(0, 10 - handCount);
                    var known = state.DrawPile.Skip(drawOffset).Take(capacity).ToArray();
                    var stop = Array.FindIndex(known, static card => !IsCardType(card, "Attack", "攻击"));
                    count = stop >= 0 ? stop + 1 : capacity;
                    break;
                default:
                    continue;
            }
            total += count;
            drawOffset += count;
            handCount = Math.Min(10, handCount + count);
        }
        return total;
    }

    private static int DrawCount(ImmutableArray<EffectSpec> effects)
    {
        if (effects.IsDefault)
            return 0;
        return effects
            .Where(static effect => effect.Kind == EffectKind.Draw && effect.UnsupportedReason is null)
            .Sum(static effect => Math.Max(0, (int)effect.Amount));
    }

    private static ImmutableArray<EffectSpec> WithoutDraw(ImmutableArray<EffectSpec> effects) =>
        effects.IsDefault ? ImmutableArray<EffectSpec>.Empty :
        effects.Where(static effect => effect.Kind != EffectKind.Draw).ToImmutableArray();

    private static ImmutableArray<EffectSpec> WithoutRandomTargetDamage(ImmutableArray<EffectSpec> effects) =>
        effects.IsDefault ? ImmutableArray<EffectSpec>.Empty :
        effects.Where(static effect => effect.Kind != EffectKind.RandomEnemyDamage).ToImmutableArray();

    private static ImmutableArray<EffectSpec> WithoutRandomExhaust(ImmutableArray<EffectSpec> effects) =>
        effects.IsDefault ? ImmutableArray<EffectSpec>.Empty :
        effects.Where(static effect => effect.Kind != EffectKind.RandomExhaustCards).ToImmutableArray();

    private static ChanceBranch<MutableCombatState> CombineChance(
        ChanceBranch<MutableCombatState> outer,
        ChanceBranch<MutableCombatState> inner)
    {
        var quality = WorstOutcomeQuality(outer.OutcomeQuality, inner.OutcomeQuality);
        var outerMass = outer.ProbabilityMassCovered ??
            (outer.Kind == OutcomeKind.Deterministic ? 1m : (decimal?)null);
        var innerMass = inner.ProbabilityMassCovered ??
            (inner.Kind == OutcomeKind.Deterministic ? 1m : (decimal?)null);
        decimal? mass = outerMass.HasValue && innerMass.HasValue
            ? outerMass.Value * innerMass.Value
            : null;
        var outerEss = outer.EffectiveSampleSize ??
            (outer.Kind == OutcomeKind.Deterministic ? 1m : (decimal?)null);
        var innerEss = inner.EffectiveSampleSize ??
            (inner.Kind == OutcomeKind.Deterministic ? 1m : (decimal?)null);
        var ess = outer.Kind == OutcomeKind.Deterministic ? innerEss
            : inner.Kind == OutcomeKind.Deterministic ? outerEss
            : outerEss.HasValue && innerEss.HasValue
                ? Math.Min(outerEss.Value, innerEss.Value)
                : outerEss ?? innerEss;
        var rng = ImmutableDictionary<string, long>.Empty;
        foreach (var pair in outer.RngConsumptionVector ?? ImmutableDictionary<string, long>.Empty)
            rng = rng.SetItem(pair.Key, pair.Value);
        foreach (var pair in inner.RngConsumptionVector ?? ImmutableDictionary<string, long>.Empty)
            rng = rng.SetItem(pair.Key, rng.TryGetValue(pair.Key, out var current) ? current + pair.Value : pair.Value);
        return new ChanceBranch<MutableCombatState>(
            outer.Label == "确定结果" ? inner.Label :
                inner.Label == "确定结果" ? outer.Label : $"{outer.Label}；{inner.Label}",
            outer.Probability * inner.Probability,
            inner.State,
            outer.Kind == OutcomeKind.Deterministic && inner.Kind == OutcomeKind.Deterministic
                ? OutcomeKind.Deterministic : OutcomeKind.Stochastic,
            outer.ProbabilityKnown && inner.ProbabilityKnown,
            inner.RngSource ?? outer.RngSource,
            quality,
            mass,
            ess,
            outer.ConfidenceIntervalLow ?? inner.ConfidenceIntervalLow,
            outer.ConfidenceIntervalHigh ?? inner.ConfidenceIntervalHigh,
            rng);
    }

    private static string WorstOutcomeQuality(string first, string second)
    {
        static int Rank(string quality) => quality switch
        {
            "Uncalculable" => 4,
            "Sampled" => 3,
            "Estimated" => 2,
            "Exact" => 1,
            _ => 0
        };
        return Rank(first) >= Rank(second) ? first : second;
    }

    private static ImmutableArray<ChanceBranch<MutableCombatState>> RandomGeneratedCardOutcomes(
        MutableCombatState original,
        ImmutableArray<EffectSpec> effects,
        string sourceId,
        int maximumExactBranches,
        int sampleCount)
    {
        var frontier = new List<ChanceBranch<MutableCombatState>>
        {
            new("随机生成", 1m, original.Clone(), OutcomeKind.Deterministic)
        };
        foreach (var effect in effects)
        {
            if (!string.Equals(effect.RandomSource, RngSnapshotSet.CombatCardGeneration, StringComparison.Ordinal) ||
                effect.GeneratedCardPool.IsDefaultOrEmpty)
            {
                var invalid = original.Clone();
                AddUncalculable(
                    invalid,
                    PredictionRiskReason.UnsupportedRandomSource,
                    "uncalculable_random_card_generation",
                    $"随机生成卡牌需要 {RngSnapshotSet.CombatCardGeneration} 概率模型和非空候选池。",
                    effect.SourceId ?? sourceId);
                return [new ChanceBranch<MutableCombatState>("随机生成卡牌不可计算", 1m, invalid)];
            }
            if (effect.RandomizeGeneratedPosition)
            {
                var invalid = original.Clone();
                AddUncalculable(
                    invalid,
                    PredictionRiskReason.UnsupportedRandomSource,
                    "uncalculable_random_generated_position",
                    "随机生成卡牌的随机放置位置尚未建模。",
                    effect.SourceId ?? sourceId);
                return [new ChanceBranch<MutableCombatState>("随机生成位置不可计算", 1m, invalid)];
            }

            var pool = effect.GeneratedCardPool.ToArray();
            var amount = Math.Max(0, (int)effect.Amount);
            if (!effect.RandomSelectionWithReplacement)
                amount = Math.Min(amount, pool.Length);
            var exactCandidates = EnumerateWeightedSelections(
                pool, amount, effect.RandomSelectionWithReplacement, maximumExactBranches + 1).ToArray();
            var exact = exactCandidates.Length <= maximumExactBranches;
            var limit = exact ? exactCandidates.Length : Math.Max(1, sampleCount);
            var weightedSelections = exact
                ? exactCandidates
                : EnumerateSelections(pool, amount, effect.RandomSelectionWithReplacement, limit)
                    .Select(selection => (Cards: selection, Probability: 1m / Math.Max(1, limit)))
                    .ToArray();
            var selections = weightedSelections.Select(item => item.Cards).ToArray();
            if (selections.Length == 0)
                return [new ChanceBranch<MutableCombatState>("随机生成无结果", 1m, original.Clone(), OutcomeKind.Deterministic)];
            var next = new List<ChanceBranch<MutableCombatState>>();
            foreach (var branch in frontier)
            foreach (var weighted in weightedSelections)
            {
                var selection = weighted.Cards;
                var state = branch.State.Clone();
                var generatedLabels = new List<string>();
                foreach (var template in selection)
                {
                    var existing = state.Hand.Concat(state.DrawPile).Concat(state.DiscardPile).Concat(state.ExhaustPile)
                        .Count(card => card.ModelId.Equals(template.ModelId, StringComparison.OrdinalIgnoreCase));
                    var generated = PrepareGeneratedCard(state, template, $"{template.InstanceId}:{existing + 1}");
                    if (effect.StatusId == "FREE_THIS_TURN")
                        generated = generated with { EnergyCost = 0, CostsX = false, TemporaryEnergyCostBeforeCap = template.EnergyCost, TemporaryCostsXBeforeOverride = template.CostsX };
                    else if (effect.StatusId == "FREE_THIS_COMBAT")
                        generated = generated with { EnergyCost = 0, CostsX = false, FreeThisCombat = true };
                    AddGeneratedCard(state, generated, effect.GeneratedDestination, effect.SourceId ?? sourceId);
                    generatedLabels.Add(template.ModelId);
                }
                AdvanceUnknownRng(state, RngSnapshotSet.CombatCardGeneration, amount);
                if (!exact)
                {
                    var message = $"随机生成卡牌候选序列超过 {maximumExactBranches}，使用 {selections.Length} 个确定性样本。";
                    state.Risks.Add(new RiskEvent(PredictionRiskReason.ChanceBranchSampled, PredictionRiskSeverity.Estimated, message, effect.SourceId ?? sourceId));
                    state.Restrictions.Add(new RestrictionReason("sampled_random_card_generation", message, effect.SourceId ?? sourceId));
                }
                next.Add(new ChanceBranch<MutableCombatState>(
                    $"随机生成：{string.Join("、", generatedLabels)}",
                    branch.Probability * weighted.Probability,
                    state,
                    weightedSelections.Length == 1 && branch.Kind == OutcomeKind.Deterministic
                        ? OutcomeKind.Deterministic : OutcomeKind.Stochastic,
                    branch.ProbabilityKnown,
                    RngSnapshotSet.CombatCardGeneration,
                    exact ? "Exact" : "Sampled",
                    exact ? 1m : null,
                    exact ? weightedSelections.Length : sampleCount,
                    RngConsumptionVector: ImmutableDictionary<string, long>.Empty
                        .Add(RngSnapshotSet.CombatCardGeneration, amount)));
            }
            frontier = next;
        }
        return frontier.ToImmutableArray();
    }

    private static int SelectionCount(int poolCount, int amount, bool withReplacement, int limit)
    {
        if (amount == 0) return 1;
        if (poolCount == 0) return 0;
        long total = 1;
        for (var index = 0; index < amount; index++)
        {
            var factor = withReplacement ? poolCount : poolCount - index;
            if (factor <= 0 || total > limit / factor) return 0;
            total *= factor;
        }
        return (int)total;
    }

    internal static string CardSemanticKey(CardState card)
    {
        var effects = string.Join(';', card.Effects.Select(EffectSemanticKey));
        var turnEnd = string.Join(';', card.SafeTurnEndInHandEffects.Select(EffectSemanticKey));
        var pool = string.Join(';', card.Effects
            .SelectMany(static effect => effect.GeneratedCardPool.IsDefault
                ? []
                : effect.GeneratedCardPool)
            .Select(static generated => generated.ModelId + ":" + generated.IsUpgraded));
        return string.Join('|',
            card.ModelId,
            card.CardType,
            card.IsUpgraded,
            card.EnergyCost,
            card.BaseEnergyCost,
            card.CostsX,
            card.Target,
            card.Destination,
            card.RetainAtTurnEnd,
            card.ExhaustAtTurnEnd,
            card.EnergyChangeOnDraw,
            card.HpLossAtTurnEnd.ToString(CultureInfo.InvariantCulture),
            card.ReplayCount,
            card.IsColorless,
            card.EnergyCostChangeOnDraw,
            card.DamageChangeOnDraw.ToString(CultureInfo.InvariantCulture),
            card.CombatDamageBonus.ToString(CultureInfo.InvariantCulture),
            card.TemporaryRetainAtTurnEnd,
            card.FreeUntilTurnEnd,
            card.FreeThisCombat,
            card.TemporaryEnergyCostBeforeCap,
            card.TemporaryCostsXBeforeOverride,
            card.CombatBlockBonus.ToString(CultureInfo.InvariantCulture),
            effects,
            turnEnd,
            pool);
    }

    private static string EffectSemanticKey(EffectSpec effect) => string.Join(',',
        effect.Kind,
        effect.Amount.ToString(CultureInfo.InvariantCulture),
        effect.StatusId,
        effect.Duration,
        effect.IsDebuff,
        effect.FutureValuePerTurn.ToString(CultureInfo.InvariantCulture),
        effect.TargetOverride,
        effect.Condition,
        effect.GeneratedDestination,
        effect.Repeat,
        effect.RepeatByEnergySpent,
        effect.RepeatByOrbCount,
        effect.XBonus,
        effect.AmountByEnergySpent,
        effect.AmountByAliveEnemyCount,
        effect.AmountByDistinctOrbTypes,
        effect.AmountByHandAttackCount,
        effect.AmountByCardsDrawnThisTurn,
        effect.RepeatByHistoryCounter,
        effect.RepeatByKillCount,
        effect.AmountByTargetVulnerableStacks,
        effect.RepeatByExhaustedCount,
        effect.RandomSource,
        effect.RandomizeGeneratedPosition,
        effect.RandomSelectionWithReplacement,
        effect.GeneratedCard is null ? string.Empty : CardSemanticKey(effect.GeneratedCard));

    private static IEnumerable<(CardState[] Cards, decimal Probability)> EnumerateWeightedSelections(
        CardState[] pool,
        int amount,
        bool withReplacement,
        int limit)
    {
        if (amount == 0)
        {
            yield return ([], 1m);
            yield break;
        }
        if (pool.Length == 0) yield break;

        var groups = pool.GroupBy(CardSemanticKey, StringComparer.Ordinal)
            .Select(group => (Card: group.First(), InitialCount: group.Count()))
            .OrderBy(item => CardSemanticKey(item.Card), StringComparer.Ordinal)
            .ToArray();
        var counts = groups.Select(item => item.InitialCount).ToArray();
        var selected = new CardState[amount];
        var produced = 0;
        foreach (var item in Visit(0, 1m))
        {
            yield return item;
            if (++produced >= limit) yield break;
        }

        IEnumerable<(CardState[] Cards, decimal Probability)> Visit(int depth, decimal probability)
        {
            if (depth == amount)
            {
                yield return (selected.ToArray(), probability);
                yield break;
            }
            var remainingTotal = withReplacement ? pool.Length : counts.Sum();
            if (remainingTotal <= 0) yield break;
            for (var index = 0; index < groups.Length; index++)
            {
                if (!withReplacement && counts[index] <= 0) continue;
                var weight = (decimal)(withReplacement ? groups[index].InitialCount : counts[index]) / remainingTotal;
                selected[depth] = groups[index].Card;
                if (!withReplacement) counts[index]--;
                foreach (var item in Visit(depth + 1, probability * weight)) yield return item;
                if (!withReplacement) counts[index]++;
            }
        }
    }

    private static IEnumerable<CardState[]> EnumerateSelections(
        CardState[] pool,
        int amount,
        bool withReplacement,
        int limit)
    {
        var selected = new CardState[amount];
        var yielded = 0;
        IEnumerable<CardState[]> Enumerate(int depth, HashSet<int> used)
        {
            if (yielded >= limit) yield break;
            if (depth == amount)
            {
                yielded++;
                yield return selected.ToArray();
                yield break;
            }
            for (var index = 0; index < pool.Length; index++)
            {
                if (!withReplacement && used.Contains(index)) continue;
                selected[depth] = pool[index];
                if (!withReplacement) used.Add(index);
                foreach (var result in Enumerate(depth + 1, used)) yield return result;
                if (!withReplacement) used.Remove(index);
                if (yielded >= limit) yield break;
            }
        }
        return Enumerate(0, new HashSet<int>());
    }

    private static ImmutableArray<ChanceBranch<MutableCombatState>> RandomExhaustOutcomes(
        MutableCombatState original,
        int count,
        string sourceId,
        int maximumExactBranches,
        int sampleCount)
    {
        count = Math.Min(Math.Max(0, count), original.Hand.Count);
        if (count == 0)
            return [new ChanceBranch<MutableCombatState>("没有可随机消耗的手牌", 1m, original.Clone(), OutcomeKind.Deterministic)];

        var knownStream = original.RngStreams.Get(RngSnapshotSet.CombatCardSelection);
        if (knownStream is { IsKnown: true })
        {
            var state = original.Clone();
            var labels = new List<string>();
            for (var index = 0; index < count && state.Hand.Count > 0; index++)
            {
                var selected = knownStream.NextInt(state.Hand.Count, out knownStream);
                var card = state.Hand[selected];
                state.Hand.RemoveAt(selected);
                state.ExhaustPile.Add(card);
                ApplyExhaustTriggers(state, [card]);
                labels.Add(card.Name);
            }
            state.RngStreams = state.RngStreams.With(knownStream);
            return [new ChanceBranch<MutableCombatState>(
                $"随机消耗：{string.Join("、", labels)}",
                1m,
                state,
                OutcomeKind.Deterministic,
                ProbabilityKnown: true,
                RngSource: RngSnapshotSet.CombatCardSelection,
                OutcomeQuality: "Exact",
                ProbabilityMassCovered: 1m,
                EffectiveSampleSize: 1m,
                RngConsumptionVector: ImmutableDictionary<string, long>.Empty
                    .Add(RngSnapshotSet.CombatCardSelection, count))];
        }

        var combinations = EnumerateCombinations(original.Hand.Count, count, maximumExactBranches + 1).ToArray();
        if (combinations.Length <= maximumExactBranches)
        {
            var probability = 1m / combinations.Length;
            var groups = combinations.GroupBy(indices => string.Join("|", indices
                .Select(index => CardSemanticKey(original.Hand[index]))
                .OrderBy(static key => key, StringComparer.Ordinal)), StringComparer.Ordinal);
            return groups.Select(group =>
            {
                var state = original.Clone();
                var indices = group.First();
                var selected = indices.Select(index => state.Hand[index]).ToArray();
                foreach (var index in indices.OrderDescending()) state.Hand.RemoveAt(index);
                state.ExhaustPile.AddRange(selected);
                ApplyExhaustTriggers(state, selected);
                AdvanceUnknownRng(state, RngSnapshotSet.CombatCardSelection, count);
                return new ChanceBranch<MutableCombatState>(
                    $"随机消耗：{string.Join("、", selected.Select(static card => card.Name))}",
                    probability * group.Count(),
                state,
                OutcomeKind.Stochastic,
                ProbabilityKnown: true,
                RngSource: RngSnapshotSet.CombatCardSelection,
                OutcomeQuality: "Exact",
                ProbabilityMassCovered: 1m,
                EffectiveSampleSize: groups.Count(),
                RngConsumptionVector: ImmutableDictionary<string, long>.Empty
                    .Add(RngSnapshotSet.CombatCardSelection, count));
            }).ToImmutableArray();
        }

        var seed = StableSeed(original.SearchBehaviorKey(), sourceId);
        var samples = new List<ChanceBranch<MutableCombatState>>();
        for (var sample = 0; sample < Math.Max(1, sampleCount); sample++)
        {
            var state = original.Clone();
            var selected = new List<CardState>();
            for (var index = 0; index < count && state.Hand.Count > 0; index++)
            {
                seed = NextSample(seed);
                var position = (int)(seed % (ulong)state.Hand.Count);
                selected.Add(state.Hand[position]);
                state.Hand.RemoveAt(position);
            }
            state.ExhaustPile.AddRange(selected);
            ApplyExhaustTriggers(state, selected);
            AdvanceUnknownRng(state, RngSnapshotSet.CombatCardSelection, count);
            var message = $"随机消耗组合超过 {maximumExactBranches}，使用 {sampleCount} 个确定性样本。";
            state.Risks.Add(new RiskEvent(PredictionRiskReason.ChanceBranchSampled, PredictionRiskSeverity.Estimated, message, sourceId));
            state.Restrictions.Add(new RestrictionReason("sampled_random_exhaust", message, sourceId));
            samples.Add(new ChanceBranch<MutableCombatState>(
                $"随机消耗样本：{string.Join("、", selected.Select(static card => card.Name))}",
                1m / Math.Max(1, sampleCount),
                    state,
                OutcomeKind.Stochastic,
                ProbabilityKnown: true,
                RngSource: RngSnapshotSet.CombatCardSelection,
                OutcomeQuality: "Sampled",
                ProbabilityMassCovered: null,
                EffectiveSampleSize: Math.Max(1, sampleCount),
                RngConsumptionVector: ImmutableDictionary<string, long>.Empty
                    .Add(RngSnapshotSet.CombatCardSelection, count)));
        }
        return samples.ToImmutableArray();
    }

    private static IEnumerable<int[]> EnumerateCombinations(int size, int count, int limit)
    {
        var selected = new int[count];
        var yielded = 0;
        return Enumerate(0, 0);

        IEnumerable<int[]> Enumerate(int depth, int start)
        {
            if (yielded >= limit) yield break;
            if (depth == count)
            {
                yielded++;
                yield return selected.ToArray();
                yield break;
            }
            for (var index = start; index <= size - (count - depth); index++)
            {
                selected[depth] = index;
                foreach (var combination in Enumerate(depth + 1, index + 1)) yield return combination;
                if (yielded >= limit) yield break;
            }
        }
    }

    private static ImmutableArray<ChanceBranch<MutableCombatState>> RandomEnemyDamageOutcomes(
        MutableCombatState original,
        ImmutableArray<EffectSpec> effects,
        string sourceId,
        int maximumExactBranches,
        int sampleCount)
    {
        var knownStream = original.RngStreams.Get(RngSnapshotSet.CombatTargets);
        if (knownStream is { IsKnown: true })
        {
            var state = original.Clone();
            var labels = new List<string>();
            foreach (var effect in effects)
            {
                var alive = state.Enemies.Where(static enemy => enemy.IsAlive).ToArray();
                if (alive.Length == 0) break;
                var selected = knownStream.NextInt(alive.Length, out knownStream);
                var enemy = alive[selected];
                DamageEnemy(state, enemy.Id, ModifyPlayerAttackDamage(state, enemy, effect.Amount));
                labels.Add(enemy.Name);
            }
            if (effects.Length > 0)
                ConsumeVigor(state);
            state.RngStreams = state.RngStreams.With(knownStream);
            return [new ChanceBranch<MutableCombatState>(
                $"随机目标：{string.Join("、", labels)}",
                1m,
                state,
                OutcomeKind.Deterministic,
                ProbabilityKnown: true,
                RngSource: RngSnapshotSet.CombatTargets,
                OutcomeQuality: "Exact",
                ProbabilityMassCovered: 1m,
                EffectiveSampleSize: 1m,
                RngConsumptionVector: ImmutableDictionary<string, long>.Empty
                    .Add(RngSnapshotSet.CombatTargets, effects.Length))];
        }

        var frontier = new List<(MutableCombatState State, decimal Probability, string Label)>
        {
            (original.Clone(), 1m, string.Empty)
        };
        var exact = true;
        foreach (var effect in effects)
        {
            var next = new List<(MutableCombatState State, decimal Probability, string Label)>();
            foreach (var branch in frontier)
            {
                var alive = branch.State.Enemies.Where(static enemy => enemy.IsAlive).ToArray();
                if (alive.Length == 0)
                {
                    next.Add(branch);
                    continue;
                }
                foreach (var enemy in alive)
                {
                    var state = branch.State.Clone();
                    var current = state.Enemies.First(item => item.Id == enemy.Id);
                    DamageEnemy(state, current.Id, ModifyPlayerAttackDamage(state, current, effect.Amount));
                    next.Add((
                        state,
                        branch.Probability / alive.Length,
                        branch.Label.Length == 0 ? enemy.Name : $"{branch.Label}、{enemy.Name}"));
                }
            }
            frontier = next;
            if (frontier.Count > maximumExactBranches)
            {
                exact = false;
                break;
            }
        }

        if (exact)
            return frontier.Select(branch =>
            {
                if (effects.Length > 0)
                    ConsumeVigor(branch.State);
                AdvanceUnknownRng(branch.State, RngSnapshotSet.CombatTargets, effects.Length);
                return new ChanceBranch<MutableCombatState>(
                    $"随机目标：{branch.Label}",
                    branch.Probability,
                    branch.State,
                    OutcomeKind.Stochastic,
                    ProbabilityKnown: true,
                    RngSource: RngSnapshotSet.CombatTargets,
                    OutcomeQuality: "Exact",
                    ProbabilityMassCovered: 1m,
                    EffectiveSampleSize: frontier.Count,
                    RngConsumptionVector: ImmutableDictionary<string, long>.Empty
                        .Add(RngSnapshotSet.CombatTargets, effects.Length));
            }).ToImmutableArray();

        var sampled = new List<ChanceBranch<MutableCombatState>>();
        var seed = StableSeed(original.SearchBehaviorKey(), sourceId);
        for (var sample = 0; sample < Math.Max(1, sampleCount); sample++)
        {
            var state = original.Clone();
            var labels = new List<string>();
            foreach (var effect in effects)
            {
                var alive = state.Enemies.Where(static enemy => enemy.IsAlive).ToArray();
                if (alive.Length == 0) break;
                seed = NextSample(seed);
                var enemy = alive[(int)(seed % (ulong)alive.Length)];
                DamageEnemy(state, enemy.Id, ModifyPlayerAttackDamage(state, enemy, effect.Amount));
                labels.Add(enemy.Name);
            }
            if (effects.Length > 0)
                ConsumeVigor(state);
            AdvanceUnknownRng(state, RngSnapshotSet.CombatTargets, effects.Length);
            var message = $"随机目标组合超过 {maximumExactBranches}，使用 {sampleCount} 个确定性样本。";
            state.Risks.Add(new RiskEvent(PredictionRiskReason.ChanceBranchSampled, PredictionRiskSeverity.Estimated, message, sourceId));
            state.Restrictions.Add(new RestrictionReason("sampled_random_targets", message, sourceId));
            sampled.Add(new ChanceBranch<MutableCombatState>(
                $"随机目标样本：{string.Join("、", labels)}",
                1m / Math.Max(1, sampleCount),
                state,
                OutcomeKind.Stochastic,
                ProbabilityKnown: true,
                RngSource: RngSnapshotSet.CombatTargets,
                OutcomeQuality: "Sampled",
                ProbabilityMassCovered: null,
                EffectiveSampleSize: Math.Max(1, sampleCount),
                RngConsumptionVector: ImmutableDictionary<string, long>.Empty
                    .Add(RngSnapshotSet.CombatTargets, effects.Length)));
        }
        return sampled.ToImmutableArray();
    }

    private static void AdvanceUnknownRng(MutableCombatState state, string streamName, int count)
    {
        if (count <= 0) return;
        if (state.RngStreams.Get(streamName) is { IsKnown: false } stream)
            state.RngStreams = state.RngStreams.With(stream with { Counter = stream.Counter + count });
    }

    private static ulong StableSeed(string stateKey, string sourceId)
    {
        var seed = 1469598103934665603UL;
        foreach (var character in stateKey + sourceId)
        {
            seed ^= character;
            seed *= 1099511628211UL;
        }
        return seed;
    }

    private static ulong NextSample(ulong state)
    {
        state ^= state << 13;
        state ^= state >> 7;
        state ^= state << 17;
        return state;
    }

    private static bool HasInterleavedDraw(ImmutableArray<EffectSpec> effects)
    {
        var drawIndex = -1;
        for (var index = 0; index < effects.Length; index++)
        {
            if (effects[index].Kind != EffectKind.Draw) continue;
            drawIndex = index;
            break;
        }
        return drawIndex >= 0 && drawIndex < effects.Length - 1;
    }

    private static MutableCombatState FinishCard(MutableCombatState state, CardState card, CardDestination destination)
    {
        switch (destination)
        {
            case CardDestination.Discard:
                state.DiscardPile.Add(card);
                break;
            case CardDestination.Exhaust:
                state.ExhaustPile.Add(card);
                ApplyExhaustTriggers(state, [card]);
                break;
            case CardDestination.DrawPileTop:
                state.DrawPile.Insert(0, card);
                break;
            case CardDestination.Remove:
                break;
            case CardDestination.Hand:
                state.Hand.Add(card);
                break;
        }
        ApplyUnceasingTopAfterHandEmptied(state);
        return state;
    }

    private static int FactorialAtMost(int count, int limit)
    {
        var value = 1;
        for (var factor = 2; factor <= count; factor++)
        {
            if (value > limit / factor) return 0;
            value *= factor;
        }
        return value;
    }

    private static DrawDistribution.Result? EnumerateDrawsOrMarkUncalculable(
        MutableCombatState state,
        CardState[] pool,
        int drawCount,
        int maximumBranches,
        string sourceId)
    {
        try
        {
            return DrawDistribution.Enumerate(pool, drawCount, Math.Max(1, maximumBranches));
        }
        catch (ArgumentOutOfRangeException exception) when (exception.ParamName == "pool")
        {
            AddUncalculable(
                state,
                PredictionRiskReason.CardDrawLimitExceeded,
                "uncalculable_draw_distribution_pool_size",
                exception.Message,
                sourceId);
            return null;
        }
    }

    private static void LoadDrawOutcome(MutableCombatState state, DrawDistribution.Outcome outcome)
    {
        state.DrawPile.AddRange(outcome.Drawn);
        state.UnorderedDrawPool.AddRange(outcome.Remaining);
    }

    private static void RestoreUndrawnOutcomeCards(MutableCombatState state, DrawDistribution.Outcome outcome)
    {
        if (outcome.Drawn.IsDefaultOrEmpty || state.DrawPile.Count == 0) return;
        var selectedIds = outcome.Drawn
            .Select(static card => card.InstanceId)
            .ToHashSet(StringComparer.Ordinal);
        var undrawn = state.DrawPile.Where(card => selectedIds.Contains(card.InstanceId)).ToArray();
        if (undrawn.Length == 0) return;
        state.DrawPile.RemoveAll(card => selectedIds.Contains(card.InstanceId));
        state.UnorderedDrawPool.AddRange(undrawn);
        state.UnorderedDrawPool.Sort(static (left, right) =>
        {
            var semantic = StringComparer.Ordinal.Compare(CardSemanticKey(left), CardSemanticKey(right));
            return semantic != 0 ? semantic : StringComparer.Ordinal.Compare(left.InstanceId, right.InstanceId);
        });
    }

    private static string DrawLabel(ImmutableArray<CardState> drawn) => drawn.IsDefaultOrEmpty
        ? "未抽到卡牌"
        : $"抽到 {string.Join("、", drawn.Select(static card => $"{card.Name}[{card.InstanceId}]"))}";

    private static int OrderedPermutationCountAtMost(CardState[] cards, int limit)
    {
        if (limit <= 0) return 0;
        if (cards.Length == 0) return 1;

        // Count unique permutations of the semantic multiset without
        // materialising permutations.  The recursive DP is capped at
        // limit+1, so large pools terminate as soon as they are known to
        // exceed the exact-branch budget.
        var groups = cards
            .GroupBy(CardSemanticKey, StringComparer.Ordinal)
            .Select(static group => group.Count())
            .OrderByDescending(static count => count)
            .ToArray();
        var memo = new Dictionary<string, int>(StringComparer.Ordinal);
        var capped = Count(groups);
        return capped > limit ? 0 : capped;

        int Count(int[] remaining)
        {
            if (remaining.All(static count => count == 0)) return 1;
            var key = string.Join(',', remaining);
            if (memo.TryGetValue(key, out var cached)) return cached;

            var total = 0;
            for (var index = 0; index < remaining.Length; index++)
            {
                if (remaining[index] == 0) continue;
                remaining[index]--;
                var child = Count(remaining);
                remaining[index]++;
                total = total > limit - child ? limit + 1 : total + child;
                if (total > limit) break;
            }
            memo[key] = total;
            return total;
        }
    }

    private static IEnumerable<CardState[]> EnumerateOrderedSemanticPermutations(CardState[] cards, int limit)
    {
        if (cards.Length == 0)
        {
            yield return [];
            yield break;
        }

        var remaining = cards.ToList();
        var prefix = new CardState[cards.Length];
        var produced = 0;
        foreach (var permutation in Visit(0))
        {
            yield return permutation;
            if (++produced >= limit) yield break;
        }

        IEnumerable<CardState[]> Visit(int depth)
        {
            if (depth == prefix.Length)
            {
                yield return prefix.ToArray();
                yield break;
            }

            var used = new HashSet<string>(StringComparer.Ordinal);
            for (var index = 0; index < remaining.Count; index++)
            {
                var card = remaining[index];
                var key = CardSemanticKey(card);
                if (!used.Add(key)) continue;
                remaining.RemoveAt(index);
                prefix[depth] = card;
                foreach (var result in Visit(depth + 1)) yield return result;
                remaining.Insert(index, card);
            }
        }
    }

    private static IEnumerable<CardState[]> EnumerateOrderedSemanticPermutations(CardState[] cards)
        => EnumerateOrderedSemanticPermutations(cards, int.MaxValue);

    private static IEnumerable<CardState[]> SampleOrderedSemanticPermutations(CardState[] cards, int count, string seedText)
    {
        var seed = 1469598103934665603UL;
        foreach (var character in seedText)
        {
            seed ^= character;
            seed *= 1099511628211UL;
        }
        var seen = new HashSet<string>(StringComparer.Ordinal);
        for (var sample = 0; sample < count * 4 && seen.Count < count; sample++)
        {
            var permutation = cards.ToArray();
            if (permutation.Length > 1)
            {
                var first = sample % permutation.Length;
                (permutation[0], permutation[first]) = (permutation[first], permutation[0]);
            }
            // Stratify the first drawn card, then randomize the tail. This keeps
            // small sample budgets from accidentally missing a whole outcome.
            for (var index = permutation.Length - 1; index > 1; index--)
            {
                seed ^= seed << 13;
                seed ^= seed >> 7;
                seed ^= seed << 17;
                var swap = 1 + (int)(seed % (ulong)index);
                (permutation[index], permutation[swap]) = (permutation[swap], permutation[index]);
            }
            if (seen.Add(string.Join('|', permutation.Select(CardSemanticKey))))
                yield return permutation;
        }
    }

    private static string ShuffleLabel(CardState[] permutation, int drawn) =>
        $"洗牌后先抽 {string.Join("、", permutation.Take(drawn).Select(static item => $"{item.Name}[{item.InstanceId}]"))}" +
        (permutation.Length <= drawn
            ? string.Empty
            : $"；余序 {string.Join("、", permutation.Skip(drawn).Select(static item => item.InstanceId))}");
}

