using System.Collections.Immutable;
using System.Globalization;
using System.Text;
using STS2BestChoice.Core.Model;

namespace STS2BestChoice.Core.Simulation;

internal sealed class MutableCombatState
{
    public required PlayerState Player { get; set; }
    public required List<CreatureState> Enemies { get; init; }
    public required List<CardState> Hand { get; init; }
    public required List<CardState> DrawPile { get; init; }
    public required List<CardState> DiscardPile { get; init; }
    public required List<CardState> UnorderedDrawPool { get; init; }
    public required List<CardState> ExhaustPile { get; init; }
    public required List<PotionState> Potions { get; init; }
    public required List<OrbState> Orbs { get; init; }
    public required List<RelicState> Relics { get; init; }
    public required List<PowerState> Powers { get; init; }
    public required int OrbCapacity { get; set; }
    public required ulong RngState { get; set; }
    public required RngSnapshotSet RngStreams { get; set; }
    public required List<RestrictionReason> Restrictions { get; init; }
    public required List<RiskEvent> Risks { get; init; }
    public decimal PotionCostSpent { get; set; }
    public decimal DamageDealt { get; set; }
    public int EnemiesKilled { get; set; }
    public decimal HpLostSinceSnapshot { get; set; }
    public int AttacksPlayedSinceSnapshot { get; set; }
    public int AttacksPlayedBeforeTurn { get; set; }
    public int SkillsPlayedSinceSnapshot { get; set; }
    public int SkillsPlayedBeforeTurn { get; set; }
    public int RainbowRingProgress { get; set; }
    public bool PaelsTearsPending { get; set; }
    public decimal SelfFormingClayBlockPending { get; set; }
    public int PocketwatchDrawPending { get; set; }
    public int CardsPlayedBeforeTurn { get; set; }
    public bool DemonTongueUsedThisTurn { get; set; }
    public bool CombatEndProcessed { get; set; }
    public decimal HpLostThisTurn { get; set; }
    public decimal Gold { get; set; }
    public bool EnemyTurnActive { get; set; }
    public int Round { get; set; }
    public int CardsPlayedSinceSnapshot { get; set; }
    public int CardPlaysFinishedSinceSnapshot { get; set; }
    public int ShivsPlayedSinceSnapshot { get; set; }
    public int EtherealCardsPlayedSinceSnapshot { get; set; }
    public int CardsDrawnSinceSnapshot { get; set; }
    public int CardsDrawnThisTurn { get; set; }
    public int CardsGeneratedSinceSnapshot { get; set; }
    public int StatusCardsDrawnSinceSnapshot { get; set; }
    public int CardsExhaustedSinceSnapshot { get; set; }
    public int CardsDiscardedSinceSnapshot { get; set; }
    public int DamageReceivedEventsSinceSnapshot { get; set; }
    public int UnmovableBlockGainsThisTurn { get; set; }
    public List<string> PendingTurnStartReturnCardInstanceIds { get; init; } = [];
    public List<CardState> PendingTurnStartCopies { get; init; } = [];
    public required int StatusCardsDrawnBeforeTurn { get; set; }
    public required int CardsExhaustedBeforeTurn { get; set; }
    public required int CardsDiscardedBeforeTurn { get; set; }
    public required int ShivsPlayedBeforeTurn { get; set; }
    public required CombatHistoryCounters HistoryBeforeSnapshot { get; init; }

    public PredictionConfidence Confidence => Restrictions.Any(static reason => reason.Code.StartsWith("uncalculable", StringComparison.Ordinal)) ||
                                              Risks.Any(static risk => risk.Severity == PredictionRiskSeverity.Uncalculable)
            ? PredictionConfidence.Uncalculable
            : Restrictions.Count > 0 || Risks.Any(static risk => risk.Severity == PredictionRiskSeverity.Estimated)
                ? PredictionConfidence.Estimated
                : PredictionConfidence.Reliable;

    public static MutableCombatState FromSnapshot(CombatSnapshot snapshot)
    {
        var history = snapshot.HistoryCounters ?? new CombatHistoryCounters();
        var shivsHitAllEnemies = snapshot.Player.Statuses.TryGetValue("SHIV_ALL_ENEMIES", out var fanOfKnives) &&
                                 fanOfKnives.Amount > 0;
        var shivsRetained = snapshot.Player.Statuses.TryGetValue("SHIV_RETAIN", out var phantomBlades) &&
                            phantomBlades.Amount > 0;
        CardState NormalizeCard(CardState card)
        {
            if (!card.ModelId.Equals("SHIV", StringComparison.OrdinalIgnoreCase) &&
                !card.ModelId.Equals("SHIV_UPGRADE", StringComparison.OrdinalIgnoreCase) &&
                !card.ModelId.Equals("INKY_SHIV", StringComparison.OrdinalIgnoreCase) &&
                !card.ModelId.Equals("INKY_SHIV_UPGRADE", StringComparison.OrdinalIgnoreCase))
                return card;
            if (shivsHitAllEnemies) card = card with { Target = TargetKind.AllEnemies };
            if (shivsRetained) card = card with { RetainAtTurnEnd = true };
            return card;
        }
        var unorderedDrawPool = snapshot.GlobalRestrictions.Contains("nosl_unordered_draw_pool");
        var semanticRestrictions = snapshot.GlobalRestrictions
            .Where(static reason => !reason.Equals("nosl_unordered_draw_pool", StringComparison.Ordinal));
        return new MutableCombatState
        {
            Player = snapshot.Player,
            Enemies = snapshot.Enemies.ToList(),
            Hand = snapshot.Hand.Select(NormalizeCard).ToList(),
            DrawPile = unorderedDrawPool ? [] : snapshot.DrawPile.Select(NormalizeCard).ToList(),
            DiscardPile = snapshot.DiscardPile.Select(NormalizeCard).ToList(),
            UnorderedDrawPool = unorderedDrawPool ? snapshot.DrawPile.Select(NormalizeCard).ToList() : [],
            ExhaustPile = snapshot.ExhaustPile.Select(NormalizeCard).ToList(),
            Potions = snapshot.Potions.ToList(),
            Orbs = snapshot.Orbs.IsDefault ? [] : snapshot.Orbs.ToList(),
            Relics = snapshot.SafeRelics.ToList(),
            Powers = snapshot.SafePowers.ToList(),
            OrbCapacity = snapshot.OrbCapacity,
            RngState = snapshot.RngState,
            RngStreams = (snapshot.RngStreams ?? RngSnapshotSet.Empty).Copy(),
            Restrictions = semanticRestrictions
                .Select(static reason => new RestrictionReason("snapshot_restriction", reason))
                .ToList(),
            Risks = semanticRestrictions
                .Select(static reason => new RiskEvent(
                    PredictionRiskReason.StateCaptureIncomplete,
                    PredictionRiskSeverity.Estimated,
                    reason))
                .ToList(),
            UnmovableBlockGainsThisTurn = history.BlockGainedThisTurn,
            HistoryBeforeSnapshot = history,
            StatusCardsDrawnBeforeTurn = history.StatusCardsDrawnThisTurn,
            CardsDrawnThisTurn = history.CardsDrawnThisTurn,
            CardsExhaustedBeforeTurn = history.CardsExhaustedThisTurn,
            CardsDiscardedBeforeTurn = history.CardsDiscardedThisTurn,
            ShivsPlayedBeforeTurn = history.ShivsPlayedThisTurn,
            AttacksPlayedBeforeTurn = history.AttacksPlayedThisTurn,
            CardsPlayedBeforeTurn = history.CardsPlayedThisTurn,
            SkillsPlayedBeforeTurn = history.SkillsPlayedThisTurn,
            RainbowRingProgress = (history.AttacksPlayedThisTurn > 0 ? 1 : 0) |
                                  (history.SkillsPlayedThisTurn > 0 ? 2 : 0) |
                                  (history.PowersPlayedThisTurn > 0 ? 4 : 0),
            Round = snapshot.Round
        };
    }

    public MutableCombatState Clone() => new()
    {
        Player = Player,
        Enemies = [.. Enemies],
        Hand = [.. Hand],
        DrawPile = [.. DrawPile],
        DiscardPile = [.. DiscardPile],
        UnorderedDrawPool = [.. UnorderedDrawPool],
        ExhaustPile = [.. ExhaustPile],
        Potions = [.. Potions],
        Orbs = [.. Orbs],
        Relics = [.. Relics],
        Powers = [.. Powers],
        OrbCapacity = OrbCapacity,
        RngState = RngState,
        RngStreams = RngStreams.Copy(),
        Restrictions = [.. Restrictions],
        Risks = [.. Risks],
        PotionCostSpent = PotionCostSpent,
        DamageDealt = DamageDealt,
        EnemiesKilled = EnemiesKilled,
        HpLostSinceSnapshot = HpLostSinceSnapshot,
        AttacksPlayedSinceSnapshot = AttacksPlayedSinceSnapshot,
        AttacksPlayedBeforeTurn = AttacksPlayedBeforeTurn,
        SkillsPlayedSinceSnapshot = SkillsPlayedSinceSnapshot,
        SkillsPlayedBeforeTurn = SkillsPlayedBeforeTurn,
        RainbowRingProgress = RainbowRingProgress,
        PaelsTearsPending = PaelsTearsPending,
        SelfFormingClayBlockPending = SelfFormingClayBlockPending,
        PocketwatchDrawPending = PocketwatchDrawPending,
        CardsPlayedBeforeTurn = CardsPlayedBeforeTurn,
        DemonTongueUsedThisTurn = DemonTongueUsedThisTurn,
        CombatEndProcessed = CombatEndProcessed,
        HpLostThisTurn = HpLostThisTurn,
        Gold = Gold,
        EnemyTurnActive = EnemyTurnActive,
        Round = Round,
        CardsPlayedSinceSnapshot = CardsPlayedSinceSnapshot,
            CardPlaysFinishedSinceSnapshot = CardPlaysFinishedSinceSnapshot,
            ShivsPlayedSinceSnapshot = ShivsPlayedSinceSnapshot,
        EtherealCardsPlayedSinceSnapshot = EtherealCardsPlayedSinceSnapshot,
        CardsDrawnSinceSnapshot = CardsDrawnSinceSnapshot,
        CardsDrawnThisTurn = CardsDrawnThisTurn,
        CardsGeneratedSinceSnapshot = CardsGeneratedSinceSnapshot,
        StatusCardsDrawnSinceSnapshot = StatusCardsDrawnSinceSnapshot,
        CardsExhaustedSinceSnapshot = CardsExhaustedSinceSnapshot,
        CardsDiscardedSinceSnapshot = CardsDiscardedSinceSnapshot,
        DamageReceivedEventsSinceSnapshot = DamageReceivedEventsSinceSnapshot,
        UnmovableBlockGainsThisTurn = UnmovableBlockGainsThisTurn,
        StatusCardsDrawnBeforeTurn = StatusCardsDrawnBeforeTurn,
        CardsExhaustedBeforeTurn = CardsExhaustedBeforeTurn,
            CardsDiscardedBeforeTurn = CardsDiscardedBeforeTurn,
        ShivsPlayedBeforeTurn = ShivsPlayedBeforeTurn,
            PendingTurnStartReturnCardInstanceIds = [.. PendingTurnStartReturnCardInstanceIds],
            PendingTurnStartCopies = [.. PendingTurnStartCopies],
        HistoryBeforeSnapshot = HistoryBeforeSnapshot
    };

    public string ExactKey()
    {
        var builder = new StringBuilder();
        if (PendingTurnStartReturnCardInstanceIds.Count > 0)
            builder.Append("|RET:").Append(string.Join(',', PendingTurnStartReturnCardInstanceIds));
        if (PendingTurnStartCopies.Count > 0)
            AppendCards(builder, "N", PendingTurnStartCopies);
        builder.Append(Player.Hp).Append('|').Append(Player.Block).Append('|').Append(Player.Energy).Append("|M:").Append(Player.MaxHp)
            .Append("|CP:").Append(AttacksPlayedSinceSnapshot).Append(':').Append(SkillsPlayedSinceSnapshot).Append(':').Append(RelevantRootCardPlays())
            .Append(":HPLOSS:").Append(HpLostSinceSnapshot)
            .Append("|HC:").Append(HistoryBeforeSnapshot.AttacksPlayedThisTurn).Append(':').Append(HistoryBeforeSnapshot.SkillsPlayedThisTurn)
            .Append(':').Append(HistoryBeforeSnapshot.CardsPlayedThisCombat).Append(':').Append(HistoryBeforeSnapshot.EtherealCardsPlayedThisCombat)
            .Append(':').Append(HistoryBeforeSnapshot.CardsDrawnThisCombat).Append(':').Append(HistoryBeforeSnapshot.CardsGeneratedThisCombat)
            .Append(':').Append(HistoryBeforeSnapshot.CardsPlayedThisTurn)
            .Append(':').Append(HistoryBeforeSnapshot.ShivsPlayedThisTurn)
            .Append(':').Append(HistoryBeforeSnapshot.DamageReceivedEventsThisCombat)
            .Append(':').Append(DamageReceivedEventsSinceSnapshot)
            .Append(':').Append(CardPlaysFinishedSinceSnapshot).Append(':').Append(EtherealCardsPlayedSinceSnapshot)
            .Append(':').Append(ShivsPlayedBeforeTurn).Append(':').Append(ShivsPlayedSinceSnapshot)
            .Append(':').Append(AttacksPlayedBeforeTurn)
            .Append(':').Append(CardsDrawnSinceSnapshot).Append(':').Append(CardsDrawnThisTurn)
            .Append(':').Append(CardsGeneratedSinceSnapshot);
        builder.Append(':').Append(StatusCardsDrawnBeforeTurn).Append(':').Append(StatusCardsDrawnSinceSnapshot);
        builder.Append(':').Append(CardsExhaustedBeforeTurn).Append(':').Append(CardsExhaustedSinceSnapshot)
            .Append(':').Append(CardsDiscardedBeforeTurn).Append(':').Append(CardsDiscardedSinceSnapshot);
        builder.Append(":UNMOVABLE:").Append(UnmovableBlockGainsThisTurn);
        if (Round != 0 || RainbowRingProgress != 0 || PaelsTearsPending ||
            SelfFormingClayBlockPending != 0m || PocketwatchDrawPending != 0 || CardsPlayedBeforeTurn != 0)
            builder.Append(":TRN:").Append(Round).Append(':').Append(RainbowRingProgress)
                .Append(':').Append(PaelsTearsPending ? '1' : '0')
                .Append(':').Append(SelfFormingClayBlockPending)
                .Append(':').Append(PocketwatchDrawPending)
                .Append(':').Append(CardsPlayedBeforeTurn);
        AppendStatuses(builder, Player.Statuses);
        foreach (var enemy in Enemies)
        {
            builder.Append("|E:").Append(enemy.Id).Append(':').Append(enemy.Hp).Append(':').Append(enemy.Block);
            AppendTargetRules(builder, enemy);
            AppendEnemyPublicAi(builder, enemy);
            AppendStatuses(builder, enemy.Statuses);
            AppendIntents(builder, enemy.Intents);
        }
        AppendCards(builder, "H", Hand
            .OrderBy(CardSemanticSortKey, StringComparer.Ordinal)
            .ThenBy(static card => card.InstanceId, StringComparer.Ordinal));
        AppendCards(builder, "D", DrawPile);
        AppendCards(builder, "C", DiscardPile);
        AppendCards(builder, "U", UnorderedDrawPool);
        AppendCards(builder, "X", ExhaustPile);
        AppendOrbs(builder, Orbs, OrbCapacity);
        AppendRelics(builder, Relics);
        AppendPowers(builder, Powers);
        foreach (var potion in Potions) builder.Append("|P:").Append(potion.InstanceId);
        builder.Append("|R:").Append(RngState);
        AppendRngStreams(builder, RngStreams);
        return builder.ToString();
    }

    public string CycleKeyWithoutProgress()
    {
        var builder = new StringBuilder();
        builder.Append(Player.Hp).Append('|').Append(Player.Block).Append('|').Append(Player.Energy).Append("|M:").Append(Player.MaxHp)
            .Append("|CP:").Append(AttacksPlayedSinceSnapshot).Append(':').Append(SkillsPlayedSinceSnapshot).Append(':').Append(RelevantRootCardPlays());
        builder.Append(":HPLOSS:").Append(HpLostSinceSnapshot);
        builder.Append(":DAMAGE_RECEIVED:").Append(HistoryBeforeSnapshot.DamageReceivedEventsThisCombat).Append(':').Append(DamageReceivedEventsSinceSnapshot);
        builder.Append(":EXHAUST:").Append(CardsExhaustedBeforeTurn).Append(':').Append(CardsExhaustedSinceSnapshot)
            .Append(":DISCARD:").Append(CardsDiscardedBeforeTurn).Append(':').Append(CardsDiscardedSinceSnapshot);
        builder.Append(":SHIVS:").Append(ShivsPlayedBeforeTurn).Append(':').Append(ShivsPlayedSinceSnapshot);
        builder.Append(":ATTACKS:").Append(AttacksPlayedBeforeTurn);
        builder.Append(":UNMOVABLE:").Append(UnmovableBlockGainsThisTurn);
        AppendStatuses(builder, Player.Statuses);
        foreach (var enemy in Enemies)
        {
            builder.Append("|E:").Append(enemy.Id).Append(':').Append(enemy.Block);
            AppendTargetRules(builder, enemy);
            AppendEnemyPublicAi(builder, enemy);
            AppendStatuses(builder, enemy.Statuses);
            AppendIntents(builder, enemy.Intents);
        }
        AppendCards(builder, "H", Hand
            .OrderBy(CardSemanticSortKey, StringComparer.Ordinal)
            .ThenBy(static card => card.InstanceId, StringComparer.Ordinal));
        AppendCards(builder, "D", DrawPile);
        AppendCards(builder, "C", DiscardPile);
        AppendCards(builder, "U", UnorderedDrawPool);
        AppendCards(builder, "X", ExhaustPile);
        AppendOrbs(builder, Orbs, OrbCapacity);
        AppendRelics(builder, Relics);
        AppendPowers(builder, Powers);
        foreach (var potion in Potions) builder.Append("|P:").Append(potion.InstanceId);
        builder.Append("|R:").Append(RngState);
        AppendRngStreams(builder, RngStreams);
        return builder.ToString();
    }

    /// <summary>Canonical key containing only public/NOSL belief information.</summary>
    public string PublicObservationKey() => BuildNoslKey("public");

    /// <summary>Canonical key for an unordered future-pile belief.</summary>
    public string NoslBeliefKey() => BuildNoslKey("belief");

    /// <summary>Behavior key used by search transposition tables.</summary>
    public string SearchBehaviorKey() => ExactKey();

    /// <summary>Audit key retaining the complete deterministic state.</summary>
    public string AuditExactKey() => ExactKey();

    /// <summary>Cycle key alias with explicit contract naming.</summary>
    public string CycleKey() => CycleKeyWithoutProgress();

    private string BuildNoslKey(string prefix)
    {
        var builder = new StringBuilder(prefix).Append("|v1|")
            .Append(Player.Hp.ToString(CultureInfo.InvariantCulture)).Append('|').Append(Player.MaxHp.ToString(CultureInfo.InvariantCulture)).Append('|')
            .Append(Player.Block.ToString(CultureInfo.InvariantCulture)).Append('|').Append(Player.Energy.ToString(CultureInfo.InvariantCulture)).Append('|').Append(Player.MaxEnergy.ToString(CultureInfo.InvariantCulture))
            .Append("|round:").Append(Round);
        if (UnorderedDrawPool.Count > 0) builder.Append("|unordered_draw:1");
        AppendStatuses(builder, Player.Statuses);
        foreach (var enemy in Enemies.OrderBy(static enemy => enemy.Id, StringComparer.Ordinal))
        {
            builder.Append("|E:").Append(enemy.Id).Append(':').Append(enemy.Hp.ToString(CultureInfo.InvariantCulture)).Append(':').Append(enemy.Block.ToString(CultureInfo.InvariantCulture));
            AppendTargetRules(builder, enemy);
            AppendEnemyPublicAi(builder, enemy);
            AppendStatuses(builder, enemy.Statuses);
            AppendIntents(builder, enemy.Intents);
        }
        foreach (var card in Hand
                     .OrderBy(static card => card.ModelId, StringComparer.Ordinal)
                     .ThenBy(CardSemanticSortKey, StringComparer.Ordinal))
            AppendCardSemantic(builder, "H", card);
        foreach (var card in DrawPile.Concat(DiscardPile).Concat(UnorderedDrawPool)
                     .OrderBy(static card => card.ModelId, StringComparer.Ordinal)
                     .ThenBy(CardSemanticSortKey, StringComparer.Ordinal))
            AppendCardSemantic(builder, "U", card);
        AppendRelics(builder, Relics);
        AppendPowers(builder, Powers);
        builder.Append("|orbs:").Append(OrbCapacity).Append(':').Append(Orbs.Count);
        return builder.ToString();
    }

    private static void AppendTargetRules(StringBuilder builder, CreatureState enemy)
    {
        builder.Append(":T:")
            .Append(enemy.IsHittable ? '1' : '0')
            .Append(enemy.IsPrimaryEnemy ? '1' : '0')
            .Append(enemy.IsSecondaryEnemy ? '1' : '0')
            .Append(enemy.IsMinion ? '1' : '0');
        foreach (var restriction in enemy.SafeTargetRestrictions.Order(StringComparer.Ordinal))
            builder.Append(':').Append(restriction);
    }

    private static void AppendEnemyPublicAi(StringBuilder builder, CreatureState enemy)
    {
        if (enemy.PublicAi is not { } publicAi) return;
        builder.Append(":AI:")
            .Append(publicAi.FirstObservedRound).Append(':')
            .Append(publicAi.LastObservedRound).Append(':')
            .Append(publicAi.ObservedTurns).Append(':')
            .Append(publicAi.Phase);
        foreach (var observedIntent in publicAi.SafeIntentHistory)
            builder.Append(':').Append(observedIntent);
    }

    private static void AppendCardSemantic(StringBuilder builder, string zone, CardState card)
    {
        builder.Append('|').Append(zone).Append(':').Append(card.ModelId).Append(':')
            .Append(card.EnergyCost.ToString(CultureInfo.InvariantCulture)).Append(':').Append(card.IsUpgraded ? '1' : '0').Append(':').Append(card.CardType)
            .Append(":target=").Append(card.Target)
            .Append(":dest=").Append(card.Destination)
            .Append(":x=").Append(card.CostsX ? '1' : '0')
            .Append(":retain=").Append(card.RetainAtTurnEnd ? '1' : '0')
            .Append(":ethereal=").Append(card.ExhaustAtTurnEnd ? '1' : '0')
            .Append(":replay=").Append(card.ReplayCount)
            .Append(":dmg=").Append(card.CombatDamageBonus.ToString(CultureInfo.InvariantCulture))
            .Append(":blk=").Append(card.CombatBlockBonus.ToString(CultureInfo.InvariantCulture));
        foreach (var effect in card.Effects)
        {
            builder.Append(":effect=");
            AppendEffectSemantic(builder, effect);
        }
        foreach (var effect in card.SafeTurnEndInHandEffects)
        {
            builder.Append(":turn_end_effect=");
            AppendEffectSemantic(builder, effect);
        }
    }

    private static string CardSemanticSortKey(CardState card)
    {
        var builder = new StringBuilder();
        AppendCardSemantic(builder, string.Empty, card);
        return builder.ToString();
    }

    private static void AppendEffectSemantic(StringBuilder builder, EffectSpec effect, int depth = 0)
    {
        builder.Append(effect.Kind).Append(',')
            .Append(effect.Amount.ToString(CultureInfo.InvariantCulture)).Append(',')
            .Append(effect.StatusId).Append(',').Append(effect.Duration).Append(',')
            .Append(effect.IsDebuff ? '1' : '0').Append(',')
            .Append(effect.TargetOverride).Append(',').Append(effect.Condition).Append(',')
            .Append(effect.GeneratedDestination).Append(',').Append(effect.Repeat).Append(',')
            .Append(effect.RepeatByEnergySpent ? '1' : '0').Append(',')
            .Append(effect.RepeatByOrbCount ? '1' : '0').Append(',').Append(effect.XBonus).Append(',')
            .Append(effect.AmountByEnergySpent ? '1' : '0').Append(',')
            .Append(effect.AmountByAliveEnemyCount ? '1' : '0').Append(',')
            .Append(effect.AmountByDistinctOrbTypes ? '1' : '0').Append(',')
            .Append(effect.AmountByHandAttackCount ? '1' : '0').Append(',')
            .Append(effect.AmountByCardsDrawnThisTurn ? '1' : '0').Append(',')
            .Append(effect.RepeatByHistoryCounter ? '1' : '0').Append(',')
            .Append(effect.RepeatByKillCount ? '1' : '0').Append(',')
            .Append(effect.AmountByTargetVulnerableStacks ? '1' : '0').Append(',')
            .Append(effect.RepeatByExhaustedCount ? '1' : '0').Append(',')
            .Append(effect.RandomSource).Append(',')
            .Append(effect.RandomizeGeneratedPosition ? '1' : '0').Append(',')
            .Append(effect.RandomSelectionWithReplacement ? '1' : '0');
        if (depth >= 2) return;
        if (effect.GeneratedCard is { } generated)
        {
            builder.Append(",generated=").Append(generated.ModelId).Append(':')
                .Append(generated.IsUpgraded ? '1' : '0').Append(':')
                .Append(generated.EnergyCost).Append(':').Append(generated.Target);
        }
        if (!effect.GeneratedCardPool.IsDefaultOrEmpty)
        {
            builder.Append(",pool=");
            foreach (var candidate in effect.GeneratedCardPool.OrderBy(static card => card.ModelId, StringComparer.Ordinal)
                         .ThenBy(static card => card.IsUpgraded))
            {
                builder.Append(candidate.ModelId).Append(':').Append(candidate.IsUpgraded ? '1' : '0').Append(';');
            }
        }
    }

    private static void AppendRelics(StringBuilder builder, IEnumerable<RelicState> relics)
    {
        foreach (var relic in relics.OrderBy(static r => r.Id, StringComparer.Ordinal))
        {
            builder.Append("|RL:").Append(relic.Id).Append(':')
                .Append(relic.Counter?.ToString() ?? "null").Append(':')
                .Append(relic.IsEnabled ? '1' : '0').Append(':')
                .Append(relic.IsUsedUp ? '1' : '0').Append(':')
                .Append(relic.UsesThisTurn).Append(':')
                .Append(relic.UsesThisCombat).Append(':')
                .Append(relic.UnknownStatePresent ? '1' : '0');
            if (relic.DynamicVars is { Count: > 0 } vars)
            {
                foreach (var pair in vars.OrderBy(static p => p.Key, StringComparer.Ordinal))
                {
                    builder.Append(':').Append(pair.Key).Append('=').Append(pair.Value.ToString(CultureInfo.InvariantCulture));
                }
            }
        }
    }

    private static void AppendPowers(StringBuilder builder, IEnumerable<PowerState> powers)
    {
        foreach (var power in powers.OrderBy(static p => p.OwnerId, StringComparer.Ordinal)
                     .ThenBy(static p => p.Id, StringComparer.Ordinal)
                     .ThenBy(static p => p.ApplierId, StringComparer.Ordinal))
        {
            builder.Append("|PW:").Append(power.OwnerId).Append(':').Append(power.Id).Append(':')
                .Append(power.ApplierId ?? "null").Append(':').Append(power.Amount.ToString(CultureInfo.InvariantCulture)).Append(':')
                .Append(power.Support).Append(':').Append(power.Evidence);
            foreach (var pair in power.SafeDynamicVars.OrderBy(static p => p.Key, StringComparer.Ordinal))
                builder.Append(':').Append(pair.Key).Append('=').Append(pair.Value.ToString(CultureInfo.InvariantCulture));
            foreach (var pair in power.SafeCounters.OrderBy(static p => p.Key, StringComparer.Ordinal))
                builder.Append(':').Append(pair.Key).Append('=').Append(pair.Value.ToString(CultureInfo.InvariantCulture));
            foreach (var phase in power.SafeTriggerPhases.OrderBy(static p => p, StringComparer.Ordinal))
                builder.Append(":PH=").Append(phase);
        }
    }

    private static void AppendRngStreams(StringBuilder builder, RngSnapshotSet streams)
    {
        foreach (var pair in streams.Streams.OrderBy(static pair => pair.Key, StringComparer.Ordinal))
        {
            var value = pair.Value;
            builder.Append("|RS:").Append(pair.Key).Append(':')
                .Append(value.State0).Append(':').Append(value.State1).Append(':')
                .Append(value.State2).Append(':').Append(value.State3).Append(':')
                .Append(value.Counter).Append(':').Append(value.IsKnown);
        }
    }

    private int RelevantRootCardPlays()
    {
        var maximumRelevant = Player.Statuses.TryGetValue("ECHO_FORM_REPLAY_FIRST_CARDS", out var active)
            ? Math.Max(0, active.Amount)
            : 0;
        maximumRelevant += Hand.Concat(DrawPile).Concat(DiscardPile).Concat(UnorderedDrawPool).Concat(ExhaustPile)
            .SelectMany(static card => card.Effects)
            .Where(static effect => effect.Kind == EffectKind.ApplyStatus && effect.StatusId == "ECHO_FORM_REPLAY_FIRST_CARDS")
            .Sum(static effect => Math.Max(0, (int)effect.Amount));
        return maximumRelevant <= 0 ? 0 : Math.Min(CardsPlayedSinceSnapshot, maximumRelevant);
    }

    private static void AppendCards(StringBuilder builder, string prefix, IEnumerable<CardState> cards)
    {
        builder.Append('|').Append(prefix).Append(':');
        foreach (var card in cards)
        {
            builder.Append(card.InstanceId).Append("@C").Append(card.EnergyCost)
                .Append("@T").Append(card.Target)
                .Append("@Y").Append(card.Rarity)
                .Append("@DMG+").Append(card.CombatDamageBonus.ToString(CultureInfo.InvariantCulture))
                .Append("@BLK+").Append(card.CombatBlockBonus.ToString(CultureInfo.InvariantCulture))
                .Append(card.CostsX ? "X" : string.Empty)
                .Append("@R").Append(card.ReplayCount)
                .Append(card.IsDupe ? "D" : string.Empty)
                .Append(card.RetainAtTurnEnd ? "P" : string.Empty)
                .Append(card.TemporaryRetainAtTurnEnd ? "T" : string.Empty)
                .Append(card.TemporaryEnergyCostBeforeCap is { } previousCost ? $"K{previousCost}" : string.Empty)
                .Append(card.TemporaryCostsXBeforeOverride is { } previousCostsX ? $"Q{previousCostsX}" : string.Empty)
                .Append(card.ExhaustAtTurnEnd ? "E" : string.Empty)
                .Append("@S=");
            AppendCardSemantic(builder, "state", card);
            builder.Append(',');
        }
    }

    private static void AppendOrbs(StringBuilder builder, IEnumerable<OrbState> orbs, int capacity)
    {
        builder.Append("|O:").Append(capacity).Append(':');
        foreach (var orb in orbs)
            builder.Append(orb.Id).Append('@').Append(orb.PassiveValue.ToString(CultureInfo.InvariantCulture)).Append('/')
                .Append(orb.EvokeValue.ToString(CultureInfo.InvariantCulture)).Append('~')
                .Append(orb.FocusAdjustment.ToString(CultureInfo.InvariantCulture)).Append(',');
    }

    private static void AppendStatuses(StringBuilder builder, ImmutableDictionary<string, StatusState> statuses)
    {
        foreach (var status in statuses.OrderBy(static pair => pair.Key, StringComparer.Ordinal))
            builder.Append(':').Append(status.Key).Append('=').Append(status.Value.Amount.ToString(CultureInfo.InvariantCulture)).Append('@').Append(status.Value.Duration)
                .Append('#').Append(status.Value.GeneratedCard?.ModelId)
                .Append('%').Append(status.Value.RandomSource);
    }

    private static void AppendIntents(StringBuilder builder, ImmutableArray<IntentState> intents)
    {
        builder.Append("|I:");
        foreach (var intent in intents)
        {
            builder.Append(intent.Type).Append('@').Append(intent.DamagePerHit.ToString(CultureInfo.InvariantCulture)).Append('#').Append(intent.Hits)
                .Append('%').Append(intent.RestrictionReason).Append('[');
            foreach (var effect in intent.SafeEffects)
            {
                builder.Append(effect.Kind).Append('@').Append(effect.Amount.ToString(CultureInfo.InvariantCulture)).Append(':').Append(effect.StatusId)
                    .Append(':').Append(effect.Duration).Append(':').Append(effect.IsDebuff)
                    .Append(':').Append(effect.FutureValuePerTurn.ToString(CultureInfo.InvariantCulture)).Append(':').Append(effect.SourceId)
                    .Append(':').Append(effect.TargetOverride).Append(':').Append(effect.Condition)
                    .Append(':').Append(effect.GeneratedDestination).Append(':').Append(effect.Repeat)
                    .Append(':').Append(effect.RepeatByEnergySpent).Append(':').Append(effect.RepeatByOrbCount)
                    .Append(':').Append(effect.XBonus).Append(':').Append(effect.AmountByEnergySpent)
                    .Append(':').Append(effect.AmountByAliveEnemyCount).Append(':').Append(effect.AmountByDistinctOrbTypes)
                    .Append(':').Append(effect.AmountByHandAttackCount).Append(':').Append(effect.AmountByCardsDrawnThisTurn)
                    .Append(':').Append(effect.RepeatByHistoryCounter).Append(':').Append(effect.RepeatByKillCount)
                    .Append(':').Append(effect.AmountByTargetVulnerableStacks).Append(':').Append(effect.RepeatByExhaustedCount)
                    .Append(':').Append(effect.RandomSource).Append(';');
                if (effect.GeneratedCard is { } generated)
                    builder.Append("G:").Append(generated.ModelId).Append('@').Append(generated.EnergyCost).Append(';');
                if (!effect.GeneratedCardPool.IsDefaultOrEmpty)
                    builder.Append("P:").Append(string.Join(',', effect.GeneratedCardPool.Select(static card => card.ModelId))).Append(';');
            }
            builder.Append(']');
        }
    }
}
