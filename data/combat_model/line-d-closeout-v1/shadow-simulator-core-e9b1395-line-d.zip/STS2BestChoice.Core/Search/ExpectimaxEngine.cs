using System.Collections.Immutable;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using STS2BestChoice.Core.Model;

namespace STS2BestChoice.Core.Search;

public interface IExpectimaxProblem<TState, TAction>
    where TState : notnull
    where TAction : notnull
{
    IEnumerable<TAction> Actions(TState state);
    IEnumerable<ChanceBranch<TState>> Apply(TState state, TAction action);
    bool IsTerminal(TState state);
    decimal Evaluate(TState state);
    string Key(TState state);
}

public sealed record ExpectimaxOptions(
    TimeSpan Budget,
    int MaximumDepth = 8,
    int MaximumChanceBranches = 32,
    decimal MinimumEvaluationValue = -1_000_000m,
    decimal MaximumEvaluationValue = 1_000_000m)
{
    public static ExpectimaxOptions Default { get; } = new(TimeSpan.FromMilliseconds(500));
}

public sealed record ExpectimaxResult<TAction>(
    decimal Value,
    ImmutableArray<TAction> PrincipalVariation,
    long ExpandedNodes,
    bool IsComplete,
    TimeSpan Elapsed,
    PredictionConfidence Confidence = PredictionConfidence.Reliable,
    ImmutableArray<ChanceSamplingStatistics> ChanceSampling = default);

public sealed record ChanceSamplingStatistics(
    string StateKey,
    string ActionLabel,
    int Depth,
    int BranchCount,
    int SampleCount,
    ulong SamplingSeed,
    decimal ProbabilityMassCovered,
    decimal Mean,
    decimal Variance,
    decimal ConfidenceInterval95Lower,
    decimal ConfidenceInterval95Upper,
    bool ProbabilityModelKnown,
    ImmutableArray<string> SampledBranchLabels,
    string OutcomeQuality = "Sampled",
    ImmutableDictionary<string, long>? RngConsumptionVector = null,
    decimal EffectiveSampleSize = 0m);

/// <summary>
/// Pure max/chance search. Game-specific state, RNG and effect mirrors stay outside this class.
/// </summary>
public sealed class ExpectimaxEngine<TState, TAction>
    where TState : notnull
    where TAction : notnull
{
    private readonly IExpectimaxProblem<TState, TAction> _problem;
    private readonly ExpectimaxOptions _options;
    private readonly Dictionary<(string Key, int Depth), NodeValue<TAction>> _cache = new();
    private readonly Stopwatch _clock = new();
    private long _expanded;
    private bool _complete = true;
    private readonly List<ChanceSamplingStatistics> _sampling = new();

    public ExpectimaxEngine(IExpectimaxProblem<TState, TAction> problem, ExpectimaxOptions? options = null)
    {
        _problem = problem;
        _options = options ?? ExpectimaxOptions.Default;
    }

    public ExpectimaxResult<TAction> Search(TState initialState)
    {
        if (_options.Budget <= TimeSpan.Zero) throw new ArgumentOutOfRangeException(nameof(_options.Budget));
        if (_options.MinimumEvaluationValue > _options.MaximumEvaluationValue)
            throw new ArgumentOutOfRangeException(nameof(_options.MinimumEvaluationValue));
        _cache.Clear();
        _expanded = 0;
        _complete = true;
        _sampling.Clear();
        _clock.Restart();
        var value = EvaluateNode(initialState, _options.MaximumDepth);
        _clock.Stop();
        return new ExpectimaxResult<TAction>(
            value.Value,
            value.Actions,
            _expanded,
            _complete,
            _clock.Elapsed,
            value.Confidence,
            _sampling.ToImmutableArray());
    }

    private NodeValue<TAction> EvaluateNode(TState state, int depth)
    {
        _expanded++;
        if (_clock.Elapsed >= _options.Budget)
        {
            _complete = false;
            return new NodeValue<TAction>(
                _problem.Evaluate(state), ImmutableArray<TAction>.Empty, PredictionConfidence.Reliable);
        }

        var key = (_problem.Key(state), depth);
        if (_cache.TryGetValue(key, out var cached)) return cached;
        if (depth <= 0 || _problem.IsTerminal(state))
        {
            var terminal = new NodeValue<TAction>(
                _problem.Evaluate(state), ImmutableArray<TAction>.Empty, PredictionConfidence.Reliable);
            _cache[key] = terminal;
            return terminal;
        }

        var best = default(NodeValue<TAction>?);
        var fallbackConfidence = PredictionConfidence.Reliable;
        foreach (var action in _problem.Actions(state))
        {
            var allBranches = MergeEquivalent(_problem.Apply(state, action).ToArray());
            var branches = allBranches;
            if (branches.Length == 0) continue;
            var actionLabel = action.ToString() ?? typeof(TAction).Name;
            var probabilityModelKnown = branches.All(static branch => branch.ProbabilityKnown);
            var hasUncalculableOutcome = branches.Any(static branch =>
                string.Equals(branch.OutcomeQuality, "Uncalculable", StringComparison.Ordinal));
            var hasEstimatedOutcome = branches.Any(static branch =>
                string.Equals(branch.OutcomeQuality, "Sampled", StringComparison.Ordinal) ||
                string.Equals(branch.OutcomeQuality, "Estimated", StringComparison.Ordinal));
            var actionConfidence = PredictionConfidence.Reliable;
            if (branches.Any(static branch => branch.Probability < 0m))
            {
                actionConfidence = PredictionConfidence.Uncalculable;
                fallbackConfidence = Worse(fallbackConfidence, actionConfidence);
                _complete = false;
                continue;
            }
            if (hasUncalculableOutcome)
            {
                actionConfidence = PredictionConfidence.Uncalculable;
                _complete = false;
            }
            else if (hasEstimatedOutcome)
            {
                // A sampled/estimated transition is never eligible for a
                // Reliable teacher label even when its reported probabilities
                // happen to sum to one and fit inside the branch budget.
                actionConfidence = PredictionConfidence.Estimated;
                _complete = false;
            }
            if (!probabilityModelKnown)
                actionConfidence = Worse(actionConfidence, PredictionConfidence.Estimated);
            if (branches.Length > _options.MaximumChanceBranches)
            {
                _complete = false;
                actionConfidence = Worse(actionConfidence, PredictionConfidence.Estimated);
                var totalMass = branches.Sum(static branch => Math.Max(0m, branch.Probability));
                if (totalMass <= 0m)
                {
                    fallbackConfidence = Worse(fallbackConfidence, PredictionConfidence.Uncalculable);
                    continue;
                }
                if (totalMass < 0.999999m || totalMass > 1.000001m)
                    actionConfidence = Worse(actionConfidence, PredictionConfidence.Estimated);

                var sampleCount = Math.Max(1, _options.MaximumChanceBranches);
                var seed = StableSeed(_problem.Key(state), actionLabel, depth);
                branches = StratifiedSample(branches, sampleCount, totalMass, seed);
                if (branches.Length == 0) continue;
                var selectedMass = branches
                    .Select(static branch => branch.Label)
                    .ToHashSet(StringComparer.Ordinal)
                    .Select(label => allBranches.First(branch => branch.Label == label))
                    .Sum(static branch => Math.Max(0m, branch.Probability));
                // Carry the actually covered probability mass on sampled
                // branches.  `StratifiedSample` receives the full mass for
                // weighting, but the selected labels can cover less than one
                // when a branch budget truncates a large outcome set.
                branches = branches
                    .Select(branch => branch with
                    {
                        ProbabilityMassCovered = selectedMass,
                        EffectiveSampleSize = branches.Length,
                    })
                    .ToArray();
                var values = new List<decimal>(branches.Length);
                var bestSampleValue = decimal.MinValue;
                var bestSampleActions = ImmutableArray<TAction>.Empty;
                var sampledConfidence = actionConfidence;
                foreach (var branch in branches)
                {
                    var child = EvaluateNode(branch.State, depth - 1);
                    values.Add(child.Value);
                    sampledConfidence = Worse(sampledConfidence, child.Confidence);
                    if (child.Value > bestSampleValue)
                    {
                        bestSampleValue = child.Value;
                        bestSampleActions = child.Actions;
                    }
                }

                var mean = values.Count == 0 ? 0m : values.Average();
                var expectedSample = mean;
                var variance = values.Count <= 1
                    ? 0m
                    : values.Sum(value => (value - mean) * (value - mean)) / (values.Count - 1);
                var margin = values.Count == 0
                    ? 0m
                    : 1.96m * (decimal)Math.Sqrt((double)variance / values.Count);
                _sampling.Add(new ChanceSamplingStatistics(
                    _problem.Key(state),
                    actionLabel,
                    depth,
                    allBranches.Length,
                    branches.Length,
                    seed,
                    selectedMass,
                    mean,
                    variance,
                    mean - margin,
                    mean + margin,
                    probabilityModelKnown,
                    branches.Select(static branch => branch.Label).ToImmutableArray(),
                    OutcomeQuality: "Sampled",
                    RngConsumptionVector: null,
                    EffectiveSampleSize: branches.Length));
                var sampledCandidate = new NodeValue<TAction>(
                    expectedSample,
                    bestSampleActions.Insert(0, action),
                    sampledConfidence);
                if (best is null || sampledCandidate.Value > best.Value) best = sampledCandidate;
                if (!_complete && _clock.Elapsed >= _options.Budget) break;
                continue;
            }

            var probabilityTotal = branches.Sum(static branch => branch.Probability);
            if (probabilityTotal <= 0m)
            {
                fallbackConfidence = Worse(fallbackConfidence, PredictionConfidence.Uncalculable);
                _complete = false;
                continue;
            }
            var declaredCoverage = branches
                .Where(static branch => branch.ProbabilityMassCovered is not null)
                .Select(static branch => branch.ProbabilityMassCovered!.Value)
                .DefaultIfEmpty(probabilityTotal)
                .Min();
            var probabilityMassCovered = Math.Min(probabilityTotal, declaredCoverage);
            var truncated = probabilityMassCovered < 0.999999m;
            if (probabilityTotal < 0.999999m || probabilityTotal > 1.000001m)
                actionConfidence = Worse(actionConfidence, PredictionConfidence.Estimated);
            if (truncated)
            {
                actionConfidence = Worse(actionConfidence, PredictionConfidence.Estimated);
                _complete = false;
            }
            var weightedObserved = 0m;
            var bestChildActions = ImmutableArray<TAction>.Empty;
            var bestChildValue = decimal.MinValue;
            var childConfidence = actionConfidence;
            var childValues = new List<decimal>(branches.Length);
            foreach (var branch in branches)
            {
                var child = EvaluateNode(branch.State, depth - 1);
                weightedObserved += branch.Probability * child.Value;
                childValues.Add(child.Value);
                childConfidence = Worse(childConfidence, child.Confidence);
                if (child.Value > bestChildValue)
                {
                    bestChildValue = child.Value;
                    bestChildActions = child.Actions;
                }
            }

            var expected = weightedObserved / probabilityTotal;
            if (truncated)
            {
                var missingMass = Math.Max(0m, 1m - probabilityMassCovered);
                var lower = weightedObserved + missingMass * _options.MinimumEvaluationValue;
                var upper = weightedObserved + missingMass * _options.MaximumEvaluationValue;
                var mean = childValues.Count == 0 ? 0m : childValues.Average();
                var variance = childValues.Count <= 1
                    ? 0m
                    : childValues.Sum(value => (value - mean) * (value - mean)) / (childValues.Count - 1);
                _sampling.Add(new ChanceSamplingStatistics(
                    _problem.Key(state),
                    actionLabel,
                    depth,
                    branches.Length,
                    branches.Length,
                    0UL,
                    probabilityMassCovered,
                    expected,
                    variance,
                    lower,
                    upper,
                    probabilityModelKnown,
                    branches.Select(static branch => branch.Label).ToImmutableArray(),
                    OutcomeQuality: "EstimatedTruncated",
                    RngConsumptionVector: MergeRngVectors(branches),
                    EffectiveSampleSize: 0m));
            }

            var candidate = new NodeValue<TAction>(
                expected, bestChildActions.Insert(0, action), childConfidence);
            if (best is null || candidate.Value > best.Value) best = candidate;
            if (!_complete && _clock.Elapsed >= _options.Budget) break;
        }

        var result = best ?? new NodeValue<TAction>(
            _problem.Evaluate(state), ImmutableArray<TAction>.Empty, fallbackConfidence);
        _cache[key] = result;
        return result;
    }

    private static ulong StableSeed(string stateKey, string actionLabel, int depth)
    {
        var payload = Encoding.UTF8.GetBytes($"{stateKey}\u001f{actionLabel}\u001f{depth}");
        var digest = SHA256.HashData(payload);
        return BitConverter.ToUInt64(digest, 0);
    }

    private ChanceBranch<TState>[] MergeEquivalent(ChanceBranch<TState>[] branches)
    {
        return branches
            .GroupBy(branch => _problem.Key(branch.State), StringComparer.Ordinal)
            .Select(group =>
            {
                var first = group.First();
                var probability = group.Sum(item => item.Probability);
                var known = group.All(item => item.ProbabilityKnown);
                var kind = group.Any(item => item.Kind == OutcomeKind.Stochastic)
                    ? OutcomeKind.Stochastic : first.Kind;
                // Preserve chance-quality metadata when equivalent post-states
                // are coalesced.  Coverage and ESS are conservative (the
                // largest evidence attached to any member), while confidence
                // intervals and RNG vectors are merged across the members.
                var coverage = group
                    .Where(static item => item.ProbabilityMassCovered is not null)
                    .Select(static item => item.ProbabilityMassCovered!.Value)
                    .DefaultIfEmpty()
                    .Max();
                var ess = group
                    .Where(static item => item.EffectiveSampleSize is not null)
                    .Select(static item => item.EffectiveSampleSize!.Value)
                    .DefaultIfEmpty()
                    .Max();
                var lows = group
                    .Where(static item => item.ConfidenceIntervalLow is not null)
                    .Select(static item => item.ConfidenceIntervalLow!.Value)
                    .ToArray();
                var highs = group
                    .Where(static item => item.ConfidenceIntervalHigh is not null)
                    .Select(static item => item.ConfidenceIntervalHigh!.Value)
                    .ToArray();
                var rngVector = group
                    .Where(static item => item.RngConsumptionVector is not null)
                    .SelectMany(static item => item.RngConsumptionVector!)
                    .GroupBy(static item => item.Key, StringComparer.Ordinal)
                    .ToImmutableDictionary(
                        static item => item.Key,
                        static item => item.Sum(entry => entry.Value),
                        StringComparer.Ordinal);
                var quality = group
                    .Select(static item => item.OutcomeQuality)
                    .OrderByDescending(OutcomeQualityRank)
                    .FirstOrDefault() ?? first.OutcomeQuality;
                return first with
                {
                    Probability = probability,
                    ProbabilityKnown = known,
                    Kind = kind,
                    OutcomeQuality = known && kind == OutcomeKind.Deterministic ? "Exact" : quality,
                    ProbabilityMassCovered = group.Any(static item => item.ProbabilityMassCovered is not null)
                        ? coverage : null,
                    EffectiveSampleSize = group.Any(static item => item.EffectiveSampleSize is not null)
                        ? ess : null,
                    ConfidenceIntervalLow = lows.Length == 0 ? null : lows.Min(),
                    ConfidenceIntervalHigh = highs.Length == 0 ? null : highs.Max(),
                    RngConsumptionVector = rngVector.Count == 0 ? null : rngVector
                };
            })
            .ToArray();
    }

    private static int OutcomeQualityRank(string quality) => quality switch
    {
        "Uncalculable" => 4,
        "Sampled" => 3,
        "Estimated" => 2,
        "Exact" => 1,
        _ => 0
    };

    private static ImmutableDictionary<string, long>? MergeRngVectors(
        IEnumerable<ChanceBranch<TState>> branches)
    {
        var merged = branches
            .Where(static branch => branch.RngConsumptionVector is not null)
            .SelectMany(static branch => branch.RngConsumptionVector!)
            .GroupBy(static pair => pair.Key, StringComparer.Ordinal)
            .ToImmutableDictionary(
                static group => group.Key,
                static group => group.Max(static pair => pair.Value),
                StringComparer.Ordinal);
        return merged.Count == 0 ? null : merged;
    }

    private static ChanceBranch<TState>[] StratifiedSample(
        ChanceBranch<TState>[] branches,
        int sampleCount,
        decimal totalMass,
        ulong seed)
    {
        var cumulative = new decimal[branches.Length];
        var running = 0m;
        for (var index = 0; index < branches.Length; index++)
        {
            running += Math.Max(0m, branches[index].Probability);
            cumulative[index] = running;
        }

        var result = new ChanceBranch<TState>[sampleCount];
        var rng = seed;
        for (var sample = 0; sample < sampleCount; sample++)
        {
            var jitter = NextUnit(ref rng);
            var target = totalMass * (sample + (decimal)jitter) / sampleCount;
            var index = Array.BinarySearch(cumulative, target);
            if (index < 0) index = ~index;
            if (index >= branches.Length) index = branches.Length - 1;
            result[sample] = branches[index] with
            {
                OutcomeQuality = "Sampled",
                ProbabilityMassCovered = totalMass,
                EffectiveSampleSize = sampleCount,
                ConfidenceIntervalLow = null,
                ConfidenceIntervalHigh = null
            };
        }
        return result;
    }

    private static double NextUnit(ref ulong state)
    {
        state += 0x9E3779B97F4A7C15UL;
        var z = state;
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
        z ^= z >> 31;
        return (z >> 11) * (1.0 / (1UL << 53));
    }

    private static PredictionConfidence Worse(
        PredictionConfidence left,
        PredictionConfidence right) =>
        (PredictionConfidence)Math.Max((int)left, (int)right);

    private sealed record NodeValue<T>(
        decimal Value,
        ImmutableArray<T> Actions,
        PredictionConfidence Confidence);
}
