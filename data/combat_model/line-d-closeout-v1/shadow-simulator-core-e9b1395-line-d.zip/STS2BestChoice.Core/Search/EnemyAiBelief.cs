using System.Collections.Immutable;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using STS2BestChoice.Core.Model;

namespace STS2BestChoice.Core.Search;

/// <summary>
/// Public/NOSL belief about enemy behavior.  Visible current intents are kept
/// separately from future outcomes so a hidden future AI choice cannot be
/// treated as a deterministic action.  No raw RNG state or hidden move index
/// is represented here.
/// </summary>
public sealed record EnemyAiBelief(
    ImmutableArray<CreatureState> VisibleEnemies,
    ImmutableArray<EnemyIntentForecastOutcome> FutureOutcomes,
    RngAvailability RngAvailability,
    PredictionConfidence Confidence,
    ImmutableArray<RestrictionReason> Restrictions = default)
{
    public ImmutableArray<CreatureState> SafeVisibleEnemies =>
        VisibleEnemies.IsDefault ? ImmutableArray<CreatureState>.Empty : VisibleEnemies;

    public ImmutableArray<EnemyIntentForecastOutcome> SafeFutureOutcomes =>
        FutureOutcomes.IsDefault ? ImmutableArray<EnemyIntentForecastOutcome>.Empty : FutureOutcomes;

    public ImmutableArray<RestrictionReason> SafeRestrictions =>
        Restrictions.IsDefault ? ImmutableArray<RestrictionReason>.Empty : Restrictions;

    public string BeliefSignature()
    {
        var builder = new StringBuilder();
        foreach (var enemy in SafeVisibleEnemies.OrderBy(static item => item.Id, StringComparer.Ordinal))
            AppendEnemy(builder, enemy);

        foreach (var outcome in SafeFutureOutcomes.OrderBy(static item => item.Label, StringComparer.Ordinal))
        {
            builder.Append(outcome.Label).Append(':')
                .Append(outcome.Probability.ToString(CultureInfo.InvariantCulture)).Append(':')
                .Append(outcome.Forecast.Confidence).Append('{');
            foreach (var enemy in outcome.Forecast.Enemies.OrderBy(static item => item.Id, StringComparer.Ordinal))
                AppendEnemy(builder, enemy);
            foreach (var restriction in outcome.Forecast.SafeRestrictions
                         .OrderBy(static item => item.Code, StringComparer.Ordinal))
                builder.Append(restriction.Code).Append(';');
            builder.Append("}|");
        }
        foreach (var restriction in SafeRestrictions.OrderBy(static item => item.Code, StringComparer.Ordinal))
            builder.Append(restriction.Code).Append(';');
        builder.Append(RngAvailability).Append('|').Append(Confidence);
        return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(builder.ToString())));
    }

    private static void AppendEnemy(StringBuilder builder, CreatureState enemy)
    {
        builder.Append(enemy.Id).Append('|')
            .Append(enemy.Hp.ToString(CultureInfo.InvariantCulture)).Append('|')
            .Append(enemy.Block.ToString(CultureInfo.InvariantCulture)).Append('|')
            .Append(enemy.IsHittable ? '1' : '0')
            .Append(enemy.IsPrimaryEnemy ? '1' : '0')
            .Append(enemy.IsSecondaryEnemy ? '1' : '0')
            .Append(enemy.IsMinion ? '1' : '0').Append('|');
        foreach (var restriction in enemy.SafeTargetRestrictions.Order(StringComparer.Ordinal))
            builder.Append(restriction).Append(';');
        if (enemy.PublicAi is { } publicAi)
        {
            builder.Append('|').Append(publicAi.FirstObservedRound).Append(':')
                .Append(publicAi.LastObservedRound).Append(':')
                .Append(publicAi.ObservedTurns).Append(':')
                .Append(publicAi.Phase).Append(':');
            foreach (var observedIntent in publicAi.SafeIntentHistory)
                builder.Append(observedIntent).Append(';');
        }
        builder.Append('|');
        foreach (var intent in enemy.Intents)
            builder.Append(intent.Type).Append(':')
                .Append(intent.DamagePerHit.ToString(CultureInfo.InvariantCulture)).Append(':')
                .Append(intent.Hits).Append(';');
        builder.Append('#');
    }

    public static EnemyAiBelief FromForecast(
        ImmutableArray<CreatureState> visibleEnemies,
        ImmutableArray<EnemyIntentForecastOutcome> outcomes,
        RngAvailability rngAvailability = RngAvailability.MaskedUnknown)
    {
        var safeOutcomes = outcomes.IsDefault ? ImmutableArray<EnemyIntentForecastOutcome>.Empty : outcomes;
        var confidence = safeOutcomes.Length == 0
            ? PredictionConfidence.Uncalculable
            : safeOutcomes.Max(static outcome => outcome.Forecast.Confidence);
        var restrictions = safeOutcomes
            .SelectMany(static outcome => outcome.Forecast.SafeRestrictions)
            .Distinct()
            .ToImmutableArray();
        var mass = safeOutcomes.Sum(static outcome => outcome.Probability);
        if (safeOutcomes.Length > 0 && mass < 0.999999m)
        {
            confidence = (PredictionConfidence)Math.Max((int)confidence, (int)PredictionConfidence.Estimated);
            restrictions = restrictions.Add(new RestrictionReason(
                "incomplete_future_intent_probability",
                $"未来敌方意图概率质量仅覆盖 {mass:P2}。"));
        }
        else if (mass > 1.000001m)
        {
            confidence = PredictionConfidence.Uncalculable;
            restrictions = restrictions.Add(new RestrictionReason(
                "invalid_future_intent_probability",
                $"未来敌方意图概率质量为 {mass:P2}，超过 100%。"));
        }
        return new EnemyAiBelief(visibleEnemies, safeOutcomes, rngAvailability, confidence, restrictions);
    }
}
