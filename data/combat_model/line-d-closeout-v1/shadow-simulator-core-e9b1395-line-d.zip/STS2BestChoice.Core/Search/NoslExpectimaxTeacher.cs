using System.Collections.Immutable;
using STS2BestChoice.Core.Model;

namespace STS2BestChoice.Core.Search;

/// <summary>Provides all public-information chance outcomes for a NOSL action.</summary>
public interface ChanceDistributionProvider<TState, in TAction>
{
    ImmutableArray<ChanceBranch<TState>> Outcomes(TState state, TAction action);
}

/// <summary>Produces a cache key that contains only observable belief state.</summary>
public interface BeliefStateKeyProvider<in TState>
{
    string Key(TState state);
}

public sealed record NoslExpectimaxOptions(
    int TopK = 5,
    int MaximumExpandedNodes = 100_000_000,
    TimeSpan? OfflineBudget = null,
    int MaximumActions = 64,
    int MaximumChanceBranches = 100_000_000,
    int ChanceSampleCount = 32,
    long MaximumStateBytes = 8L * 1024 * 1024 * 1024)
{
    public bool IsUnboundedOffline => OfflineBudget is null;
}

public sealed record NoslTeacherResult(
    SearchResults Search,
    ImmutableArray<ActionLine> TopBalanced,
    ImmutableArray<ActionLine> TopHighestDamage,
    ImmutableArray<ActionLine> TopMinimumLoss,
    string BeliefSignature,
    bool IsComplete,
    PredictionConfidence Confidence,
    long ExpandedNodes);

/// <summary>
/// Offline NOSL teacher facade. It enforces unknown RNG streams and unordered
/// future piles before delegating action expansion to the existing simulator.
/// The complete probability distribution is handled by the simulator's chance
/// transitions; no realized RNG outcome is selected here.
/// </summary>
public sealed class NoslExpectimaxTeacher
{
    public NoslTeacherResult Solve(CombatSnapshot publicSnapshot, NoslExpectimaxOptions? options = null)
    {
        var effective = options ?? new NoslExpectimaxOptions();
        var search = Search(publicSnapshot, effective);
        var belief = search.Progress.SnapshotFingerprint;
        var balanced = search.Balanced.IsDefaultOrEmpty ? search.EstimatedBalanced : search.Balanced;
        var damage = search.HighestDamage.IsDefaultOrEmpty ? search.EstimatedHighestDamage : search.HighestDamage;
        var loss = search.MinimumLoss.IsDefaultOrEmpty ? search.EstimatedMinimumLoss : search.MinimumLoss;
        var confidence = balanced.IsDefaultOrEmpty
            ? PredictionConfidence.Uncalculable
            : balanced.Max(static line => line.Confidence);
        return new NoslTeacherResult(
            search,
            balanced.Take(effective.TopK).ToImmutableArray(),
            damage.Take(effective.TopK).ToImmutableArray(),
            loss.Take(effective.TopK).ToImmutableArray(),
            belief,
            search.Progress.IsComplete,
            confidence,
            search.Progress.ExpandedNodes);
    }

    public SearchResults Search(CombatSnapshot publicSnapshot, NoslExpectimaxOptions? options = null)
    {
        ArgumentNullException.ThrowIfNull(publicSnapshot);
        if (publicSnapshot.View != ObservationView.Public)
            throw new ArgumentException("NOSL teacher input must use ObservationView.Public.", nameof(publicSnapshot));
        var effective = options ?? new NoslExpectimaxOptions();
        if (effective.TopK <= 0 || effective.MaximumExpandedNodes <= 0 || effective.MaximumActions <= 0 ||
            effective.MaximumChanceBranches <= 0 || effective.ChanceSampleCount <= 0)
            throw new ArgumentOutOfRangeException(nameof(options));
        if (effective.MaximumStateBytes <= 0)
            throw new ArgumentOutOfRangeException(nameof(options));

        var beliefSnapshot = MaskHiddenState(publicSnapshot);
        var searchOptions = SearchOptions.Default with
        {
            InitialBudget = effective.OfflineBudget ?? TimeSpan.FromSeconds(1),
            TopCount = effective.TopK,
            MaximumActions = effective.MaximumActions,
            MaximumExpandedNodes = effective.MaximumExpandedNodes,
            MaximumChanceBranches = effective.MaximumChanceBranches,
            ChanceSampleCount = effective.ChanceSampleCount,
            MaximumStateBytes = effective.MaximumStateBytes
        };
        var session = new CombatSearchSession(beliefSnapshot, searchOptions);
        if (!effective.IsUnboundedOffline)
            return session.Continue(effective.OfflineBudget!.Value);

        SearchResults result;
        do
        {
            result = session.Continue(TimeSpan.FromSeconds(1));
        }
        while (!result.Progress.IsComplete && result.Progress.StopReason == SearchStopReason.BudgetSlice);
        return result;
    }

    public static CombatSnapshot MaskHiddenState(CombatSnapshot source)
    {
        var belief = NoslBeliefState.FromPublicSnapshot(source);
        var unorderedPool = source.DrawPile
            .OrderBy(card => card.ModelId, StringComparer.Ordinal)
            .ThenBy(card => card.InstanceId, StringComparer.Ordinal)
            .ToImmutableArray();
        return source with
        {
            Fingerprint = belief.BeliefSignature,
            // DrawPile carries canonical unordered content across the immutable
            // snapshot boundary. MutableCombatState moves it into its dedicated
            // UnorderedDrawPool when it sees the marker below.
            DrawPile = unorderedPool,
            DiscardPile = source.DiscardPile,
            ExhaustPile = ImmutableArray<CardState>.Empty,
            RngState = 0,
            RngStreams = null,
            View = ObservationView.Public,
            RngAvailability = RngAvailability.MaskedUnknown,
            NoslBelief = belief,
            Provenance = source.Provenance is null
                ? null
                : source.Provenance with { View = ObservationView.Public },
            GlobalRestrictions = source.GlobalRestrictions.Contains(
                "nosl_unordered_draw_pool", StringComparer.Ordinal)
                ? source.GlobalRestrictions
                : source.GlobalRestrictions.Add("nosl_unordered_draw_pool")
        };
    }
}
