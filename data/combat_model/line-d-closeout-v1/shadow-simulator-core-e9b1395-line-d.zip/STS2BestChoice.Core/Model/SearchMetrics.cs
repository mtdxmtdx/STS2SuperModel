namespace STS2BestChoice.Core.Model;

public sealed record SearchMetrics(
    long ExpandedNodes,
    long ChanceBranchesGenerated,
    long ChanceBranchesPruned,
    long TranspositionHits,
    long TranspositionMisses,
    long StatesCloned,
    long StateKeysBuilt,
    long EnemyTurnProjections,
    TimeSpan CpuTime,
    long AllocatedBytes,
    int Gen0Collections,
    int Gen1Collections,
    int Gen2Collections)
{
    public decimal BytesPerNode =>
        ExpandedNodes == 0 ? 0m : (decimal)AllocatedBytes / ExpandedNodes;

    public static SearchMetrics Empty { get; } = new(
        0, 0, 0, 0, 0, 0, 0, 0,
        TimeSpan.Zero, 0, 0, 0, 0);
}
