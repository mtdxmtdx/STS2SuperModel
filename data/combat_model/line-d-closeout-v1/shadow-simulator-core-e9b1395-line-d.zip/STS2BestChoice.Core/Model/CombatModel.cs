using System.Collections.Immutable;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace STS2BestChoice.Core.Model;

public enum TargetKind
{
    None,
    Self,
    Companion,
    Enemy,
    AllEnemies
}

public enum CardDestination
{
    Discard,
    Exhaust,
    Remove,
    DrawPileTop,
    Hand
}

public enum EvidenceLevel
{
    Unknown,
    HeuristicInferred,
    WikiText,
    OfficialPatchNote,
    LiveObserved,
    ILConfirmed
}

public enum ObservationView
{
    Public,
    Teacher
}

public enum RngAvailability
{
    Known,
    MaskedUnknown,
    Missing
}

public enum SemanticSupportStatus
{
    Unknown,
    StateCapturedOnly,
    PartiallySupported,
    SimulatorSupported,
    NoCombatEffect,
    UnsupportedKnownEffect
}

public enum GeneratedCardDestination
{
    Hand,
    DrawPile,
    DiscardPile
}

public enum EffectKind
{
    Damage,
    DynamicDamage,
    LoseEnemyHp,
    RandomEnemyDamage,
    RandomEnemyStatus,
    StunEnemy,
    Outbreak,
    RandomEnemyAttackByExhaustedCount,
    LoseHp,
    Block,
    DynamicBlock,
    Heal,
    HealPercent,
    GainEnergy,
    ModifyMaxHp,
    ScheduleCurrentBlock,
    Draw,
    DrawToHandSize,
    DrawUntilNonAttack,
    DiscardDrawnNonZeroCost,
    ApplyStatus,
    MultiplyStatus,
    RemoveStatus,
    DiscardCards,
    ExhaustCards,
    ExhaustStatusCards,
    RandomExhaustCards,
    RandomExhaustAttackAndGrow,
    DiscardHand,
    ExhaustHand,
    ExhaustNonAttacksAndBlock,
    GenerateCards,
    GenerateRandomCards,
    AutoPlayFromDrawPile,
    AutoPlayShivsFromExhaust,
    AutoPlaySelfFromPile,
    AutoPlayEtherealFromExhaust,
    CopyPlayedCard,
    CopyChosenHandCard,
    ModifySelectedHandCard,
    ChannelOrbs,
    EvokeOrbs,
    TriggerOrbPassives,
    ModifyOrbCapacity,
    ModifyHandCosts,
    CapHandCosts,
    ModifyPlayedCardCost,
    ModifyPlayedCardDamage,
    ModifyPlayedCardBlock,
    ClearEnemyBlockAndArtifact,
    ChooseDrawToHand,
    ChooseDrawToExhaust,
    ChooseDiscardToHand,
    ChooseDiscardToDrawTop,
    ChooseHandToDrawTop,
    MoveAllZeroCostDiscardToHand,
    MoveRandomRareDrawToHand,
    DiscardHandThenDrawSame,
    Reboot,
    DiscardHandAndGenerate,
    ReturnSelfToHandAfterSkills,
    PlayRestriction,
    KillAllDoomedEnemies,
    UpgradeCards,
    MoveKingsBladeToHand,
    RetainHand,
    TransformCards,
    Summon,
    CompanionDamage,
    KillCompanion,
    DelayedReturnSelfToHand,
    Forge,
    GenerateRandomPotion,
    EndTurn
}

public sealed record StatusState(
    string Id,
    int Amount,
    int Duration = -1,
    bool IsDebuff = false,
    decimal FutureValuePerTurn = 0m,
    CardState? GeneratedCard = null,
    string? RandomSource = null);

public sealed record PowerState(
    string Id,
    string OwnerId,
    string? ApplierId,
    decimal Amount = 0m,
    ImmutableDictionary<string, string>? DynamicVars = null,
    ImmutableDictionary<string, decimal>? Counters = null,
    ImmutableArray<string> TriggerPhases = default,
    string? SourceId = null,
    SemanticSupportStatus Support = SemanticSupportStatus.Unknown,
    EvidenceLevel Evidence = EvidenceLevel.Unknown,
    string? SourceVersion = null)
{
    public ImmutableDictionary<string, string> SafeDynamicVars =>
        DynamicVars ?? ImmutableDictionary<string, string>.Empty;

    public ImmutableDictionary<string, decimal> SafeCounters =>
        Counters ?? ImmutableDictionary<string, decimal>.Empty;

    public ImmutableArray<string> SafeTriggerPhases =>
        TriggerPhases.IsDefault ? ImmutableArray<string>.Empty : TriggerPhases;
}

public sealed record SnapshotProvenance(
    string GameVersion,
    string? GameCommit,
    string? AssemblySha256,
    string CliProtocolVersion,
    string SimulatorVersion,
    int SchemaVersion = 1,
    ObservationView View = ObservationView.Public,
    string? CaptureSource = null,
    string? SemanticDatabaseVersion = null,
    string? ScorerVersion = null,
    string? FeatureSchemaVersion = null,
    string? ModelVersion = null);

/// <summary>
/// Public-information belief input for NOSL teacher evaluation. Concrete RNG
/// words, future pile order and realized hidden outcomes are deliberately not
/// represented by this type.
/// </summary>
public sealed record NoslBeliefState(
    string PublicStateHash,
    ImmutableArray<(string ModelId, int Count)> KnownDeckComposition,
    ImmutableArray<(string ModelId, int Count)> RemainingCardMultiset,
    ImmutableArray<string> KnownHandInstanceIds,
    ImmutableArray<string> VisibleRelicIds,
    ImmutableArray<string> VisiblePowerIds,
    ImmutableDictionary<string, string> PublicHistory,
    ImmutableDictionary<string, string> RandomEffectDistributions,
    int Round,
    int Energy,
    int MaxEnergy,
    string BeliefSignature,
    int SchemaVersion = 1)
{
    public ImmutableArray<(string ModelId, int Count)> SafeKnownDeckComposition =>
        KnownDeckComposition.IsDefault ? ImmutableArray<(string ModelId, int Count)>.Empty : KnownDeckComposition;

    public ImmutableArray<(string ModelId, int Count)> SafeRemainingCardMultiset =>
        RemainingCardMultiset.IsDefault ? ImmutableArray<(string ModelId, int Count)>.Empty : RemainingCardMultiset;

    public ImmutableArray<string> SafeKnownHandInstanceIds =>
        KnownHandInstanceIds.IsDefault ? ImmutableArray<string>.Empty : KnownHandInstanceIds;

    public ImmutableArray<string> SafeVisibleRelicIds =>
        VisibleRelicIds.IsDefault ? ImmutableArray<string>.Empty : VisibleRelicIds;

    public ImmutableArray<string> SafeVisiblePowerIds =>
        VisiblePowerIds.IsDefault ? ImmutableArray<string>.Empty : VisiblePowerIds;

    /// <summary>
    /// Builds a belief from a public-view snapshot without reading ordered
    /// piles, RNG words, or any other teacher-only field.
    /// </summary>
    public static NoslBeliefState FromPublicSnapshot(CombatSnapshot source)
    {
        ArgumentNullException.ThrowIfNull(source);
        if (source.View != ObservationView.Public)
            throw new ArgumentException("NOSL belief construction requires a public-view snapshot.", nameof(source));
        var allCards = source.Hand
            .Concat(source.DrawPile)
            .Concat(source.DiscardPile)
            .ToArray();
        var deckCounts = allCards
            .GroupBy(static card => card.ModelId, StringComparer.Ordinal)
            .OrderBy(static group => group.Key, StringComparer.Ordinal)
            .Select(static group => (ModelId: group.Key, Count: group.Count()))
            .ToImmutableArray();
        var handCounts = source.Hand
            .GroupBy(static card => card.ModelId, StringComparer.Ordinal)
            .ToDictionary(static group => group.Key, static group => group.Count(), StringComparer.Ordinal);
        var remaining = deckCounts
            .Select(item => (ModelId: item.ModelId, Count: item.Count - handCounts.GetValueOrDefault(item.ModelId)))
            .Where(static item => item.Count > 0)
            .ToImmutableArray();
        var history = source.HistoryCounters ?? new CombatHistoryCounters();
        var publicHistory = ImmutableDictionary<string, string>.Empty
            .Add("attacks_played_this_turn", history.AttacksPlayedThisTurn.ToString(CultureInfo.InvariantCulture))
            .Add("skills_played_this_turn", history.SkillsPlayedThisTurn.ToString(CultureInfo.InvariantCulture))
            .Add("cards_played_this_turn", history.CardsPlayedThisTurn.ToString(CultureInfo.InvariantCulture))
            .Add("cards_drawn_this_turn", history.CardsDrawnThisTurn.ToString(CultureInfo.InvariantCulture))
            .Add("cards_discarded_this_turn", history.CardsDiscardedThisTurn.ToString(CultureInfo.InvariantCulture))
            .Add("cards_exhausted_this_turn", history.CardsExhaustedThisTurn.ToString(CultureInfo.InvariantCulture));

        var canonical = new StringBuilder();
        static void Add(StringBuilder builder, string value) => builder.Append(value.Length).Append(':').Append(value).Append('|');
        static void AddNumber(StringBuilder builder, decimal value) => Add(builder, value.ToString(CultureInfo.InvariantCulture));
        Add(canonical, "nosl-v1");
        Add(canonical, source.Round.ToString(CultureInfo.InvariantCulture));
        AddNumber(canonical, source.Player.Hp);
        AddNumber(canonical, source.Player.MaxHp);
        AddNumber(canonical, source.Player.Block);
        Add(canonical, source.Player.Energy.ToString(CultureInfo.InvariantCulture));
        Add(canonical, source.Player.MaxEnergy.ToString(CultureInfo.InvariantCulture));
        foreach (var status in source.Player.Statuses.OrderBy(static pair => pair.Key, StringComparer.Ordinal))
        {
            Add(canonical, $"ps:{status.Key}:{status.Value.Amount}:{status.Value.Duration}:{status.Value.IsDebuff}");
        }
        foreach (var enemy in source.Enemies.OrderBy(static enemy => enemy.Id, StringComparer.Ordinal))
        {
            Add(canonical, $"enemy:{enemy.Id}:{enemy.Hp.ToString(CultureInfo.InvariantCulture)}:{enemy.Block.ToString(CultureInfo.InvariantCulture)}");
            Add(canonical, $"target:{enemy.Id}:{enemy.IsHittable}:{enemy.IsPrimaryEnemy}:{enemy.IsSecondaryEnemy}:{enemy.IsMinion}:{string.Join(',', enemy.SafeTargetRestrictions.Order(StringComparer.Ordinal))}");
            if (enemy.PublicAi is { } publicAi)
            {
                Add(canonical, $"enemy_ai:{enemy.Id}:{publicAi.FirstObservedRound}:{publicAi.LastObservedRound}:{publicAi.ObservedTurns}:{publicAi.Phase}");
                foreach (var observedIntent in publicAi.SafeIntentHistory)
                    Add(canonical, $"enemy_ai_intent:{enemy.Id}:{observedIntent}");
            }
            foreach (var status in enemy.Statuses.OrderBy(static pair => pair.Key, StringComparer.Ordinal))
                Add(canonical, $"es:{enemy.Id}:{status.Key}:{status.Value.Amount}:{status.Value.Duration}:{status.Value.IsDebuff}");
            foreach (var intent in enemy.Intents)
                Add(canonical, $"intent:{enemy.Id}:{intent.Type}:{intent.DamagePerHit.ToString(CultureInfo.InvariantCulture)}:{intent.Hits}");
        }
        foreach (var card in source.Hand)
            Add(canonical, $"hand:{card.InstanceId}:{card.ModelId}:{card.EnergyCost}:{card.IsUpgraded}");
        foreach (var item in deckCounts)
            Add(canonical, $"deck:{item.ModelId}:{item.Count}");
        foreach (var item in source.DrawPile
                     .GroupBy(static card => card.ModelId, StringComparer.Ordinal)
                     .OrderBy(static group => group.Key, StringComparer.Ordinal))
            Add(canonical, $"draw:{item.Key}:{item.Count()}");
        foreach (var item in source.DiscardPile
                     .GroupBy(static card => card.ModelId, StringComparer.Ordinal)
                     .OrderBy(static group => group.Key, StringComparer.Ordinal))
            Add(canonical, $"discard:{item.Key}:{item.Count()}");
        foreach (var relic in source.SafeRelics.OrderBy(static relic => relic.Id, StringComparer.Ordinal))
            Add(canonical, $"relic:{relic.Id}:{relic.Counter}:{relic.IsEnabled}:{relic.IsUsedUp}:{relic.UsesThisTurn}:{relic.UsesThisCombat}");
        foreach (var power in source.SafePowers.OrderBy(static power => power.OwnerId, StringComparer.Ordinal).ThenBy(static power => power.Id, StringComparer.Ordinal))
            Add(canonical, $"power:{power.OwnerId}:{power.Id}:{power.ApplierId}:{power.Amount.ToString(CultureInfo.InvariantCulture)}");
        foreach (var item in publicHistory.OrderBy(static pair => pair.Key, StringComparer.Ordinal))
            Add(canonical, $"history:{item.Key}:{item.Value}");
        var signature = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(canonical.ToString())));
        return new NoslBeliefState(
            signature,
            deckCounts,
            remaining,
            source.Hand.Select(static card => card.InstanceId).ToImmutableArray(),
            source.SafeRelics.Select(static relic => relic.Id).Order(StringComparer.Ordinal).ToImmutableArray(),
            source.SafePowers.Select(static power => power.Id).Order(StringComparer.Ordinal).ToImmutableArray(),
            publicHistory,
            ImmutableDictionary<string, string>.Empty,
            source.Round,
            source.Player.Energy,
            source.Player.MaxEnergy,
            signature);
    }
}

/// <summary>
/// An occupied orb slot captured after live modifiers (including Focus) have
/// been applied. The shadow state keeps order because overflow evokes first.
/// </summary>
public sealed record OrbState(
    string Id,
    decimal PassiveValue,
    decimal EvokeValue,
    decimal FocusAdjustment = 0m)
{
    public decimal EffectivePassiveValue => Id.ToUpperInvariant() switch
    {
        "LIGHTNING" or "FROST" or "DARK" => Math.Max(0m, PassiveValue + FocusAdjustment),
        _ => PassiveValue
    };

    public decimal EffectiveEvokeValue => Id.ToUpperInvariant() switch
    {
        "LIGHTNING" or "FROST" => Math.Max(0m, EvokeValue + FocusAdjustment),
        _ => EvokeValue
    };
}

public sealed record EffectSpec(
    EffectKind Kind,
    decimal Amount = 0m,
    string? StatusId = null,
    int Duration = -1,
    bool IsDebuff = false,
    decimal FutureValuePerTurn = 0m,
    string? SourceId = null,
    string? UnsupportedReason = null,
    CardState? GeneratedCard = null,
    TargetKind? TargetOverride = null,
    string? Condition = null,
    GeneratedCardDestination GeneratedDestination = GeneratedCardDestination.Hand,
    int Repeat = 1,
    bool RepeatByEnergySpent = false,
    bool RepeatByOrbCount = false,
    int XBonus = 0,
    bool AmountByEnergySpent = false,
    bool AmountByAliveEnemyCount = false,
    bool AmountByDistinctOrbTypes = false,
    bool AmountByHandAttackCount = false,
    bool AmountByCardsDrawnThisTurn = false,
    bool RepeatByHistoryCounter = false,
    bool RepeatByKillCount = false,
    bool AmountByTargetVulnerableStacks = false,
    bool RepeatByExhaustedCount = false,
    string? RandomSource = null,
    ImmutableArray<CardState> GeneratedCardPool = default,
    bool RandomizeGeneratedPosition = false,
    bool RandomSelectionWithReplacement = false);

public sealed record CardState(
    string InstanceId,
    string ModelId,
    string Name,
    int EnergyCost,
    TargetKind Target,
    ImmutableArray<EffectSpec> Effects,
    CardDestination Destination = CardDestination.Discard,
    decimal PriorityHint = 0m,
    bool IsPlayable = true,
    string? RestrictionReason = null,
    ImmutableArray<ChoiceSpec> Choices = default,
    string? CardType = null,
    bool RetainAtTurnEnd = false,
    bool ExhaustAtTurnEnd = false,
    int EnergyChangeOnDraw = 0,
    decimal HpLossAtTurnEnd = 0m,
    bool CostsX = false,
    bool IsDupe = false,
    int ReplayCount = 0,
    bool IsColorless = false,
    int BaseEnergyCost = 0,
    int EnergyCostChangeOnDraw = 0,
    decimal DamageChangeOnDraw = 0m,
    decimal CombatDamageBonus = 0m,
    bool TemporaryRetainAtTurnEnd = false,
    ImmutableArray<EffectSpec> TurnEndInHandEffects = default,
    bool FreeUntilTurnEnd = false,
    bool FreeThisCombat = false,
    int? TemporaryEnergyCostBeforeCap = null,
    bool? TemporaryCostsXBeforeOverride = null,
    string? Rarity = null,
    decimal CombatBlockBonus = 0m,
    bool IsUpgraded = false)
{
    public ImmutableArray<ChoiceSpec> SafeChoices =>
        Choices.IsDefault ? ImmutableArray<ChoiceSpec>.Empty : Choices;

    public ImmutableArray<EffectSpec> SafeTurnEndInHandEffects =>
        TurnEndInHandEffects.IsDefault ? ImmutableArray<EffectSpec>.Empty : TurnEndInHandEffects;
}

public sealed record PotionState(
    string InstanceId,
    string ModelId,
    string Name,
    TargetKind Target,
    ImmutableArray<EffectSpec> Effects,
    decimal OpportunityCost,
    decimal? PriorityHint = 0m,
    bool IsUsable = true,
    string? RestrictionReason = null);

public sealed record ChoiceSpec(
    string Id,
    string Label,
    ImmutableArray<EffectSpec> Effects,
    string? CardInstanceId = null,
    string? RestrictionReason = null,
    ImmutableArray<string> CardInstanceIds = default)
{
    public ImmutableArray<string> SelectedCardInstanceIds =>
        CardInstanceIds.IsDefaultOrEmpty
            ? CardInstanceId is { Length: > 0 } id ? [id] : []
            : CardInstanceIds;
}

public sealed record IntentState(
    string Type,
    decimal DamagePerHit = 0m,
    int Hits = 0,
    ImmutableArray<EffectSpec> Effects = default,
    string? RestrictionReason = null)
{
    public ImmutableArray<EffectSpec> SafeEffects =>
        Effects.IsDefault ? ImmutableArray<EffectSpec>.Empty : Effects;
}

/// <summary>
/// Enemy AI information reconstructed only from public observations. It does
/// not contain MonsterAi RNG, internal state-machine nodes, or runtime logs.
/// One intent signature is recorded per observed combat round.
/// </summary>
public sealed record EnemyAiPublicState(
    int FirstObservedRound,
    int LastObservedRound,
    int ObservedTurns,
    string Phase,
    ImmutableArray<string> IntentHistory = default)
{
    public ImmutableArray<string> SafeIntentHistory =>
        IntentHistory.IsDefault ? ImmutableArray<string>.Empty : IntentHistory;
}

public sealed record CreatureState(
    string Id,
    string Name,
    decimal Hp,
    decimal MaxHp,
    decimal Block,
    ImmutableDictionary<string, StatusState> Statuses,
    ImmutableArray<IntentState> Intents,
    decimal ThreatPerFutureTurn = 0m,
    bool IsHittable = true,
    bool IsPrimaryEnemy = true,
    bool IsSecondaryEnemy = false,
    bool IsMinion = false,
    ImmutableArray<string> TargetRestrictions = default,
    EnemyAiPublicState? PublicAi = null)
{
    public bool IsAlive => Hp > 0m;
    public ImmutableArray<string> SafeTargetRestrictions =>
        TargetRestrictions.IsDefault ? ImmutableArray<string>.Empty : TargetRestrictions;
}

public sealed record PlayerState(
    decimal Hp,
    decimal MaxHp,
    decimal Block,
    int Energy,
    int MaxEnergy,
    ImmutableDictionary<string, StatusState> Statuses,
    int CardsPerTurn = 5);

public sealed record CombatHistoryCounters(
    int AttacksPlayedThisTurn = 0,
    int SkillsPlayedThisTurn = 0,
    int CardsPlayedThisCombat = 0,
    int EtherealCardsPlayedThisCombat = 0,
    int CardsDrawnThisCombat = 0,
    int CardsDrawnThisTurn = 0,
    int CardsGeneratedThisCombat = 0,
    int StatusCardsDrawnThisTurn = 0,
    int CardsExhaustedThisTurn = 0,
    int BlockGainedThisTurn = 0,
    int CardsPlayedThisTurn = 0,
    int CardsDiscardedThisTurn = 0,
    int ShivsPlayedThisTurn = 0,
    int DamageReceivedEventsThisCombat = 0,
    int PowersPlayedThisTurn = 0);

public sealed record CombatSnapshot(
    string Fingerprint,
    PlayerState Player,
    ImmutableArray<CreatureState> Enemies,
    ImmutableArray<CardState> Hand,
    ImmutableArray<CardState> DrawPile,
    ImmutableArray<CardState> DiscardPile,
    ImmutableArray<CardState> ExhaustPile,
    ImmutableArray<PotionState> Potions,
    ulong RngState,
    int Round,
    bool IsBoss,
    ImmutableArray<string> GlobalRestrictions,
    RngSnapshotSet? RngStreams = null,
    ImmutableArray<OrbState> Orbs = default,
    int OrbCapacity = 0,
    CombatHistoryCounters? HistoryCounters = null,
    ImmutableArray<RelicState> Relics = default,
    ImmutableArray<PowerState> Powers = default,
    SnapshotProvenance? Provenance = null,
    ObservationView View = ObservationView.Public,
    NoslBeliefState? NoslBelief = null,
    RngAvailability RngAvailability = RngAvailability.MaskedUnknown)
{
    public ImmutableArray<RelicState> SafeRelics =>
        Relics.IsDefault ? ImmutableArray<RelicState>.Empty : Relics;

    public ImmutableArray<PowerState> SafePowers =>
        Powers.IsDefault ? ImmutableArray<PowerState>.Empty : Powers;

    public static CombatSnapshot Create(
        string fingerprint,
        PlayerState player,
        IEnumerable<CreatureState> enemies,
        IEnumerable<CardState> hand,
        IEnumerable<CardState>? drawPile = null,
        IEnumerable<CardState>? discardPile = null,
        IEnumerable<CardState>? exhaustPile = null,
        IEnumerable<PotionState>? potions = null,
        ulong rngState = 1,
        RngSnapshotSet? rngStreams = null,
        int round = 1,
        bool isBoss = false,
        IEnumerable<string>? globalRestrictions = null,
        IEnumerable<OrbState>? orbs = null,
        int orbCapacity = 0,
        CombatHistoryCounters? historyCounters = null,
        IEnumerable<RelicState>? relics = null,
        IEnumerable<PowerState>? powers = null,
        SnapshotProvenance? provenance = null,
        ObservationView view = ObservationView.Public,
        RngAvailability rngAvailability = RngAvailability.MaskedUnknown) =>
        new(
            fingerprint,
            player,
            enemies.ToImmutableArray(),
            hand.ToImmutableArray(),
            (drawPile ?? []).ToImmutableArray(),
            (discardPile ?? []).ToImmutableArray(),
            (exhaustPile ?? []).ToImmutableArray(),
            (potions ?? []).ToImmutableArray(),
            rngState,
            round,
            isBoss,
            (globalRestrictions ?? []).ToImmutableArray(),
            rngStreams,
            (orbs ?? []).ToImmutableArray(),
            orbCapacity,
            historyCounters,
            (relics ?? []).ToImmutableArray(),
            (powers ?? []).ToImmutableArray(),
            provenance,
            view,
            null,
            rngAvailability);
}
