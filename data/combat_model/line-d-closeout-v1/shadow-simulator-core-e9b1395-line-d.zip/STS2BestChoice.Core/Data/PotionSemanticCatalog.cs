using System.Collections.Immutable;
using STS2BestChoice.Core.Model;

namespace STS2BestChoice.Core.Data;

public sealed record PotionSemanticMapping(
    ImmutableArray<EffectSpec> Effects,
    string? UnsupportedReason = null)
{
    public bool IsSupported => string.IsNullOrWhiteSpace(UnsupportedReason);
}

/// <summary>
/// Version-locked v0.111 potion semantics. Numeric amounts are supplied by
/// PotionModel.DynamicVars at capture time; this table only maps runtime IDs
/// and variable names to the shared deterministic effect vocabulary.
/// </summary>
public static class PotionSemanticCatalog
{
    public static PotionSemanticMapping Resolve(
        string potionId,
        IReadOnlyDictionary<string, decimal> dynamicVars)
    {
        var id = potionId.ToUpperInvariant();
        decimal V(string name) => dynamicVars.TryGetValue(name, out var value) ? value : 0m;
        bool Has(params string[] names) => names.All(dynamicVars.ContainsKey);
        EffectSpec Status(string variable, string statusId, bool debuff = false, int? duration = null) =>
            new(
                EffectKind.ApplyStatus,
                V(variable),
                statusId,
                Duration: duration ?? (statusId is "WEAK" or "VULNERABLE" ? (int)V(variable) : -1),
                IsDebuff: debuff,
                SourceId: id);
        PotionSemanticMapping Effects(params EffectSpec[] effects) => new([.. effects]);
        PotionSemanticMapping Missing(params string[] names) => new(
            [],
            $"{id} requires DynamicVars: {string.Join(", ", names)}");

        return id switch
        {
            "FIRE_POTION" => Has("Damage")
                ? Effects(new EffectSpec(EffectKind.Damage, V("Damage"), SourceId: id))
                : Missing("Damage"),
            "EXPLOSIVE_AMPOULE" or "POTION_SHAPED_ROCK" => Has("Damage")
                ? Effects(new EffectSpec(EffectKind.Damage, V("Damage"), SourceId: id))
                : Missing("Damage"),
            "BLOCK_POTION" => Has("Block")
                ? Effects(new EffectSpec(EffectKind.Block, V("Block"), SourceId: id))
                : Missing("Block"),
            "ENERGY_POTION" => Has("Energy")
                ? Effects(new EffectSpec(EffectKind.GainEnergy, V("Energy"), SourceId: id))
                : Missing("Energy"),
            "SWIFT_POTION" => Has("Cards")
                ? Effects(new EffectSpec(EffectKind.Draw, V("Cards"), SourceId: id))
                : Missing("Cards"),
            "CURE_ALL" => Has("Energy", "Cards")
                ? Effects(
                    new EffectSpec(EffectKind.GainEnergy, V("Energy"), SourceId: id),
                    new EffectSpec(EffectKind.Draw, V("Cards"), SourceId: id))
                : Missing("Energy", "Cards"),
            "GLOWWATER_POTION" => Has("Cards")
                ? Effects(
                    new EffectSpec(EffectKind.ExhaustHand, SourceId: id),
                    new EffectSpec(EffectKind.Draw, V("Cards"), SourceId: id))
                : Missing("Cards"),
            "BLESSING_OF_THE_FORGE" => Effects(
                new EffectSpec(EffectKind.UpgradeCards, StatusId: "HAND_ALL", SourceId: id)),
            "STRENGTH_POTION" => Has("StrengthPower")
                ? Effects(Status("StrengthPower", "STRENGTH"))
                : Missing("StrengthPower"),
            "DEXTERITY_POTION" => Has("DexterityPower")
                ? Effects(Status("DexterityPower", "DEXTERITY"))
                : Missing("DexterityPower"),
            "FOCUS_POTION" => Has("FocusPower")
                ? Effects(Status("FocusPower", "FOCUS"))
                : Missing("FocusPower"),
            "FYSH_OIL" => Has("StrengthPower", "DexterityPower")
                ? Effects(
                    Status("StrengthPower", "STRENGTH"),
                    Status("DexterityPower", "DEXTERITY"))
                : Missing("StrengthPower", "DexterityPower"),
            "WEAK_POTION" => Has("WeakPower")
                ? Effects(Status("WeakPower", "WEAK", debuff: true))
                : Missing("WeakPower"),
            "VULNERABLE_POTION" => Has("VulnerablePower")
                ? Effects(Status("VulnerablePower", "VULNERABLE", debuff: true))
                : Missing("VulnerablePower"),
            "POISON_POTION" => Has("PoisonPower")
                ? Effects(Status("PoisonPower", "POISON", debuff: true))
                : Missing("PoisonPower"),
            "POTION_OF_DOOM" => Has("DoomPower")
                ? Effects(Status("DoomPower", "DOOM", debuff: true))
                : Missing("DoomPower"),
            "POTION_OF_BINDING" => Has("WeakPower", "VulnerablePower")
                ? Effects(
                    Status("WeakPower", "WEAK", debuff: true),
                    Status("VulnerablePower", "VULNERABLE", debuff: true))
                : Missing("WeakPower", "VulnerablePower"),
            "LIQUID_BRONZE" => Has("ThornsPower")
                ? Effects(Status("ThornsPower", "THORNS"))
                : Missing("ThornsPower"),
            "HEART_OF_IRON" => Has("PlatingPower")
                ? Effects(Status("PlatingPower", "PLATING"))
                : Missing("PlatingPower"),
            "LUCKY_TONIC" => Has("BufferPower")
                ? Effects(Status("BufferPower", "BUFFER"))
                : Missing("BufferPower"),
            "REGEN_POTION" => Has("RegenPower")
                ? Effects(Status("RegenPower", "REGEN"))
                : Missing("RegenPower"),
            "GHOST_IN_A_JAR" => Has("IntangiblePower")
                ? Effects(Status("IntangiblePower", "INTANGIBLE", duration: (int)V("IntangiblePower")))
                : Missing("IntangiblePower"),
            "SHIP_IN_A_BOTTLE" => Has("Block")
                ? Effects(
                    new EffectSpec(EffectKind.Block, V("Block"), SourceId: id),
                    new EffectSpec(EffectKind.ApplyStatus, V("Block"), "SCHEDULED_BLOCK", Duration: 1, SourceId: id))
                : Missing("Block"),
            "CLARITY" => Has("Cards", "ClarityPower")
                ? Effects(
                    new EffectSpec(EffectKind.Draw, V("Cards"), SourceId: id),
                    new EffectSpec(EffectKind.ApplyStatus, V("ClarityPower"), "CLARITY", SourceId: id))
                : Missing("Cards", "ClarityPower"),
            "RADIANT_TINCTURE" => Has("Energy", "RadiancePower")
                ? Effects(
                    new EffectSpec(EffectKind.GainEnergy, V("Energy"), SourceId: id),
                    new EffectSpec(EffectKind.ApplyStatus, V("RadiancePower"), "RADIANCE", SourceId: id))
                : Missing("Energy", "RadiancePower"),
            "BLOOD_POTION" => Has("HealPercent")
                ? Effects(new EffectSpec(EffectKind.HealPercent, V("HealPercent"), SourceId: id))
                : Missing("HealPercent"),
            "FRUIT_JUICE" => Has("MaxHp")
                ? Effects(new EffectSpec(EffectKind.ModifyMaxHp, V("MaxHp"), "HEAL_SAME_AMOUNT", SourceId: id))
                : Missing("MaxHp"),
            _ => new([], $"{id} is not deterministically modeled in potion-semantic-v0.111")
        };
    }
}
