using System.Reflection;
using System.Text.Json;
using Xunit;

namespace STS2BestChoice.Tests;

public sealed class PackageAssemblyTests
{
    [Fact]
    public void PackagedModIsSelfContainedAndHasNoCoreAssemblyDependency()
    {
        var package = Path.GetFullPath(Path.Combine(
            AppContext.BaseDirectory, "..", "..", "..", "..", "out", "STS2BestChoice"));
        var dll = Path.Combine(package, "STS2BestChoice.dll");
        var manifest = Path.Combine(package, "STS2BestChoice.json");

        Assert.True(File.Exists(dll), $"Missing packaged mod: {dll}");
        Assert.True(File.Exists(manifest), $"Missing packaged manifest: {manifest}");
        Assert.False(File.Exists(Path.Combine(package, "STS2BestChoice.Core.dll")),
            "The game mod loader cannot reliably resolve an arbitrary sibling Core DLL.");

        var references = Assembly.LoadFile(dll).GetReferencedAssemblies();
        Assert.DoesNotContain(references, reference => reference.Name == "STS2BestChoice.Core");

        using var json = JsonDocument.Parse(File.ReadAllText(manifest));
        Assert.Equal("0.2.2", json.RootElement.GetProperty("version").GetString());
        Assert.Equal("0.110.0", json.RootElement.GetProperty("min_game_version").GetString());
        var dependency = Assert.Single(json.RootElement.GetProperty("dependencies").EnumerateArray());
        Assert.Equal("STS2-RitsuLib", dependency.GetProperty("id").GetString());
        Assert.Equal("0.5.0", dependency.GetProperty("min_version").GetString());
        Assert.DoesNotContain(references, reference => reference.Name?.Contains("RandomForeseer", StringComparison.OrdinalIgnoreCase) == true);
        Assert.Equal(
            new[] { "README.md", "STS2BestChoice.dll", "STS2BestChoice.json" },
            Directory.GetFiles(package).Select(Path.GetFileName).Order(StringComparer.Ordinal).ToArray());
    }
}
