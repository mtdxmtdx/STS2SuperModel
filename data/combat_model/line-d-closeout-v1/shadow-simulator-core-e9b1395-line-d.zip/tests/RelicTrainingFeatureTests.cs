using System.Collections.Immutable;
using STS2BestChoice.Core.Data;
using STS2BestChoice.Core.Model;
using STS2BestChoice.Core.Simulation;
using Xunit;

namespace STS2BestChoice.Tests;

public sealed class RelicTrainingFeatureTests
{
    private static PlayerState MakePlayer(int hp = 80, int maxHp = 80) =>
        new(hp, maxHp, 0, 3, 3, ImmutableDictionary<string, StatusState>.Empty);

    private static CreatureState MakeEnemy(string id = "CULTIST:1") =>
        new(id, "Cultist", 50, 50, 0, ImmutableDictionary<string, StatusState>.Empty, []);

    [Fact]
    public void UnsupportedCombatRelicDowngradesConfidenceFromReliable()
    {
        var unsupportedRelic = new RelicState(
            "DUSTY_TOME",
            SupportStatus: RelicEffectSupportStatus.UnsupportedKnownEffect,
            UnknownStatePresent: false);

        var snap = CombatSnapshot.Create(
            "fp", MakePlayer(), [MakeEnemy()], [],
            globalRestrictions: ["遗物 尘封典籍 (DUSTY_TOME) 的相关动作钩子尚未镜像"],
            relics: [unsupportedRelic]);

        var state = MutableCombatState.FromSnapshot(snap);

        // Confidence must NOT be Reliable when unsupported relic restriction is present
        Assert.NotEqual(PredictionConfidence.Reliable, state.Confidence);
        Assert.Equal(PredictionConfidence.Estimated, state.Confidence);
    }

    [Fact]
    public void SupportedAndNoCombatEffectRelicsRetainReliableConfidence()
    {
        var supportedRelic = new RelicState("ANCHOR", SupportStatus: RelicEffectSupportStatus.SimulatorSupported);
        var passiveRelic = new RelicState("BURNING_BLOOD", SupportStatus: RelicEffectSupportStatus.NoCombatEffect);

        var snap = CombatSnapshot.Create(
            "fp", MakePlayer(), [MakeEnemy()], [],
            relics: [supportedRelic, passiveRelic]);

        var state = MutableCombatState.FromSnapshot(snap);

        Assert.Equal(PredictionConfidence.Reliable, state.Confidence);
    }

    [Fact]
    public void PublicStudentFeaturesDoNotLeakPrivilegedRngOrFutureDeck()
    {
        var db = VersionedRelicDatabase.LoadEmbedded(typeof(VersionedRelicDatabase).Assembly);

        var relic = new RelicState(
            "HAPPY_FLOWER",
            Counter: 2,
            DynamicVars: ImmutableDictionary<string, decimal>.Empty.Add("Energy", 1m).Add("Turns", 3m),
            IsEnabled: true,
            SupportStatus: RelicEffectSupportStatus.SimulatorSupported);

        var strike1 = new CardState("strike_1", "STRIKE_IRONCLAD", "打击", 1, TargetKind.Enemy, [], CardType: "Attack");
        var hiddenCard = new CardState("secret_card", "BLUDGEON", "重锤", 3, TargetKind.Enemy, [], CardType: "Attack");

        var snap = CombatSnapshot.Create(
            "fp", MakePlayer(), [MakeEnemy()],
            hand: [strike1],
            drawPile: [hiddenCard], // Draw pile contains unrevealed cards
            rngState: 0xDEADBEEFCAFEUL,
            relics: [relic]);

        // Student observable features extractor
        var studentFeatures = new
        {
            player_hp = snap.Player.Hp,
            player_max_hp = snap.Player.MaxHp,
            player_energy = snap.Player.Energy,
            hand_card_ids = snap.Hand.Select(c => c.ModelId).ToArray(),
            draw_pile_count = snap.DrawPile.Length, // Only pile size is observable to student
            relics = snap.Relics.Select(r => new
            {
                r.Id,
                r.Counter,
                r.IsEnabled,
                r.SafeDynamicVars
            }).ToArray()
        };

        // Assert observable feature contents
        Assert.Single(studentFeatures.relics);
        Assert.Equal("HAPPY_FLOWER", studentFeatures.relics[0].Id);
        Assert.Equal(2, studentFeatures.relics[0].Counter);
        Assert.Equal(1, studentFeatures.draw_pile_count);

        // Verify that student features do not expose hidden cards or raw RNG words
        var serializedStudent = System.Text.Json.JsonSerializer.Serialize(studentFeatures);
        Assert.DoesNotContain("BLUDGEON", serializedStudent);
        Assert.DoesNotContain("DEADBEEF", serializedStudent);
    }
}
