using System.Collections.Immutable;
using System.Collections;
using System.Reflection;
using STS2BestChoice.Core.Model;
using STS2BestChoice.Core.Scoring;
using STS2BestChoice.Core.Search;
using STS2BestChoice.Core.Simulation;
using Xunit;

namespace STS2BestChoice.Tests;

public sealed class CombatSearchSessionTests
{
    [Fact]
    public void CloneCopiesEveryMutableStateProperty()
    {
        var card = DamageCard("clone-card", 6);
        var snapshot = CombatSnapshot.Create(
            "clone-fixture",
            new PlayerState(30, 40, 3, 2, 4,
                EmptyStatuses.Add("STRENGTH", new StatusState("STRENGTH", 2))),
            [new CreatureState(
                "enemy-0", "Enemy", 20, 30, 1,
                EmptyStatuses.Add("VULNERABLE", new StatusState("VULNERABLE", 1)),
                [new IntentState("Attack", 7, 1)], 7)],
            [card], [card with { InstanceId = "draw-card" }],
            [card with { InstanceId = "discard-card" }],
            [card with { InstanceId = "exhaust-card" }],
            [new PotionState("potion-0", "BLOCK_POTION", "Block Potion", TargetKind.Self,
                [new EffectSpec(EffectKind.Block, 5)], 2)],
            rngState: 123,
            rngStreams: KnownTargetRng(),
            round: 3,
            orbs: [new OrbState("LIGHTNING", 3, 5)],
            orbCapacity: 2,
            historyCounters: new CombatHistoryCounters(
                AttacksPlayedThisTurn: 1,
                SkillsPlayedThisTurn: 2,
                PowersPlayedThisTurn: 3,
                CardsPlayedThisCombat: 4,
                EtherealCardsPlayedThisCombat: 5,
                CardsDrawnThisCombat: 6,
                CardsGeneratedThisCombat: 7,
                CardsPlayedThisTurn: 8,
                ShivsPlayedThisTurn: 9,
                DamageReceivedEventsThisCombat: 10,
                BlockGainedThisTurn: 11),
            relics: [new RelicState("ANCHOR", Counter: 1,
                DynamicVars: ImmutableDictionary<string, decimal>.Empty.Add("charges", 2),
                IsEnabled: true, IsUsedUp: false, UsesThisTurn: 1, UsesThisCombat: 2,
                SupportStatus: RelicEffectSupportStatus.SimulatorSupported,
                EvidenceLevel: RelicEvidenceLevel.LiveObserved,
                UnknownStatePresent: false, Name: "Anchor", Description: "")],
            powers: [new PowerState("STRENGTH", "player", "player", 2,
                DynamicVars: ImmutableDictionary<string, string>.Empty.Add("x", "y"),
                Counters: ImmutableDictionary<string, decimal>.Empty.Add("ticks", 1),
                TriggerPhases: ["TurnStart"], SourceId: "fixture",
                Support: SemanticSupportStatus.SimulatorSupported,
                Evidence: EvidenceLevel.LiveObserved, SourceVersion: "v0.111.0")]);
        var state = MutableCombatState.FromSnapshot(snapshot);
        state.PotionCostSpent = 1.5m;
        state.DamageDealt = 9m;
        state.EnemiesKilled = 2;
        state.HpLostSinceSnapshot = 3m;
        state.AttacksPlayedSinceSnapshot = 4;
        state.SkillsPlayedSinceSnapshot = 5;
        state.RainbowRingProgress = 6;
        state.PaelsTearsPending = true;
        state.SelfFormingClayBlockPending = 7m;
        state.PocketwatchDrawPending = 8;
        state.CardsPlayedBeforeTurn = 9;
        state.DemonTongueUsedThisTurn = true;
        state.CombatEndProcessed = true;
        state.HpLostThisTurn = 10m;
        state.Gold = 11m;
        state.EnemyTurnActive = true;
        state.CardsPlayedSinceSnapshot = 12;
        state.CardPlaysFinishedSinceSnapshot = 13;
        state.ShivsPlayedSinceSnapshot = 14;
        state.EtherealCardsPlayedSinceSnapshot = 15;
        state.CardsDrawnSinceSnapshot = 16;
        state.CardsDrawnThisTurn = 17;
        state.CardsGeneratedSinceSnapshot = 18;
        state.StatusCardsDrawnSinceSnapshot = 19;
        state.CardsExhaustedSinceSnapshot = 20;
        state.CardsDiscardedSinceSnapshot = 21;
        state.DamageReceivedEventsSinceSnapshot = 22;
        state.UnmovableBlockGainsThisTurn = 23;
        state.PendingTurnStartReturnCardInstanceIds.Add("return-card");
        state.PendingTurnStartCopies.Add(card with { InstanceId = "pending-copy" });
        state.StatusCardsDrawnBeforeTurn = 24;
        state.CardsExhaustedBeforeTurn = 25;
        state.CardsDiscardedBeforeTurn = 26;
        state.ShivsPlayedBeforeTurn = 27;

        var clone = state.Clone();
        foreach (var property in typeof(MutableCombatState).GetProperties(BindingFlags.Public | BindingFlags.Instance))
        {
            var expected = property.GetValue(state);
            var actual = property.GetValue(clone);
            if (expected is RngSnapshotSet expectedRng && actual is RngSnapshotSet actualRng)
            {
                Assert.Equal(expectedRng.Streams, actualRng.Streams);
            }
            else if (expected is IEnumerable expectedItems && expected is not string)
            {
                Assert.Equal(expectedItems.Cast<object>().ToArray(),
                    ((IEnumerable)actual!).Cast<object>().ToArray());
            }
            else
            {
                Assert.Equal(expected, actual);
            }
        }
    }

    [Fact]
    public void CrueltyAddsToVulnerableMultiplierOnlyForPoweredAttacks()
    {
        var cruelty = new CardState(
            "cruelty", "CRUELTY", "Cruelty", 0, TargetKind.AllEnemies,
            [new EffectSpec(
                EffectKind.ApplyStatus,
                25,
                "BONUS_VULNERABLE_POWERED_ATTACK_DAMAGE_PERCENT",
                IsDebuff: true,
                TargetOverride: TargetKind.AllEnemies)],
            CardType: "Power");
        var attack = new CardState(
            "attack", "STRIKE", "Strike", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 10)], CardType: "Attack");
        var skill = new CardState(
            "skill", "DAMAGE_SKILL", "Damage Skill", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 10)], CardType: "Skill");
        var vulnerable = EmptyStatuses.Add("VULNERABLE", new StatusState("VULNERABLE", 1, IsDebuff: true));
        var snapshot = Snapshot(30, 100, 0, [cruelty, attack, skill], energy: 0) with
        {
            Enemies = [new CreatureState("enemy-0", "Enemy", 100, 100, 0, vulnerable, [], 0)]
        };
        var simulator = new DeterministicSimulator();

        var afterCruelty = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), cruelty, null, null);
        var afterAttack = simulator.PlayCard(afterCruelty, attack, "enemy-0", null);
        var result = simulator.PlayCard(afterAttack, skill, "enemy-0", null);

        Assert.Equal(83m, afterAttack.Enemies[0].Hp);
        Assert.Equal(68m, result.Enemies[0].Hp);
    }

    [Fact]
    public void SearchIncludesZeroCostEnemyDebuffAndFollowUpAttacks()
    {
        var neutralize = new CardState(
            "neutralize", "NEUTRALIZE", "Neutralize", 0, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 3),
                new EffectSpec(EffectKind.ApplyStatus, 1, "WEAK", IsDebuff: true, TargetOverride: TargetKind.Enemy)
            ], CardType: "Attack");
        var strikes = Enumerable.Range(1, 3)
            .Select(index => DamageCard($"strike-{index}", 6, 1) with { CardType = "Attack" })
            .ToArray();
        var defend = BlockCard("defend", 5, 1);
        var snapshot = Snapshot(30, 100, 7, [neutralize, .. strikes, defend], energy: 3);

        var results = Complete(snapshot, maximumActions: 8);
        var lines = results.Balanced
            .Concat(results.HighestDamage)
            .Concat(results.MinimumLoss)
            .Concat(results.EstimatedBalanced)
            .Concat(results.EstimatedHighestDamage)
            .Concat(results.EstimatedMinimumLoss);

        Assert.Contains(lines, line =>
            line.Steps.Any(step => step.SourceInstanceId == "neutralize") &&
            line.Steps.Any(step => step.SourceInstanceId.StartsWith("strike-", StringComparison.Ordinal)));
    }

    [Fact]
    public void BalancedRankingPutsZeroCostNeutralizeSetupInTheTopLine()
    {
        var neutralize = new CardState(
            "neutralize",
            "NEUTRALIZE",
            "Neutralize",
            0,
            TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 3),
                new EffectSpec(EffectKind.ApplyStatus, 1, "WEAK", Duration: 1, IsDebuff: true)
            ],
            CardType: "Attack");
        var strikes = Enumerable.Range(1, 3)
            .Select(index => DamageCard($"strike-{index}", 6, 1) with { CardType = "Attack" })
            .ToArray();
        var defend = BlockCard("defend", 5, 1);
        var results = Complete(Snapshot(30, 100, 7, [neutralize, .. strikes, defend], energy: 3), maximumActions: 8);

        var best = results.Balanced[0];
        Assert.Contains(best.Steps, step => step.SourceInstanceId == "neutralize");
        Assert.Contains(best.Steps, step => step.SourceInstanceId.StartsWith("strike-", StringComparison.Ordinal));
    }

    [Fact]
    public void BalancedRankingUsesNeutralizeAndDamageWhenTwoDefendsAlreadyBlockTheAttack()
    {
        var neutralize = new CardState(
            "neutralize",
            "NEUTRALIZE",
            "Neutralize",
            0,
            TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 3),
                new EffectSpec(EffectKind.ApplyStatus, 1, "WEAK", Duration: 1, IsDebuff: true)
            ],
            CardType: "Attack");
        var strike = DamageCard("strike", 6, 1) with { CardType = "Attack" };
        var defends = Enumerable.Range(1, 3)
            .Select(index => BlockCard($"defend-{index}", 5, 1))
            .ToArray();
        var results = Complete(
            Snapshot(30, 100, 13, [.. defends, neutralize, strike], energy: 3),
            maximumActions: 8);

        var best = results.Balanced[0];

        Assert.Contains(best.Steps, step => step.SourceInstanceId == "neutralize");
        Assert.Contains(best.Steps, step => step.SourceInstanceId == "strike");
        Assert.Equal(2, best.Steps.Count(step => step.SourceInstanceId.StartsWith("defend-", StringComparison.Ordinal)));
        Assert.Equal(0m, best.Score!.PlayerHpLoss);
    }

    [Fact]
    public void BalancedRankingStillSpendsRemainingEnergyOnAnAttackWhenTwoDefendsAreNeeded()
    {
        var strikes = Enumerable.Range(1, 3)
            .Select(index => DamageCard($"strike-{index}", 6, 1) with { CardType = "Attack" })
            .ToArray();
        var defends = Enumerable.Range(1, 2)
            .Select(index => BlockCard($"defend-{index}", 5, 1))
            .ToArray();
        var results = Complete(
            Snapshot(30, 100, 16, [.. strikes, .. defends], energy: 3),
            maximumActions: 8);

        var best = results.Balanced[0];

        Assert.Equal(1, best.Steps.Count(step => step.SourceInstanceId.StartsWith("strike-", StringComparison.Ordinal)));
        Assert.Equal(2, best.Steps.Count(step => step.SourceInstanceId.StartsWith("defend-", StringComparison.Ordinal)));
        Assert.Equal(6m, best.Score!.EffectiveDamage);
    }

    [Fact]
    public void SingleBudgetSliceStillFindsAttackWhenTwoDefendsAreNeeded()
    {
        var strikes = Enumerable.Range(1, 3)
            .Select(index => DamageCard($"slice-strike-{index}", 6, 1) with { CardType = "Attack" })
            .ToArray();
        var defends = Enumerable.Range(1, 2)
            .Select(index => BlockCard($"slice-defend-{index}", 5, 1))
            .ToArray();
        var session = new CombatSearchSession(
            Snapshot(30, 100, 16, [.. strikes, .. defends], energy: 3),
            Options(8));
        var result = session.Continue(TimeSpan.FromMilliseconds(500));
        var candidates = result.Balanced.Concat(result.EstimatedBalanced).ToArray();

        Assert.Contains(candidates, line =>
            line.Steps.Any(step => step.SourceInstanceId.StartsWith("slice-strike-", StringComparison.Ordinal)) &&
            line.Steps.Count(step => step.SourceInstanceId.StartsWith("slice-defend-", StringComparison.Ordinal)) == 2);
    }

    [Fact]
    public void HighestDamageRankingIncludesZeroCostNeutralizeAndAllThreeStrikes()
    {
        var neutralize = new CardState(
            "neutralize",
            "NEUTRALIZE",
            "Neutralize",
            0,
            TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 3),
                new EffectSpec(EffectKind.ApplyStatus, 1, "WEAK", Duration: 1, IsDebuff: true)
            ],
            CardType: "Attack");
        var strikes = Enumerable.Range(1, 3)
            .Select(index => DamageCard($"strike-{index}", 6, 1) with { CardType = "Attack" })
            .ToArray();
        var defend = BlockCard("defend", 5, 1);
        var results = Complete(Snapshot(30, 100, 7, [neutralize, .. strikes, defend], energy: 3), maximumActions: 8);

        var best = results.HighestDamage[0];
        Assert.Equal(21m, best.Score!.EffectiveDamage);
        Assert.Contains(best.Steps, step => step.SourceInstanceId == "neutralize");
        Assert.Equal(3, best.Steps.Count(step => step.SourceInstanceId.StartsWith("strike-", StringComparison.Ordinal)));
    }

    [Fact]
    public void EnemyWeakFutureValueIsScoredAsPlayerBenefit()
    {
        var neutralize = new CardState(
            "neutralize", "NEUTRALIZE", "Neutralize", 0, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 3),
                new EffectSpec(
                    EffectKind.ApplyStatus,
                    1,
                    "WEAK",
                    Duration: 1,
                    IsDebuff: true,
                    FutureValuePerTurn: StatusValuation.IntrinsicFutureValue("WEAK", 1))
            ], CardType: "Attack");
        var defend = BlockCard("defend", 5, 1);
        var snapshot = Snapshot(30, 100, 7, [neutralize, defend], energy: 1);
        var results = Complete(snapshot, maximumActions: 4);
        var neutralizeLine = results.Balanced.Concat(results.MinimumLoss)
            .First(line => line.Steps.Any(step => step.SourceInstanceId == "neutralize"));

        Assert.Equal(0m, neutralizeLine.Score!.PlayerHpLoss);
    }

    [Fact]
    public void GenericStatusApplicationDefaultsToIntrinsicValuation()
    {
        var weaken = new CardState(
            "weaken",
            "WEAKEN",
            "Weaken",
            0,
            TargetKind.Enemy,
            [new EffectSpec(EffectKind.ApplyStatus, 2, "WEAK", Duration: 1, IsDebuff: true)],
            CardType: "Skill");
        var strengthen = new CardState(
            "strengthen",
            "STRENGTHEN",
            "Strengthen",
            0,
            TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 2, "STRENGTH", Duration: 1)],
            CardType: "Skill");
        var snapshot = Snapshot(30, 30, 0, [weaken, strengthen], energy: 0);
        var simulator = new DeterministicSimulator();
        var baseState = MutableCombatState.FromSnapshot(snapshot);
        var scorer = new CombatScorer(snapshot, SearchOptions.Default);

        var enemyDebuffed = simulator.PlayCard(baseState, weaken, "enemy-0", null);
        var playerBuffed = simulator.PlayCard(baseState, strengthen, null, null);

        Assert.Equal(-3m, enemyDebuffed.Enemies[0].Statuses["WEAK"].FutureValuePerTurn);
        Assert.Equal(3m, playerBuffed.Player.Statuses["STRENGTH"].FutureValuePerTurn);
        Assert.True(scorer.Score(enemyDebuffed).LongTermValue > 0m);
        Assert.True(scorer.Score(playerBuffed).LongTermValue > 0m);
    }

    [Fact]
    public void HangDamagesBeforeDoublingItsTargetSpecificMultiplier()
    {
        var hang = new CardState(
            "hang", "HANG", "Hang", 0, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 10),
                new EffectSpec(
                    EffectKind.ApplyStatus,
                    2,
                    "HANG_DAMAGE_MULTIPLIER",
                    IsDebuff: true,
                    TargetOverride: TargetKind.Enemy)
            ],
            CardType: "Attack");
        var strike = new CardState(
            "strike", "STRIKE", "Strike", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 10)],
            CardType: "Attack");
        var snapshot = Snapshot(30, 200, 0, [hang, strike], energy: 0);
        var simulator = new DeterministicSimulator();

        var afterFirst = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), hang, "enemy-0", null);
        afterFirst.Hand.Add(hang);
        var afterSecond = simulator.PlayCard(afterFirst, hang, "enemy-0", null);
        afterSecond.Hand.Add(hang);
        var afterThird = simulator.PlayCard(afterSecond, hang, "enemy-0", null);
        afterThird.Hand.Add(strike);
        var afterStrike = simulator.PlayCard(afterThird, strike, "enemy-0", null);

        Assert.Equal(190m, afterFirst.Enemies[0].Hp);
        Assert.Equal(2, afterFirst.Enemies[0].Statuses["HANG_DAMAGE_MULTIPLIER"].Amount);
        Assert.Equal(170m, afterSecond.Enemies[0].Hp);
        Assert.Equal(4, afterSecond.Enemies[0].Statuses["HANG_DAMAGE_MULTIPLIER"].Amount);
        Assert.Equal(130m, afterThird.Enemies[0].Hp);
        Assert.Equal(8, afterThird.Enemies[0].Statuses["HANG_DAMAGE_MULTIPLIER"].Amount);
        Assert.Equal(120m, afterStrike.Enemies[0].Hp);
    }

    [Fact]
    public void HangUpgradeUsesThirteenBaseDamageWithExistingMultiplier()
    {
        var hangUpgrade = new CardState(
            "hang-upgrade", "HANG_UPGRADE", "Hang+", 0, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 13),
                new EffectSpec(
                    EffectKind.ApplyStatus,
                    2,
                    "HANG_DAMAGE_MULTIPLIER",
                    IsDebuff: true,
                    TargetOverride: TargetKind.Enemy)
            ],
            CardType: "Attack");
        var snapshot = Snapshot(30, 100, 0, [hangUpgrade], energy: 0) with
        {
            Enemies =
            [
                new CreatureState(
                    "enemy-0", "Enemy", 100, 100, 0,
                    EmptyStatuses.Add("HANG_DAMAGE_MULTIPLIER", new StatusState("HANG_DAMAGE_MULTIPLIER", 2)),
                    [], 0)
            ]
        };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), hangUpgrade, "enemy-0", null);

        Assert.Equal(74m, result.Enemies[0].Hp);
        Assert.Equal(4, result.Enemies[0].Statuses["HANG_DAMAGE_MULTIPLIER"].Amount);
    }

    [Fact]
    public void TemporaryStrengthAndDexterityApplyForTheCurrentTurn()
    {
        var setupStrike = new CardState(
            "setup-strike", "SETUP_STRIKE", "Setup Strike", 0, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 7),
                new EffectSpec(EffectKind.ApplyStatus, 2, "STRENGTH", Duration: 1, TargetOverride: TargetKind.Self)
            ], CardType: "Attack");
        var anticipate = new CardState(
            "anticipate", "ANTICIPATE", "Anticipate", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 2, "DEXTERITY", Duration: 1, TargetOverride: TargetKind.Self)],
            CardType: "Skill");
        var strike = new CardState(
            "strike", "STRIKE", "Strike", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 6)], CardType: "Attack");
        var snapshot = Snapshot(30, 100, 0, [setupStrike, anticipate, strike], energy: 0);
        var simulator = new DeterministicSimulator();

        var afterSetup = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), setupStrike, "enemy-0", null);
        var afterAnticipate = simulator.PlayCard(afterSetup, anticipate, null, null);
        var afterStrike = simulator.PlayCard(afterAnticipate, strike, "enemy-0", null);

        Assert.Equal(93m, afterSetup.Enemies[0].Hp);
        Assert.Equal(2, afterSetup.Player.Statuses["STRENGTH"].Amount);
        Assert.Equal(2, afterAnticipate.Player.Statuses["DEXTERITY"].Amount);
        Assert.Equal(85m, afterStrike.Enemies[0].Hp);
    }

    [Fact]
    public void TurnStartStrengthAccumulatesFromPersistentPower()
    {
        var demonForm = new CardState(
            "demon-form", "DEMON_FORM", "Demon Form", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 2, "TURN_START_STRENGTH", TargetOverride: TargetKind.Self)],
            CardType: "Power");
        var snapshot = Snapshot(30, 100, 0, [demonForm], energy: 0);
        var simulator = new DeterministicSimulator();

        var afterPlay = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), demonForm, null, null);
        var firstTurn = simulator.ProjectToNextPlayerTurn(afterPlay);
        var secondTurn = simulator.ProjectToNextPlayerTurn(firstTurn);

        Assert.Equal(2, firstTurn.Player.Statuses["STRENGTH"].Amount);
        Assert.Equal(4, secondTurn.Player.Statuses["STRENGTH"].Amount);
        Assert.Equal(2, secondTurn.Player.Statuses["TURN_START_STRENGTH"].Amount);
    }

    [Fact]
    public void MementoMoriCountsOnlyExplicitDiscardsThisTurn()
    {
        var discard = new CardState(
            "discard", "PREPARED", "Prepared", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.DiscardCards, 1)],
            Choices: [new ChoiceSpec("fodder", "Discard fodder", [], "fodder")],
            CardType: "Skill");
        var fodder = DamageCard("fodder", 1, 0);
        var memento = new CardState(
            "memento", "MEMENTO_MORI", "Memento Mori", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.DynamicDamage, 9, "CARDS_DISCARDED_THIS_TURN", XBonus: 4)],
            CardType: "Attack");
        var history = new CombatHistoryCounters(CardsDiscardedThisTurn: 2);
        var snapshot = Snapshot(30, 100, 0, [discard, fodder, memento], energy: 0) with
        {
            HistoryCounters = history
        };
        var simulator = new DeterministicSimulator();

        var afterDiscard = simulator.PlayCard(
            MutableCombatState.FromSnapshot(snapshot),
            discard,
            null,
            discard.SafeChoices.Single());
        var result = simulator.PlayCard(afterDiscard, memento, "enemy-0", null);

        Assert.Equal(79m, result.Enemies[0].Hp);
        Assert.Equal(1, result.CardsDiscardedSinceSnapshot);
        Assert.Contains(result.DiscardPile, card => card.InstanceId == "discard");

        var nextTurn = simulator.ProjectToNextPlayerTurn(result);
        Assert.Equal(0, nextTurn.CardsDiscardedBeforeTurn);
        Assert.Equal(0, nextTurn.CardsDiscardedSinceSnapshot);

        var distinct = afterDiscard.Clone();
        distinct.CardsDiscardedSinceSnapshot++;
        Assert.NotEqual(afterDiscard.ExactKey(), distinct.ExactKey());
    }

    [Fact]
    public void AccuracyAddsDamageOnlyToShivAttacks()
    {
        var accuracy = new CardState(
            "accuracy", "ACCURACY", "Accuracy", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 4, "SHIV_DAMAGE_BONUS")],
            CardType: "Power");
        var shiv = new CardState(
            "shiv", "SHIV", "Shiv", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 3)],
            CardType: "Attack");
        var strike = new CardState(
            "strike", "STRIKE", "Strike", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 3)],
            CardType: "Attack");
        var snapshot = Snapshot(30, 100, 0, [accuracy, shiv, strike], energy: 0);
        var simulator = new DeterministicSimulator();

        var afterAccuracy = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), accuracy, null, null);
        var afterShiv = simulator.PlayCard(afterAccuracy, shiv, "enemy-0", null);
        var afterStrike = simulator.PlayCard(afterShiv, strike, "enemy-0", null);

        Assert.Equal(93m, afterShiv.Enemies[0].Hp);
        Assert.Equal(90m, afterStrike.Enemies[0].Hp);
        Assert.Equal(4, afterStrike.Player.Statuses["SHIV_DAMAGE_BONUS"].Amount);
    }

    [Fact]
    public void FanOfKnivesMakesExistingAndGeneratedShivsHitAllEnemies()
    {
        var shiv = new CardState(
            "shiv", "SHIV", "Shiv", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 4)],
            CardDestination.Exhaust,
            CardType: "Attack");
        var generatedShiv = shiv with { InstanceId = "generated-shiv" };
        var fan = new CardState(
            "fan", "FAN_OF_KNIVES", "Fan of Knives", 0, TargetKind.Self,
            [
                new EffectSpec(EffectKind.ApplyStatus, 1, "SHIV_ALL_ENEMIES"),
                new EffectSpec(EffectKind.GenerateCards, 1, GeneratedCard: generatedShiv)
            ],
            CardType: "Power");
        var snapshot = Snapshot(30, 20, 0, [fan, shiv], energy: 0) with
        {
            Enemies =
            [
                new CreatureState("enemy-0", "Enemy 1", 20, 20, 0, EmptyStatuses, [], 0),
                new CreatureState("enemy-1", "Enemy 2", 20, 20, 0, EmptyStatuses, [], 0)
            ]
        };
        var simulator = new DeterministicSimulator();

        var afterFan = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), fan, null, null);
        Assert.Equal(TargetKind.AllEnemies, afterFan.Hand.Single(card => card.InstanceId == "shiv").Target);
        Assert.Equal(TargetKind.AllEnemies, afterFan.Hand.Single(card =>
            card.InstanceId.StartsWith("generated-shiv", StringComparison.Ordinal)).Target);

        var shivToPlay = afterFan.Hand.Single(card => card.InstanceId == "shiv");
        var afterShiv = simulator.PlayCard(afterFan, shivToPlay, null, null);

        Assert.All(afterShiv.Enemies, target => Assert.Equal(16m, target.Hp));
        Assert.Equal(TargetKind.Self, fan.Target);
    }

    [Fact]
    public void FanOfKnivesSnapshotRestoresShivTargetsAcrossPiles()
    {
        var shiv = new CardState(
            "shiv", "SHIV", "Shiv", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 4)],
            CardDestination.Exhaust,
            CardType: "Attack");
        var fanStatus = new StatusState("SHIV_ALL_ENEMIES", 1);
        var snapshot = Snapshot(30, 20, 0, [shiv], [shiv with { InstanceId = "draw" }],
            [shiv with { InstanceId = "discard" }], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, EmptyStatuses.Add(fanStatus.Id, fanStatus)),
            ExhaustPile = [shiv with { InstanceId = "exhaust" }]
        };

        var state = MutableCombatState.FromSnapshot(snapshot);

        Assert.All(state.Hand.Concat(state.DrawPile).Concat(state.DiscardPile).Concat(state.ExhaustPile),
            card => Assert.Equal(TargetKind.AllEnemies, card.Target));
    }

    [Fact]
    public void PhantomBladesRetainsShivsAndAddsDamageOnlyToFirstShivEachTurn()
    {
        var phantom = new CardState(
            "phantom", "PHANTOM_BLADES", "Phantom Blades", 0, TargetKind.Self,
            [
                new EffectSpec(EffectKind.ApplyStatus, 1, "SHIV_RETAIN"),
                new EffectSpec(EffectKind.ApplyStatus, 9, "FIRST_SHIV_DAMAGE_BONUS")
            ], CardType: "Power");
        var shiv1 = new CardState(
            "shiv-1", "SHIV", "Shiv", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 4)], CardDestination.Exhaust, CardType: "Attack");
        var shiv2 = shiv1 with { InstanceId = "shiv-2" };
        var shiv3 = shiv1 with { InstanceId = "shiv-3" };
        var snapshot = Snapshot(30, 100, 0, [phantom, shiv1, shiv2], [shiv3], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, EmptyStatuses, CardsPerTurn: 1)
        };
        var simulator = new DeterministicSimulator();

        var afterPhantom = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), phantom, null, null);
        Assert.True(afterPhantom.Hand.Single(card => card.InstanceId == "shiv-1").RetainAtTurnEnd);
        Assert.True(afterPhantom.Hand.Single(card => card.InstanceId == "shiv-2").RetainAtTurnEnd);

        var afterFirst = simulator.PlayCard(afterPhantom,
            afterPhantom.Hand.Single(card => card.InstanceId == "shiv-1"), "enemy-0", null);
        var afterSecond = simulator.PlayCard(afterFirst,
            afterFirst.Hand.Single(card => card.InstanceId == "shiv-2"), "enemy-0", null);
        Assert.Equal(87m, afterFirst.Enemies[0].Hp);
        Assert.Equal(83m, afterSecond.Enemies[0].Hp);
        Assert.Equal(2, afterSecond.ShivsPlayedSinceSnapshot);

        var nextTurn = simulator.ProjectToNextPlayerTurn(afterSecond);
        var afterNextTurnShiv = simulator.PlayCard(nextTurn,
            nextTurn.Hand.Single(card => card.InstanceId == "shiv-3"), "enemy-0", null);
        Assert.Equal(70m, afterNextTurnShiv.Enemies[0].Hp);
        Assert.Equal(1, afterNextTurnShiv.ShivsPlayedSinceSnapshot);
    }

    [Fact]
    public void JugglingCopiesOnlyTheThirdAttackIntoHand()
    {
        var juggling = new CardState(
            "juggling", "JUGGLING", "Juggling", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 1, "JUGGLING")], CardType: "Power");
        CardState Attack(string id) => new(
            id, "TEST_ATTACK", "Test Attack", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 4)], CardType: "Attack");
        var attack1 = Attack("attack-1");
        var attack2 = Attack("attack-2");
        var attack3 = Attack("attack-3");
        var snapshot = Snapshot(30, 100, 0, [juggling, attack1, attack2, attack3], energy: 0);
        var simulator = new DeterministicSimulator();

        var state = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), juggling, null, null);
        state = simulator.PlayCard(state, state.Hand.Single(card => card.InstanceId == "attack-1"), "enemy-0", null);
        state = simulator.PlayCard(state, state.Hand.Single(card => card.InstanceId == "attack-2"), "enemy-0", null);
        Assert.DoesNotContain(state.Hand, card =>
            card.InstanceId.StartsWith("juggling:", StringComparison.Ordinal));

        state = simulator.PlayCard(state, state.Hand.Single(card => card.InstanceId == "attack-3"), "enemy-0", null);
        var copy = Assert.Single(state.Hand, card => card.ModelId == "TEST_ATTACK");
        Assert.StartsWith("juggling:attack-3:", copy.InstanceId, StringComparison.Ordinal);
        Assert.Equal(TargetKind.Enemy, copy.Target);

        state = simulator.PlayCard(state, copy, "enemy-0", null);
        Assert.DoesNotContain(state.Hand, card => card.ModelId == "TEST_ATTACK");
    }

    [Fact]
    public void TheGambitKillsAfterUnblockedPoweredAttackButNotWhenFullyBlocked()
    {
        var gambit = new CardState(
            "gambit", "THE_GAMBIT", "The Gambit", 0, TargetKind.Self,
            [
                new EffectSpec(EffectKind.Block, 50),
                new EffectSpec(EffectKind.ApplyStatus, 1, "THE_GAMBIT")
            ], CardType: "Skill");
        var simulator = new DeterministicSimulator();

        var lethal = Snapshot(30, 60, 60, [gambit], energy: 0);
        var lethalState = simulator.PlayCard(
            MutableCombatState.FromSnapshot(lethal), gambit, null, null);
        lethalState = simulator.ProjectToNextPlayerTurn(lethalState);
        Assert.Equal(0m, lethalState.Player.Hp);
        Assert.DoesNotContain("THE_GAMBIT", lethalState.Player.Statuses.Keys);

        var blocked = Snapshot(30, 5, 5, [gambit], energy: 0);
        var blockedState = simulator.PlayCard(
            MutableCombatState.FromSnapshot(blocked), gambit, null, null);
        blockedState = simulator.ProjectToNextPlayerTurn(blockedState);
        Assert.Equal(30m, blockedState.Player.Hp);
        Assert.Contains("THE_GAMBIT", blockedState.Player.Statuses.Keys);
    }

    [Fact]
    public void LethalityBoostsOnlyTheFirstAttackEachTurn()
    {
        var lethality = new CardState(
            "lethality", "LETHALITY", "Lethality", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 50, "LETHALITY")], CardType: "Power");
        var attack1 = DamageCard("attack-1", 10, 0) with { CardType = "Attack" };
        var attack2 = DamageCard("attack-2", 10, 0) with { CardType = "Attack" };
        var snapshot = Snapshot(30, 100, 0, [lethality, attack1, attack2], energy: 0);
        var simulator = new DeterministicSimulator();

        var state = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), lethality, null, null);
        state = simulator.PlayCard(state, attack1, "enemy-0", null);
        state = simulator.PlayCard(state, attack2, "enemy-0", null);

        Assert.Equal(75m, state.Enemies[0].Hp);
        var nextTurn = simulator.ProjectToNextPlayerTurn(state);
        var attack3 = DamageCard("attack-3", 10, 0) with { CardType = "Attack" };
        nextTurn.Hand.Add(attack3);
        nextTurn = simulator.PlayCard(nextTurn, attack3, "enemy-0", null);
        Assert.Equal(60m, nextTurn.Enemies[0].Hp);
    }

    [Fact]
    public void PaleBlueDotSchedulesOneDrawAfterFiveAttacks()
    {
        var pale = new CardState(
            "pale", "PALE_BLUE_DOT", "Pale Blue Dot", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 1, "PALE_BLUE_DOT")], CardType: "Power");
        CardState Attack(string id) => DamageCard(id, 0, 0) with { CardType = "Attack" };
        var attacks = Enumerable.Range(1, 5).Select(index => Attack($"attack-{index}")).ToArray();
        var draw = DamageCard("drawn", 1, 0);
        var snapshot = Snapshot(30, 100, 0, [pale, .. attacks], [draw], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, EmptyStatuses, CardsPerTurn: 0)
        };
        var simulator = new DeterministicSimulator();
        var state = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), pale, null, null);
        foreach (var attack in attacks)
            state = simulator.PlayCard(state, state.Hand.Single(card => card.InstanceId == attack.InstanceId), "enemy-0", null);

        Assert.Contains("SCHEDULED_DRAW", state.Player.Statuses.Keys);
        var nextTurn = simulator.ProjectToNextPlayerTurn(state);
        Assert.Contains(nextTurn.Hand, card => card.InstanceId == "drawn");
        Assert.DoesNotContain("SCHEDULED_DRAW", nextTurn.Player.Statuses.Keys);
    }

    [Fact]
    public void OneForAllBoostsOnlyZeroCostAttacks()
    {
        var power = new CardState(
            "one", "ONE_FOR_ALL", "One For All", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 3, "ONE_FOR_ALL")], CardType: "Power");
        var zero = DamageCard("zero", 5, 0) with { CardType = "Attack" };
        var costly = DamageCard("costly", 5, 1) with { CardType = "Attack" };
        var snapshot = Snapshot(30, 100, 0, [power, zero, costly], energy: 1);
        var simulator = new DeterministicSimulator();

        var state = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), power, null, null);
        state = simulator.PlayCard(state, zero, "enemy-0", null);
        state = simulator.PlayCard(state, costly, "enemy-0", null);

        Assert.Equal(87m, state.Enemies[0].Hp);
    }

    [Fact]
    public void OutrageAddsItsCopyToTheDiscardPileAfterPlay()
    {
        var outrage = new CardState(
            "outrage", "OUTRAGE", "Outrage", 0, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 9),
                new EffectSpec(EffectKind.CopyPlayedCard, 1, GeneratedDestination: GeneratedCardDestination.DiscardPile)
            ], CardType: "Attack");
        var snapshot = Snapshot(30, 30, 0, [outrage], energy: 0);
        var state = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), outrage, "enemy-0", null);

        Assert.Equal(21m, state.Enemies[0].Hp);
        var copy = Assert.Single(state.DiscardPile, card =>
            card.ModelId == "OUTRAGE" && card.InstanceId != "outrage");
        Assert.NotEqual("outrage", copy.InstanceId);
    }

    [Fact]
    public void FastenAddsBlockOnlyToDefendCards()
    {
        var fasten = new CardState(
            "fasten", "FASTEN", "Fasten", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 4, "FASTEN")], CardType: "Power");
        var defend = new CardState(
            "defend", "DEFEND", "Defend", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.Block, 5)], CardType: "Skill");
        var other = new CardState(
            "other", "OTHER_BLOCK", "Other Block", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.Block, 5)], CardType: "Skill");
        var snapshot = Snapshot(30, 100, 0, [fasten, defend, other], energy: 0);
        var simulator = new DeterministicSimulator();

        var state = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), fasten, null, null);
        state = simulator.PlayCard(state, defend, null, null);
        state = simulator.PlayCard(state, other, null, null);

        Assert.Equal(14m, state.Player.Block);
    }

    [Fact]
    public void AccelerantTriggersPoisonAnAdditionalTimeAndConsumesStacks()
    {
        var poison = new StatusState("POISON", 2, IsDebuff: true);
        var accelerant = new StatusState("ACCELERANT", 1);
        var snapshot = Snapshot(30, 10, 0, [], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0,
                EmptyStatuses.Add(accelerant.Id, accelerant)),
            Enemies =
            [
                new CreatureState("enemy-0", "Poisoned", 10, 10, 0,
                    EmptyStatuses.Add(poison.Id, poison), [], 0)
            ]
        };

        var state = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(snapshot));

        Assert.Equal(7m, state.Enemies[0].Hp);
        Assert.DoesNotContain("POISON", state.Enemies[0].Statuses.Keys);
    }

    [Fact]
    public void OutbreakAppliesPoisonToAllEnemiesThenTriggersEachPoisonPower()
    {
        var outbreak = new CardState(
            "outbreak", "OUTBREAK", "Outbreak", 0, TargetKind.AllEnemies,
            [new EffectSpec(EffectKind.Outbreak, 3, "POISON", TargetOverride: TargetKind.AllEnemies)],
            CardType: "Skill");
        var existingPoison = new StatusState("POISON", 2, IsDebuff: true);
        var snapshot = Snapshot(30, 100, 0, [outbreak], energy: 0) with
        {
            Enemies =
            [
                new CreatureState("enemy-0", "Poisoned", 20, 20, 0,
                    EmptyStatuses.Add(existingPoison.Id, existingPoison), [], 0),
                new CreatureState("enemy-1", "Fresh", 20, 20, 0, EmptyStatuses, [], 0)
            ]
        };

        var state = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), outbreak, null, null);

        Assert.Equal(15m, state.Enemies[0].Hp);
        Assert.Equal(17m, state.Enemies[1].Hp);
        Assert.Equal(4, state.Enemies[0].Statuses["POISON"].Amount);
        Assert.Equal(2, state.Enemies[1].Statuses["POISON"].Amount);
    }

    [Fact]
    public void MakeItSoReturnsToHandAfterEveryThirdSkill()
    {
        var makeItSo = new CardState(
            "make-it-so", "MAKE_IT_SO", "Make It So", 0, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 6),
                new EffectSpec(EffectKind.ReturnSelfToHandAfterSkills, 3)
            ], CardType: "Attack");
        var skill1 = BlockCard("skill-1", 0, 0) with { CardType = "Skill" };
        var skill2 = BlockCard("skill-2", 0, 0) with { CardType = "Skill" };
        var skill3 = BlockCard("skill-3", 0, 0) with { CardType = "Skill" };
        var snapshot = Snapshot(30, 30, 0, [makeItSo, skill1, skill2, skill3], energy: 0);
        var simulator = new DeterministicSimulator();

        var state = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), makeItSo, "enemy-0", null);
        state = simulator.PlayCard(state, state.Hand.Single(card => card.InstanceId == "skill-1"), null, null);
        state = simulator.PlayCard(state, state.Hand.Single(card => card.InstanceId == "skill-2"), null, null);
        Assert.DoesNotContain(state.Hand, card => card.InstanceId == "make-it-so");
        state = simulator.PlayCard(state, state.Hand.Single(card => card.InstanceId == "skill-3"), null, null);

        Assert.Contains(state.Hand, card => card.InstanceId == "make-it-so");
        Assert.DoesNotContain(state.DiscardPile, card => card.InstanceId == "make-it-so");
    }

    [Fact]
    public void RebootMovesAllNonExhaustedCardsBeforeDrawingAndExhaustsItself()
    {
        var reboot = new CardState(
            "reboot", "REBOOT", "Reboot", 0, TargetKind.Self,
            [
                new EffectSpec(EffectKind.Reboot, RandomSource: "Shuffle"),
                new EffectSpec(EffectKind.Draw, 2)
            ],
            CardDestination.Exhaust,
            CardType: "Skill");
        var a = DamageCard("a", 1, 0);
        var b = DamageCard("b", 1, 0);
        var c = DamageCard("c", 1, 0);
        var snapshot = Snapshot(30, 100, 0, [reboot, a], energy: 0) with
        {
            DrawPile = [b],
            DiscardPile = [c],
            RngState = 0
        };

        var outcomes = new DeterministicSimulator().PlayCardOutcomes(
            MutableCombatState.FromSnapshot(snapshot), reboot, null, null);

        // a/b/c share the same semantic card signature; NOSL merges their
        // interchangeable permutations into one probability branch.
        Assert.Single(outcomes);
        Assert.All(outcomes, outcome =>
        {
            Assert.Contains(outcome.State.ExhaustPile, card => card.InstanceId == "reboot");
            Assert.Equal(2, outcome.State.Hand.Count);
            Assert.Empty(outcome.State.DiscardPile);
            Assert.Empty(outcome.State.DrawPile);
            Assert.Single(outcome.State.UnorderedDrawPool);
        });
    }

    [Fact]
    public void RanksDamageAndMinimumLossIndependently()
    {
        var snapshot = Snapshot(
            hp: 50,
            enemyHp: 30,
            enemyDamage: 10,
            hand:
            [
                DamageCard("s1", 6),
                DamageCard("s2", 6),
                DamageCard("s3", 6),
                BlockCard("d1", 5),
                BlockCard("d2", 5)
            ],
            energy: 3);

        var results = Complete(snapshot);

        Assert.True(results.Progress.IsComplete);
        Assert.Equal(18m, results.HighestDamage[0].Score!.EffectiveDamage);
        Assert.Equal(0m, results.MinimumLoss[0].Score!.PlayerHpLoss);
        Assert.Contains(results.MinimumLoss[0].Steps, step => step.SourceInstanceId == "d1" || step.SourceInstanceId == "d2");
    }

    [Fact]
    public void AllObjectivesPreferSurvivalOverAHighDamageDeathLine()
    {
        var lethalButUnsafe = DamageCard("unsafe-attack", 50, cost: 1);
        var safeBlock = BlockCard("safe-block", 10, cost: 1);
        var snapshot = Snapshot(5, 100, 10, [lethalButUnsafe, safeBlock], energy: 1);

        var results = Complete(snapshot, maximumActions: 4);

        Assert.NotEmpty(results.HighestDamage);
        Assert.NotEmpty(results.MinimumLoss);
        Assert.False(results.HighestDamage[0].Terminal!.PlayerDied);
        Assert.False(results.MinimumLoss[0].Terminal!.PlayerDied);
        Assert.Contains(results.HighestDamage[0].Steps, step => step.SourceInstanceId == "safe-block");
    }

    [Fact]
    public void GeneratedStatusCardRunsStrengthBlockAndSmokestackHooksPerCard()
    {
        var status = new CardState(
            "status-template", "WOUND", "Wound", 0, TargetKind.None, [],
            IsPlayable: false, CardType: "Status");
        var generator = new CardState(
            "generator", "GENERATE_STATUS", "Generate Status", 0, TargetKind.None,
            [new EffectSpec(EffectKind.GenerateCards, 2, GeneratedCard: status)]);
        var statuses = EmptyStatuses
            .Add("TRIGGER_CARD_GENERATED_STRENGTH", new StatusState("TRIGGER_CARD_GENERATED_STRENGTH", 1))
            .Add("TRIGGER_CARD_GENERATED_BLOCK", new StatusState("TRIGGER_CARD_GENERATED_BLOCK", 2))
            .Add("TRIGGER_STATUS_CARD_GENERATED_ALL_DAMAGE", new StatusState("TRIGGER_STATUS_CARD_GENERATED_ALL_DAMAGE", 5));
        var snapshot = Snapshot(40, 20, 0, [generator], energy: 0) with
        {
            Player = new PlayerState(40, 40, 0, 0, 0, statuses)
        };

        var result = new DeterministicSimulator().PlayCard(MutableCombatState.FromSnapshot(snapshot), generator, null, null);

        Assert.Equal(2m, result.Player.Statuses["STRENGTH"].Amount);
        Assert.Equal(4m, result.Player.Block);
        Assert.Equal(10m, result.Enemies[0].Hp);
        Assert.Equal(2, result.CardsGeneratedSinceSnapshot);
        Assert.Equal(2, result.Hand.Count(card => card.CardType == "Status"));
    }

    [Fact]
    public void ShadowStepDoublesOnlyPoweredAttacksOnNextTurn()
    {
        var shadow = new CardState(
            "shadow", "SHADOW_STEP", "Shadow Step", 0, TargetKind.None,
            [
                new EffectSpec(EffectKind.DiscardHand),
                new EffectSpec(EffectKind.ApplyStatus, 1, "SHADOW_STEP_PENDING", Duration: 2, FutureValuePerTurn: 5m)
            ], CardType: "Skill");
        var attack = new CardState(
            "attack", "STRIKE", "Strike", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 5)], CardType: "Attack");
        var skillDamage = new CardState(
            "skill-damage", "SKILL_DAMAGE", "Skill Damage", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 5)], CardType: "Skill");
        var snapshot = Snapshot(40, 100, 0, [shadow], energy: 0);
        var simulator = new DeterministicSimulator();

        var afterShadow = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), shadow, null, null);
        Assert.Empty(afterShadow.Hand);
        Assert.Equal(2, afterShadow.Player.Statuses["SHADOW_STEP_PENDING"].Duration);

        afterShadow.Hand.Add(attack);
        var sameTurnAttack = simulator.PlayCard(afterShadow, attack, "enemy-0", null);
        Assert.Equal(95m, sameTurnAttack.Enemies[0].Hp);

        var nextTurn = simulator.ProjectToNextPlayerTurn(sameTurnAttack);
        Assert.False(nextTurn.Player.Statuses.ContainsKey("SHADOW_STEP_PENDING"));
        Assert.Equal(1, nextTurn.Player.Statuses["DOUBLE_DAMAGE"].Duration);
        Assert.Equal(1, nextTurn.Player.Statuses["DOUBLE_DAMAGE"].Amount);
        nextTurn.Hand.Add(attack);
        Assert.Equal("Attack", nextTurn.Hand[^1].CardType);
        var afterAttack = simulator.PlayCard(nextTurn, attack, "enemy-0", null);
        Assert.Contains("DOUBLE_DAMAGE", afterAttack.Player.Statuses.Keys);
        Assert.Equal(85m, afterAttack.Enemies[0].Hp);

        afterAttack.Hand.Add(skillDamage);
        var afterSkill = simulator.PlayCard(afterAttack, skillDamage, "enemy-0", null);
        Assert.Equal(80m, afterSkill.Enemies[0].Hp);

        var followingTurn = simulator.ProjectToNextPlayerTurn(afterSkill);
        Assert.False(followingTurn.Player.Statuses.ContainsKey("DOUBLE_DAMAGE"));
    }

    [Fact]
    public void ReaperFormAppliesDoomFromActualPoweredAttackDamage()
    {
        var reaper = new CardState(
            "reaper", "REAPER_FORM", "Reaper Form", 0, TargetKind.None,
            [new EffectSpec(EffectKind.ApplyStatus, 1, "TRIGGER_ATTACK_DAMAGE_DOOM", FutureValuePerTurn: 3m)],
            CardType: "Power");
        var attack = new CardState(
            "attack", "STRIKE", "Strike", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 5)], CardType: "Attack");
        var skillDamage = new CardState(
            "skill-damage", "SKILL_DAMAGE", "Skill Damage", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 5)], CardType: "Skill");
        var snapshot = Snapshot(40, 30, 0, [reaper, attack], energy: 0);
        var simulator = new DeterministicSimulator();

        var afterReaper = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), reaper, null, null);
        var afterAttack = simulator.PlayCard(afterReaper, attack, "enemy-0", null);
        Assert.Equal(25m, afterAttack.Enemies[0].Hp);
        Assert.Equal(5, afterAttack.Enemies[0].Statuses["DOOM"].Amount);

        afterAttack.Hand.Add(skillDamage);
        var afterSkill = simulator.PlayCard(afterAttack, skillDamage, "enemy-0", null);
        Assert.Equal(20m, afterSkill.Enemies[0].Hp);
        Assert.Equal(5, afterSkill.Enemies[0].Statuses["DOOM"].Amount);
    }

    [Fact]
    public void BlightStrikeUsesTotalDamageIncludingBlockedDamageForDoom()
    {
        var blightStrike = new CardState(
            "blight-strike", "BLIGHT_STRIKE", "Blight Strike", 0, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 8),
                new EffectSpec(EffectKind.ApplyStatus, 1, "DOOM_EQUAL_DAMAGE")
            ],
            CardType: "Attack");
        var snapshot = Snapshot(40, 100, 0, [blightStrike], energy: 0) with
        {
            Enemies = [new CreatureState("enemy-0", "Enemy", 100, 100, 3, EmptyStatuses, [], 0)]
        };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), blightStrike, "enemy-0", null);

        Assert.Equal(95m, result.Enemies[0].Hp);
        Assert.Equal(0m, result.Enemies[0].Block);
        Assert.Equal(8, result.Enemies[0].Statuses["DOOM"].Amount);
    }

    [Fact]
    public void ColossusHalvesOnlyVulnerableEnemyPoweredAttacks()
    {
        var colossus = new CardState(
            "colossus", "COLOSSUS", "Colossus", 0, TargetKind.Self,
            [
                new EffectSpec(EffectKind.Block, 5),
                new EffectSpec(EffectKind.ApplyStatus, 1, "REDUCE_VULNERABLE_ATTACK_DAMAGE", Duration: 1, FutureValuePerTurn: 3m)
            ], CardType: "Skill");
        var baseSnapshot = Snapshot(40, 30, 20, [colossus], energy: 0);
        var vulnerableSnapshot = baseSnapshot with
        {
            Enemies =
            [
                baseSnapshot.Enemies[0] with
                {
                    Statuses = EmptyStatuses.Add("VULNERABLE", new StatusState("VULNERABLE", 1))
                }
            ]
        };
        var simulator = new DeterministicSimulator();

        var protectedTurn = simulator.ProjectToNextPlayerTurn(
            simulator.PlayCard(MutableCombatState.FromSnapshot(vulnerableSnapshot), colossus, null, null));
        Assert.Equal(35m, protectedTurn.Player.Hp);
        Assert.False(protectedTurn.Player.Statuses.ContainsKey("REDUCE_VULNERABLE_ATTACK_DAMAGE"));

        var normalTurn = simulator.ProjectToNextPlayerTurn(
            simulator.PlayCard(MutableCombatState.FromSnapshot(baseSnapshot), colossus, null, null));
        Assert.Equal(25m, normalTurn.Player.Hp);
    }

    [Fact]
    public void RocketPunchCostReducesPerGeneratedStatusAndResetsAfterPlay()
    {
        var status = new CardState(
            "status-template", "WOUND", "Wound", 0, TargetKind.None, [],
            IsPlayable: false, CardType: "Status");
        var generator = new CardState(
            "generator", "GENERATE_STATUS", "Generate Status", 0, TargetKind.None,
            [new EffectSpec(EffectKind.GenerateCards, 2, GeneratedCard: status)]);
        var rocket = new CardState(
            "rocket", "ROCKET_PUNCH", "Rocket Punch", 2, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 1),
                new EffectSpec(EffectKind.ModifyPlayedCardCost, -1, "SELF_BY_STATUS_GENERATED")
            ], BaseEnergyCost: 2);
        var snapshot = Snapshot(40, 20, 0, [generator, rocket], energy: 3);

        var afterGeneration = new DeterministicSimulator().PlayCard(MutableCombatState.FromSnapshot(snapshot), generator, null, null);
        var liveRocket = Assert.Single(afterGeneration.Hand.Where(card => card.ModelId == "ROCKET_PUNCH"));
        Assert.Equal(0, liveRocket.EnergyCost);
        var afterPlay = new DeterministicSimulator().PlayCard(afterGeneration, liveRocket, "enemy-0", null);

        var discardedRocket = Assert.Single(afterPlay.DiscardPile.Where(card => card.ModelId == "ROCKET_PUNCH"));
        Assert.Equal(2, discardedRocket.EnergyCost);
    }

    [Fact]
    public void SearchStateKeysDistinguishCardEnergyCostAndXCost()
    {
        var card = DamageCard("cost-card", 6, 1);
        var state = MutableCombatState.FromSnapshot(Snapshot(30, 30, 0, [card], energy: 1));
        var reduced = state.Clone();
        reduced.Hand[0] = reduced.Hand[0] with { EnergyCost = 0 };
        var xCost = state.Clone();
        xCost.Hand[0] = xCost.Hand[0] with { CostsX = true };

        Assert.NotEqual(state.ExactKey(), reduced.ExactKey());
        Assert.NotEqual(state.CycleKeyWithoutProgress(), reduced.CycleKeyWithoutProgress());
        Assert.NotEqual(state.ExactKey(), xCost.ExactKey());
    }

    [Fact]
    public void DrawingKinglyKickReducesItsLiveCost()
    {
        var draw = new CardState(
            "draw", "DRAW_ONE", "Draw", 0, TargetKind.None,
            [new EffectSpec(EffectKind.Draw, 1)]);
        var kinglyKick = DamageCard("kingly", 27, 2) with
        {
            ModelId = "KINGLY_KICK",
            EnergyCostChangeOnDraw = -1
        };
        var state = MutableCombatState.FromSnapshot(
            Snapshot(30, 30, 0, [draw], [kinglyKick], energy: 0));

        var result = new DeterministicSimulator().PlayCard(state, draw, null, null);

        Assert.Equal(1, result.Hand.Single(card => card.InstanceId == "kingly").EnergyCost);
    }

    [Fact]
    public void ScheduledFixedBlockArrivesOnNextPlayerTurn()
    {
        var card = new CardState(
            "glitter", "GLITTERSTREAM", "Glitterstream", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 5, "SCHEDULED_BLOCK", Duration: 1)]);
        var state = MutableCombatState.FromSnapshot(Snapshot(30, 30, 0, [card], energy: 0));

        var afterPlay = new DeterministicSimulator().PlayCard(state, card, null, null);
        var nextTurn = new DeterministicSimulator().ProjectToNextPlayerTurn(afterPlay);

        Assert.Equal(5m, nextTurn.Player.Block);
    }

    [Fact]
    public void DrawnCardBecomesAvailableInSameSearch()
    {
        var draw = new CardState(
            "draw",
            "DRAW_ONE",
            "Draw",
            0,
            TargetKind.None,
            [new EffectSpec(EffectKind.Draw, 1)]);
        var finisher = DamageCard("finisher", 20);
        var snapshot = Snapshot(
            hp: 40,
            enemyHp: 20,
            enemyDamage: 0,
            hand: [draw],
            drawPile: [finisher],
            energy: 1);

        var results = Complete(snapshot);

        var winning = Assert.Single(results.HighestDamage.Where(line => line.Terminal!.CombatWon));
        Assert.Equal(new[] { "draw", "finisher" },
            winning.Steps.Where(step => step.Kind == ActionKind.PlayCard).Select(step => step.SourceInstanceId));
        Assert.Equal(2, winning.SafeCheckpoints.Length);
        Assert.Equal(new[] { "finisher" }, winning.SafeCheckpoints[0].HandInstanceIds);
    }

    [Fact]
    public void MissingRngProducesAnExplicitPolicyInsteadOfAFixedReliableLine()
    {
        var draw = new CardState("draw", "DRAW", "Draw", 0, TargetKind.None, [new EffectSpec(EffectKind.Draw, 1)]);
        var snapshot = Snapshot(40, 20, 0, [draw], discardPile: [DamageCard("next", 8)], energy: 1) with { RngState = 0 };

        var results = Complete(snapshot);

        Assert.Contains(results.Policies, policy =>
            policy.DeterministicPrefix.Any(step => step.SourceInstanceId == "draw"));
        Assert.DoesNotContain(results.Balanced, line => line.Steps.Any(step => step.SourceInstanceId == "draw"));
        Assert.DoesNotContain(results.EstimatedBalanced, line => line.Steps.Any(step => step.SourceInstanceId == "draw"));
    }

    [Fact]
    public void UnknownEndTurnShuffleExpandsNextTurnDrawsAsExactKnownProbabilityBranches()
    {
        var strike = DamageCard("strike", 8, 0);
        var defend = BlockCard("defend", 7, 0);
        var snapshot = Snapshot(
            40,
            30,
            0,
            [],
            discardPile: [strike, defend],
            energy: 0) with
        {
            RngState = 0,
            Player = Snapshot(40, 30, 0, [], energy: 0).Player with { CardsPerTurn = 1 }
        };

        var outcomes = new DeterministicSimulator()
            .ProjectToNextPlayerTurnOutcomes(MutableCombatState.FromSnapshot(snapshot));

        Assert.Equal(2, outcomes.Length);
        Assert.All(outcomes, outcome => Assert.Equal(0.5m, outcome.Probability));
        Assert.All(outcomes, outcome =>
        {
            Assert.Equal(PredictionConfidence.Reliable, outcome.State.Confidence);
            Assert.DoesNotContain(outcome.State.Restrictions,
                restriction => restriction.Code == "unknown_shuffle_rng_state");
            Assert.Equal("Exact", outcome.OutcomeQuality);
            Assert.Single(outcome.State.Hand);
        });
        Assert.Contains(outcomes, outcome => outcome.State.Hand[0].InstanceId == "strike");
        Assert.Contains(outcomes, outcome => outcome.State.Hand[0].InstanceId == "defend");
    }

    [Fact]
    public void ShrinkerBeetleDebuffAppliesShrinkPowerAndReducesNextAttack()
    {
        var debuff = new IntentState(
            "DebuffStrong",
            Effects: [new EffectSpec(EffectKind.ApplyStatus, 1, "SHRINK", Duration: 3, IsDebuff: true)]);
        var enemy = new CreatureState(
            "enemy:SHRINKER_BEETLE:1", "Shrinker Beetle", 30, 30, 0,
            EmptyStatuses, [debuff]);
        var snapshot = CombatSnapshot.Create(
            "shrink-intent",
            new PlayerState(30, 30, 0, 0, 0, EmptyStatuses, CardsPerTurn: 0),
            [enemy], [], drawPile: [], discardPile: []);
        var simulator = new DeterministicSimulator();

        var first = simulator.ProjectToNextPlayerTurn(MutableCombatState.FromSnapshot(snapshot));
        Assert.Equal(1, first.Player.Statuses["SHRINK"].Amount);
        Assert.Equal(-1m, first.Powers.Single(power => power.Id == "SHRINK_POWER").Amount);

        first.Enemies[0] = first.Enemies[0] with
        {
            Intents = [new IntentState("Attack", 10, 1)]
        };
        var second = simulator.ProjectToNextPlayerTurn(first);
        Assert.Equal(23m, second.Player.Hp);
    }

    [Fact]
    public void UnknownTwoCardShuffleProducesAnExactConditionalPolicy()
    {
        var draw = new CardState("draw", "DRAW", "Draw", 0, TargetKind.None, [new EffectSpec(EffectKind.Draw, 1)]);
        var strike = DamageCard("strike", 8, 0);
        var defend = BlockCard("defend", 7, 0);
        var snapshot = Snapshot(
            40,
            30,
            7,
            [draw],
            discardPile: [strike, defend],
            energy: 0) with { RngState = 0 };
        snapshot = snapshot with { Player = snapshot.Player with { CardsPerTurn = 0 } };

        var results = Complete(snapshot);

        var policy = Assert.Single(results.Policies.Where(item =>
            item.Objective == ObjectiveKind.Balanced &&
            item.DeterministicPrefix.Any(step => step.SourceInstanceId == "draw")));
        Assert.Equal(2, policy.Branches.Length);
        Assert.Equal(1m, policy.Branches.Sum(static branch => branch.Probability));
        Assert.All(policy.Branches, static branch => Assert.Equal(0.5m, branch.Probability));
        Assert.Contains(policy.Branches, branch => branch.Label.Contains("Strike", StringComparison.Ordinal) &&
                                                   branch.Actions.Any(step => step.SourceInstanceId == "strike"));
        Assert.Contains(policy.Branches, branch => branch.Label.Contains("Defend", StringComparison.Ordinal) &&
                                                   branch.Actions.Any(step => step.SourceInstanceId == "defend"));
        Assert.True(policy.BalancedDistribution!.IsExact);
        Assert.Equal(policy.DeterministicPrefix.Length - 1, policy.ChanceBoundaryActionIndex);
        Assert.DoesNotContain(policy.DeterministicPrefix, step => step.SourceInstanceId is "strike" or "defend");
        Assert.Equal(policy.DeterministicPrefix.Length, policy.SafePrefixCheckpoints.Length);
    }

    [Fact]
    public void ConditionalPolicyReportsDeathProbabilityAcrossDrawOutcomes()
    {
        var draw = new CardState("draw", "DRAW", "Draw", 0, TargetKind.None, [new EffectSpec(EffectKind.Draw, 1)]);
        var strike = DamageCard("strike", 4, 0);
        var defend = BlockCard("defend", 8, 0);
        var snapshot = Snapshot(5, 30, 7, [draw], discardPile: [strike, defend], energy: 0) with { RngState = 0 };
        snapshot = snapshot with { Player = snapshot.Player with { CardsPerTurn = 0 } };

        var results = Complete(snapshot);

        var policy = Assert.Single(results.Policies.Where(item =>
            item.Objective == ObjectiveKind.Balanced &&
            item.DeterministicPrefix.Any(step => step.SourceInstanceId == "draw")));
        Assert.Equal(0.5m, policy.LossDistribution!.DeathProbability);
        Assert.All(policy.Branches, branch => Assert.NotEmpty(branch.Actions));
        Assert.Contains(policy.Branches, branch => branch.Actions.Any(step => step.SourceInstanceId == "strike"));
        Assert.Contains(policy.Branches, branch => branch.Actions.Any(step => step.SourceInstanceId == "defend"));
    }

    [Fact]
    public void RiskFromUnsupportedCardDoesNotPoisonIndependentLine()
    {
        var unknown = new CardState(
            "unknown",
            "UNKNOWN",
            "Unknown",
            1,
            TargetKind.None,
            [new EffectSpec(EffectKind.GainEnergy, UnsupportedReason: "Missing hook")]);
        var strike = DamageCard("strike", 6);

        var results = Complete(Snapshot(40, 20, 0, [unknown, strike], energy: 1));

        Assert.Contains(results.Balanced, line => line.Steps.Any(step => step.SourceInstanceId == "strike") &&
                                                 line.RiskTimeline.Events.Length == 0);
        Assert.Contains(results.Restricted, line => line.Steps.Any(step => step.SourceInstanceId == "unknown") &&
                                                   line.RiskTimeline.Events.Any(risk => risk.ActionIndex == 0));
    }

    [Fact]
    public void SmallShuffleEnumeratesKnownMultisetExactly()
    {
        var draw = new CardState("draw", "DRAW", "Draw", 0, TargetKind.None, [new EffectSpec(EffectKind.Draw, 1)]);
        var cards = Enumerable.Range(0, 5).Select(index => DamageCard($"s{index}", index + 1, 0)).ToArray();
        var snapshot = Snapshot(40, 99, 0, [draw], discardPile: cards, energy: 0) with { RngState = 0 };
        snapshot = snapshot with { Player = snapshot.Player with { CardsPerTurn = 0 } };

        var results = Complete(snapshot, maximumActions: 3);

        var policy = Assert.Single(results.Policies.Where(item =>
            item.Objective == ObjectiveKind.Balanced &&
            item.DeterministicPrefix.Any(step => step.SourceInstanceId == "draw")));
        Assert.True(policy.BalancedDistribution!.IsExact);
        Assert.Equal(5, policy.Branches.Length);
        Assert.Equal(1m, policy.Branches.Sum(static branch => branch.Probability));
        Assert.Equal(policy.BalancedDistribution.Expected, policy.BalancedDistribution.ConfidenceIntervalLow);
        Assert.Equal(policy.BalancedDistribution.Expected, policy.BalancedDistribution.ConfidenceIntervalHigh);
        Assert.Equal(PredictionConfidence.Reliable, policy.Confidence);
        Assert.DoesNotContain(policy.Risks, static risk => risk.Reason == PredictionRiskReason.ChanceBranchSampled);
    }

    [Fact]
    public void UnsupportedEffectsAreRestrictedAndNeverEnterMainRankings()
    {
        var unknown = new CardState(
            "mystery",
            "MYSTERY",
            "Mystery",
            0,
            TargetKind.None,
            [new EffectSpec(EffectKind.GainEnergy, UnsupportedReason: "No mirror for custom hook.")]);
        var results = Complete(Snapshot(40, 20, 0, [unknown], energy: 1));

        Assert.Contains(results.Restricted, line => line.Steps.Any(step => step.SourceInstanceId == "mystery"));
        Assert.DoesNotContain(results.Balanced, line => line.Steps.Any(step => step.SourceInstanceId == "mystery"));
    }

    [Fact]
    public void CalculableEstimatedLinesReceiveObjectiveRankingsButRemainOutsideReliableRankings()
    {
        var snapshot = Snapshot(
            hp: 40,
            enemyHp: 20,
            enemyDamage: 6,
            hand: [DamageCard("strike", 6), BlockCard("defend", 5)],
            energy: 1) with
        {
            GlobalRestrictions = ["Relic hook has not been verified."]
        };

        var results = Complete(snapshot);

        Assert.Empty(results.Balanced);
        Assert.NotEmpty(results.EstimatedBalanced);
        Assert.NotEmpty(results.EstimatedHighestDamage);
        Assert.NotEmpty(results.EstimatedMinimumLoss);
        Assert.All(results.EstimatedBalanced, line => Assert.Equal(PredictionConfidence.Estimated, line.Confidence));
    }

    [Fact]
    public void DexterityIncreasesPlayerBlockFromCardEffects()
    {
        var snapshot = Snapshot(
            hp: 40,
            enemyHp: 20,
            enemyDamage: 10,
            hand: [BlockCard("defend", 5)],
            energy: 1) with
        {
            Player = new PlayerState(
                40,
                40,
                0,
                1,
                1,
                EmptyStatuses.Add("DEXTERITY", new StatusState("DEXTERITY", 2)))
        };

        var results = Complete(snapshot);

        Assert.Equal(3m, results.MinimumLoss[0].Score!.PlayerHpLoss);
    }

    [Fact]
    public void SurvivorBranchesOnEachDiscardAndMovesTheChosenCard()
    {
        var strike = DamageCard("strike", 6);
        var defend = BlockCard("defend", 5);
        var survivor = new CardState(
            "survivor",
            "SURVIVOR",
            "Survivor",
            1,
            TargetKind.Self,
            [new EffectSpec(EffectKind.Block, 8), new EffectSpec(EffectKind.DiscardCards, 1)],
            Choices:
            [
                new ChoiceSpec("strike", "Discard Strike", [], "strike"),
                new ChoiceSpec("defend", "Discard Defend", [], "defend")
            ]);

        var results = Complete(Snapshot(40, 30, 10, [survivor, strike, defend], energy: 1));
        var branches = results.Balanced.Concat(results.EstimatedBalanced).Concat(results.Restricted)
            .Where(line => line.Steps.FirstOrDefault()?.SourceInstanceId == "survivor")
            .ToArray();

        Assert.Contains(branches, line =>
            line.Steps[0].ChoiceId == "strike" &&
            !line.SafeCheckpoints[0].HandInstanceIds.Contains("strike"));
        Assert.Contains(branches, line =>
            line.Steps[0].ChoiceId == "defend" &&
            !line.SafeCheckpoints[0].HandInstanceIds.Contains("defend"));
    }

    [Fact]
    public void StormOfSteelDiscardsTheRemainingHandAndGeneratedShivsRemainPlayable()
    {
        var shiv = new CardState(
            "generated-shiv",
            "SHIV",
            "Shiv",
            0,
            TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 4)],
            CardDestination.Exhaust);
        var storm = new CardState(
            "storm",
            "STORM_OF_STEEL",
            "Storm of Steel",
            1,
            TargetKind.None,
            [new EffectSpec(EffectKind.DiscardHandAndGenerate, GeneratedCard: shiv)]);
        var snapshot = Snapshot(
            40,
            40,
            0,
            [
                storm,
                DamageCard("strike-1", 6),
                DamageCard("strike-2", 6),
                DamageCard("strike-3", 6),
                DamageCard("strike-4", 6),
                DamageCard("strike-5", 6)
            ],
            energy: 3);

        var results = Complete(snapshot);

        Assert.Equal(24m, results.HighestDamage[0].Score!.EffectiveDamage);
        Assert.Contains(results.HighestDamage[0].Steps, step => step.SourceInstanceId == "storm");
        Assert.Equal(3, results.HighestDamage[0].Steps.Count(step => step.SourceInstanceId.StartsWith("generated-shiv:", StringComparison.Ordinal)));
    }

    [Fact]
    public void NeutralizeWeakReducesProjectedEnemyDamage()
    {
        var neutralize = new CardState(
            "neutralize",
            "NEUTRALIZE",
            "Neutralize",
            0,
            TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 3),
                new EffectSpec(EffectKind.ApplyStatus, 1, "WEAK", Duration: 1, IsDebuff: true)
            ]);

        var results = Complete(Snapshot(40, 30, 10, [neutralize], energy: 0));

        Assert.Equal(7m, results.MinimumLoss[0].Score!.PlayerHpLoss);
        Assert.Contains(results.MinimumLoss[0].Steps, step => step.SourceInstanceId == "neutralize");
    }

    [Fact]
    public void ScheduledEnergyAndDrawResolveAtTheNextPlayerTurn()
    {
        var setup = new CardState(
            "setup",
            "SETUP",
            "Setup",
            0,
            TargetKind.Self,
            [
                new EffectSpec(EffectKind.ApplyStatus, 2, "SCHEDULED_ENERGY", Duration: 1),
                new EffectSpec(EffectKind.ApplyStatus, 1, "SCHEDULED_DRAW", Duration: 1)
            ]);
        var drawn = DamageCard("drawn", 6, 0);
        var snapshot = Snapshot(40, 30, 0, [setup], drawPile: [drawn], energy: 0);
        snapshot = snapshot with { Player = snapshot.Player with { CardsPerTurn = 0 } };

        var results = Complete(snapshot);
        var line = Assert.Single(results.Balanced.Where(candidate =>
            candidate.Steps.Any(step => step.SourceInstanceId == "setup")));

        Assert.Contains(line.Terminal!.NextHand, card => card.InstanceId == "drawn");
        Assert.Equal(1.25m, line.Score!.HandAndResourceValue);
    }

    [Fact]
    public void DeterministicallyGeneratedCardsJoinTheSameTurnSearch()
    {
        var shiv = new CardState(
            "generated:shiv",
            "SHIV",
            "Shiv",
            0,
            TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 4)],
            CardDestination.Exhaust);
        var generator = new CardState(
            "generator",
            "GENERATE_SHIVS",
            "Generate Shivs",
            0,
            TargetKind.None,
            [new EffectSpec(EffectKind.GenerateCards, 2, GeneratedCard: shiv)]);

        var results = Complete(Snapshot(40, 8, 0, [generator], energy: 0));
        var winning = results.HighestDamage.First(line => line.Terminal!.CombatWon);

        Assert.Equal(8m, winning.Score!.EffectiveDamage);
        Assert.Equal(2, winning.Steps.Count(step => step.SourceModelId == "SHIV"));
    }

    [Fact]
    public void DeterministicallyGeneratedCardsCanEnterTheDiscardPile()
    {
        var wound = new CardState(
            "generated:wound", "WOUND", "Wound", 0, TargetKind.None, [],
            IsPlayable: false, RestrictionReason: "Status card");
        var generator = new CardState(
            "generator", "GENERATE_WOUNDS", "Generate Wounds", 0, TargetKind.None,
            [new EffectSpec(
                EffectKind.GenerateCards,
                2,
                GeneratedCard: wound,
                GeneratedDestination: GeneratedCardDestination.DiscardPile)]);
        var results = Complete(Snapshot(40, 20, 0, [generator], energy: 0), maximumActions: 1);
        var line = Assert.Single(results.Balanced.Where(candidate =>
            candidate.Steps.Any(step => step.SourceInstanceId == "generator")));

        Assert.Equal(2, line.Terminal!.NextHand.Count(card => card.ModelId == "WOUND"));
    }

    [Fact]
    public void SelfCopyPreservesThePlayedCardsEffectsInTheDiscardPile()
    {
        var anger = new CardState(
            "anger", "ANGER", "Anger", 0, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 6),
                new EffectSpec(
                    EffectKind.CopyPlayedCard,
                    1,
                    GeneratedDestination: GeneratedCardDestination.DiscardPile)
            ]);

        var results = Complete(Snapshot(40, 20, 0, [anger], energy: 0), maximumActions: 1);
        var line = Assert.Single(results.HighestDamage.Where(candidate =>
            candidate.Steps.Any(step => step.SourceInstanceId == "anger")));
        var copy = Assert.Single(line.Terminal!.NextHand.Where(card => card.InstanceId.StartsWith("copy:", StringComparison.Ordinal)));

        Assert.Contains(copy.Effects, effect => effect.Kind == EffectKind.Damage && effect.Amount == 6);
        Assert.Contains(copy.Effects, effect => effect.Kind == EffectKind.CopyPlayedCard);
    }

    [Fact]
    public void DynamicDamageReadsTheCurrentPlayerBlock()
    {
        var bodySlam = new CardState(
            "body-slam", "BODY_SLAM", "Body Slam", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.DynamicDamage, 1, "PLAYER_BLOCK")]);
        var snapshot = Snapshot(40, 12, 0, [bodySlam], energy: 0);
        snapshot = snapshot with { Player = snapshot.Player with { Block = 12 } };

        var results = Complete(snapshot, maximumActions: 1);
        var winning = Assert.Single(results.HighestDamage.Where(line => line.Terminal!.CombatWon));

        Assert.Equal(12m, winning.Score!.EffectiveDamage);
    }

    [Fact]
    public void StatusMultiplierUpdatesTheSelectedEnemy()
    {
        var catalyst = new CardState(
            "catalyst", "CATALYST", "Catalyst", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.MultiplyStatus, 2, "POISON")]);
        var snapshot = Snapshot(40, 20, 0, [catalyst], energy: 0);
        snapshot = snapshot with
        {
            Enemies =
            [
                snapshot.Enemies[0] with
                {
                    Statuses = snapshot.Enemies[0].Statuses.Add("POISON", new StatusState("POISON", 4))
                }
            ]
        };

        var results = Complete(snapshot, maximumActions: 1);
        var line = Assert.Single(results.Balanced.Where(candidate =>
            candidate.Steps.Any(step => step.SourceInstanceId == "catalyst")));

        Assert.Equal(7, line.Terminal!.Enemies[0].Statuses["POISON"].Amount); // doubled to 8, then normal poison decay at projection
    }

    [Fact]
    public void ProjectionRetainsRetainCardsAndExhaustsEtherealCards()
    {
        var retained = BlockCard("retained", 1, 9) with
        {
            IsPlayable = false,
            RetainAtTurnEnd = true
        };
        var ethereal = BlockCard("ethereal", 1, 9) with
        {
            IsPlayable = false,
            ExhaustAtTurnEnd = true
        };
        var drawn = DamageCard("drawn", 1, 9) with { IsPlayable = false };

        var results = Complete(Snapshot(40, 20, 0, [retained, ethereal], drawPile: [drawn], energy: 0), maximumActions: 1);
        var terminal = Assert.Single(results.Balanced).Terminal!;

        Assert.Contains(terminal.NextHand, card => card.InstanceId == "retained");
        Assert.Contains(terminal.NextHand, card => card.InstanceId == "drawn");
        Assert.DoesNotContain(terminal.NextHand, card => card.InstanceId == "ethereal");
    }

    [Fact]
    public void ProjectionAppliesBurnDamageAndVoidEnergyLoss()
    {
        var burn = BlockCard("burn", 0, 9) with
        {
            IsPlayable = false,
            ExhaustAtTurnEnd = true,
            HpLossAtTurnEnd = 2
        };
        var voidCard = BlockCard("void", 0, 9) with
        {
            IsPlayable = false,
            ExhaustAtTurnEnd = true,
            EnergyChangeOnDraw = -1
        };
        var snapshot = Snapshot(10, 20, 0, [burn], drawPile: [voidCard], energy: 0);
        snapshot = snapshot with { Player = snapshot.Player with { MaxEnergy = 3, CardsPerTurn = 1 } };

        var results = Complete(snapshot, maximumActions: 1);
        var terminal = Assert.Single(results.Balanced).Terminal!;

        Assert.Equal(8, terminal.PlayerHp);
        Assert.Contains(terminal.NextHand, card => card.InstanceId == "void");
        Assert.StartsWith("8|0|2", terminal.StateKey, StringComparison.Ordinal);
    }

    [Fact]
    public void MultiCardDiscardPileChoiceContinuesWithEverySelectedCard()
    {
        var first = DamageCard("discard-hit-1", 6, 0);
        var second = DamageCard("discard-hit-2", 6, 0);
        var dredge = new CardState(
            "dredge", "DREDGE", "Dredge", 0, TargetKind.None,
            [new EffectSpec(EffectKind.ChooseDiscardToHand, 2)],
            Choices:
            [
                new ChoiceSpec(
                    "both-hits",
                    "Both hits",
                    [],
                    CardInstanceIds: [first.InstanceId, second.InstanceId])
            ]);

        var results = Complete(
            Snapshot(40, 12, 0, [dredge], discardPile: [first, second], energy: 0),
            maximumActions: 3);
        var winning = results.HighestDamage.First(line => line.Terminal!.CombatWon);

        Assert.Equal(new[] { "dredge", "discard-hit-1", "discard-hit-2" },
            winning.Steps.Where(step => step.Kind == ActionKind.PlayCard).Select(step => step.SourceInstanceId));
    }

    [Fact]
    public void XCostDamageUsesAndConsumesTheEnergyAvailableAtPlayTime()
    {
        var skewer = new CardState(
            "skewer", "SKEWER", "Skewer", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 5, RepeatByEnergySpent: true)],
            CostsX: true);

        var results = Complete(Snapshot(40, 15, 0, [skewer], energy: 3), maximumActions: 1);
        var winning = Assert.Single(results.HighestDamage.Where(line => line.Terminal!.CombatWon));

        Assert.Equal(15m, winning.Score!.EffectiveDamage);
        Assert.Equal(0, Assert.Single(winning.Checkpoints).PlayerEnergy);
    }

    [Fact]
    public void XCostDebuffsScaleFromEnergySpent()
    {
        var malaise = new CardState(
            "malaise", "MALAISE", "Malaise", 0, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.ApplyStatus, -1, "STRENGTH", AmountByEnergySpent: true),
                new EffectSpec(EffectKind.ApplyStatus, 1, "WEAK", AmountByEnergySpent: true)
            ],
            CardDestination.Exhaust,
            CostsX: true);
        var snapshot = Snapshot(40, 30, 10, [malaise], energy: 2);
        snapshot = snapshot with
        {
            Enemies =
            [
                snapshot.Enemies[0] with
                {
                    Statuses = snapshot.Enemies[0].Statuses.Add("STRENGTH", new StatusState("STRENGTH", 5))
                }
            ]
        };

        var results = Complete(snapshot, maximumActions: 1);
        var line = Assert.Single(results.MinimumLoss.Where(candidate =>
            candidate.Steps.Any(step => step.SourceInstanceId == "malaise")));

        Assert.Equal(3, line.Terminal!.Enemies[0].Statuses["STRENGTH"].Amount);
        Assert.Equal(31, line.Terminal.PlayerHp); // floor((10 + 3 Strength) * 0.75 Weak) = 9
    }

    [Fact]
    public void IntangibleCapsAttackDamageAndThornsReflectsEachHit()
    {
        var snapshot = Snapshot(40, 20, 10, [], energy: 0);
        snapshot = snapshot with
        {
            Player = snapshot.Player with
            {
                Statuses = snapshot.Player.Statuses
                    .Add("INTANGIBLE", new StatusState("INTANGIBLE", 1, Duration: 1))
                    .Add("THORNS", new StatusState("THORNS", 3))
            }
        };

        var terminal = Assert.Single(Complete(snapshot, maximumActions: 1).Balanced).Terminal!;

        Assert.Equal(39, terminal.PlayerHp);
        Assert.Equal(17, terminal.Enemies[0].Hp);
    }

    [Fact]
    public void PlatedArmorBlocksBeforeEnemyAttacksAndDecrementsOnHpLoss()
    {
        var snapshot = Snapshot(40, 20, 10, [], energy: 0);
        snapshot = snapshot with
        {
            Player = snapshot.Player with
            {
                Statuses = snapshot.Player.Statuses.Add("PLATED_ARMOR", new StatusState("PLATED_ARMOR", 5))
            }
        };

        var terminal = Assert.Single(Complete(snapshot, maximumActions: 1).Balanced).Terminal!;

        Assert.Equal(35, terminal.PlayerHp);
        Assert.Contains("PLATED_ARMOR=4", terminal.StateKey, StringComparison.Ordinal);
    }

    [Fact]
    public void DynamicBlockCountsDiscardCardsAndAllEnemyPoison()
    {
        var discardBlock = new CardState(
            "discard-block", "DISCARD_BLOCK", "Discard Block", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.DynamicBlock, 1, "DISCARD_PILE_COUNT", XBonus: 3)]);
        var poisonBlock = new CardState(
            "poison-block", "POISON_BLOCK", "Poison Block", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.DynamicBlock, 1, "ALL_ENEMY_STATUS:POISON")]);
        var fillerOne = DamageCard("discard-1", 1, 9);
        var fillerTwo = DamageCard("discard-2", 1, 9);
        var snapshot = Snapshot(40, 30, 20, [discardBlock, poisonBlock], discardPile: [fillerOne, fillerTwo], energy: 0);
        snapshot = snapshot with
        {
            Enemies =
            [
                snapshot.Enemies[0] with
                {
                    Statuses = snapshot.Enemies[0].Statuses.Add("POISON", new StatusState("POISON", 4))
                }
            ]
        };

        var results = Complete(snapshot, maximumActions: 2);
        var line = results.MinimumLoss.First(candidate =>
            candidate.Steps.Count(step => step.Kind == ActionKind.PlayCard) == 2);

        Assert.Equal(10m, line.Checkpoints[^1].PlayerBlock);
    }

    [Fact]
    public void DiscardAndRedrawMakesNewCardsAvailableInTheSameTurn()
    {
        var redraw = new CardState(
            "redraw",
            "REDRAW",
            "Redraw",
            0,
            TargetKind.None,
            [new EffectSpec(EffectKind.DiscardHandThenDrawSame)]);
        var fillerOne = BlockCard("filler-1", 1, 0);
        var fillerTwo = BlockCard("filler-2", 1, 0);
        var finisher = DamageCard("finisher", 20, 0);
        var snapshot = Snapshot(40, 20, 0, [redraw, fillerOne, fillerTwo], drawPile: [finisher], energy: 0);

        var results = Complete(snapshot);
        var winning = results.HighestDamage.First(line => line.Terminal!.CombatWon);

        Assert.Equal(new[] { "redraw", "finisher" },
            winning.Steps.Where(step => step.Kind == ActionKind.PlayCard).Take(2).Select(step => step.SourceInstanceId));
    }

    [Fact]
    public void UnknownRandomEnemyTargetCreatesExactChanceBranches()
    {
        var randomHit = new CardState(
            "random-hit",
            "RANDOM_HIT",
            "Random Hit",
            0,
            TargetKind.None,
            [new EffectSpec(EffectKind.RandomEnemyDamage, 4)]);
        var snapshot = CombatSnapshot.Create(
            "random-target-fixture",
            new PlayerState(40, 40, 0, 0, 0, EmptyStatuses, CardsPerTurn: 0),
            [
                new CreatureState("enemy-a", "A", 4, 4, 0, EmptyStatuses, [], 0),
                new CreatureState("enemy-b", "B", 4, 4, 0, EmptyStatuses, [], 0)
            ],
            [randomHit],
            rngState: 0);

        var results = Complete(snapshot);
        var policy = Assert.Single(results.Policies.Where(candidate =>
            candidate.Objective == ObjectiveKind.HighestDamage &&
            candidate.DeterministicPrefix.Any(step => step.SourceInstanceId == "random-hit")));

        Assert.Equal(2, policy.Branches.Length);
        Assert.All(policy.Branches, branch => Assert.Equal(0.5m, branch.Probability));
        Assert.Contains(policy.Branches, branch => branch.Label.Contains("A", StringComparison.Ordinal));
        Assert.Contains(policy.Branches, branch => branch.Label.Contains("B", StringComparison.Ordinal));
    }

    [Fact]
    public void UnknownRandomExhaustCreatesOneExactBranchPerHandCard()
    {
        var randomExhaust = new CardState(
            "random-exhaust",
            "RANDOM_EXHAUST",
            "Random Exhaust",
            0,
            TargetKind.None,
            [new EffectSpec(EffectKind.RandomExhaustCards, 1)]);
        var a = DamageCard("a", 1, 0) with { IsPlayable = false };
        var b = BlockCard("b", 1, 0) with { IsPlayable = false };
        var snapshot = Snapshot(40, 20, 0, [randomExhaust, a, b], energy: 0);

        var results = Complete(snapshot);
        var policy = Assert.Single(results.Policies.Where(candidate =>
            candidate.Objective == ObjectiveKind.Balanced &&
            candidate.DeterministicPrefix.Any(step => step.SourceInstanceId == "random-exhaust")));

        Assert.Equal(2, policy.Branches.Length);
        Assert.All(policy.Branches, branch => Assert.Equal(0.5m, branch.Probability));
        Assert.Contains(policy.Branches, branch => branch.Label.Contains("Strike", StringComparison.Ordinal));
        Assert.Contains(policy.Branches, branch => branch.Label.Contains("Defend", StringComparison.Ordinal));
    }

    [Fact]
    public void UnknownRandomExhaustMergesEquivalentDuplicateCards()
    {
        var randomExhaust = new CardState(
            "random-exhaust-dup", "RANDOM_EXHAUST", "Random Exhaust", 0, TargetKind.None,
            [new EffectSpec(EffectKind.RandomExhaustCards, 1)]);
        var a1 = DamageCard("a1", 1, 0) with { IsPlayable = false };
        var a2 = DamageCard("a2", 1, 0) with { IsPlayable = false };
        var b = BlockCard("b", 1, 0) with { IsPlayable = false };
        var state = MutableCombatState.FromSnapshot(Snapshot(40, 20, 0, [randomExhaust, a1, a2, b], energy: 0));
        var outcomes = new DeterministicSimulator().PlayCardOutcomes(state, randomExhaust, null, null,
            maximumExactBranches: 16, sampleCount: 4);

        // The two discard cards are semantically identical, so their
        // interchangeable permutations merge into one Strike branch; the
        // distinct Defend card remains a second branch.
        Assert.Equal(2, outcomes.Length);
        Assert.Contains(outcomes, outcome => outcome.Label.Contains("Strike", StringComparison.Ordinal) &&
            outcome.Probability > 0.666m && outcome.Probability < 0.667m);
        Assert.Contains(outcomes, outcome => outcome.Label.Contains("Defend", StringComparison.Ordinal) &&
            outcome.Probability > 0.333m && outcome.Probability < 0.334m);
        Assert.All(outcomes, outcome =>
        {
            Assert.Equal("Exact", outcome.OutcomeQuality);
            Assert.Equal("CombatCardSelection", outcome.RngSource);
            Assert.Equal(1m, outcome.ProbabilityMassCovered);
            Assert.Equal(2m, outcome.EffectiveSampleSize);
        });
    }

    [Fact]
    public void ConditionalEffectReadsTheSelectedEnemiesIntent()
    {
        var conditional = new CardState(
            "conditional",
            "CONDITIONAL",
            "Conditional",
            0,
            TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 5, Condition: "TARGET_INTENDS_ATTACK")]);

        var attacking = Complete(Snapshot(40, 20, 1, [conditional], energy: 0));
        var idle = Complete(Snapshot(40, 20, 0, [conditional], energy: 0));
        var attackingLine = attacking.HighestDamage.First(line =>
            line.Steps.Any(step => step.SourceInstanceId == "conditional"));

        Assert.Equal(5m, attackingLine.Score!.EffectiveDamage);
        Assert.All(idle.HighestDamage, line => Assert.Equal(0m, line.Score!.EffectiveDamage));
    }

    [Fact]
    public void DrawPileSelectionBranchesAndChosenCardContinuesTheSearch()
    {
        var finisher = DamageCard("finisher", 20, 0);
        var defend = BlockCard("defend", 5, 0);
        var tutor = new CardState(
            "tutor",
            "TUTOR",
            "Tutor",
            0,
            TargetKind.None,
            [new EffectSpec(EffectKind.ChooseDrawToHand, 1)],
            Choices:
            [
                new ChoiceSpec("finisher", "Finisher to hand", [], "finisher"),
                new ChoiceSpec("defend", "Defend to hand", [], "defend")
            ]);
        var snapshot = Snapshot(40, 20, 0, [tutor], drawPile: [finisher, defend], energy: 0);

        var results = Complete(snapshot);
        var winning = results.HighestDamage.First(line => line.Terminal!.CombatWon);

        Assert.Equal("finisher", winning.Steps[0].ChoiceId);
        Assert.Equal(new[] { "tutor", "finisher" },
            winning.Steps.Where(step => step.Kind == ActionKind.PlayCard).Take(2).Select(step => step.SourceInstanceId));
    }

    [Fact]
    public void ExhaustTriggerCanDrawAndContinueTheSameTurnSearch()
    {
        var power = new CardState(
            "power",
            "EXHAUST_DRAW_POWER",
            "Exhaust Draw Power",
            0,
            TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 1, "TRIGGER_CARD_EXHAUSTED_DRAW")],
            CardDestination.Remove);
        var exhaust = new CardState(
            "exhaust",
            "EXHAUST",
            "Exhaust",
            0,
            TargetKind.None,
            [],
            CardDestination.Exhaust);
        var finisher = DamageCard("finisher", 20, 0);
        var snapshot = Snapshot(40, 20, 0, [power, exhaust], drawPile: [finisher], energy: 0);

        var results = Complete(snapshot);
        var winning = results.HighestDamage.First(line => line.Terminal!.CombatWon);

        Assert.Equal(new[] { "power", "exhaust", "finisher" },
            winning.Steps.Where(step => step.Kind == ActionKind.PlayCard).Take(3).Select(step => step.SourceInstanceId));
    }

    [Fact]
    public void ChannelingKnownOrbsPreservesSlotOrderAndScoresTheirFutureValue()
    {
        var zap = new CardState(
            "zap",
            "ZAP",
            "Zap",
            0,
            TargetKind.Self,
            [new EffectSpec(EffectKind.ChannelOrbs, 1, "LIGHTNING")]);
        var snapshot = Snapshot(40, 30, 0, [zap], energy: 0) with
        {
            OrbCapacity = 3
        };

        var results = Complete(snapshot, maximumActions: 1);
        var line = Assert.Single(results.Balanced.Where(candidate =>
            candidate.Steps.Any(step => step.SourceInstanceId == "zap")));

        var orb = Assert.Single(line.Terminal!.NextOrbs);
        Assert.Equal("LIGHTNING", orb.Id);
        Assert.Equal(3m, orb.PassiveValue);
        Assert.True(line.Score!.LongTermValue > 0m);
    }

    [Fact]
    public void FullOrbQueueEvokesTheOldestOrbBeforeAppendingTheNewOrb()
    {
        var channel = new CardState(
            "channel",
            "CHANNEL_FROST",
            "Channel Frost",
            0,
            TargetKind.Self,
            [new EffectSpec(EffectKind.ChannelOrbs, 1, "FROST")]);
        var snapshot = Snapshot(40, 20, 0, [channel], energy: 0) with
        {
            Orbs = [new OrbState("LIGHTNING", 3m, 8m)],
            OrbCapacity = 1
        };

        var results = Complete(snapshot, maximumActions: 1);
        var line = Assert.Single(results.HighestDamage.Where(candidate =>
            candidate.Steps.Any(step => step.SourceInstanceId == "channel")));

        Assert.Equal(8m, line.Score!.EffectiveDamage);
        Assert.Equal("FROST", Assert.Single(line.Terminal!.NextOrbs).Id);
    }

    [Fact]
    public void FrostAndPlasmaPassivesResolveAtTheirVerifiedTurnBoundaries()
    {
        var snapshot = Snapshot(40, 30, 5, [], energy: 0) with
        {
            Orbs =
            [
                new OrbState("FROST", 2m, 5m),
                new OrbState("PLASMA", 1m, 2m)
            ],
            OrbCapacity = 3
        };

        var terminal = Assert.Single(Complete(snapshot, maximumActions: 1).Balanced).Terminal!;

        Assert.Equal(37m, terminal.PlayerHp);
        Assert.StartsWith("37|0|1", terminal.StateKey, StringComparison.Ordinal);
        Assert.Equal(new[] { "FROST", "PLASMA" }, terminal.NextOrbs.Select(static orb => orb.Id));
    }

    [Fact]
    public void EvokingRightmostOrbsConsumesThemAndAppliesEachEvokeValue()
    {
        var evoke = new CardState(
            "evoke",
            "EVOKE",
            "Evoke",
            0,
            TargetKind.Self,
            [new EffectSpec(EffectKind.EvokeOrbs, 2, "RIGHTMOST")]);
        var snapshot = Snapshot(40, 30, 0, [evoke], energy: 0) with
        {
            Orbs =
            [
                new OrbState("FROST", 2m, 5m),
                new OrbState("LIGHTNING", 3m, 8m),
                new OrbState("PLASMA", 1m, 2m)
            ],
            OrbCapacity = 3
        };

        var line = Assert.Single(Complete(snapshot, maximumActions: 1).HighestDamage.Where(candidate =>
            candidate.Steps.Any(step => step.SourceInstanceId == "evoke")));

        Assert.Equal(8m, line.Score!.EffectiveDamage);
        Assert.Equal("FROST", Assert.Single(line.Terminal!.NextOrbs).Id);
        Assert.Equal(2, line.Checkpoints[^1].PlayerEnergy);
    }

    [Fact]
    public void ReducingOrbCapacityEvokesOverflowFromTheLeft()
    {
        var removeSlot = new CardState(
            "remove-slot",
            "REMOVE_SLOT",
            "Remove Slot",
            0,
            TargetKind.Self,
            [new EffectSpec(EffectKind.ModifyOrbCapacity, -1)]);
        var snapshot = Snapshot(40, 30, 0, [removeSlot], energy: 0) with
        {
            Orbs =
            [
                new OrbState("LIGHTNING", 3m, 8m),
                new OrbState("FROST", 2m, 5m)
            ],
            OrbCapacity = 2
        };

        var line = Assert.Single(Complete(snapshot, maximumActions: 1).HighestDamage.Where(candidate =>
            candidate.Steps.Any(step => step.SourceInstanceId == "remove-slot")));

        Assert.Equal(8m, line.Score!.EffectiveDamage);
        Assert.Equal("FROST", Assert.Single(line.Terminal!.NextOrbs).Id);
        Assert.Contains("|O:1:", line.Terminal.StateKey, StringComparison.Ordinal);
    }

    [Fact]
    public void OrbCountDamageAndEnergyScaledChannelingUseTheLiveOrbState()
    {
        var barrage = new CardState(
            "barrage", "BARRAGE", "Barrage", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 5, RepeatByOrbCount: true)]);
        var tempest = new CardState(
            "tempest", "TEMPEST", "Tempest", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ChannelOrbs, 1, "LIGHTNING", AmountByEnergySpent: true)],
            CostsX: true);
        var snapshot = Snapshot(40, 30, 0, [barrage, tempest], energy: 2) with
        {
            Orbs = [new OrbState("FROST", 2m, 5m)],
            OrbCapacity = 3
        };

        var results = Complete(snapshot, maximumActions: 2);
        var line = results.HighestDamage.First(candidate =>
            candidate.Steps.Count(step => step.Kind == ActionKind.PlayCard) == 2);

        Assert.Equal(15m, 30m - line.Checkpoints[^1].EnemyHp["enemy-0"]);
        Assert.Equal(21m, line.Score!.EffectiveDamage); // three-orb Barrage plus two Lightning turn-end passives
        Assert.Equal(3, line.Terminal!.NextOrbs.Length);
        Assert.Equal(0, line.Checkpoints[^1].PlayerEnergy);
    }

    [Fact]
    public void EnemyScaledChannelingAndExplicitPassiveTriggersUseCurrentTargets()
    {
        var chill = new CardState(
            "chill", "CHILL", "Chill", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ChannelOrbs, 1, "FROST", AmountByAliveEnemyCount: true)]);
        var chillSnapshot = CombatSnapshot.Create(
            "orb-target-fixture",
            new PlayerState(40, 40, 0, 0, 0, EmptyStatuses, CardsPerTurn: 0),
            [
                new CreatureState("enemy-a", "A", 20, 20, 0, EmptyStatuses, [], 0),
                new CreatureState("enemy-b", "B", 20, 20, 0, EmptyStatuses, [], 0)
            ],
            [chill],
            rngState: 42,
            rngStreams: KnownTargetRng(),
            orbs: [new OrbState("LIGHTNING", 3m, 8m)],
            orbCapacity: 4);

        var chillLine = Assert.Single(Complete(chillSnapshot, maximumActions: 1).Balanced.Where(candidate =>
            candidate.Steps.Any(step => step.SourceInstanceId == "chill")));
        Assert.Equal(new[] { "LIGHTNING", "FROST", "FROST" }, chillLine.Terminal!.NextOrbs.Select(static orb => orb.Id));

        var tesla = new CardState(
            "tesla", "TESLA", "Tesla", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.TriggerOrbPassives, 2, "LIGHTNING")]);
        var teslaSnapshot = CombatSnapshot.Create(
            "orb-passive-fixture",
            new PlayerState(40, 40, 0, 0, 0, EmptyStatuses, CardsPerTurn: 0),
            [
                new CreatureState("enemy-a", "A", 20, 20, 0, EmptyStatuses, [], 0),
                new CreatureState("enemy-b", "B", 20, 20, 0, EmptyStatuses, [], 0)
            ],
            [tesla],
            rngState: 42,
            rngStreams: KnownTargetRng(),
            orbs: [new OrbState("LIGHTNING", 3m, 8m)],
            orbCapacity: 4);
        var teslaLine = Complete(teslaSnapshot, maximumActions: 1).HighestDamage.First(candidate =>
            candidate.Steps.Any(step => step.SourceInstanceId == "tesla"));
        var targetId = teslaLine.Steps.First(step => step.SourceInstanceId == "tesla").TargetId!;

        Assert.Equal(6m, 20m - teslaLine.Checkpoints[^1].EnemyHp[targetId]);
        Assert.Equal("LIGHTNING", Assert.Single(teslaLine.Terminal!.NextOrbs).Id);
    }

    [Fact]
    public void DistinctOrbTypesScaleImmediateDrawAndFocus()
    {
        var setup = new CardState(
            "setup", "ORB_SETUP", "Orb Setup", 0, TargetKind.Self,
            [
                new EffectSpec(EffectKind.Draw, 1, AmountByDistinctOrbTypes: true),
                new EffectSpec(EffectKind.ApplyStatus, 2, "TEMP_FOCUS", Duration: 1, AmountByDistinctOrbTypes: true)
            ]);
        var channel = new CardState(
            "channel", "CHANNEL", "Channel", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ChannelOrbs, 1, "LIGHTNING")]);
        var draws = new[]
        {
            BlockCard("draw-1", 1, 9) with { IsPlayable = false },
            BlockCard("draw-2", 1, 9) with { IsPlayable = false },
            BlockCard("draw-3", 1, 9) with { IsPlayable = false }
        };
        var snapshot = Snapshot(40, 30, 0, [setup, channel], drawPile: draws, energy: 0) with
        {
            Player = new PlayerState(40, 40, 0, 0, 0, EmptyStatuses, CardsPerTurn: 0),
            Orbs =
            [
                new OrbState("LIGHTNING", 3m, 8m),
                new OrbState("FROST", 2m, 5m),
                new OrbState("DARK", 6m, 6m)
            ],
            OrbCapacity = 3
        };

        var line = Complete(snapshot, maximumActions: 2).Balanced.First(candidate =>
            candidate.Steps.Count(step => step.Kind == ActionKind.PlayCard) == 2 &&
            candidate.Steps[0].SourceInstanceId == "setup");

        Assert.Equal(3, line.Checkpoints[0].HandInstanceIds.Count(id => id.StartsWith("draw-", StringComparison.Ordinal)));
        var lightning = Assert.Single(line.Terminal!.NextOrbs.Where(orb => orb.Id == "LIGHTNING"));
        Assert.Equal(3m, lightning.PassiveValue);
        Assert.Equal(8m, lightning.EvokeValue);
        Assert.Equal(0m, lightning.FocusAdjustment);
        Assert.Equal(3m, lightning.EffectivePassiveValue);
        Assert.Equal(8m, lightning.EffectiveEvokeValue);
        Assert.DoesNotContain("TEMP_FOCUS=", line.Terminal.StateKey, StringComparison.Ordinal);
    }

    [Fact]
    public void ExpectAFightAddsBlockForNonNegativePlayerStrength()
    {
        var expectAFight = new CardState(
            "expect", "EXPECT_A_FIGHT", "Expect a Fight", 0, TargetKind.Self,
            [
                new EffectSpec(EffectKind.Block, 15),
                new EffectSpec(EffectKind.DynamicBlock, 5, "PLAYER_STRENGTH")
            ]);
        var simulator = new DeterministicSimulator();
        var positiveSnapshot = Snapshot(30, 30, 0, [expectAFight], energy: 0) with
        {
            Player = new PlayerState(
                30, 30, 0, 0, 0,
                EmptyStatuses.Add("STRENGTH", new StatusState("STRENGTH", 2)))
        };
        var negativeSnapshot = positiveSnapshot with
        {
            Player = positiveSnapshot.Player with
            {
                Statuses = EmptyStatuses.Add("STRENGTH", new StatusState("STRENGTH", -2))
            }
        };

        var positive = simulator.PlayCard(
            MutableCombatState.FromSnapshot(positiveSnapshot), expectAFight, null, null);
        var negative = simulator.PlayCard(
            MutableCombatState.FromSnapshot(negativeSnapshot), expectAFight, null, null);

        Assert.Equal(25m, positive.Player.Block);
        Assert.Equal(15m, negative.Player.Block);
    }

    [Fact]
    public void HyperbeamTemporaryFocusDownAffectsOrbsThenRestoresExactly()
    {
        var hyperbeam = new CardState(
            "hyperbeam", "HYPERBEAM", "Hyperbeam", 0, TargetKind.AllEnemies,
            [new EffectSpec(EffectKind.ApplyStatus, -3, "TEMP_FOCUS", Duration: 1, TargetOverride: TargetKind.Self)]);
        var channel = new CardState(
            "channel", "CHANNEL_LIGHTNING", "Channel Lightning", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ChannelOrbs, 1, "LIGHTNING")]);
        var snapshot = Snapshot(30, 100, 0, [hyperbeam, channel], energy: 0) with
        {
            Player = new PlayerState(
                30, 30, 0, 0, 0,
                EmptyStatuses.Add("FOCUS", new StatusState("FOCUS", -2)),
                CardsPerTurn: 0),
            Orbs =
            [
                new OrbState("LIGHTNING", 1, 6),
                new OrbState("FROST", 0, 3),
                new OrbState("DARK", 4, 6)
            ],
            OrbCapacity = 4
        };
        var simulator = new DeterministicSimulator();

        var afterPlay = simulator.PlayCard(
            MutableCombatState.FromSnapshot(snapshot), hyperbeam, null, null);

        Assert.Equal(-3m, afterPlay.Orbs[0].FocusAdjustment);
        Assert.Equal(0m, afterPlay.Orbs[0].EffectivePassiveValue);
        Assert.Equal(3m, afterPlay.Orbs[0].EffectiveEvokeValue);
        Assert.Equal(0m, afterPlay.Orbs[1].EffectivePassiveValue);
        Assert.Equal(1m, afterPlay.Orbs[2].EffectivePassiveValue);

        var afterChannel = simulator.PlayCard(afterPlay, channel, null, null);
        var channeled = afterChannel.Orbs[3];
        Assert.Equal(1m, channeled.PassiveValue);
        Assert.Equal(6m, channeled.EvokeValue);
        Assert.Equal(-3m, channeled.FocusAdjustment);
        Assert.Equal(0m, channeled.EffectivePassiveValue);
        Assert.Equal(3m, channeled.EffectiveEvokeValue);

        var nextTurn = simulator.ProjectToNextPlayerTurn(afterChannel);

        Assert.False(nextTurn.Player.Statuses.ContainsKey("TEMP_FOCUS"));
        Assert.All(nextTurn.Orbs, orb => Assert.Equal(0m, orb.FocusAdjustment));
        Assert.Equal(1m, nextTurn.Orbs[0].EffectivePassiveValue);
        Assert.Equal(3m, nextTurn.Orbs[1].EffectiveEvokeValue);
        Assert.Equal(4m, nextTurn.Orbs[2].EffectivePassiveValue);
        Assert.Equal(7m, nextTurn.Orbs[2].EffectiveEvokeValue);
        Assert.Equal(1m, nextTurn.Orbs[3].EffectivePassiveValue);
        Assert.Equal(6m, nextTurn.Orbs[3].EffectiveEvokeValue);
    }

    [Fact]
    public void DistinctOrbTurnStartBlockUsesTheProjectedOrbSet()
    {
        var power = new CardState(
            "power", "ORB_BLOCK_POWER", "Orb Block", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 3, "TURN_START_DISTINCT_ORB_BLOCK", Duration: 1)],
            CardDestination.Remove);
        var snapshot = Snapshot(40, 30, 0, [power], energy: 0) with
        {
            Player = new PlayerState(40, 40, 0, 0, 0, EmptyStatuses, CardsPerTurn: 0),
            Orbs =
            [
                new OrbState("LIGHTNING", 0m, 8m),
                new OrbState("FROST", 0m, 5m),
                new OrbState("PLASMA", 0m, 2m)
            ],
            OrbCapacity = 3
        };

        var line = Assert.Single(Complete(snapshot, maximumActions: 1).Balanced.Where(candidate =>
            candidate.Steps.Any(step => step.SourceInstanceId == "power")));

        Assert.Equal(9m, line.Terminal!.PlayerBlock);
    }

    [Fact]
    public void FrostConditionalTurnEndDamageAndRightmostPassiveResolveOnProjection()
    {
        var power = new CardState(
            "power", "ORB_TIMING", "Orb Timing", 0, TargetKind.Self,
            [
                new EffectSpec(EffectKind.ApplyStatus, 6, "TURN_END_HAS_FROST_DAMAGE"),
                new EffectSpec(EffectKind.ApplyStatus, 2, "TURN_START_RIGHTMOST_ORB_PASSIVE")
            ],
            CardDestination.Remove);
        var snapshot = Snapshot(40, 30, 0, [power], energy: 0) with
        {
            Player = new PlayerState(40, 40, 0, 0, 0, EmptyStatuses, CardsPerTurn: 0),
            Orbs =
            [
                new OrbState("FROST", 2m, 5m),
                new OrbState("PLASMA", 1m, 2m)
            ],
            OrbCapacity = 3
        };

        var line = Assert.Single(Complete(snapshot, maximumActions: 1).HighestDamage.Where(candidate =>
            candidate.Steps.Any(step => step.SourceInstanceId == "power")));

        Assert.Equal(6m, line.Score!.EffectiveDamage);
        Assert.StartsWith("40|0|3", line.Terminal!.StateKey, StringComparison.Ordinal); // 2 explicit + 1 normal Plasma passive
    }

    [Fact]
    public void ScheduledLightningChannelsForExactlyTwoTurnStarts()
    {
        var power = new CardState(
            "power", "SCHEDULE_LIGHTNING", "Schedule Lightning", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 1, "TURN_START_CHANNEL_LIGHTNING", Duration: 2)],
            CardDestination.Remove);
        var snapshot = Snapshot(40, 100, 0, [power], energy: 0) with
        {
            Player = new PlayerState(40, 40, 0, 0, 0, EmptyStatuses, CardsPerTurn: 0),
            OrbCapacity = 3
        };
        var first = Complete(snapshot, maximumActions: 1).Balanced.First(candidate =>
            candidate.Steps.Any(step => step.SourceInstanceId == "power"));
        var firstTerminal = first.Terminal!;
        Assert.Single(firstTerminal.NextOrbs);
        Assert.Contains("TURN_START_CHANNEL_LIGHTNING=1@1", firstTerminal.StateKey, StringComparison.Ordinal);

        var secondSnapshot = CombatSnapshot.Create(
            "scheduled-second",
            new PlayerState(firstTerminal.PlayerHp, 40, firstTerminal.PlayerBlock, 0, 0,
                ImmutableDictionary<string, StatusState>.Empty.Add(
                    "TURN_START_CHANNEL_LIGHTNING",
                    new StatusState("TURN_START_CHANNEL_LIGHTNING", 1, Duration: 1)),
                CardsPerTurn: 0),
            firstTerminal.Enemies,
            [],
            rngState: 42,
            rngStreams: KnownTargetRng(),
            orbs: firstTerminal.NextOrbs,
            orbCapacity: 3);
        var secondTerminal = Assert.Single(Complete(secondSnapshot, maximumActions: 1).Balanced).Terminal!;

        Assert.Equal(2, secondTerminal.NextOrbs.Length);
        Assert.DoesNotContain("TURN_START_CHANNEL_LIGHTNING", secondTerminal.StateKey, StringComparison.Ordinal);
    }

    [Fact]
    public void KnownRandomOrbStreamProducesOneDeterministicSequenceAndAdvancesTwice()
    {
        var chaos = new CardState(
            "chaos", "CHAOS", "Chaos", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ChannelOrbs, 2, "RANDOM")]);
        var stream = new RngStreamSnapshot(RngSnapshotSet.CombatOrbGeneration, 1, 2, 3, 4);
        var snapshot = Snapshot(40, 30, 0, [chaos], energy: 0) with
        {
            Player = new PlayerState(40, 40, 0, 0, 0, EmptyStatuses, CardsPerTurn: 0),
            RngStreams = KnownTargetRng().With(stream),
            OrbCapacity = 3
        };

        var results = Complete(snapshot, maximumActions: 1);
        var line = Assert.Single(results.Balanced.Where(candidate =>
            candidate.Steps.Any(step => step.SourceInstanceId == "chaos")));

        Assert.Equal(2, line.Terminal!.NextOrbs.Length);
        Assert.DoesNotContain(line.Restrictions, restriction => restriction.Code.Contains("random", StringComparison.OrdinalIgnoreCase));
    }

    [Fact]
    public void UnknownTwoRandomOrbsEnumerateSixteenEqualSequences()
    {
        var chaos = new CardState(
            "chaos", "CHAOS", "Chaos", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ChannelOrbs, 2, "RANDOM")]);
        var snapshot = Snapshot(40, 30, 0, [chaos], energy: 0) with
        {
            Player = new PlayerState(40, 40, 0, 0, 0, EmptyStatuses, CardsPerTurn: 0),
            RngStreams = KnownTargetRng(),
            OrbCapacity = 3
        };

        var results = Complete(snapshot, maximumActions: 1);
        var policy = Assert.Single(results.Policies.Where(candidate =>
            candidate.Objective == ObjectiveKind.Balanced &&
            candidate.DeterministicPrefix.Any(step => step.SourceInstanceId == "chaos")));

        Assert.Equal(16, policy.Branches.Length);
        Assert.All(policy.Branches, branch => Assert.Equal(1m / 16m, branch.Probability));
        Assert.Equal(16, policy.Branches.Select(branch => branch.Label).Distinct(StringComparer.Ordinal).Count());
    }

    [Fact]
    public void ProjectedPlayerDeathIsSeparatedFromMainRankings()
    {
        var results = Complete(Snapshot(5, 20, 10, [], energy: 0));

        Assert.Empty(results.Balanced);
        Assert.NotEmpty(results.ProjectedDeaths);
        Assert.True(results.ProjectedDeaths[0].Terminal!.PlayerDied);
    }

    [Fact]
    public void HandCostRewriteMakesSubsequentExpensiveAttackPlayable()
    {
        var rewrite = new CardState("rewrite", "BULLET_TIME", "Bullet Time", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ModifyHandCosts, 0)]);
        var expensive = DamageCard("expensive", 20, cost: 3);

        var results = Complete(Snapshot(50, 40, 0, [rewrite, expensive], energy: 0));

        Assert.Contains(results.Balanced, line =>
            line.Steps.Take(2).Select(step => step.SourceInstanceId).SequenceEqual(["rewrite", "expensive"]));
    }

    [Fact]
    public void StunSkipsEnemyIntentAndMaximumHpLossIsProjected()
    {
        var card = new CardState("control", "CONTROL", "Control", 0, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.ApplyStatus, 1, "STUN", Duration: 1, TargetOverride: TargetKind.Enemy),
                new EffectSpec(EffectKind.ModifyMaxHp, -1, TargetOverride: TargetKind.Self)
            ]);

        var results = Complete(Snapshot(20, 100, 12, [card], energy: 0));
        var line = Assert.Single(results.MinimumLoss.Where(candidate => candidate.Steps.Any(step => step.SourceInstanceId == "control")));

        Assert.Equal(19m, line.Terminal!.PlayerHp);
        Assert.Contains("|M:19", line.Terminal.StateKey, StringComparison.Ordinal);
    }

    [Fact]
    public void CannotDrawStopsLaterDrawAndEnemyResetClearsBlockAndArtifact()
    {
        var restriction = new CardState("restriction", "RESTRICT", "Restrict", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 1, "CANNOT_DRAW", Duration: 1)]);
        var draw = new CardState("draw", "DRAW", "Draw", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Draw, 1), new EffectSpec(EffectKind.Damage, 1)]);
        var reset = new CardState("reset", "EXPOSE", "Expose", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.ClearEnemyBlockAndArtifact, 1, TargetOverride: TargetKind.Enemy)]);
        var drawn = DamageCard("drawn", 9, 0);
        var statuses = EmptyStatuses.Add("ARTIFACT", new StatusState("ARTIFACT", 1));
        var snapshot = CombatSnapshot.Create(
            "fixture", new PlayerState(30, 30, 0, 0, 0, EmptyStatuses),
            [new CreatureState("enemy-0", "Enemy", 50, 50, 8, statuses, [], 0)],
            [restriction, draw, reset], [drawn]);

        var results = Complete(snapshot);
        var resetLine = results.Balanced.First(line => line.Steps.Any(step => step.SourceInstanceId == "reset"));

        var resetEnemy = Assert.Single(resetLine.Terminal!.Enemies);
        Assert.Equal(0m, resetEnemy.Block);
        Assert.DoesNotContain("ARTIFACT", resetEnemy.Statuses.Keys);
    }

    [Fact]
    public void DiscardPileTopdeckChoiceBecomesTheNextDraw()
    {
        var topdeck = new CardState("topdeck", "HEADBUTT", "Headbutt", 0, TargetKind.None,
            [new EffectSpec(EffectKind.ChooseDiscardToDrawTop, 1)],
            Choices: [new ChoiceSpec("chosen", "Chosen to top", [], "chosen")]);
        var draw = new CardState("draw", "DRAW", "Draw", 0, TargetKind.None,
            [new EffectSpec(EffectKind.Draw, 1)]);
        var chosen = DamageCard("chosen", 12, 0);
        var buried = DamageCard("buried", 3, 0);

        var results = Complete(Snapshot(30, 100, 0, [topdeck, draw], [buried], [chosen], energy: 0));
        var line = results.HighestDamage.First(candidate => candidate.Steps.Any(step => step.SourceInstanceId == "chosen"));

        Assert.Contains(line.Steps, step => step.SourceInstanceId == "chosen");
        Assert.DoesNotContain(line.Steps, step => step.SourceInstanceId == "buried");
    }

    [Fact]
    public void EnemyStrengthAppliedByCardIncreasesItsProjectedAttack()
    {
        var empower = new CardState("empower", "FIGHT_ME", "Fight Me", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.ApplyStatus, 2, "STRENGTH", TargetOverride: TargetKind.Enemy)]);

        var results = Complete(Snapshot(30, 100, 10, [empower], energy: 0));
        var line = results.MinimumLoss.First(candidate => candidate.Steps.Any(step => step.SourceInstanceId == "empower"));

        Assert.Equal(12m, line.Score!.PlayerHpLoss);
    }

    [Fact]
    public void AdditiveDynamicDamageIsModifiedAsOneAttack()
    {
        var perfect = new CardState("perfect", "PERFECTED_STRIKE", "Perfected Strike", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.DynamicDamage, 6, "STRIKE_CARD_COUNT", XBonus: 2)]);
        var strike = DamageCard("strike", 1, 0);
        var snapshot = CombatSnapshot.Create(
            "fixture",
            new PlayerState(30, 30, 0, 0, 0,
                EmptyStatuses.Add("STRENGTH", new StatusState("STRENGTH", 2))),
            [new CreatureState("enemy-0", "Enemy", 100, 100, 0, EmptyStatuses, [], 0)],
            [perfect], [strike]);

        var line = Complete(snapshot).HighestDamage.First(candidate => candidate.Steps.Any(step => step.SourceInstanceId == "perfect"));

        Assert.Equal(10m, line.Score!.EffectiveDamage); // (6 + one Strike * 2) + 2 Strength
    }

    [Fact]
    public void SecondWindExhaustsOnlyNonAttacksAndAppliesDexterityAndExhaustTriggers()
    {
        var secondWind = new CardState("second-wind", "SECOND_WIND", "Second Wind", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ExhaustNonAttacksAndBlock, 5)]);
        var attack = DamageCard("attack", 4, 0) with { CardType = "Attack" };
        var skill = BlockCard("skill", 1, 0) with { CardType = "Skill" };
        var status = BlockCard("status", 0, 0) with { CardType = "Status" };
        var playerStatuses = EmptyStatuses
            .Add("BARRICADE", new StatusState("BARRICADE", 1))
            .Add("DEXTERITY", new StatusState("DEXTERITY", 2))
            .Add("TRIGGER_CARD_EXHAUSTED_BLOCK", new StatusState("TRIGGER_CARD_EXHAUSTED_BLOCK", 1));
        var snapshot = CombatSnapshot.Create(
            "fixture", new PlayerState(30, 30, 0, 0, 0, playerStatuses),
            [new CreatureState("enemy-0", "Enemy", 100, 100, 0, EmptyStatuses, [], 0)],
            [secondWind, attack, skill, status]);

        var line = Complete(snapshot).MinimumLoss.First(candidate => candidate.Steps.Any(step => step.SourceInstanceId == "second-wind"));

        Assert.Equal(16m, line.Terminal!.PlayerBlock); // 2 * (5 + 2 Dexterity) + 2 trigger block
        Assert.Contains(line.Terminal.NextHand, card => card.InstanceId == "attack");
        Assert.DoesNotContain(line.Terminal.NextHand, card => card.InstanceId is "skill" or "status");
    }

    [Fact]
    public void PlayedCardCanReturnToDrawTopAndZeroCostDiscardCardsReturnToHand()
    {
        var topdeck = new CardState("topdeck", "SHINING_STRIKE", "Shining Strike", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 4)], CardDestination.DrawPileTop);
        var recover = new CardState("recover", "ALL_FOR_ONE", "All For One", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.MoveAllZeroCostDiscardToHand)]);
        var zero = DamageCard("zero", 3, 0);
        var costly = DamageCard("costly", 3, 1);

        var snapshot = CombatSnapshot.Create(
            "fixture", new PlayerState(30, 30, 0, 0, 0, EmptyStatuses),
            [new CreatureState("enemy-0", "Enemy", 100, 100, 0, EmptyStatuses, [], 0)],
            [topdeck, recover], [], [zero, costly]);
        var results = Complete(snapshot);

        var topLine = results.HighestDamage.First(line => line.Steps.Any(step => step.SourceInstanceId == "topdeck"));
        var recoverLine = results.HighestDamage.First(line => line.Steps.Any(step => step.SourceInstanceId == "recover"));
        var recoveryStep = recoverLine.Steps.TakeWhile(step => step.SourceInstanceId != "recover").Count();
        var recoveryCheckpoint = recoverLine.SafeCheckpoints[recoveryStep];
        Assert.Contains(topLine.Terminal!.NextHand, card => card.InstanceId == "topdeck");
        Assert.Contains("zero", recoveryCheckpoint.HandInstanceIds);
        Assert.DoesNotContain("costly", recoveryCheckpoint.HandInstanceIds);
    }

    [Fact]
    public void NextFreeAttackAffectsSearchAndEnergyExactlyOnce()
    {
        var setup = new CardState("setup", "UNRELENTING", "Unrelenting", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 1, "NEXT_FREE_ATTACK", Duration: 1)]);
        var first = DamageCard("first", 8, 2) with { CardType = "Attack" };
        var second = DamageCard("second", 7, 2) with { CardType = "Attack" };
        var skill = BlockCard("skill", 4, 2) with { CardType = "Skill" };

        var results = Complete(Snapshot(30, 100, 0, [setup, first, second, skill], energy: 0));
        var line = results.HighestDamage.First(candidate =>
            candidate.Steps.Take(2).Select(step => step.SourceInstanceId).SequenceEqual(["setup", "first"]));

        Assert.Equal(0, line.SafeCheckpoints[1].PlayerEnergy);
        Assert.DoesNotContain(line.Steps, step => step.SourceInstanceId is "second" or "skill");
    }

    [Fact]
    public void CostReductionCountsOnlyMatchingCardsPlayedDuringSearch()
    {
        var attack = DamageCard("attack", 3, 0) with { CardType = "Attack" };
        var skill = BlockCard("skill", 1, 0) with { CardType = "Skill" };
        var discounted = DamageCard("discounted", 12, 2) with
        {
            CardType = "Attack",
            Effects = [
                new EffectSpec(EffectKind.Damage, 12),
                new EffectSpec(EffectKind.ModifyPlayedCardCost, -1, "BY_ATTACKS_PLAYED")
            ]
        };

        var results = Complete(Snapshot(30, 100, 0, [attack, skill, discounted], energy: 1));

        Assert.Contains(results.HighestDamage, line =>
            line.Steps.Take(2).Select(step => step.SourceInstanceId).SequenceEqual(["attack", "discounted"]));
        Assert.DoesNotContain(results.HighestDamage, line =>
            line.Steps.Take(2).Select(step => step.SourceInstanceId).SequenceEqual(["skill", "discounted"]));
    }

    [Fact]
    public void BlurRetainsBlockAndProlongSnapshotsBlockAtPlayTime()
    {
        var blur = new CardState("blur", "BLUR", "Blur", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.Block, 5), new EffectSpec(EffectKind.ApplyStatus, 1, "BLUR", Duration: 1)]);
        var prolong = new CardState("prolong", "PROLONG", "Prolong", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.Block, 4), new EffectSpec(EffectKind.ScheduleCurrentBlock, 1)]);

        var blurLine = Complete(Snapshot(30, 100, 0, [blur], energy: 0)).MinimumLoss
            .First(line => line.Steps.Any(step => step.SourceInstanceId == "blur"));
        var prolongLine = Complete(Snapshot(30, 100, 0, [prolong], energy: 0)).MinimumLoss
            .First(line => line.Steps.Any(step => step.SourceInstanceId == "prolong"));

        Assert.Equal(5m, blurLine.Terminal!.PlayerBlock);
        Assert.Equal(4m, prolongLine.Terminal!.PlayerBlock);
    }

    [Fact]
    public void ReboundRedirectsOnlyTheNextDiscardDestinationCard()
    {
        var rebound = new CardState("rebound", "REBOUND", "Rebound", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 1, "NEXT_CARD_TO_DRAW_TOP", Duration: 1)]);
        var exhaust = new CardState("exhaust", "EXHAUST", "Exhaust", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 1, "STRENGTH")], CardDestination.Exhaust);
        var ordinary = DamageCard("ordinary", 4, 0);
        var snapshot = Snapshot(30, 100, 0, [rebound, exhaust, ordinary], energy: 0);

        var results = Complete(snapshot);
        var line = results.HighestDamage.First(candidate =>
            candidate.Steps.Take(3).Select(step => step.SourceInstanceId).SequenceEqual(["rebound", "exhaust", "ordinary"]));

        Assert.Contains(line.Terminal!.NextHand, card => card.InstanceId == "ordinary");
        Assert.DoesNotContain(line.Terminal.NextHand, card => card.InstanceId == "exhaust");
    }

    [Fact]
    public void FixedGeneratedCardsAndSelfCopyUseExistingTemplatesAndDestinations()
    {
        var soul = new CardState("soul-template", "SOUL", "Soul", 0, TargetKind.None,
            [new EffectSpec(EffectKind.Draw, 2)], CardDestination.Exhaust, CardType: "Skill");
        var generator = new CardState("generator", "GRAVE_WARDEN", "Grave Warden", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.GenerateCards, 1, GeneratedCard: soul, GeneratedDestination: GeneratedCardDestination.DrawPile)]);
        var selfCopy = new CardState("copy", "UNDEATH", "Undeath", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.CopyPlayedCard, 1, GeneratedDestination: GeneratedCardDestination.DiscardPile)]);

        var generatedLine = Complete(Snapshot(30, 100, 0, [generator], energy: 0)).Balanced
            .First(line => line.Steps.Any(step => step.SourceInstanceId == "generator"));
        var copiedLine = Complete(Snapshot(30, 100, 0, [selfCopy], energy: 0)).Balanced
            .First(line => line.Steps.Any(step => step.SourceInstanceId == "copy"));

        Assert.Contains(generatedLine.Terminal!.NextHand, card => card.ModelId == "SOUL");
        Assert.Contains(copiedLine.Terminal!.NextHand, card => card.InstanceId.StartsWith("copy:undeath", StringComparison.Ordinal));
    }

    [Fact]
    public void PersistentTurnStartResourcesApplyToTheProjectedTurn()
    {
        var power = new CardState("power", "RESOURCE_POWER", "Resource Power", 0, TargetKind.Self,
            [
                new EffectSpec(EffectKind.ApplyStatus, 1, "TURN_START_ENERGY", FutureValuePerTurn: 3),
                new EffectSpec(EffectKind.ApplyStatus, 1, "TURN_START_DRAW", FutureValuePerTurn: 2)
            ], CardDestination.Remove, CardType: "Power");
        var draw = new[] { DamageCard("draw-0", 1), DamageCard("draw-1", 1) };
        var snapshot = CombatSnapshot.Create(
            "fixture",
            new PlayerState(30, 30, 0, 0, 3, EmptyStatuses, CardsPerTurn: 1),
            [new CreatureState("enemy-0", "Enemy", 100, 100, 0, EmptyStatuses, [], 0)],
            [power], draw);

        var line = Complete(snapshot).Balanced.First(candidate =>
            candidate.Steps.Any(step => step.SourceInstanceId == "power"));
        var terminal = Assert.IsType<ProjectedTerminal>(line.Terminal);

        Assert.StartsWith("30|0|4|", terminal.StateKey, StringComparison.Ordinal);
        Assert.Equal(2, terminal.NextHand.Length);
        Assert.Contains("TURN_START_ENERGY=1", terminal.StateKey, StringComparison.Ordinal);
        Assert.Contains("TURN_START_DRAW=1", terminal.StateKey, StringComparison.Ordinal);
    }

    [Fact]
    public void CardPlayedTriggersUsePrePlayPowerSnapshotsAndCorrectTiming()
    {
        var statuses = EmptyStatuses
            .Add("TRIGGER_CARD_PLAYED_BLOCK", new StatusState("TRIGGER_CARD_PLAYED_BLOCK", 1))
            .Add("TRIGGER_POWER_PLAYED_ENERGY", new StatusState("TRIGGER_POWER_PLAYED_ENERGY", 1))
            .Add("TRIGGER_POWER_PLAYED_LIGHTNING", new StatusState("TRIGGER_POWER_PLAYED_LIGHTNING", 1))
            .Add("TRIGGER_ETHEREAL_PLAYED_BLOCK", new StatusState("TRIGGER_ETHEREAL_PLAYED_BLOCK", 3));
        var power = new CardState("power", "POWER", "Power", 1, TargetKind.Self,
            [
                new EffectSpec(EffectKind.ApplyStatus, 1, "TRIGGER_CARD_PLAYED_BLOCK"),
                new EffectSpec(EffectKind.ApplyStatus, 2, "TRIGGER_POWER_PLAYED_ENERGY"),
                new EffectSpec(EffectKind.ApplyStatus, 2, "TRIGGER_POWER_PLAYED_LIGHTNING")
            ], CardDestination.Remove, CardType: "Power");
        var ethereal = new CardState("ethereal", "ETHEREAL", "Ethereal", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.Block, 1)], CardType: "Skill", ExhaustAtTurnEnd: true);
        var snapshot = CombatSnapshot.Create(
            "fixture",
            new PlayerState(30, 30, 0, 1, 1, statuses, CardsPerTurn: 0),
            [new CreatureState("enemy-0", "Enemy", 100, 100, 0, EmptyStatuses, [], 0)],
            [power, ethereal],
            rngStreams: KnownTargetRng(),
            orbs: [],
            orbCapacity: 3);

        var line = Complete(snapshot).Balanced.First(candidate =>
            candidate.Steps.Take(2).Select(step => step.SourceInstanceId).SequenceEqual(["power", "ethereal"]));

        Assert.Equal(7m, line.SafeCheckpoints[1].PlayerBlock); // Power: old Afterimage 1; Ethereal: Ash 3 before + card 1 + two Afterimage stacks.
        Assert.Equal(1, line.SafeCheckpoints[0].PlayerEnergy); // Only the pre-existing Subroutine stack refunds the Power.
        Assert.Single(line.Terminal!.NextOrbs); // Only the pre-existing Storm stack channels for this Power.
    }

    [Fact]
    public void EnergyThresholdTriggerUsesActualEnergySpentBeforeCardEffects()
    {
        var statuses = EmptyStatuses.Add(
            "TRIGGER_ENERGY_AT_LEAST_2_BLOCK",
            new StatusState("TRIGGER_ENERGY_AT_LEAST_2_BLOCK", 4));
        var costly = new CardState("costly", "COSTLY", "Costly", 2, TargetKind.Self,
            [new EffectSpec(EffectKind.Block, 1)], CardType: "Skill");
        var free = costly with { InstanceId = "free", ModelId = "FREE", EnergyCost = 0 };
        var snapshot = CombatSnapshot.Create(
            "fixture",
            new PlayerState(30, 30, 0, 2, 2, statuses, CardsPerTurn: 0),
            [new CreatureState("enemy-0", "Enemy", 100, 100, 0, EmptyStatuses, [], 0)],
            [costly, free]);

        var results = Complete(snapshot);
        var costlyLine = results.MinimumLoss.First(candidate =>
            candidate.Steps.FirstOrDefault()?.SourceInstanceId == "costly");
        var freeLine = results.MinimumLoss.First(candidate =>
            candidate.Steps.FirstOrDefault()?.SourceInstanceId == "free");

        Assert.Equal(5m, costlyLine.SafeCheckpoints[0].PlayerBlock);
        Assert.Equal(1m, freeLine.SafeCheckpoints[0].PlayerBlock);
    }

    [Fact]
    public void CorruptionMakesSkillsFreeAndExhaustsThemWithoutConsumingRebound()
    {
        var corruption = new CardState("corruption", "CORRUPTION", "Corruption", 0, TargetKind.Self,
            [
                new EffectSpec(EffectKind.ApplyStatus, 1, "SKILLS_COST_ZERO"),
                new EffectSpec(EffectKind.ApplyStatus, 1, "SKILLS_EXHAUST_ON_PLAY"),
                new EffectSpec(EffectKind.ApplyStatus, 1, "NEXT_CARD_TO_DRAW_TOP")
            ], CardDestination.Remove, CardType: "Power");
        var skill = new CardState("skill", "SKILL", "Skill", 3, TargetKind.Self,
            [new EffectSpec(EffectKind.Block, 5)], CardType: "Skill");
        var attack = DamageCard("attack", 4, 0) with { CardType = "Attack" };

        var simulator = new DeterministicSimulator();
        var state = MutableCombatState.FromSnapshot(Snapshot(30, 100, 0, [corruption, skill, attack], energy: 0));
        state = simulator.PlayCard(state, state.Hand.Single(card => card.InstanceId == "corruption"), null, null);
        state = simulator.PlayCard(state, state.Hand.Single(card => card.InstanceId == "skill"), null, null);

        Assert.Equal(0, state.Player.Energy);
        Assert.Contains(state.ExhaustPile, card => card.InstanceId == "skill");
        Assert.True(state.Player.Statuses.ContainsKey("NEXT_CARD_TO_DRAW_TOP"));

        state = simulator.PlayCard(state, state.Hand.Single(card => card.InstanceId == "attack"), "enemy-0", null);

        Assert.Equal("attack", Assert.Single(state.DrawPile).InstanceId);
        Assert.True(state.Player.Statuses.ContainsKey("SKILLS_EXHAUST_ON_PLAY"));
    }

    [Fact]
    public void CorruptionDestinationIsPreservedAcrossUnknownShuffleBranches()
    {
        var statuses = EmptyStatuses
            .Add("SKILLS_COST_ZERO", new StatusState("SKILLS_COST_ZERO", 1))
            .Add("SKILLS_EXHAUST_ON_PLAY", new StatusState("SKILLS_EXHAUST_ON_PLAY", 1))
            .Add("NEXT_CARD_TO_DRAW_TOP", new StatusState("NEXT_CARD_TO_DRAW_TOP", 1));
        var drawSkill = new CardState("draw-skill", "DRAW_SKILL", "Draw Skill", 2, TargetKind.Self,
            [new EffectSpec(EffectKind.Draw, 1)], CardType: "Skill");
        var snapshot = CombatSnapshot.Create(
            "fixture",
            new PlayerState(30, 30, 0, 0, 0, statuses, CardsPerTurn: 0),
            [new CreatureState("enemy-0", "Enemy", 100, 100, 0, EmptyStatuses, [], 0)],
            [drawSkill],
            discardPile: [DamageCard("a", 1, 0), DamageCard("b", 1, 0)],
            rngState: 0);

        var outcomes = new DeterministicSimulator().PlayCardOutcomes(
            MutableCombatState.FromSnapshot(snapshot), drawSkill, null, null);

        // The two discard cards are semantically identical, so their
        // interchangeable permutations merge into one NOSL branch.
        Assert.Single(outcomes);
        Assert.All(outcomes, outcome =>
        {
            Assert.Single(outcome.State.ExhaustPile, card => card.InstanceId == "draw-skill");
            Assert.DoesNotContain(outcome.State.DiscardPile, card => card.InstanceId == "draw-skill");
            Assert.True(outcome.State.Player.Statuses.ContainsKey("NEXT_CARD_TO_DRAW_TOP"));
        });
    }

    [Fact]
    public void FeralReturnsOnlyTheFirstZeroCostNonDupeAttackEachTurn()
    {
        var statuses = EmptyStatuses.Add(
            "FERAL_ZERO_COST_ATTACK_RETURN",
            new StatusState("FERAL_ZERO_COST_ATTACK_RETURN", 1));
        var attack = DamageCard("attack", 1, 0) with { CardType = "Attack" };
        var snapshot = CombatSnapshot.Create(
            "fixture",
            new PlayerState(30, 30, 0, 0, 0, statuses, CardsPerTurn: 0),
            [new CreatureState("enemy-0", "Enemy", 100, 100, 0, EmptyStatuses, [], 0)],
            [attack]);
        var simulator = new DeterministicSimulator();

        var first = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), attack, "enemy-0", null);
        var returned = Assert.Single(first.Hand, card => card.InstanceId == "attack");
        Assert.Equal(1, first.Player.Statuses["FERAL_ZERO_COST_ATTACK_RETURN_USED"].Amount);

        var second = simulator.PlayCard(first, returned, "enemy-0", null);
        Assert.DoesNotContain(second.Hand, card => card.InstanceId == "attack");
        Assert.Single(second.DiscardPile, card => card.InstanceId == "attack");

        var dupe = attack with { InstanceId = "dupe", IsDupe = true };
        var dupeSnapshot = snapshot with { Hand = [dupe] };
        var dupeResult = simulator.PlayCard(MutableCombatState.FromSnapshot(dupeSnapshot), dupe, "enemy-0", null);
        Assert.DoesNotContain(dupeResult.Hand, card => card.InstanceId == "dupe");
        Assert.DoesNotContain(dupeResult.DiscardPile, card => card.InstanceId == "dupe");
        Assert.DoesNotContain(dupeResult.ExhaustPile, card => card.InstanceId == "dupe");
        Assert.False(dupeResult.Player.Statuses.ContainsKey("FERAL_ZERO_COST_ATTACK_RETURN_USED"));
    }

    [Fact]
    public void NostalgiaUsesPrePlayTurnCountAndOnlyRedirectsDiscardCards()
    {
        var statuses = EmptyStatuses.Add(
            "NOSTALGIA_ATTACK_SKILL_TOPDECK",
            new StatusState("NOSTALGIA_ATTACK_SKILL_TOPDECK", 1));
        var attack = DamageCard("attack", 1, 0) with { CardType = "Attack" };
        var skill = new CardState("skill", "SKILL", "Skill", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.Block, 1)], CardType: "Skill");
        var snapshot = CombatSnapshot.Create(
            "fixture",
            new PlayerState(30, 30, 0, 0, 0, statuses, CardsPerTurn: 0),
            [new CreatureState("enemy-0", "Enemy", 100, 100, 0, EmptyStatuses, [], 0)],
            [attack, skill]);
        var simulator = new DeterministicSimulator();

        var first = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), attack, "enemy-0", null);
        Assert.Equal("attack", Assert.Single(first.DrawPile).InstanceId);
        var second = simulator.PlayCard(first, skill, null, null);
        Assert.Single(second.DiscardPile, card => card.InstanceId == "skill");

        var usedStatuses = statuses.Add(
            "NOSTALGIA_ATTACK_SKILL_PLAYS_BEFORE_SNAPSHOT",
            new StatusState("NOSTALGIA_ATTACK_SKILL_PLAYS_BEFORE_SNAPSHOT", 1));
        var usedSnapshot = snapshot with
        {
            Player = snapshot.Player with { Statuses = usedStatuses },
            Hand = [attack]
        };
        var alreadyUsed = simulator.PlayCard(MutableCombatState.FromSnapshot(usedSnapshot), attack, "enemy-0", null);
        Assert.Single(alreadyUsed.DiscardPile, card => card.InstanceId == "attack");
    }

    [Fact]
    public void DestinationPowerPriorityPreservesUnusedReboundAndCorruptionWinsForSkills()
    {
        var rebound = new StatusState("NEXT_CARD_TO_DRAW_TOP", 1);
        var attack = DamageCard("attack", 1, 0) with { CardType = "Attack" };
        var feralStatuses = EmptyStatuses
            .Add("FERAL_ZERO_COST_ATTACK_RETURN", new StatusState("FERAL_ZERO_COST_ATTACK_RETURN", 1))
            .Add(rebound.Id, rebound);
        var feralSnapshot = CombatSnapshot.Create(
            "fixture",
            new PlayerState(30, 30, 0, 0, 0, feralStatuses, CardsPerTurn: 0),
            [new CreatureState("enemy-0", "Enemy", 100, 100, 0, EmptyStatuses, [], 0)],
            [attack]);
        var simulator = new DeterministicSimulator();

        var feral = simulator.PlayCard(MutableCombatState.FromSnapshot(feralSnapshot), attack, "enemy-0", null);
        Assert.Contains(feral.Hand, card => card.InstanceId == "attack");
        Assert.True(feral.Player.Statuses.ContainsKey(rebound.Id));

        var nostalgiaStatuses = EmptyStatuses
            .Add("NOSTALGIA_ATTACK_SKILL_TOPDECK", new StatusState("NOSTALGIA_ATTACK_SKILL_TOPDECK", 1))
            .Add(rebound.Id, rebound);
        var nostalgiaSnapshot = feralSnapshot with
        {
            Player = feralSnapshot.Player with { Statuses = nostalgiaStatuses }
        };
        var nostalgia = simulator.PlayCard(MutableCombatState.FromSnapshot(nostalgiaSnapshot), attack, "enemy-0", null);
        Assert.Equal("attack", Assert.Single(nostalgia.DrawPile).InstanceId);
        Assert.True(nostalgia.Player.Statuses.ContainsKey(rebound.Id));

        var skill = new CardState("skill", "SKILL", "Skill", 2, TargetKind.Self,
            [new EffectSpec(EffectKind.Block, 1)], CardType: "Skill");
        var corruptionStatuses = nostalgiaStatuses
            .Add("SKILLS_COST_ZERO", new StatusState("SKILLS_COST_ZERO", 1))
            .Add("SKILLS_EXHAUST_ON_PLAY", new StatusState("SKILLS_EXHAUST_ON_PLAY", 1));
        var corruptionSnapshot = nostalgiaSnapshot with
        {
            Player = nostalgiaSnapshot.Player with { Statuses = corruptionStatuses },
            Hand = [skill]
        };
        var corruption = simulator.PlayCard(MutableCombatState.FromSnapshot(corruptionSnapshot), skill, null, null);
        Assert.Single(corruption.ExhaustPile, card => card.InstanceId == "skill");
        Assert.True(corruption.Player.Statuses.ContainsKey(rebound.Id));
    }

    [Fact]
    public void UnknownShuffleFinishesFeralAndNostalgiaCardsExactlyOnce()
    {
        var drawAttack = new CardState("draw-attack", "DRAW_ATTACK", "Draw Attack", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 1), new EffectSpec(EffectKind.Draw, 1)], CardType: "Attack");
        var discard = new[] { DamageCard("a", 1, 0), DamageCard("b", 1, 0) };
        var basePlayer = new PlayerState(30, 30, 0, 0, 0, EmptyStatuses, CardsPerTurn: 0);
        var enemy = new CreatureState("enemy-0", "Enemy", 100, 100, 0, EmptyStatuses, [], 0);
        var simulator = new DeterministicSimulator();

        var feralSnapshot = CombatSnapshot.Create(
            "fixture",
            basePlayer with { Statuses = EmptyStatuses.Add("FERAL_ZERO_COST_ATTACK_RETURN", new StatusState("FERAL_ZERO_COST_ATTACK_RETURN", 1)) },
            [enemy], [drawAttack], discardPile: discard, rngState: 0);
        var feralOutcomes = simulator.PlayCardOutcomes(
            MutableCombatState.FromSnapshot(feralSnapshot), drawAttack, "enemy-0", null);
        Assert.All(feralOutcomes, outcome =>
        {
            Assert.Single(outcome.State.Hand, card => card.InstanceId == "draw-attack");
            Assert.DoesNotContain(outcome.State.DiscardPile, card => card.InstanceId == "draw-attack");
            Assert.Equal(1, outcome.State.Player.Statuses["FERAL_ZERO_COST_ATTACK_RETURN_USED"].Amount);
        });

        var nostalgiaSnapshot = feralSnapshot with
        {
            Player = basePlayer with { Statuses = EmptyStatuses.Add("NOSTALGIA_ATTACK_SKILL_TOPDECK", new StatusState("NOSTALGIA_ATTACK_SKILL_TOPDECK", 1)) }
        };
        var nostalgiaOutcomes = simulator.PlayCardOutcomes(
            MutableCombatState.FromSnapshot(nostalgiaSnapshot), drawAttack, "enemy-0", null);
        Assert.All(nostalgiaOutcomes, outcome =>
            Assert.Equal("draw-attack", outcome.State.DrawPile[0].InstanceId));
    }

    [Fact]
    public void PerTurnDestinationUsageResetsWithoutRemovingPersistentPowers()
    {
        var statuses = EmptyStatuses
            .Add("FERAL_ZERO_COST_ATTACK_RETURN", new StatusState("FERAL_ZERO_COST_ATTACK_RETURN", 1))
            .Add("FERAL_ZERO_COST_ATTACK_RETURN_USED", new StatusState("FERAL_ZERO_COST_ATTACK_RETURN_USED", 1))
            .Add("NOSTALGIA_ATTACK_SKILL_TOPDECK", new StatusState("NOSTALGIA_ATTACK_SKILL_TOPDECK", 1))
            .Add("NOSTALGIA_ATTACK_SKILL_PLAYS_BEFORE_SNAPSHOT", new StatusState("NOSTALGIA_ATTACK_SKILL_PLAYS_BEFORE_SNAPSHOT", 1));
        var snapshot = CombatSnapshot.Create(
            "fixture",
            new PlayerState(30, 30, 0, 0, 0, statuses, CardsPerTurn: 0),
            [new CreatureState("enemy-0", "Enemy", 100, 100, 0, EmptyStatuses, [], 0)],
            []);

        var nextTurn = new DeterministicSimulator().ProjectToNextPlayerTurn(MutableCombatState.FromSnapshot(snapshot));

        Assert.True(nextTurn.Player.Statuses.ContainsKey("FERAL_ZERO_COST_ATTACK_RETURN"));
        Assert.True(nextTurn.Player.Statuses.ContainsKey("NOSTALGIA_ATTACK_SKILL_TOPDECK"));
        Assert.False(nextTurn.Player.Statuses.ContainsKey("FERAL_ZERO_COST_ATTACK_RETURN_USED"));
        Assert.False(nextTurn.Player.Statuses.ContainsKey("NOSTALGIA_ATTACK_SKILL_PLAYS_BEFORE_SNAPSHOT"));
    }

    [Fact]
    public void ConsumableReplayStatusesRepeatEffectsButSpendAndMoveOnce()
    {
        var statuses = EmptyStatuses.Add("NEXT_ATTACK_REPLAY", new StatusState("NEXT_ATTACK_REPLAY", 2, Duration: 1));
        var firstCard = DamageCard("first", 6, 1) with { CardType = "Attack" };
        var secondCard = DamageCard("second", 6, 1) with { CardType = "Attack" };
        var snapshot = CombatSnapshot.Create(
            "fixture",
            new PlayerState(30, 30, 0, 2, 2, statuses, CardsPerTurn: 0),
            [new CreatureState("enemy-0", "Enemy", 100, 100, 0, EmptyStatuses, [], 0)],
            [firstCard, secondCard]);
        var simulator = new DeterministicSimulator();

        var first = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), firstCard, "enemy-0", null);
        Assert.Equal(88m, first.Enemies[0].Hp);
        Assert.Equal(1, first.Player.Energy);
        Assert.Single(first.DiscardPile, card => card.InstanceId == "first");
        Assert.Equal(1, first.Player.Statuses["NEXT_ATTACK_REPLAY"].Amount);
        Assert.Equal(2, first.AttacksPlayedSinceSnapshot);
        Assert.Equal(1, first.CardsPlayedSinceSnapshot);

        var second = simulator.PlayCard(first, secondCard, "enemy-0", null);
        Assert.Equal(76m, second.Enemies[0].Hp);
        Assert.Equal(0, second.Player.Energy);
        Assert.Single(second.DiscardPile, card => card.InstanceId == "second");
        Assert.False(second.Player.Statuses.ContainsKey("NEXT_ATTACK_REPLAY"));
        Assert.Equal(4, second.AttacksPlayedSinceSnapshot);
        Assert.Equal(2, second.CardsPlayedSinceSnapshot);
    }

    [Fact]
    public void EchoFormCountsRootSeriesAndDoesNotActivateRetroactively()
    {
        var echoStatuses = EmptyStatuses.Add(
            "ECHO_FORM_REPLAY_FIRST_CARDS",
            new StatusState("ECHO_FORM_REPLAY_FIRST_CARDS", 1));
        var firstCard = DamageCard("first", 5, 0) with { CardType = "Attack" };
        var secondCard = DamageCard("second", 5, 0) with { CardType = "Attack" };
        var snapshot = CombatSnapshot.Create(
            "fixture",
            new PlayerState(30, 30, 0, 0, 0, echoStatuses, CardsPerTurn: 0),
            [new CreatureState("enemy-0", "Enemy", 100, 100, 0, EmptyStatuses, [], 0)],
            [firstCard, secondCard]);
        var simulator = new DeterministicSimulator();

        var first = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), firstCard, "enemy-0", null);
        var second = simulator.PlayCard(first, secondCard, "enemy-0", null);
        Assert.Equal(85m, second.Enemies[0].Hp); // first card twice, second card once

        var usedSnapshot = snapshot with
        {
            Player = snapshot.Player with
            {
                Statuses = echoStatuses.Add(
                    "ECHO_FORM_ROOT_PLAYS_BEFORE_SNAPSHOT",
                    new StatusState("ECHO_FORM_ROOT_PLAYS_BEFORE_SNAPSHOT", 1))
            },
            Hand = [firstCard]
        };
        var used = simulator.PlayCard(MutableCombatState.FromSnapshot(usedSnapshot), firstCard, "enemy-0", null);
        Assert.Equal(95m, used.Enemies[0].Hp);

        var echoCard = new CardState("echo", "ECHO_FORM", "Echo Form", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 1, "ECHO_FORM_REPLAY_FIRST_CARDS")],
            CardDestination.Remove, CardType: "Power");
        var freshSnapshot = snapshot with
        {
            Player = snapshot.Player with { Statuses = EmptyStatuses },
            Hand = [echoCard, firstCard]
        };
        var afterEcho = simulator.PlayCard(MutableCombatState.FromSnapshot(freshSnapshot), echoCard, null, null);
        var afterAttack = simulator.PlayCard(afterEcho, firstCard, "enemy-0", null);
        Assert.Equal(95m, afterAttack.Enemies[0].Hp); // Echo Form itself was already the first root series.
    }

    [Fact]
    public void ReplayedPowerResnapshotsCardPlayTriggersForEveryIteration()
    {
        var statuses = EmptyStatuses
            .Add("NEXT_POWER_REPLAY", new StatusState("NEXT_POWER_REPLAY", 1))
            .Add("TRIGGER_CARD_PLAYED_BLOCK", new StatusState("TRIGGER_CARD_PLAYED_BLOCK", 1))
            .Add("TRIGGER_POWER_PLAYED_ENERGY", new StatusState("TRIGGER_POWER_PLAYED_ENERGY", 1))
            .Add("TRIGGER_POWER_PLAYED_LIGHTNING", new StatusState("TRIGGER_POWER_PLAYED_LIGHTNING", 1));
        var power = new CardState("power", "POWER", "Power", 1, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 1, "TRIGGER_CARD_PLAYED_BLOCK")],
            CardDestination.Remove, CardType: "Power");
        var snapshot = CombatSnapshot.Create(
            "fixture",
            new PlayerState(30, 30, 0, 1, 1, statuses, CardsPerTurn: 0),
            [new CreatureState("enemy-0", "Enemy", 100, 100, 0, EmptyStatuses, [], 0)],
            [power], orbs: [], orbCapacity: 3);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), power, null, null);

        Assert.Equal(3m, result.Player.Block); // old stack after play 1, then old+new stack after play 2
        Assert.Equal(2, result.Player.Energy); // paid once, Subroutine refunded twice
        Assert.Equal(2, result.Orbs.Count); // Storm triggered once per replay iteration
        Assert.Equal(3, result.Player.Statuses["TRIGGER_CARD_PLAYED_BLOCK"].Amount);
        Assert.False(result.Player.Statuses.ContainsKey("NEXT_POWER_REPLAY"));
    }

    [Fact]
    public void CardReplayEnchantmentRepeatsWithoutAnyPowerStatus()
    {
        var replayed = DamageCard("replayed", 4, 1) with { CardType = "Attack", ReplayCount = 2 };
        var snapshot = Snapshot(30, 100, 0, [replayed], energy: 1);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), replayed, "enemy-0", null);

        Assert.Equal(88m, result.Enemies[0].Hp);
        Assert.Equal(0, result.Player.Energy);
        Assert.Single(result.DiscardPile, card => card.InstanceId == "replayed");
        Assert.Equal(3, result.AttacksPlayedSinceSnapshot);
        Assert.Equal(1, result.CardsPlayedSinceSnapshot);
    }

    [Fact]
    public void ReplayedUnknownShuffleDrawsAndRandomDamageBranchPerIteration()
    {
        var replayStatuses = EmptyStatuses.Add("NEXT_SKILL_REPLAY", new StatusState("NEXT_SKILL_REPLAY", 1, Duration: 1));
        var drawSkill = new CardState("draw", "DRAW", "Draw", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.Draw, 1)], CardType: "Skill");
        var drawSnapshot = CombatSnapshot.Create(
            "fixture",
            new PlayerState(30, 30, 0, 0, 0, replayStatuses, CardsPerTurn: 0),
            [new CreatureState("enemy-0", "Enemy", 100, 100, 0, EmptyStatuses, [], 0)],
            [drawSkill], discardPile: [DamageCard("a", 1, 0), DamageCard("b", 1, 0), DamageCard("c", 1, 0)], rngState: 0);
        var simulator = new DeterministicSimulator();

        var drawOutcomes = simulator.PlayCardOutcomes(
            MutableCombatState.FromSnapshot(drawSnapshot), drawSkill, null, null);
        // a/b/c share one semantic signature and therefore collapse to one
        // equivalent post-state branch.
        Assert.Single(drawOutcomes);
        Assert.All(drawOutcomes, outcome =>
        {
            Assert.Equal(2, outcome.State.Hand.Count);
            Assert.Single(outcome.State.DiscardPile, card => card.InstanceId == "draw");
            Assert.False(outcome.State.Player.Statuses.ContainsKey("NEXT_SKILL_REPLAY"));
        });

        var randomAttack = new CardState("random", "RANDOM", "Random", 0, TargetKind.None,
            [new EffectSpec(EffectKind.RandomEnemyDamage, 3)], CardType: "Attack");
        var randomSnapshot = CombatSnapshot.Create(
            "fixture",
            new PlayerState(30, 30, 0, 0, 0,
                EmptyStatuses.Add("NEXT_ATTACK_REPLAY", new StatusState("NEXT_ATTACK_REPLAY", 1, Duration: 1)), CardsPerTurn: 0),
            [
                new CreatureState("enemy-a", "A", 20, 20, 0, EmptyStatuses, [], 0),
                new CreatureState("enemy-b", "B", 20, 20, 0, EmptyStatuses, [], 0)
            ],
            [randomAttack]);
        var randomOutcomes = simulator.PlayCardOutcomes(
            MutableCombatState.FromSnapshot(randomSnapshot), randomAttack, null, null);
        Assert.Equal(4, randomOutcomes.Length);
        Assert.All(randomOutcomes, outcome => Assert.Equal(6m, outcome.State.DamageDealt));
    }

    [Fact]
    public void BarricadeRetainsCurrentBlockAcrossEnemyTurnProjection()
    {
        var barricade = new CardState("barricade", "BARRICADE", "Barricade", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 1, "BARRICADE")],
            CardDestination.Remove, CardType: "Power");
        var snapshot = CombatSnapshot.Create(
            "fixture",
            new PlayerState(30, 30, 12, 0, 0, EmptyStatuses, CardsPerTurn: 0),
            [new CreatureState("enemy-0", "Enemy", 30, 30, 0, EmptyStatuses, [], 0)],
            [barricade]);
        var simulator = new DeterministicSimulator();

        var played = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), barricade, null, null);
        var projected = simulator.ProjectToNextPlayerTurn(played);

        Assert.Equal(12m, projected.Player.Block);
        Assert.True(projected.Player.Statuses.ContainsKey("BARRICADE"));
    }

    [Fact]
    public void SelfToHandDestinationKeepsParticleWallSearchable()
    {
        var wall = new CardState("wall", "PARTICLE_WALL", "Particle Wall", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.Block, 9)],
            CardDestination.Hand, CardType: "Skill");
        var snapshot = Snapshot(30, 30, 0, [wall], energy: 0);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), wall, null, null);

        Assert.Equal(9m, result.Player.Block);
        Assert.Single(result.Hand, card => card.InstanceId == "wall");
        Assert.Empty(result.DiscardPile);
    }

    [Fact]
    public void ZeroCostSelfCopyPreservesOriginalDestinationAndOverridesCopyCost()
    {
        var adaptive = new CardState("adaptive", "ADAPTIVE_STRIKE", "Adaptive Strike", 2, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 18),
                new EffectSpec(
                    EffectKind.CopyPlayedCard,
                    1,
                    StatusId: "ZERO_COST",
                    GeneratedDestination: GeneratedCardDestination.DiscardPile)
            ],
            CardType: "Attack");
        var snapshot = Snapshot(30, 50, 0, [adaptive], energy: 2);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), adaptive, "enemy-0", null);

        Assert.Equal(32m, result.Enemies[0].Hp);
        Assert.Equal(2, result.DiscardPile.Count);
        Assert.Contains(result.DiscardPile, card => card.InstanceId == "adaptive" && card.EnergyCost == 2);
        Assert.Contains(result.DiscardPile, card => card.InstanceId.StartsWith("copy:adaptive_strike:") && card.EnergyCost == 0 && !card.CostsX);
    }

    [Fact]
    public void HandTopdeckChoiceResolvesAfterDrawAndSearchOffersTheDrawnCard()
    {
        var drawn = DamageCard("drawn", 3, 0);
        var kept = DamageCard("kept", 3, 0);
        var planner = new CardState("planner", "PHOTON_CUT", "Photon Cut", 0, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 10),
                new EffectSpec(EffectKind.Draw, 1),
                new EffectSpec(EffectKind.ChooseHandToDrawTop, 1)
            ],
            CardType: "Attack");
        var snapshot = Snapshot(30, 30, 0, [planner, kept], drawPile: [drawn], energy: 0);
        var state = MutableCombatState.FromSnapshot(snapshot);
        var choices = CombatSearchSession.BuildDynamicChoices(state, planner);
        var drawnChoice = Assert.Single(choices, choice => choice.CardInstanceId == "drawn");

        var result = new DeterministicSimulator().PlayCard(state, planner, "enemy-0", drawnChoice);

        Assert.Equal(20m, result.Enemies[0].Hp);
        Assert.DoesNotContain(result.Hand, card => card.InstanceId == "drawn");
        Assert.Equal("drawn", result.DrawPile[0].InstanceId);
        Assert.Contains(result.Hand, card => card.InstanceId == "kept");
    }

    [Fact]
    public void SelectedColorlessCardCopyKeepsOriginalAndAddsOneCloneToHand()
    {
        var colorless = DamageCard("colorless", 3, 0) with { IsColorless = true };
        var colored = DamageCard("colored", 3, 0);
        var hammer = new CardState("hammer", "HEIRLOOM_HAMMER", "Heirloom Hammer", 2, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 20),
                new EffectSpec(EffectKind.CopyChosenHandCard, 1, StatusId: "COLORLESS")
            ],
            CardType: "Attack");
        var snapshot = Snapshot(30, 60, 0, [hammer, colorless, colored], energy: 2);
        var state = MutableCombatState.FromSnapshot(snapshot);
        var choices = CombatSearchSession.BuildDynamicChoices(state, hammer);
        var choice = Assert.Single(choices);

        Assert.Equal("colorless", choice.CardInstanceId);
        var result = new DeterministicSimulator().PlayCard(state, hammer, "enemy-0", choice);

        Assert.Equal(40m, result.Enemies[0].Hp);
        Assert.Contains(result.Hand, card => card.InstanceId == "colorless");
        Assert.Contains(result.Hand, card => card.InstanceId.StartsWith("copy:selected:") && card.ModelId == "STRIKE" && card.IsColorless);
        Assert.Contains(result.Hand, card => card.InstanceId == "colored");
        Assert.Single(result.DiscardPile, card => card.InstanceId == "hammer");
    }

    [Fact]
    public void SelectedColorlessCopyAllowsNoSelectionWhenNoEligibleCardExists()
    {
        var colored = DamageCard("colored", 3, 0);
        var hammer = new CardState("hammer", "HEIRLOOM_HAMMER", "Heirloom Hammer", 2, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 20),
                new EffectSpec(EffectKind.CopyChosenHandCard, 1, StatusId: "COLORLESS")
            ],
            CardType: "Attack");
        var snapshot = Snapshot(30, 60, 0, [hammer, colored], energy: 2);
        var state = MutableCombatState.FromSnapshot(snapshot);

        Assert.Empty(CombatSearchSession.BuildDynamicChoices(state, hammer));
        var result = new DeterministicSimulator().PlayCard(state, hammer, "enemy-0", null);

        Assert.Equal(PredictionConfidence.Reliable, result.Confidence);
        Assert.Equal(40m, result.Enemies[0].Hp);
        Assert.Single(result.Hand, card => card.InstanceId == "colored");
    }

    [Fact]
    public void BorrowedTimeRaisesFutureCurrentTurnCostsButLateFreeEffectsStillWin()
    {
        var borrowed = new CardState("borrowed", "BORROWED_TIME", "Borrowed Time", 1, TargetKind.Self,
            [
                new EffectSpec(EffectKind.GainEnergy, 4),
                new EffectSpec(EffectKind.ApplyStatus, 1, "ALL_CARD_COST_DELTA", Duration: 1)
            ],
            CardType: "Skill");
        var attack = DamageCard("attack", 6, 1) with { CardType = "Attack" };
        var skill = new CardState("skill", "SKILL", "Skill", 2, TargetKind.Self,
            [new EffectSpec(EffectKind.Block, 5)], CardType: "Skill");
        var snapshot = CombatSnapshot.Create(
            "fixture",
            new PlayerState(30, 30, 0, 3, 3, EmptyStatuses, CardsPerTurn: 0),
            [new CreatureState("enemy-0", "Enemy", 30, 30, 0, EmptyStatuses, [], 0)],
            [borrowed, attack, skill]);
        var simulator = new DeterministicSimulator();

        var afterBorrowed = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), borrowed, null, null);
        Assert.Equal(6, afterBorrowed.Player.Energy);
        Assert.Equal(2, DeterministicSimulator.EnergyCostToPlay(afterBorrowed, attack));
        Assert.Equal(3, DeterministicSimulator.EnergyCostToPlay(afterBorrowed, skill));

        afterBorrowed.Player = afterBorrowed.Player with
        {
            Statuses = afterBorrowed.Player.Statuses
                .Add("NEXT_FREE_ATTACK", new StatusState("NEXT_FREE_ATTACK", 1, Duration: 1))
                .Add("SKILLS_COST_ZERO", new StatusState("SKILLS_COST_ZERO", 1))
        };
        Assert.Equal(0, DeterministicSimulator.EnergyCostToPlay(afterBorrowed, attack));
        Assert.Equal(0, DeterministicSimulator.EnergyCostToPlay(afterBorrowed, skill));

        var nextTurn = simulator.ProjectToNextPlayerTurn(afterBorrowed);
        Assert.False(nextTurn.Player.Statuses.ContainsKey("ALL_CARD_COST_DELTA"));
    }

    [Fact]
    public void DoomKillsTheFirstEligibleCreatureOnEachSideAtSideTurnEnd()
    {
        var playerStatuses = EmptyStatuses.Add("DOOM", new StatusState("DOOM", 3, FutureValuePerTurn: -3m));
        var enemyStatuses = EmptyStatuses.Add("DOOM", new StatusState("DOOM", 5, FutureValuePerTurn: -5m));
        var lethalPlayerSnapshot = CombatSnapshot.Create(
            "player-doom-fixture",
            new PlayerState(3, 30, 0, 3, 3, playerStatuses, CardsPerTurn: 0),
            [new CreatureState("enemy", "Enemy", 20, 20, 0, EmptyStatuses, [], 0)],
            []);
        var enemyDoomSnapshot = CombatSnapshot.Create(
            "enemy-doom-fixture",
            new PlayerState(10, 30, 0, 3, 3, playerStatuses, CardsPerTurn: 0),
            [
                new CreatureState("enemy-0", "Enemy A", 5, 20, 0, enemyStatuses, [], 0),
                new CreatureState("enemy-1", "Enemy B", 4, 20, 0, enemyStatuses, [], 0)
            ],
            []);
        var simulator = new DeterministicSimulator();

        var playerDoom = simulator.ProjectToNextPlayerTurn(MutableCombatState.FromSnapshot(lethalPlayerSnapshot));
        var enemyDoom = simulator.ProjectToNextPlayerTurn(MutableCombatState.FromSnapshot(enemyDoomSnapshot));

        Assert.Equal(0m, playerDoom.Player.Hp);
        Assert.Equal(0m, enemyDoom.Enemies[0].Hp);
        Assert.Equal(4m, enemyDoom.Enemies[1].Hp);
        Assert.Equal(1, enemyDoom.EnemiesKilled);
    }

    [Fact]
    public void NeurosurgeAddsSelfDoomAtEveryPlayerTurnStart()
    {
        var statuses = EmptyStatuses.Add(
            "TURN_START_SELF_DOOM",
            new StatusState("TURN_START_SELF_DOOM", 3, FutureValuePerTurn: -3m));
        var snapshot = CombatSnapshot.Create(
            "neurosurge-fixture",
            new PlayerState(10, 30, 0, 3, 3, statuses, CardsPerTurn: 0),
            [new CreatureState("enemy", "Enemy", 20, 20, 0, EmptyStatuses, [], 0)],
            []);
        var simulator = new DeterministicSimulator();

        var firstStart = simulator.ProjectToNextPlayerTurn(MutableCombatState.FromSnapshot(snapshot));
        var secondStart = simulator.ProjectToNextPlayerTurn(firstStart);

        Assert.Equal(3, firstStart.Player.Statuses["DOOM"].Amount);
        Assert.Equal(6, secondStart.Player.Statuses["DOOM"].Amount);
        Assert.True(secondStart.Player.Statuses.ContainsKey("TURN_START_SELF_DOOM"));
    }

    [Fact]
    public void CountdownAppliesRandomDoomAtPlayerTurnStart()
    {
        var baseSnapshot = Snapshot(30, 40, 0, []);
        var statuses = EmptyStatuses.Add(
            "TURN_START_RANDOM_DOOM",
            new StatusState("TURN_START_RANDOM_DOOM", 6));
        var snapshot = baseSnapshot with
        {
            Player = baseSnapshot.Player with { Statuses = statuses }
        };

        var result = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(snapshot));

        Assert.Equal(6, result.Enemies[0].Statuses["DOOM"].Amount);
        Assert.True(result.Player.Statuses.ContainsKey("TURN_START_RANDOM_DOOM"));
    }

    [Theory]
    [InlineData("STRENGTH", 2, 3)]
    [InlineData("STRENGTH", -2, -3)]
    [InlineData("WEAK", 2, -3)]
    [InlineData("VULNERABLE", 2, -4)]
    [InlineData("POISON", 2, -2)]
    [InlineData("DOOM", 3, -3)]
    [InlineData("CANNOT_DRAW", 1, -3)]
    [InlineData("DEBILITATE", 1, -3)]
    [InlineData("BONUS_VULNERABLE_POWERED_ATTACK_DAMAGE_PERCENT", 25, -2)]
    public void StatusValuationUsesTheStatusOwnersPerspective(string id, decimal amount, decimal expected)
    {
        Assert.Equal(expected, StatusValuation.IntrinsicFutureValue(id, amount));
    }

    [Fact]
    public void CombatScorerRewardsEnemyDebuffsAndPenalizesPlayerDebuffs()
    {
        var snapshot = Snapshot(30, 30, 0, [], energy: 3);
        var scorer = new CombatScorer(snapshot, SearchOptions.Default);
        var enemyPoisoned = MutableCombatState.FromSnapshot(snapshot);
        enemyPoisoned.Enemies[0] = enemyPoisoned.Enemies[0] with
        {
            Statuses = enemyPoisoned.Enemies[0].Statuses.Add("POISON", new StatusState("POISON", 3))
        };
        var enemyDebilitated = MutableCombatState.FromSnapshot(snapshot);
        enemyDebilitated.Enemies[0] = enemyDebilitated.Enemies[0] with
        {
            Statuses = enemyDebilitated.Enemies[0].Statuses.Add(
                "DEBILITATE",
                new StatusState("DEBILITATE", 1, FutureValuePerTurn: -3m))
        };
        var playerPoisoned = MutableCombatState.FromSnapshot(snapshot);
        playerPoisoned.Player = playerPoisoned.Player with
        {
            Statuses = playerPoisoned.Player.Statuses.Add("POISON", new StatusState("POISON", 3))
        };
        var playerCruelty = MutableCombatState.FromSnapshot(snapshot);
        playerCruelty.Player = playerCruelty.Player with
        {
            Statuses = playerCruelty.Player.Statuses.Add(
                "BONUS_VULNERABLE_POWERED_ATTACK_DAMAGE_PERCENT",
                new StatusState("BONUS_VULNERABLE_POWERED_ATTACK_DAMAGE_PERCENT", 25, FutureValuePerTurn: 2m))
        };

        Assert.True(scorer.Score(enemyPoisoned).LongTermValue > 0m);
        Assert.True(scorer.Score(enemyDebilitated).LongTermValue > 0m);
        Assert.True(scorer.Score(playerPoisoned).LongTermValue < 0m);
        Assert.True(scorer.Score(playerCruelty).LongTermValue > 0m);
    }

    [Fact]
    public void PreciseCutUsesTheRemainingHandCountAfterLeavingTheHand()
    {
        var precise = new CardState("precise", "PRECISE_CUT", "Precise Cut", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.DynamicDamage, 13, "HAND_CARD_COUNT", XBonus: -2)], CardType: "Attack");
        var snapshot = Snapshot(30, 30, 0,
            [precise, DamageCard("other-a", 1, 0), DamageCard("other-b", 1, 0)], energy: 0);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), precise, "enemy-0", null);

        Assert.Equal(21m, result.Enemies[0].Hp);
        Assert.Equal(9m, result.DamageDealt);
    }

    [Fact]
    public void ClashAndGrandFinaleReevaluateTheirPlayRestrictionsAfterStateChanges()
    {
        var clash = new CardState("clash", "CLASH", "Clash", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.PlayRestriction, 1, "HAND_ALL_ATTACKS"), new EffectSpec(EffectKind.Damage, 14)],
            CardType: "Attack");
        var skill = BlockCard("skill", 1, 0) with { CardType = "Skill" };
        var finale = new CardState("finale", "GRAND_FINALE", "Grand Finale", 0, TargetKind.AllEnemies,
            [new EffectSpec(EffectKind.PlayRestriction, 1, "DRAW_PILE_EMPTY"), new EffectSpec(EffectKind.Damage, 60)],
            CardType: "Attack");
        var state = MutableCombatState.FromSnapshot(Snapshot(30, 100, 0, [clash, skill, finale],
            drawPile: [DamageCard("drawn", 1, 0)], energy: 0));

        Assert.False(DeterministicSimulator.IsCardPlayableNow(state, clash));
        Assert.False(DeterministicSimulator.IsCardPlayableNow(state, finale));
        state = new DeterministicSimulator().PlayCard(state, skill, null, null);
        state.Hand.RemoveAll(card => card.InstanceId == "finale");
        Assert.True(DeterministicSimulator.IsCardPlayableNow(state, clash));
        state.DrawPile.Clear();
        state.Hand.Add(finale);
        Assert.True(DeterministicSimulator.IsCardPlayableNow(state, finale));
    }

    [Fact]
    public void SunderOnlyRefundsEnergyWhenItsOwnDamageKills()
    {
        var sunder = new CardState("sunder", "SUNDER", "Sunder", 3, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 24), new EffectSpec(EffectKind.GainEnergy, 3, Condition: "SOURCE_CARD_KILLED")],
            CardType: "Attack");
        var simulator = new DeterministicSimulator();
        var lethal = simulator.PlayCard(MutableCombatState.FromSnapshot(Snapshot(30, 20, 0, [sunder], energy: 3)), sunder, "enemy-0", null);
        var nonlethal = simulator.PlayCard(MutableCombatState.FromSnapshot(Snapshot(30, 30, 0, [sunder], energy: 3)), sunder, "enemy-0", null);

        Assert.Equal(3, lethal.Player.Energy);
        Assert.Equal(0, nonlethal.Player.Energy);
    }

    [Fact]
    public void EndOfDaysKillsEveryEligibleDoomedEnemyImmediately()
    {
        var end = new CardState("end", "END_OF_DAYS", "End of Days", 0, TargetKind.AllEnemies,
            [
                new EffectSpec(EffectKind.ApplyStatus, 29, "DOOM", TargetOverride: TargetKind.AllEnemies),
                new EffectSpec(EffectKind.KillAllDoomedEnemies, 1, "DOOM_AT_LEAST_HP", TargetOverride: TargetKind.AllEnemies)
            ]);
        var secondStatuses = EmptyStatuses.Add("DOOM", new StatusState("DOOM", 2));
        var snapshot = CombatSnapshot.Create(
            "end-of-days",
            new PlayerState(30, 30, 0, 0, 0, EmptyStatuses, CardsPerTurn: 0),
            [
                new CreatureState("enemy-a", "A", 20, 20, 0, EmptyStatuses, [], 0),
                new CreatureState("enemy-b", "B", 30, 30, 0, secondStatuses, [], 0),
                new CreatureState("enemy-c", "C", 40, 40, 0, EmptyStatuses, [], 0)
            ],
            [end]);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), end, null, null);

        Assert.Equal([0m, 0m, 40m], result.Enemies.Select(static enemy => enemy.Hp));
        Assert.Equal(2, result.EnemiesKilled);
    }

    [Fact]
    public void ShadowmeldDoublesEachLaterBlockGainAfterDexterity()
    {
        var statuses = EmptyStatuses
            .Add("DEXTERITY", new StatusState("DEXTERITY", 2))
            .Add("DOUBLE_BLOCK_GAINED", new StatusState("DOUBLE_BLOCK_GAINED", 1, Duration: 1));
        var block = BlockCard("block", 5, 0);
        var snapshot = Snapshot(30, 30, 0, [block], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, statuses, CardsPerTurn: 0)
        };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), block, null, null);

        Assert.Equal(14m, result.Player.Block);
    }

    [Fact]
    public void TemporaryStrengthLossReducesThisEnemyTurnThenExpires()
    {
        var enemyStatuses = EmptyStatuses.Add("STRENGTH", new StatusState("STRENGTH", 2));
        var weaken = new CardState("weaken", "DARK_SHACKLES", "Dark Shackles", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.ApplyStatus, 5, "TEMP_STRENGTH_LOSS", Duration: 1, TargetOverride: TargetKind.Enemy)]);
        var snapshot = CombatSnapshot.Create(
            "temporary-strength",
            new PlayerState(30, 30, 0, 0, 0, EmptyStatuses, CardsPerTurn: 0),
            [new CreatureState("enemy", "Enemy", 30, 30, 0, enemyStatuses, [new IntentState("Attack", 10, 1)], 10)],
            [weaken]);
        var simulator = new DeterministicSimulator();
        var afterPlay = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), weaken, "enemy", null);

        var nextTurn = simulator.ProjectToNextPlayerTurn(afterPlay);

        Assert.Equal(23m, nextTurn.Player.Hp);
        Assert.False(nextTurn.Enemies[0].Statuses.ContainsKey("TEMP_STRENGTH_LOSS"));
        Assert.Equal(2, nextTurn.Enemies[0].Statuses["STRENGTH"].Amount);
    }

    [Fact]
    public void EnemyHpLossBypassesBlock()
    {
        var capture = new CardState("capture", "CAPTURE_SPIRIT", "Capture Spirit", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.LoseEnemyHp, 3, TargetOverride: TargetKind.Enemy)]);
        var snapshot = Snapshot(30, 10, 0, [capture], energy: 0);
        var state = MutableCombatState.FromSnapshot(snapshot);
        state.Enemies[0] = state.Enemies[0] with { Block = 9 };

        var result = new DeterministicSimulator().PlayCard(state, capture, "enemy-0", null);

        Assert.Equal(7m, result.Enemies[0].Hp);
        Assert.Equal(9m, result.Enemies[0].Block);
    }

    [Fact]
    public void RepeatedDamageUsesLiveHistoryAndSearchLocalCardPlays()
    {
        var setupAttack = new CardState("setup", "SETUP", "Setup", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 0)], CardType: "Attack");
        var finisher = new CardState("finisher", "FINISHER", "Finisher", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.DynamicDamage, 6, "ATTACKS_PLAYED_THIS_TURN", RepeatByHistoryCounter: true)],
            CardType: "Attack");
        var snapshot = Snapshot(30, 100, 0, [setupAttack, finisher], energy: 0) with
        {
            HistoryCounters = new CombatHistoryCounters(AttacksPlayedThisTurn: 2)
        };
        var simulator = new DeterministicSimulator();
        var afterSetup = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), setupAttack, "enemy-0", null);

        var result = simulator.PlayCard(afterSetup, finisher, "enemy-0", null);

        Assert.Equal(82m, result.Enemies[0].Hp);
        Assert.Equal(2, result.AttacksPlayedSinceSnapshot);
        Assert.Equal(2, result.CardPlaysFinishedSinceSnapshot);
    }

    [Fact]
    public void TearAsunderUsesDamageReceivedEventCount()
    {
        var tear = new CardState("tear", "TEAR_ASUNDER", "Tear Asunder", 0, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 5),
                new EffectSpec(EffectKind.DynamicDamage, 1, "PLAYER_DAMAGE_RECEIVED_THIS_COMBAT", RepeatByHistoryCounter: true)
            ], CardType: "Attack");
        var snapshot = Snapshot(30, 100, 0, [tear], energy: 0) with
        {
            HistoryCounters = new CombatHistoryCounters(DamageReceivedEventsThisCombat: 2)
        };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), tear, "enemy-0", null);

        Assert.Equal(93m, result.Enemies[0].Hp);
    }

    [Fact]
    public void MelancholyReducesCostWhenAnEnemyDies()
    {
        var melancholy = new CardState("melancholy", "MELANCHOLY", "Melancholy", 2, TargetKind.Self,
            [
                new EffectSpec(EffectKind.Block, 13),
                new EffectSpec(EffectKind.ModifyPlayedCardCost, -1, "SELF_DEATH_COST_DELTA")
            ], CardType: "Skill");
        var strike = new CardState("strike", "STRIKE", "Strike", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 10)], CardType: "Attack");
        var snapshot = Snapshot(30, 100, 0, [melancholy, strike], energy: 0) with
        {
            Enemies = [new CreatureState("enemy-0", "Enemy", 5, 5, 0,
                ImmutableDictionary<string, StatusState>.Empty, [])]
        };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), strike, "enemy-0", null);

        Assert.Equal(1, result.Hand.Single(card => card.ModelId == "MELANCHOLY").EnergyCost);
    }

    [Fact]
    public void DeathsDoorAddsConditionalBlockAfterApplyingDoom()
    {
        var doom = new CardState("doom", "DOOM_CARD", "Doom", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.ApplyStatus, 2, "DOOM", IsDebuff: true)], CardType: "Skill");
        var deathsDoor = new CardState("door", "DEATHS_DOOR", "Deaths Door", 0, TargetKind.Self,
            [
                new EffectSpec(EffectKind.Block, 6),
                new EffectSpec(EffectKind.Block, 2, Condition: "DOOM_APPLIED_THIS_TURN")
            ], CardType: "Skill");
        var snapshot = Snapshot(30, 100, 0, [doom, deathsDoor], energy: 0);
        var simulator = new DeterministicSimulator();
        var afterDoom = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), doom, "enemy-0", null);

        var result = simulator.PlayCard(afterDoom, deathsDoor, null, null);

        Assert.Equal(8m, result.Player.Block);
    }

    [Fact]
    public void FeedAddsMaxHpOnlyWhenItsAttackKills()
    {
        var feed = new CardState(
            "feed", "FEED", "Feed", 0, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 10),
                new EffectSpec(EffectKind.ModifyMaxHp, 3, Condition: "SOURCE_CARD_KILLED")
            ], CardType: "Attack");
        var snapshot = Snapshot(20, 5, 0, [feed], energy: 0);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), feed, "enemy-0", null);

        Assert.Equal(23m, result.Player.MaxHp);
        Assert.Equal(20m, result.Player.Hp);
        Assert.False(result.Enemies[0].IsAlive);
    }

    [Fact]
    public void HandSkillAndCombatHistoryDamageUseExactCurrentCounts()
    {
        var skillA = new CardState("skill-a", "SKILL_A", "Skill A", 0, TargetKind.Self, [], CardType: "Skill");
        var skillB = new CardState("skill-b", "SKILL_B", "Skill B", 0, TargetKind.Self, [], CardType: "技能");
        var flechettes = new CardState("flechettes", "FLECHETTES", "Flechettes", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.DynamicDamage, 5, "HAND_SKILL_COUNT", RepeatByHistoryCounter: true)],
            CardType: "Attack");
        var goldAxe = new CardState("gold", "GOLD_AXE", "Gold Axe", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.DynamicDamage, 1, "CARDS_PLAYED_THIS_COMBAT")], CardType: "Attack");
        var snapshot = Snapshot(30, 100, 0, [skillA, skillB, flechettes, goldAxe], energy: 0) with
        {
            HistoryCounters = new CombatHistoryCounters(CardsPlayedThisCombat: 4)
        };
        var simulator = new DeterministicSimulator();
        var afterFlechettes = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), flechettes, "enemy-0", null);

        var result = simulator.PlayCard(afterFlechettes, goldAxe, "enemy-0", null);

        Assert.Equal(85m, result.Enemies[0].Hp);
    }

    [Fact]
    public void DrawAndGenerationCountersAdvanceInsideThePredictedSequence()
    {
        var fillerA = BlockCard("filler-a", 0, 9);
        var fillerB = BlockCard("filler-b", 0, 9);
        var generated = BlockCard("generated", 0, 9);
        var draw = new CardState("draw", "DRAW_TWO", "Draw Two", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.Draw, 2)], CardType: "Skill");
        var generate = new CardState("generate", "GENERATE_TWO", "Generate Two", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.GenerateCards, 2, GeneratedCard: generated)], CardType: "Skill");
        var murder = new CardState("murder", "MURDER", "Murder", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.DynamicDamage, 1, "CARDS_DRAWN_THIS_COMBAT", XBonus: 1)], CardType: "Attack");
        var supermassive = new CardState("supermassive", "SUPERMASSIVE", "Supermassive", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.DynamicDamage, 5, "CARDS_GENERATED_THIS_COMBAT", XBonus: 3)], CardType: "Attack");
        var snapshot = Snapshot(30, 100, 0, [draw, generate, murder, supermassive], [fillerA, fillerB], energy: 0) with
        {
            HistoryCounters = new CombatHistoryCounters(CardsDrawnThisCombat: 6, CardsGeneratedThisCombat: 2)
        };
        var simulator = new DeterministicSimulator();
        var state = MutableCombatState.FromSnapshot(snapshot);
        state = simulator.PlayCard(state, draw, null, null);
        state = simulator.PlayCard(state, generate, null, null);
        state = simulator.PlayCard(state, murder, "enemy-0", null);

        var result = simulator.PlayCard(state, supermassive, "enemy-0", null);

        Assert.Equal(74m, result.Enemies[0].Hp);
        Assert.Equal(2, result.CardsDrawnSinceSnapshot);
        Assert.Equal(2, result.CardsGeneratedSinceSnapshot);
    }

    [Fact]
    public void AutomationStartsAtTenDrawsAndResetsAfterTriggering()
    {
        var automation = new CardState("automation", "AUTOMATION", "Automation", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 1, "AUTOMATION_DRAW_ENERGY")], CardType: "Power");
        var draw = new CardState("draw", "DRAW_TEN", "Draw Ten", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.Draw, 10)], CardType: "Skill");
        var drawPile = Enumerable.Range(0, 10).Select(index => BlockCard($"drawn-{index}", 0, 9)).ToArray();
        var simulator = new DeterministicSimulator();
        var state = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(30, 30, 0, [automation, draw], drawPile, energy: 0)),
            automation, null, null);

        var result = simulator.PlayCard(state, draw, null, null);

        Assert.Equal(1, result.Player.Energy);
        Assert.Equal(10, result.Player.Statuses["AUTOMATION_DRAWS_LEFT"].Amount);
    }

    [Fact]
    public void OrbitCountsOnlyEnergySpentWhileActiveAndCarriesRemainder()
    {
        var orbit = new CardState("orbit", "ORBIT", "Orbit", 2, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 1, "ORBIT_ENERGY_REBATE")], CardType: "Power");
        var first = DamageCard("first", 0, 2);
        var second = DamageCard("second", 0, 2);
        var simulator = new DeterministicSimulator();
        var state = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(30, 30, 0, [orbit, first, second], energy: 6)),
            orbit, null, null);
        state = simulator.PlayCard(state, first, "enemy-0", null);

        var result = simulator.PlayCard(state, second, "enemy-0", null);

        Assert.Equal(1, result.Player.Energy);
        Assert.Equal(0, result.Player.Statuses["ORBIT_ENERGY_REMAINDER"].Amount);
    }

    [Fact]
    public void BansheesCryUsesCapturedAndPredictedEtherealHistoryWithoutDoubleCounting()
    {
        var costProgression = new EffectSpec(
            EffectKind.ModifyPlayedCardCost,
            -2,
            "BY_ETHEREAL_PLAYED_SINCE_SNAPSHOT");
        var bansheeTemplate = new CardState(
            "generated:banshees_cry",
            "BANSHEES_CRY",
            "Banshee's Cry",
            9,
            TargetKind.AllEnemies,
            [new EffectSpec(EffectKind.Damage, 33), costProgression],
            CardType: "Attack");
        var generator = new CardState(
            "generator",
            "GENERATE_BANSHEE",
            "Generate Banshee",
            0,
            TargetKind.Self,
            [new EffectSpec(EffectKind.GenerateCards, 1, GeneratedCard: bansheeTemplate)],
            CardType: "Skill");
        var ethereal = new CardState(
            "ethereal",
            "ETHEREAL",
            "Ethereal",
            0,
            TargetKind.Self,
            [],
            CardType: "Skill",
            ExhaustAtTurnEnd: true);
        var snapshot = Snapshot(30, 100, 0, [generator, ethereal], energy: 9) with
        {
            HistoryCounters = new CombatHistoryCounters(EtherealCardsPlayedThisCombat: 2)
        };
        var simulator = new DeterministicSimulator();
        var state = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), generator, null, null);
        var generated = Assert.Single(state.Hand, card => card.ModelId == "BANSHEES_CRY");

        Assert.Equal(5, DeterministicSimulator.EnergyCostToPlay(state, generated));
        state = simulator.PlayCard(state, ethereal, null, null);
        generated = Assert.Single(state.Hand, card => card.ModelId == "BANSHEES_CRY");

        Assert.Equal(3, DeterministicSimulator.EnergyCostToPlay(state, generated));
        Assert.Equal(1, state.EtherealCardsPlayedSinceSnapshot);
    }

    [Fact]
    public void VigorAddsToEveryHitOfTheNextAttackCommandThenIsConsumed()
    {
        var statuses = EmptyStatuses.Add("VIGOR", new StatusState("VIGOR", 2));
        var multiHit = new CardState(
            "multi",
            "MULTI",
            "Multi",
            0,
            TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 5, Repeat: 3)],
            CardType: "Attack");
        var snapshot = Snapshot(30, 100, 0, [multiHit], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, statuses, CardsPerTurn: 0)
        };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), multiHit, "enemy-0", null);

        Assert.Equal(79m, result.Enemies[0].Hp);
        Assert.False(result.Player.Statuses.ContainsKey("VIGOR"));
    }

    [Fact]
    public void VigorAppliesOnlyToTheFirstSeparateAttackCommand()
    {
        var statuses = EmptyStatuses.Add("VIGOR", new StatusState("VIGOR", 2));
        var twoCommands = new CardState(
            "two-commands",
            "TWO_COMMANDS",
            "Two Commands",
            0,
            TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 5), new EffectSpec(EffectKind.Damage, 4)],
            CardType: "Attack");
        var snapshot = Snapshot(30, 100, 0, [twoCommands], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, statuses, CardsPerTurn: 0)
        };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), twoCommands, "enemy-0", null);

        Assert.Equal(89m, result.Enemies[0].Hp);
    }

    [Fact]
    public void PrepTimeAddsVigorAtEachProjectedPlayerTurnStart()
    {
        var statuses = EmptyStatuses.Add(
            "TURN_START_VIGOR",
            new StatusState("TURN_START_VIGOR", 4, FutureValuePerTurn: 4));
        var snapshot = Snapshot(30, 30, 0, [], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, statuses, CardsPerTurn: 0)
        };

        var result = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(snapshot));

        Assert.Equal(4, result.Player.Statuses["VIGOR"].Amount);
        Assert.Equal(4, result.Player.Statuses["TURN_START_VIGOR"].Amount);
    }

    [Fact]
    public void RandomMultiHitAttackUsesVigorForEveryHitAndConsumesItAfterTheCommand()
    {
        var statuses = EmptyStatuses.Add("VIGOR", new StatusState("VIGOR", 2));
        var randomAttack = new CardState(
            "random-vigor",
            "RANDOM_VIGOR",
            "Random Vigor",
            0,
            TargetKind.None,
            [
                new EffectSpec(EffectKind.RandomEnemyDamage, 5),
                new EffectSpec(EffectKind.RandomEnemyDamage, 5)
            ],
            CardType: "Attack");
        var snapshot = CombatSnapshot.Create(
            "random-vigor",
            new PlayerState(30, 30, 0, 0, 0, statuses, CardsPerTurn: 0),
            [
                new CreatureState("enemy-a", "A", 20, 20, 0, EmptyStatuses, [], 0),
                new CreatureState("enemy-b", "B", 20, 20, 0, EmptyStatuses, [], 0)
            ],
            [randomAttack],
            rngState: 0);

        var outcomes = new DeterministicSimulator().PlayCardOutcomes(
            MutableCombatState.FromSnapshot(snapshot), randomAttack, null, null);

        Assert.NotEmpty(outcomes);
        Assert.All(outcomes, outcome =>
        {
            Assert.Equal(14m, outcome.State.DamageDealt);
            Assert.False(outcome.State.Player.Statuses.ContainsKey("VIGOR"));
        });
    }

    [Fact]
    public void PotionDamageDoesNotUseOrConsumeVigor()
    {
        var statuses = EmptyStatuses.Add("VIGOR", new StatusState("VIGOR", 2));
        var potion = new PotionState(
            "potion",
            "DAMAGE_POTION",
            "Damage Potion",
            TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 5)],
            OpportunityCost: 0);
        var snapshot = Snapshot(30, 20, 0, [], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, statuses, CardsPerTurn: 0),
            Potions = [potion]
        };

        var result = new DeterministicSimulator().UsePotion(
            MutableCombatState.FromSnapshot(snapshot), potion, "enemy-0");

        Assert.Equal(15m, result.Enemies[0].Hp);
        Assert.Equal(2, result.Player.Statuses["VIGOR"].Amount);
    }

    [Fact]
    public void TurnStartHpLossBlockAndShivGenerationResolveBeforeNormalDraw()
    {
        var shiv = new CardState(
            "generated:shiv",
            "SHIV",
            "Shiv",
            0,
            TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 4)],
            CardDestination.Exhaust,
            CardType: "Attack");
        var statuses = EmptyStatuses
            .Add("TURN_START_SELF_HP_LOSS", new StatusState("TURN_START_SELF_HP_LOSS", 1))
            .Add("TURN_START_BLOCK", new StatusState("TURN_START_BLOCK", 8))
            .Add("TURN_START_GENERATE_SHIV", new StatusState(
                "TURN_START_GENERATE_SHIV",
                2,
                GeneratedCard: shiv));
        var snapshot = Snapshot(30, 30, 0, [], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, statuses, CardsPerTurn: 0)
        };

        var result = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(snapshot));

        Assert.Equal(29m, result.Player.Hp);
        Assert.Equal(8m, result.Player.Block);
        Assert.Equal(2, result.Hand.Count(card => card.ModelId == "SHIV"));
        Assert.Equal(2, result.CardsGeneratedSinceSnapshot);
    }

    [Fact]
    public void TurnStartFocusLossReducesOrbFocusAndPersistsMarker()
    {
        var statuses = EmptyStatuses
            .Add("FOCUS", new StatusState("FOCUS", 4))
            .Add("TURN_START_FOCUS_LOSS", new StatusState("TURN_START_FOCUS_LOSS", 1));
        var snapshot = Snapshot(30, 30, 0, [], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, statuses),
            Orbs = [new OrbState("LIGHTNING", 3, 8)]
        };

        var result = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(snapshot));

        Assert.Equal(3, result.Player.Statuses["FOCUS"].Amount);
        Assert.Equal(1, result.Player.Statuses["TURN_START_FOCUS_LOSS"].Amount);
        Assert.Equal(2m, result.Orbs[0].EffectivePassiveValue);
    }

    [Fact]
    public void PersistentEnergyAndDrawPenaltiesApplyToTheNextTurnProjection()
    {
        var statuses = EmptyStatuses
            .Add("MAX_ENERGY_DELTA", new StatusState("MAX_ENERGY_DELTA", -1))
            .Add("HAND_DRAW_DELTA", new StatusState("HAND_DRAW_DELTA", -1));
        var drawPile = Enumerable.Range(0, 5)
            .Select(index => BlockCard($"drawn-{index}", 0, 9))
            .ToArray();
        var snapshot = Snapshot(30, 30, 0, [], drawPile, energy: 3) with
        {
            Player = new PlayerState(30, 30, 0, 3, 2, statuses, CardsPerTurn: 5)
        };

        var result = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(snapshot));

        Assert.Equal(2, result.Player.MaxEnergy);
        Assert.Equal(2, result.Player.Energy);
        Assert.Equal(4, result.Hand.Count);
    }

    [Fact]
    public void RandomEnergySpentDamageExpandsOneTargetChancePerXHit()
    {
        var volley = new CardState(
            "volley",
            "VOLLEY",
            "Volley",
            0,
            TargetKind.None,
            [new EffectSpec(EffectKind.RandomEnemyDamage, 5, RepeatByEnergySpent: true)],
            CardType: "Attack",
            CostsX: true);
        var snapshot = CombatSnapshot.Create(
            "volley",
            new PlayerState(30, 30, 0, 3, 3, EmptyStatuses, CardsPerTurn: 0),
            [
                new CreatureState("enemy-a", "A", 30, 30, 0, EmptyStatuses, [], 0),
                new CreatureState("enemy-b", "B", 30, 30, 0, EmptyStatuses, [], 0)
            ],
            [volley],
            rngState: 0);

        var outcomes = new DeterministicSimulator().PlayCardOutcomes(
            MutableCombatState.FromSnapshot(snapshot), volley, null, null);

        Assert.Equal(8, outcomes.Length);
        Assert.All(outcomes, outcome =>
        {
            Assert.Equal(15m, outcome.State.DamageDealt);
            Assert.Equal(0, outcome.State.Player.Energy);
        });
    }

    [Fact]
    public void IterationDrawsOnlyOnceForTheFirstStatusCardThisTurn()
    {
        var statuses = EmptyStatuses.Add("ITERATION_DRAW", new StatusState("ITERATION_DRAW", 2));
        var draw = new CardState(
            "draw",
            "DRAW",
            "Draw",
            0,
            TargetKind.Self,
            [new EffectSpec(EffectKind.Draw, 1)],
            CardType: "Skill");
        var statusA = new CardState("status-a", "WASTE_AWAY", "Waste Away", 0,
            TargetKind.Self, [], CardType: "Status");
        var statusB = new CardState("status-b", "MIND_ROT", "Mind Rot", 0,
            TargetKind.Self, [], CardType: "Status");
        var filler = BlockCard("filler", 0, 9);
        var snapshot = Snapshot(30, 30, 0, [draw], [statusA, statusB, filler], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, statuses, CardsPerTurn: 0)
        };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), draw, null, null);

        Assert.Equal(new[] { "status-a", "status-b", "filler" },
            result.Hand.Select(card => card.InstanceId));
        Assert.Equal(2, result.StatusCardsDrawnSinceSnapshot);
    }

    [Fact]
    public void IterationDoesNotTriggerWhenTheSnapshotAlreadyDrewAStatusCard()
    {
        var statuses = EmptyStatuses.Add("ITERATION_DRAW", new StatusState("ITERATION_DRAW", 2));
        var draw = new CardState("draw", "DRAW", "Draw", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.Draw, 1)], CardType: "Skill");
        var status = new CardState("status", "WASTE_AWAY", "Waste Away", 0,
            TargetKind.Self, [], CardType: "Status");
        var snapshot = Snapshot(30, 30, 0, [draw], [status], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, statuses, CardsPerTurn: 0),
            HistoryCounters = new CombatHistoryCounters(StatusCardsDrawnThisTurn: 1)
        };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), draw, null, null);

        Assert.Single(result.Hand);
        Assert.Equal("status", result.Hand[0].InstanceId);
        Assert.Equal(1, result.StatusCardsDrawnSinceSnapshot);
    }

    [Fact]
    public void PagestormDrawsForEveryEtherealCardAndRunsAfterIteration()
    {
        var statuses = EmptyStatuses
            .Add("ITERATION_DRAW", new StatusState("ITERATION_DRAW", 1))
            .Add("PAGESTORM_DRAW", new StatusState("PAGESTORM_DRAW", 1));
        var draw = new CardState("draw", "DRAW", "Draw", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.Draw, 1)], CardType: "Skill");
        var first = new CardState("first", "ETHEREAL_STATUS", "Ethereal Status", 0,
            TargetKind.Self, [], CardType: "Status", ExhaustAtTurnEnd: true);
        var iterationDraw = BlockCard("iteration", 0, 0);
        var second = new CardState("second", "ETHEREAL_SKILL", "Ethereal Skill", 0,
            TargetKind.Self, [], CardType: "Skill", ExhaustAtTurnEnd: true);
        var nestedPagestormDraw = BlockCard("nested", 0, 0);
        var snapshot = Snapshot(
            30,
            30,
            0,
            [draw],
            [first, iterationDraw, second, nestedPagestormDraw],
            energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, statuses, CardsPerTurn: 0)
        };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), draw, null, null);

        Assert.Equal(new[] { "first", "iteration", "second", "nested" },
            result.Hand.Select(card => card.InstanceId));
        Assert.Empty(result.DrawPile);
        Assert.Equal(4, result.CardsDrawnSinceSnapshot);
        Assert.Equal(1, result.StatusCardsDrawnSinceSnapshot);
    }

    [Fact]
    public void PagestormDoesNotDrawForNonEtherealCards()
    {
        var statuses = EmptyStatuses.Add("PAGESTORM_DRAW", new StatusState("PAGESTORM_DRAW", 1));
        var draw = new CardState("draw", "DRAW", "Draw", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.Draw, 1)], CardType: "Skill");
        var ordinary = BlockCard("ordinary", 0, 0);
        var untouched = BlockCard("untouched", 0, 0);
        var snapshot = Snapshot(30, 30, 0, [draw], [ordinary, untouched], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, statuses, CardsPerTurn: 0)
        };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), draw, null, null);

        Assert.Equal(new[] { "ordinary" }, result.Hand.Select(card => card.InstanceId));
        Assert.Equal(new[] { "untouched" }, result.DrawPile.Select(card => card.InstanceId));
    }

    [Fact]
    public void PagestormPreservesAutomationBeforeVoidEnergyLossOrdering()
    {
        var statuses = EmptyStatuses
            .Add("PAGESTORM_DRAW", new StatusState("PAGESTORM_DRAW", 1))
            .Add("AUTOMATION_DRAW_ENERGY", new StatusState("AUTOMATION_DRAW_ENERGY", 1))
            .Add("AUTOMATION_DRAWS_LEFT", new StatusState("AUTOMATION_DRAWS_LEFT", 2));
        var draw = new CardState("draw", "DRAW", "Draw", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.Draw, 1)], CardType: "Skill");
        var drawnVoid = new CardState(
            "void",
            "VOID",
            "Void",
            0,
            TargetKind.Self,
            [],
            CardType: "Status",
            ExhaustAtTurnEnd: true,
            EnergyChangeOnDraw: -1);
        var pagestormDraw = BlockCard("nested", 0, 0);
        var snapshot = Snapshot(30, 30, 0, [draw], [drawnVoid, pagestormDraw], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, statuses, CardsPerTurn: 0)
        };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), draw, null, null);

        Assert.Equal(0, result.Player.Energy);
        Assert.Equal(10, result.Player.Statuses["AUTOMATION_DRAWS_LEFT"].Amount);
    }

    [Fact]
    public void RageGrantsBlockAfterAttacksAndExpiresAtNextTurn()
    {
        var rage = new CardState(
            "rage",
            "RAGE",
            "Rage",
            0,
            TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 3, "TRIGGER_ATTACK_PLAYED_BLOCK", Duration: 1)],
            CardType: "Skill");
        var attack = DamageCard("attack", 4, cost: 0) with { CardType = "Attack" };
        var snapshot = Snapshot(30, 30, 0, [rage, attack], energy: 0);
        var simulator = new DeterministicSimulator();

        var afterRage = simulator.PlayCard(
            MutableCombatState.FromSnapshot(snapshot), rage, null, null);
        var afterAttack = simulator.PlayCard(
            afterRage, afterRage.Hand.Single(card => card.InstanceId == "attack"), "enemy-0", null);

        Assert.Equal(3m, afterAttack.Player.Block);
        Assert.Equal(3, afterAttack.Player.Statuses["TRIGGER_ATTACK_PLAYED_BLOCK"].Amount);
        var nextTurn = simulator.ProjectToNextPlayerTurn(afterAttack);
        Assert.DoesNotContain("TRIGGER_ATTACK_PLAYED_BLOCK", nextTurn.Player.Statuses.Keys);
    }

    [Fact]
    public void FisticuffsGainsBlockFromActualDamageDealtByTheSameCard()
    {
        var fisticuffs = new CardState(
            "fisticuffs",
            "FISTICUFFS",
            "Fisticuffs",
            0,
            TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 7),
                new EffectSpec(EffectKind.DynamicBlock, 1, "DAMAGE_DEALT_THIS_CARD")
            ],
            CardType: "Attack");
        var snapshot = Snapshot(30, 30, 0, [fisticuffs], energy: 0) with
        {
            Enemies = [new CreatureState("enemy-0", "Enemy", 30, 30, 2, EmptyStatuses, [], 0)]
        };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), fisticuffs, "enemy-0", null);

        Assert.Equal(25m, result.Enemies[0].Hp);
        Assert.Equal(5m, result.Player.Block);
    }

    [Fact]
    public void EchoingSlashRepeatsForChainedEnemyKills()
    {
        var echoingSlash = new CardState(
            "echoing",
            "ECHOING_SLASH",
            "Echoing Slash",
            0,
            TargetKind.AllEnemies,
            [new EffectSpec(EffectKind.Damage, 10, RepeatByKillCount: true)],
            CardType: "Attack");
        var snapshot = Snapshot(30, 30, 0, [echoingSlash], energy: 0) with
        {
            Enemies =
            [
                new CreatureState("enemy-a", "A", 5, 5, 0, EmptyStatuses, [], 0),
                new CreatureState("enemy-b", "B", 10, 10, 0, EmptyStatuses, [], 0),
                new CreatureState("enemy-c", "C", 20, 20, 0, EmptyStatuses, [], 0)
            ]
        };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), echoingSlash, null, null);

        Assert.All(result.Enemies, enemy => Assert.False(enemy.IsAlive));
        Assert.Equal(35m, result.DamageDealt);
        Assert.Equal(3, result.EnemiesKilled);
    }

    [Fact]
    public void SpiteRepeatsAfterPlayerLosesHealthThisTurn()
    {
        var selfHarm = new CardState(
            "self-harm",
            "SELF_HARM",
            "Self Harm",
            0,
            TargetKind.Self,
            [new EffectSpec(EffectKind.LoseHp, 1)],
            CardType: "Skill");
        var spite = new CardState(
            "spite",
            "SPITE",
            "Spite",
            0,
            TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 5, Condition: "PLAYER_HP_LOST_THIS_TURN", Repeat: 2)],
            CardType: "Attack");
        var snapshot = Snapshot(30, 20, 0, [selfHarm, spite], energy: 0);
        var simulator = new DeterministicSimulator();
        var afterHarm = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), selfHarm, null, null);
        var result = simulator.PlayCard(afterHarm, afterHarm.Hand.Single(card => card.InstanceId == "spite"), "enemy-0", null);

        Assert.Equal(10m, result.Enemies[0].Hp);
        Assert.Equal(1m, result.HpLostSinceSnapshot);
    }

    [Fact]
    public void DominateGainsStrengthFromSelectedEnemyVulnerableStacks()
    {
        var dominate = new CardState(
            "dominate",
            "DOMINATE",
            "Dominate",
            0,
            TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.ApplyStatus, 1, "VULNERABLE", TargetOverride: TargetKind.Enemy),
                new EffectSpec(
                    EffectKind.ApplyStatus,
                    1,
                    "STRENGTH",
                    TargetOverride: TargetKind.Self,
                    AmountByTargetVulnerableStacks: true)
            ],
            CardType: "Power");
        var snapshot = Snapshot(30, 20, 0, [dominate], energy: 0) with
        {
            Enemies = [new CreatureState(
                "enemy-0", "Enemy", 20, 20, 0,
                EmptyStatuses.Add("VULNERABLE", new StatusState("VULNERABLE", 3)),
                [], 0)]
        };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), dominate, "enemy-0", null);

        Assert.Equal(4, result.Player.Statuses["STRENGTH"].Amount);
    }

    [Fact]
    public void ExhaustedThisTurnUnlocksRitualAndEvilEyeBonuses()
    {
        var exhaust = new CardState(
            "exhaust",
            "EXHAUST",
            "Exhaust",
            0,
            TargetKind.Self,
            [],
            Destination: CardDestination.Exhaust,
            CardType: "Skill");
        var ritual = new CardState(
            "ritual",
            "FORGOTTEN_RITUAL",
            "Forgotten Ritual",
            0,
            TargetKind.Self,
            [new EffectSpec(EffectKind.GainEnergy, 3, Condition: "CARD_EXHAUSTED_THIS_TURN")],
            CardType: "Skill");
        var eye = new CardState(
            "eye",
            "EVIL_EYE",
            "Evil Eye",
            0,
            TargetKind.Self,
            [
                new EffectSpec(EffectKind.Block, 8),
                new EffectSpec(EffectKind.Block, 8, Condition: "CARD_EXHAUSTED_THIS_TURN")
            ],
            CardType: "Skill");
        var snapshot = Snapshot(30, 20, 0, [exhaust, ritual, eye], energy: 0);
        var simulator = new DeterministicSimulator();
        var afterExhaust = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), exhaust, null, null);
        var afterRitual = simulator.PlayCard(afterExhaust, afterExhaust.Hand.Single(card => card.InstanceId == "ritual"), null, null);
        var result = simulator.PlayCard(afterRitual, afterRitual.Hand.Single(card => card.InstanceId == "eye"), null, null);

        Assert.Equal(3, afterRitual.Player.Energy);
        Assert.Equal(16m, result.Player.Block);
        Assert.Equal(1, result.CardsExhaustedSinceSnapshot);
    }

    [Fact]
    public void DrumOfBattleGainsEnergyOnlyWhenItsOwnCardIsExhausted()
    {
        var drum = new CardState(
            "drum",
            "DRUM_OF_BATTLE",
            "Drum of Battle",
            0,
            TargetKind.Self,
            [
                new EffectSpec(EffectKind.Draw, 2),
                new EffectSpec(EffectKind.GainEnergy, 2, Condition: "SELF_EXHAUSTED")
            ],
            Destination: CardDestination.Exhaust,
            CardType: "Skill");
        var snapshot = Snapshot(30, 20, 0, [drum], energy: 0);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), drum, null, null);

        Assert.Equal(2, result.Player.Energy);
        Assert.Contains(result.ExhaustPile, card => card.InstanceId == "drum");
    }

    [Fact]
    public void HistoricalDrumExhaustsDrawTopBeforeNormalTurnDraw()
    {
        var exhausted = DamageCard("top", 4, 0);
        var drawn = BlockCard("next", 5, 0);
        var snapshot = Snapshot(30, 20, 0, [], drawPile: [exhausted, drawn], energy: 0) with
        {
            Player = new PlayerState(
                30, 30, 0, 0, 0,
                EmptyStatuses.Add(
                    "TURN_START_EXHAUST_DRAW_TOP",
                    new StatusState("TURN_START_EXHAUST_DRAW_TOP", 1)),
                CardsPerTurn: 1)
        };

        var result = new DeterministicSimulator().ProjectToNextPlayerTurn(MutableCombatState.FromSnapshot(snapshot));

        Assert.Contains(result.ExhaustPile, card => card.InstanceId == "top");
        Assert.Contains(result.Hand, card => card.InstanceId == "next");
        Assert.Empty(result.DrawPile);
    }

    [Fact]
    public void ViciousDrawsAfterPlayerAppliesVulnerable()
    {
        var applyVulnerable = new CardState(
            "apply",
            "APPLY_VULNERABLE",
            "Apply Vulnerable",
            0,
            TargetKind.Enemy,
            [new EffectSpec(EffectKind.ApplyStatus, 1, "VULNERABLE")],
            CardType: "Skill");
        var first = BlockCard("first", 1, 0);
        var second = DamageCard("second", 1, 0);
        var snapshot = Snapshot(30, 20, 0, [applyVulnerable], drawPile: [first, second], energy: 0) with
        {
            Player = new PlayerState(
                30, 30, 0, 0, 0,
                EmptyStatuses.Add(
                    "TRIGGER_VULNERABLE_APPLIED_DRAW",
                    new StatusState("TRIGGER_VULNERABLE_APPLIED_DRAW", 2)))
        };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), applyVulnerable, "enemy-0", null);

        Assert.Contains(result.Hand, card => card.InstanceId == "first");
        Assert.Contains(result.Hand, card => card.InstanceId == "second");
        Assert.Equal(1, result.Enemies[0].Statuses["VULNERABLE"].Amount);
    }

    [Fact]
    public void InfernoDamagesAllEnemiesOncePerPlayerHpLossEvent()
    {
        var selfHarm = new CardState(
            "self-harm",
            "SELF_HARM",
            "Self Harm",
            0,
            TargetKind.Self,
            [new EffectSpec(EffectKind.LoseHp, 3)],
            CardType: "Skill");
        var snapshot = Snapshot(30, 20, 0, [selfHarm], energy: 0) with
        {
            Player = new PlayerState(
                30, 30, 0, 0, 0,
                EmptyStatuses.Add(
                    "TRIGGER_PLAYER_HP_LOST_ALL_ENEMY_DAMAGE",
                    new StatusState("TRIGGER_PLAYER_HP_LOST_ALL_ENEMY_DAMAGE", 6))),
            Enemies =
            [
                new CreatureState("enemy-a", "A", 20, 20, 0, EmptyStatuses, [], 0),
                new CreatureState("enemy-b", "B", 12, 12, 0, EmptyStatuses, [], 0)
            ]
        };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), selfHarm, null, null);

        Assert.Equal(27m, result.Player.Hp);
        Assert.Equal(14m, result.Enemies[0].Hp);
        Assert.Equal(6m, result.Enemies[1].Hp);
    }

    [Fact]
    public void RuptureAccumulatesEachCardSourcedHpLossAndFlushesAfterEachReplay()
    {
        var selfHarm = new CardState(
            "self-harm",
            "SELF_HARM_ATTACK",
            "Self Harm Attack",
            0,
            TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.LoseHp, 1),
                new EffectSpec(EffectKind.LoseHp, 9),
                new EffectSpec(EffectKind.Damage, 5)
            ],
            CardType: "Attack",
            ReplayCount: 1);
        var snapshot = Snapshot(30, 40, 0, [selfHarm], energy: 0) with
        {
            Player = new PlayerState(
                30, 30, 0, 0, 0,
                EmptyStatuses.Add(
                    "TRIGGER_PLAYER_HP_LOST_STRENGTH",
                    new StatusState("TRIGGER_PLAYER_HP_LOST_STRENGTH", 2)))
        };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), selfHarm, "enemy-0", null);

        Assert.Equal(10m, result.Player.Hp);
        Assert.Equal(20m, result.HpLostSinceSnapshot);
        Assert.Equal(8, result.Player.Statuses["STRENGTH"].Amount);
        Assert.Equal(26m, result.Enemies[0].Hp);
    }

    [Fact]
    public void RuptureDropsPendingCardGainWhenTheOwnerDiesBeforeAfterCardPlayed()
    {
        var fatal = new CardState(
            "fatal",
            "FATAL_SELF_HARM",
            "Fatal Self Harm",
            0,
            TargetKind.Self,
            [
                new EffectSpec(EffectKind.LoseHp, 1),
                new EffectSpec(EffectKind.LoseHp, 9)
            ],
            CardType: "Skill");
        var snapshot = Snapshot(5, 20, 0, [fatal], energy: 0) with
        {
            Player = new PlayerState(
                5, 5, 0, 0, 0,
                EmptyStatuses.Add(
                    "TRIGGER_PLAYER_HP_LOST_STRENGTH",
                    new StatusState("TRIGGER_PLAYER_HP_LOST_STRENGTH", 2)))
        };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), fatal, null, null);

        Assert.Equal(0m, result.Player.Hp);
        Assert.False(result.Player.Statuses.ContainsKey("STRENGTH"));
    }

    [Fact]
    public void RuptureAppliesUntrackedOwnerSideHpLossImmediatelyButNotEnemyTurnDamage()
    {
        var burn = BlockCard("burn", 0, 0) with { HpLossAtTurnEnd = 3, IsPlayable = false };
        var rupture = EmptyStatuses.Add(
            "TRIGGER_PLAYER_HP_LOST_STRENGTH",
            new StatusState("TRIGGER_PLAYER_HP_LOST_STRENGTH", 2));
        var ownerSide = Snapshot(30, 20, 0, [burn], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, rupture, CardsPerTurn: 0)
        };
        var enemySide = Snapshot(30, 20, 3, [], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, rupture, CardsPerTurn: 0)
        };
        var simulator = new DeterministicSimulator();

        var afterOwnerLoss = simulator.ProjectToNextPlayerTurn(MutableCombatState.FromSnapshot(ownerSide));
        var afterEnemyDamage = simulator.ProjectToNextPlayerTurn(MutableCombatState.FromSnapshot(enemySide));

        Assert.Equal(27m, afterOwnerLoss.Player.Hp);
        Assert.Equal(2, afterOwnerLoss.Player.Statuses["STRENGTH"].Amount);
        Assert.Equal(27m, afterEnemyDamage.Player.Hp);
        Assert.False(afterEnemyDamage.Player.Statuses.ContainsKey("STRENGTH"));
    }

    [Fact]
    public void RuptureTriggersOnceForEachTurnEndHpLossEvent()
    {
        var first = BlockCard("first-burn", 0, 0) with { HpLossAtTurnEnd = 1, IsPlayable = false };
        var second = BlockCard("second-burn", 0, 0) with { HpLossAtTurnEnd = 2, IsPlayable = false };
        var rupture = EmptyStatuses.Add(
            "TRIGGER_PLAYER_HP_LOST_STRENGTH",
            new StatusState("TRIGGER_PLAYER_HP_LOST_STRENGTH", 2));
        var snapshot = Snapshot(30, 20, 0, [first, second], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, rupture, CardsPerTurn: 0)
        };

        var result = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(snapshot));

        Assert.Equal(27m, result.Player.Hp);
        Assert.Equal(4, result.Player.Statuses["STRENGTH"].Amount);
    }

    [Fact]
    public void RuptureKeepsEarlierImmediateGainWhenALaterTurnEndHpLossIsFatal()
    {
        var first = BlockCard("first-burn", 0, 0) with { HpLossAtTurnEnd = 1, IsPlayable = false };
        var fatal = BlockCard("fatal-burn", 0, 0) with { HpLossAtTurnEnd = 5, IsPlayable = false };
        var rupture = EmptyStatuses.Add(
            "TRIGGER_PLAYER_HP_LOST_STRENGTH",
            new StatusState("TRIGGER_PLAYER_HP_LOST_STRENGTH", 2));
        var snapshot = Snapshot(3, 20, 0, [first, fatal], energy: 0) with
        {
            Player = new PlayerState(3, 3, 0, 0, 0, rupture, CardsPerTurn: 0)
        };

        var result = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(snapshot));

        Assert.Equal(0m, result.Player.Hp);
        Assert.Equal(2, result.Player.Statuses["STRENGTH"].Amount);
    }

    [Fact]
    public void MonologueTriggersOnlyExistingInstancesAndRemovesOnlyItsTemporaryStrength()
    {
        var monologue = new CardState(
            "monologue",
            "MONOLOGUE",
            "Monologue",
            0,
            TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 1, "TRIGGER_CARD_PLAYED_TEMP_STRENGTH", Duration: 1)],
            CardType: "Skill");
        var first = DamageCard("first", 5, 0) with { CardType = "Attack" };
        var second = DamageCard("second", 5, 0) with { CardType = "Attack" };
        var snapshot = Snapshot(30, 100, 0, [monologue, first, second], energy: 0) with
        {
            Player = new PlayerState(
                30, 30, 0, 0, 0,
                EmptyStatuses.Add("STRENGTH", new StatusState("STRENGTH", 2)),
                CardsPerTurn: 0)
        };
        var simulator = new DeterministicSimulator();

        var afterMonologue = simulator.PlayCard(
            MutableCombatState.FromSnapshot(snapshot), monologue, null, null);
        var afterFirst = simulator.PlayCard(
            afterMonologue, afterMonologue.Hand.Single(card => card.InstanceId == "first"), "enemy-0", null);
        var afterSecond = simulator.PlayCard(
            afterFirst, afterFirst.Hand.Single(card => card.InstanceId == "second"), "enemy-0", null);

        Assert.Equal(2, afterMonologue.Player.Statuses["STRENGTH"].Amount);
        Assert.False(afterMonologue.Player.Statuses.ContainsKey("MONOLOGUE_STRENGTH_APPLIED"));
        Assert.Equal(3, afterFirst.Player.Statuses["STRENGTH"].Amount);
        Assert.Equal(1, afterFirst.Player.Statuses["MONOLOGUE_STRENGTH_APPLIED"].Amount);
        Assert.Equal(4, afterSecond.Player.Statuses["STRENGTH"].Amount);
        Assert.Equal(2, afterSecond.Player.Statuses["MONOLOGUE_STRENGTH_APPLIED"].Amount);
        Assert.Equal(85m, afterSecond.Enemies[0].Hp);

        var nextTurn = simulator.ProjectToNextPlayerTurn(afterSecond);
        Assert.Equal(2, nextTurn.Player.Statuses["STRENGTH"].Amount);
        Assert.False(nextTurn.Player.Statuses.ContainsKey("TRIGGER_CARD_PLAYED_TEMP_STRENGTH"));
        Assert.False(nextTurn.Player.Statuses.ContainsKey("MONOLOGUE_STRENGTH_APPLIED"));
    }

    [Fact]
    public void MonologueReplayTreatsEachPlayIterationAsASeparateCardPlayedEvent()
    {
        var replayed = new CardState(
            "monologue",
            "MONOLOGUE",
            "Monologue",
            0,
            TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 1, "TRIGGER_CARD_PLAYED_TEMP_STRENGTH", Duration: 1)],
            CardType: "Skill",
            ReplayCount: 1);
        var snapshot = Snapshot(30, 30, 0, [replayed], energy: 0);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), replayed, null, null);

        Assert.Equal(2, result.Player.Statuses["TRIGGER_CARD_PLAYED_TEMP_STRENGTH"].Amount);
        Assert.Equal(1, result.Player.Statuses["STRENGTH"].Amount);
        Assert.Equal(1, result.Player.Statuses["MONOLOGUE_STRENGTH_APPLIED"].Amount);
    }

    [Fact]
    public void OblivionBindsItsEnemyAndArtifactGatesMarkerInstallationAndEveryDoomApplication()
    {
        var oblivion = new CardState(
            "oblivion",
            "OBLIVION",
            "Oblivion",
            0,
            TargetKind.Enemy,
            [new EffectSpec(
                EffectKind.ApplyStatus,
                4,
                "TRIGGER_CARD_PLAYED_DOOM",
                Duration: 1,
                IsDebuff: true,
                TargetOverride: TargetKind.Enemy)],
            CardType: "Skill");
        var followUp = BlockCard("follow-up", 0, 0) with { CardType = "Skill" };
        var artifact = new StatusState("ARTIFACT", 1);
        var snapshot = Snapshot(30, 30, 0, [oblivion, followUp], energy: 0) with
        {
            Enemies =
            [
                new CreatureState(
                    "enemy-a", "A", 30, 30, 0,
                    EmptyStatuses
                        .Add("TRIGGER_CARD_PLAYED_DOOM", new StatusState(
                            "TRIGGER_CARD_PLAYED_DOOM", 3, Duration: 1, IsDebuff: true))
                        .Add("ARTIFACT", artifact),
                    [], 0),
                new CreatureState(
                    "enemy-b", "B", 30, 30, 0,
                    EmptyStatuses.Add("ARTIFACT", artifact),
                    [], 0)
            ]
        };
        var simulator = new DeterministicSimulator();

        var afterOblivion = simulator.PlayCard(
            MutableCombatState.FromSnapshot(snapshot), oblivion, "enemy-b", null);

        Assert.False(afterOblivion.Enemies.Single(enemy => enemy.Id == "enemy-a").Statuses.ContainsKey("ARTIFACT"));
        Assert.False(afterOblivion.Enemies.Single(enemy => enemy.Id == "enemy-a").Statuses.ContainsKey("DOOM"));
        Assert.False(afterOblivion.Enemies.Single(enemy => enemy.Id == "enemy-b").Statuses.ContainsKey("ARTIFACT"));
        Assert.False(afterOblivion.Enemies.Single(enemy => enemy.Id == "enemy-b").Statuses.ContainsKey("TRIGGER_CARD_PLAYED_DOOM"));

        var result = simulator.PlayCard(
            afterOblivion, afterOblivion.Hand.Single(card => card.InstanceId == "follow-up"), null, null);

        Assert.Equal(3, result.Enemies.Single(enemy => enemy.Id == "enemy-a").Statuses["DOOM"].Amount);
        Assert.False(result.Enemies.Single(enemy => enemy.Id == "enemy-b").Statuses.ContainsKey("DOOM"));
    }

    [Fact]
    public void OblivionReplayDoesNotTriggerTheFirstInstallationButTriggersItOnTheSecondIteration()
    {
        var oblivion = new CardState(
            "oblivion",
            "OBLIVION",
            "Oblivion",
            0,
            TargetKind.Enemy,
            [new EffectSpec(
                EffectKind.ApplyStatus,
                3,
                "TRIGGER_CARD_PLAYED_DOOM",
                Duration: 1,
                IsDebuff: true,
                TargetOverride: TargetKind.Enemy)],
            CardType: "Skill",
            ReplayCount: 1);
        var snapshot = Snapshot(30, 30, 0, [oblivion], energy: 0);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), oblivion, "enemy-0", null);

        Assert.Equal(6, result.Enemies[0].Statuses["TRIGGER_CARD_PLAYED_DOOM"].Amount);
        Assert.Equal(3, result.Enemies[0].Statuses["DOOM"].Amount);
    }

    [Fact]
    public void CorrosiveWaveAndSpeedsterTriggerPerSuccessfulDrawAndStopAtTheHandLimit()
    {
        var draw = new CardState(
            "draw",
            "DRAW_THREE",
            "Draw Three",
            0,
            TargetKind.Self,
            [new EffectSpec(EffectKind.Draw, 3)],
            CardType: "Skill");
        var fillers = Enumerable.Range(0, 8).Select(index => BlockCard($"held-{index}", 0, 0)).ToArray();
        var drawn = Enumerable.Range(0, 3).Select(index => BlockCard($"drawn-{index}", 0, 0)).ToArray();
        var statuses = EmptyStatuses
            .Add("STRENGTH", new StatusState("STRENGTH", 10))
            .Add("TRIGGER_CARD_DRAWN_ALL_POISON", new StatusState("TRIGGER_CARD_DRAWN_ALL_POISON", 2, Duration: 1))
            .Add("TRIGGER_NON_HAND_DRAW_ALL_DAMAGE", new StatusState("TRIGGER_NON_HAND_DRAW_ALL_DAMAGE", 3));
        var snapshot = Snapshot(30, 20, 0, new[] { draw }.Concat(fillers), drawn, energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, statuses),
            Enemies =
            [
                new CreatureState(
                    "enemy-a", "A", 20, 20, 0,
                    EmptyStatuses.Add("ARTIFACT", new StatusState("ARTIFACT", 1)), [], 0),
                new CreatureState(
                    "enemy-b", "B", 20, 20, 2,
                    EmptyStatuses.Add("VULNERABLE", new StatusState("VULNERABLE", 1)), [], 0)
            ]
        };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), draw, null, null);

        Assert.Equal(10, result.Hand.Count);
        Assert.Equal(2, result.CardsDrawnSinceSnapshot);
        Assert.Equal("drawn-2", Assert.Single(result.DrawPile).InstanceId);
        Assert.Equal(14m, result.Enemies.Single(enemy => enemy.Id == "enemy-a").Hp);
        Assert.Equal(2, result.Enemies.Single(enemy => enemy.Id == "enemy-a").Statuses["POISON"].Amount);
        Assert.False(result.Enemies.Single(enemy => enemy.Id == "enemy-a").Statuses.ContainsKey("ARTIFACT"));
        Assert.Equal(16m, result.Enemies.Single(enemy => enemy.Id == "enemy-b").Hp);
        Assert.Equal(4, result.Enemies.Single(enemy => enemy.Id == "enemy-b").Statuses["POISON"].Amount);
    }

    [Fact]
    public void SpeedsterIgnoresNormalTurnDrawButTriggersRecursiveInTurnDraws()
    {
        var ethereal = BlockCard("ethereal", 0, 0) with { ExhaustAtTurnEnd = true };
        var nested = BlockCard("nested", 0, 0);
        var statuses = EmptyStatuses
            .Add("PAGESTORM_DRAW", new StatusState("PAGESTORM_DRAW", 1))
            .Add("TRIGGER_NON_HAND_DRAW_ALL_DAMAGE", new StatusState("TRIGGER_NON_HAND_DRAW_ALL_DAMAGE", 4));
        var snapshot = Snapshot(30, 20, 0, [], drawPile: [ethereal, nested], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, statuses, CardsPerTurn: 1)
        };

        var result = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(snapshot));

        Assert.Equal(16m, result.Enemies[0].Hp);
        Assert.Equal(2, result.CardsDrawnSinceSnapshot);
        Assert.Contains(result.Hand, card => card.InstanceId == "ethereal");
        Assert.Contains(result.Hand, card => card.InstanceId == "nested");
    }

    [Fact]
    public void FlameBarrierRetaliatesPerBlockedPoweredHitAndKillingTheAttackerStopsLaterHits()
    {
        var flame = EmptyStatuses.Add(
            "TRIGGER_POWERED_ATTACK_RECEIVED_DAMAGE",
            new StatusState("TRIGGER_POWERED_ATTACK_RECEIVED_DAMAGE", 3, Duration: 1));
        var snapshot = Snapshot(30, 5, 4, [], energy: 0) with
        {
            Player = new PlayerState(30, 30, 8, 0, 0, flame, CardsPerTurn: 0),
            Enemies =
            [
                new CreatureState(
                    "enemy-0", "Enemy", 5, 5, 0, EmptyStatuses,
                    [new IntentState("Attack", 4, 3)], 4)
            ]
        };

        var result = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(snapshot));

        Assert.Equal(30m, result.Player.Hp);
        Assert.Equal(0m, result.Enemies[0].Hp);
        Assert.False(result.Player.Statuses.ContainsKey("TRIGGER_POWERED_ATTACK_RECEIVED_DAMAGE"));
    }

    [Fact]
    public void FlameBarrierRetaliationIsBlockableAndSkipsFatalOrUnpoweredDamage()
    {
        var flame = EmptyStatuses.Add(
            "TRIGGER_POWERED_ATTACK_RECEIVED_DAMAGE",
            new StatusState("TRIGGER_POWERED_ATTACK_RECEIVED_DAMAGE", 4, Duration: 1));
        var blockable = Snapshot(30, 10, 1, [], energy: 0) with
        {
            Player = new PlayerState(30, 30, 10, 0, 0, flame, CardsPerTurn: 0),
            Enemies = [new CreatureState(
                "enemy-0", "Enemy", 10, 10, 5, EmptyStatuses,
                [new IntentState("Attack", 1, 1)], 1)]
        };
        var fatal = Snapshot(3, 10, 4, [], energy: 0) with
        {
            Player = new PlayerState(3, 3, 0, 0, 0, flame, CardsPerTurn: 0)
        };
        var unpowered = Snapshot(30, 10, 0, [], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, flame, CardsPerTurn: 0),
            Enemies = [new CreatureState(
                "enemy-0", "Enemy", 10, 10, 0, EmptyStatuses,
                [new IntentState("Safe damage", Effects: [new EffectSpec(EffectKind.Damage, 2)])], 0)]
        };
        var simulator = new DeterministicSimulator();

        var afterBlocked = simulator.ProjectToNextPlayerTurn(MutableCombatState.FromSnapshot(blockable));
        var afterFatal = simulator.ProjectToNextPlayerTurn(MutableCombatState.FromSnapshot(fatal));
        var afterUnpowered = simulator.ProjectToNextPlayerTurn(MutableCombatState.FromSnapshot(unpowered));

        Assert.Equal(10m, afterBlocked.Enemies[0].Hp);
        Assert.Equal(1m, afterBlocked.Enemies[0].Block);
        Assert.Equal(0m, afterFatal.Player.Hp);
        Assert.Equal(10m, afterFatal.Enemies[0].Hp);
        Assert.Equal(28m, afterUnpowered.Player.Hp);
        Assert.Equal(10m, afterUnpowered.Enemies[0].Hp);
    }

    [Fact]
    public void ReflectReturnsOnlyBlockedPoweredAttackDamageAndExpires()
    {
        var reflect = EmptyStatuses.Add(
            "REFLECT_BLOCKED_ATTACK_DAMAGE",
            new StatusState("REFLECT_BLOCKED_ATTACK_DAMAGE", 1, Duration: 1));
        var fullBlock = Snapshot(30, 30, 10, [], energy: 0) with
        {
            Player = new PlayerState(30, 30, 15, 0, 0, reflect, CardsPerTurn: 0)
        };
        var partialBlock = Snapshot(30, 30, 10, [], energy: 0) with
        {
            Player = new PlayerState(30, 30, 4, 0, 0, reflect, CardsPerTurn: 0)
        };
        var simulator = new DeterministicSimulator();

        var afterFullBlock = simulator.ProjectToNextPlayerTurn(MutableCombatState.FromSnapshot(fullBlock));
        var afterPartialBlock = simulator.ProjectToNextPlayerTurn(MutableCombatState.FromSnapshot(partialBlock));

        Assert.Equal(30m, afterFullBlock.Player.Hp);
        Assert.Equal(20m, afterFullBlock.Enemies[0].Hp);
        Assert.False(afterFullBlock.Player.Statuses.ContainsKey("REFLECT_BLOCKED_ATTACK_DAMAGE"));
        Assert.Equal(24m, afterPartialBlock.Player.Hp);
        Assert.Equal(26m, afterPartialBlock.Enemies[0].Hp);
    }

    [Fact]
    public void ReflectDamageIsRawBlockableAndSkipsUnblockedOrUnpoweredDamage()
    {
        var reflect = EmptyStatuses
            .Add("REFLECT_BLOCKED_ATTACK_DAMAGE", new StatusState("REFLECT_BLOCKED_ATTACK_DAMAGE", 1, Duration: 1))
            .Add("STRENGTH", new StatusState("STRENGTH", 10));
        var blockable = Snapshot(30, 20, 5, [], energy: 0) with
        {
            Player = new PlayerState(30, 30, 5, 0, 0, reflect, CardsPerTurn: 0),
            Enemies = [new CreatureState(
                "enemy-0", "Enemy", 20, 20, 3,
                EmptyStatuses.Add("VULNERABLE", new StatusState("VULNERABLE", 1)),
                [new IntentState("Attack", 5, 1)], 5)]
        };
        var noBlock = Snapshot(30, 20, 5, [], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, reflect, CardsPerTurn: 0)
        };
        var unpowered = Snapshot(30, 20, 0, [], energy: 0) with
        {
            Player = new PlayerState(30, 30, 5, 0, 0, reflect, CardsPerTurn: 0),
            Enemies = [new CreatureState(
                "enemy-0", "Enemy", 20, 20, 0, EmptyStatuses,
                [new IntentState("Safe damage", Effects: [new EffectSpec(EffectKind.Damage, 5)])], 0)]
        };
        var simulator = new DeterministicSimulator();

        var afterBlockable = simulator.ProjectToNextPlayerTurn(MutableCombatState.FromSnapshot(blockable));
        var afterNoBlock = simulator.ProjectToNextPlayerTurn(MutableCombatState.FromSnapshot(noBlock));
        var afterUnpowered = simulator.ProjectToNextPlayerTurn(MutableCombatState.FromSnapshot(unpowered));

        Assert.Equal(18m, afterBlockable.Enemies[0].Hp);
        Assert.Equal(0m, afterBlockable.Enemies[0].Block);
        Assert.Equal(25m, afterNoBlock.Player.Hp);
        Assert.Equal(20m, afterNoBlock.Enemies[0].Hp);
        Assert.Equal(30m, afterUnpowered.Player.Hp);
        Assert.Equal(20m, afterUnpowered.Enemies[0].Hp);
    }

    [Fact]
    public void TrackingAddsAndStacksFiftyPercentOnlyForPoweredAttacksAgainstWeakTargets()
    {
        var tracking = new CardState(
            "tracking", "TRACKING", "Tracking", 0, TargetKind.None,
            [new EffectSpec(EffectKind.ApplyStatus, 50, "BONUS_WEAK_TARGET_POWERED_ATTACK_DAMAGE_PERCENT", FutureValuePerTurn: 4m)],
            CardType: "Power");
        var secondTracking = tracking with { InstanceId = "tracking-2" };
        var attack = new CardState(
            "attack", "STRIKE", "Strike", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 5)], CardType: "Attack");
        var skill = new CardState(
            "skill", "DAMAGE_SKILL", "Damage Skill", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 5)], CardType: "Skill");
        var baseSnapshot = Snapshot(30, 30, 0, [tracking, secondTracking, attack, skill], energy: 0);
        var weakSnapshot = baseSnapshot with
        {
            Enemies =
            [
                baseSnapshot.Enemies[0] with
                {
                    Statuses = EmptyStatuses.Add("WEAK", new StatusState("WEAK", 1))
                }
            ]
        };
        var simulator = new DeterministicSimulator();

        var afterTracking = simulator.PlayCard(MutableCombatState.FromSnapshot(weakSnapshot), tracking, null, null);
        var afterAttack = simulator.PlayCard(afterTracking, attack, "enemy-0", null);
        var afterSkill = simulator.PlayCard(afterAttack, skill, "enemy-0", null);
        Assert.Equal(23m, afterAttack.Enemies[0].Hp);
        Assert.Equal(18m, afterSkill.Enemies[0].Hp);

        var stacked = simulator.PlayCard(MutableCombatState.FromSnapshot(weakSnapshot), tracking, null, null);
        stacked = simulator.PlayCard(stacked, secondTracking, null, null);
        stacked = simulator.PlayCard(stacked, attack, "enemy-0", null);
        Assert.Equal(20m, stacked.Enemies[0].Hp);

        var normalTarget = simulator.PlayCard(MutableCombatState.FromSnapshot(baseSnapshot), tracking, null, null);
        normalTarget = simulator.PlayCard(normalTarget, attack, "enemy-0", null);
        Assert.Equal(25m, normalTarget.Enemies[0].Hp);
    }

    [Fact]
    public void UnmovableDoublesCardBlockGainsByHistoryCountAndResetsNextTurn()
    {
        var statuses = EmptyStatuses.Add("UNMOVABLE", new StatusState("UNMOVABLE", 1));
        var first = BlockCard("first-block", 5, 0);
        var second = BlockCard("second-block", 5, 0);
        var snapshot = Snapshot(30, 30, 0, [first, second], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, statuses, CardsPerTurn: 0)
        };
        var simulator = new DeterministicSimulator();

        var afterFirst = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), first, null, null);
        Assert.Equal(10m, afterFirst.Player.Block);
        var afterSecond = simulator.PlayCard(afterFirst, second, null, null);
        Assert.Equal(15m, afterSecond.Player.Block);

        var nextTurn = simulator.ProjectToNextPlayerTurn(afterSecond);
        nextTurn.Hand.Add(BlockCard("next-block", 5, 0));
        var afterReset = simulator.PlayCard(nextTurn, nextTurn.Hand[^1], null, null);
        Assert.Equal(10m, afterReset.Player.Block);

        var capturedMidTurn = snapshot with
        {
            HistoryCounters = new CombatHistoryCounters(BlockGainedThisTurn: 1)
        };
        var afterCapturedBlock = simulator.PlayCard(MutableCombatState.FromSnapshot(capturedMidTurn), first, null, null);
        Assert.Equal(5m, afterCapturedBlock.Player.Block);
    }

    [Fact]
    public void ScrapeDiscardsOnlyDrawnNonZeroCostCards()
    {
        var scrape = new CardState(
            "scrape", "SCRAPE", "Scrape", 0, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 7),
                new EffectSpec(EffectKind.Draw, 4),
                new EffectSpec(EffectKind.DiscardDrawnNonZeroCost)
            ], CardType: "Attack");
        var keepInHand = BlockCard("keep-in-hand", 0, 2);
        var zero = BlockCard("zero", 0, 0);
        var nonZero = BlockCard("non-zero", 0, 1);
        var xCost = BlockCard("x-cost", 0, 0) with { CostsX = true };
        var secondZero = BlockCard("second-zero", 0, 0);
        var snapshot = Snapshot(30, 30, 0, [scrape, keepInHand], [zero, nonZero, xCost, secondZero], energy: 0);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), scrape, "enemy-0", null);

        Assert.Equal(23m, result.Enemies[0].Hp);
        Assert.Contains(result.Hand, card => card.InstanceId == "keep-in-hand");
        Assert.Contains(result.Hand, card => card.InstanceId == "zero");
        Assert.Contains(result.Hand, card => card.InstanceId == "second-zero");
        Assert.DoesNotContain(result.Hand, card => card.InstanceId is "non-zero" or "x-cost");
        Assert.Contains(result.DiscardPile, card => card.InstanceId == "non-zero");
        Assert.Contains(result.DiscardPile, card => card.InstanceId == "x-cost");
    }

    [Fact]
    public void SculptingStrikeEnumeratesAndAppliesAnEtherealHandMutation()
    {
        var sculpt = new CardState(
            "sculpt",
            "SCULPTING_STRIKE",
            "Sculpting Strike",
            0,
            TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 9),
                new EffectSpec(EffectKind.ModifySelectedHandCard, 1, "ADD_ETHEREAL")
            ],
            CardType: "Attack");
        var ordinary = BlockCard("ordinary", 0, 0);
        var other = DamageCard("other", 1, 0);
        var snapshot = Snapshot(30, 30, 0, [sculpt, ordinary, other], energy: 0);
        var state = MutableCombatState.FromSnapshot(snapshot);

        var choices = CombatSearchSession.BuildDynamicChoices(state, sculpt);
        Assert.Equal(2, choices.Length);
        var chosen = choices.Single(choice => choice.CardInstanceId == "ordinary");
        var result = new DeterministicSimulator().PlayCard(state, sculpt, "enemy-0", chosen);

        Assert.True(result.Hand.Single(card => card.InstanceId == "ordinary").ExhaustAtTurnEnd);
        Assert.False(result.Hand.Single(card => card.InstanceId == "other").ExhaustAtTurnEnd);
        Assert.Equal(21m, result.Enemies[0].Hp);

        var projected = new DeterministicSimulator().ProjectToNextPlayerTurn(result);
        Assert.DoesNotContain(projected.Hand, card => card.InstanceId == "ordinary");
        Assert.Contains(projected.ExhaustPile, card => card.InstanceId == "ordinary");
    }

    [Fact]
    public void TransfigureAddsReplayAndCostButLeavesXCostUnchanged()
    {
        var transfigure = new CardState(
            "transfigure", "TRANSFIGURE", "Transfigure", 0, TargetKind.None,
            [new EffectSpec(EffectKind.ModifySelectedHandCard, 1, "ADD_REPLAY_AND_COST", XBonus: 1)],
            CardType: "Skill");
        var ordinary = DamageCard("ordinary", 1, 1);
        var xCost = DamageCard("x-cost", 1, 0) with { CostsX = true };
        var snapshot = Snapshot(30, 30, 0, [transfigure, ordinary, xCost], energy: 0);
        var state = MutableCombatState.FromSnapshot(snapshot);
        var choices = CombatSearchSession.BuildDynamicChoices(state, transfigure);

        Assert.Equal(2, choices.Length);
        var ordinaryResult = new DeterministicSimulator().PlayCard(
            state, transfigure, null, choices.Single(choice => choice.CardInstanceId == "ordinary"));
        var changed = ordinaryResult.Hand.Single(card => card.InstanceId == "ordinary");
        Assert.Equal(1, changed.ReplayCount);
        Assert.Equal(2, changed.EnergyCost);

        var xResult = new DeterministicSimulator().PlayCard(
            state, transfigure, null, choices.Single(choice => choice.CardInstanceId == "x-cost"));
        var unchanged = xResult.Hand.Single(card => card.InstanceId == "x-cost");
        Assert.Equal(1, unchanged.ReplayCount);
        Assert.Equal(0, unchanged.EnergyCost);
        Assert.True(unchanged.CostsX);
    }

    [Fact]
    public void TurnStartDexterityLossFromWraithFormIsAppliedOnNextPlayerTurn()
    {
        var wraith = new CardState(
            "wraith", "WRAITH_FORM", "Wraith Form", 0, TargetKind.Self,
            [
                new EffectSpec(EffectKind.ApplyStatus, 2, "INTANGIBLE", Duration: 2),
                new EffectSpec(EffectKind.ApplyStatus, 1, "TURN_START_DEXTERITY_LOSS")
            ],
            CardType: "Power");
        var snapshot = Snapshot(30, 30, 0, [wraith], energy: 0) with
        {
            Player = new PlayerState(
                30, 30, 0, 0, 0,
                EmptyStatuses.Add("DEXTERITY", new StatusState("DEXTERITY", 3)))
        };

        var afterPlay = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), wraith, null, null);
        var nextTurn = new DeterministicSimulator().ProjectToNextPlayerTurn(afterPlay);

        Assert.Equal(2, nextTurn.Player.Statuses["DEXTERITY"].Amount);
        Assert.Equal(1, nextTurn.Player.Statuses["INTANGIBLE"].Duration);
    }

    [Fact]
    public void PanicButtonBlocksOnlyCardSourcedBlockForItsRemainingTurns()
    {
        var panic = new CardState(
            "panic", "PANIC_BUTTON", "Panic Button", 0, TargetKind.Self,
            [
                new EffectSpec(EffectKind.Block, 30),
                new EffectSpec(
                    EffectKind.ApplyStatus, 1, "NO_BLOCK_FROM_CARDS", Duration: 2,
                    IsDebuff: true, FutureValuePerTurn: -6m)
            ]);
        var defend = BlockCard("defend", 5, 0);
        var afterimage = EmptyStatuses.Add(
            "TRIGGER_CARD_PLAYED_BLOCK",
            new StatusState("TRIGGER_CARD_PLAYED_BLOCK", 3, FutureValuePerTurn: 6m));
        var snapshot = Snapshot(30, 30, 0, [panic, defend], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, afterimage)
        };
        var simulator = new DeterministicSimulator();

        var afterPanic = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), panic, null, null);
        Assert.Equal(33m, afterPanic.Player.Block);
        Assert.Equal(2, afterPanic.Player.Statuses["NO_BLOCK_FROM_CARDS"].Duration);

        var afterDefend = simulator.PlayCard(afterPanic, defend, null, null);
        Assert.Equal(36m, afterDefend.Player.Block);

        var nextTurn = simulator.ProjectToNextPlayerTurn(afterDefend);
        Assert.Equal(1, nextTurn.Player.Statuses["NO_BLOCK_FROM_CARDS"].Duration);
        var nextDefend = BlockCard("next-defend", 5, 0);
        nextTurn.Hand.Add(nextDefend);
        var nextBlocked = simulator.PlayCard(nextTurn, nextDefend, null, null);
        Assert.Equal(3m, nextBlocked.Player.Block);

        var followingTurn = simulator.ProjectToNextPlayerTurn(nextBlocked);
        Assert.DoesNotContain("NO_BLOCK_FROM_CARDS", followingTurn.Player.Statuses.Keys);
        var finalDefend = BlockCard("final-defend", 5, 0);
        followingTurn.Hand.Add(finalDefend);
        var allowedAgain = simulator.PlayCard(followingTurn, finalDefend, null, null);
        Assert.Equal(8m, allowedAgain.Player.Block);
    }

    [Fact]
    public void RepeatedPanicButtonsAddTheirRemainingTurns()
    {
        static CardState Panic(string id) => new(
            id, "PANIC_BUTTON", "Panic Button", 0, TargetKind.Self,
            [
                new EffectSpec(EffectKind.Block, 30),
                new EffectSpec(
                    EffectKind.ApplyStatus, 1, "NO_BLOCK_FROM_CARDS", Duration: 2,
                    IsDebuff: true, FutureValuePerTurn: -6m)
            ]);

        var first = Panic("panic-1");
        var second = Panic("panic-2");
        var state = MutableCombatState.FromSnapshot(Snapshot(30, 30, 0, [first, second], energy: 0));
        var simulator = new DeterministicSimulator();

        var afterFirst = simulator.PlayCard(state, first, null, null);
        var afterSecond = simulator.PlayCard(afterFirst, second, null, null);

        Assert.Equal(30m, afterSecond.Player.Block);
        Assert.Equal(1, afterSecond.Player.Statuses["NO_BLOCK_FROM_CARDS"].Amount);
        Assert.Equal(4, afterSecond.Player.Statuses["NO_BLOCK_FROM_CARDS"].Duration);
        Assert.Equal(-6m, afterSecond.Player.Statuses["NO_BLOCK_FROM_CARDS"].FutureValuePerTurn);
    }

    [Fact]
    public void DrawToHandSizeUsesThePostPlayHandCount()
    {
        var expertise = new CardState(
            "expertise", "EXPERTISE", "Expertise", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.DrawToHandSize, 6, "RETAIN_DRAWN_THIS_TURN")], CardType: "Skill");
        var kept = BlockCard("kept", 1, 0);
        var drawPile = Enumerable.Range(1, 7).Select(index => BlockCard($"draw-{index}", 1, 0)).ToArray();
        var state = MutableCombatState.FromSnapshot(Snapshot(30, 30, 0, [expertise, kept], drawPile, energy: 0));

        var result = new DeterministicSimulator().PlayCard(state, expertise, null, null);

        Assert.Equal(6, result.Hand.Count);
        Assert.Equal(2, result.DrawPile.Count);
        Assert.Single(result.DiscardPile, card => card.InstanceId == "expertise");
        Assert.False(result.Hand.Single(card => card.InstanceId == "kept").RetainAtTurnEnd);
        Assert.All(result.Hand.Where(card => card.InstanceId.StartsWith("draw-", StringComparison.Ordinal)), card =>
        {
            Assert.True(card.RetainAtTurnEnd);
            Assert.True(card.TemporaryRetainAtTurnEnd);
        });

        var nextTurn = new DeterministicSimulator().ProjectToNextPlayerTurn(result);
        Assert.All(nextTurn.Hand.Where(card => card.InstanceId.StartsWith("draw-", StringComparison.Ordinal)), card =>
        {
            Assert.False(card.RetainAtTurnEnd);
            Assert.False(card.TemporaryRetainAtTurnEnd);
        });
    }

    [Fact]
    public void EscapePlanBlocksOnlyWhenItsDirectDrawIsASkill()
    {
        static CardState Escape() => new(
            "escape", "ESCAPE_PLAN", "Escape Plan", 0, TargetKind.Self,
            [
                new EffectSpec(EffectKind.Draw, 1),
                new EffectSpec(EffectKind.Block, 3, Condition: "LAST_DRAWN_CARD_SKILL")
            ], CardType: "Skill");

        var skill = BlockCard("skill", 1, 0) with { CardType = "Skill" };
        var attack = DamageCard("attack", 1, 0) with { CardType = "Attack" };
        var simulator = new DeterministicSimulator();
        var skillResult = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(30, 30, 0, [Escape()], [skill], energy: 0)),
            Escape(), null, null);
        var attackResult = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(30, 30, 0, [Escape()], [attack], energy: 0)),
            Escape(), null, null);

        Assert.Equal(3m, skillResult.Player.Block);
        Assert.Equal(0m, attackResult.Player.Block);
    }

    [Fact]
    public void DrawUntilNonAttackStopsAfterTheFirstNonAttack()
    {
        var pillage = new CardState(
            "pillage", "PILLAGE", "Pillage", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 6), new EffectSpec(EffectKind.DrawUntilNonAttack)],
            CardType: "Attack");
        var first = DamageCard("attack-1", 1, 0) with { CardType = "Attack" };
        var second = DamageCard("attack-2", 1, 0) with { CardType = "Attack" };
        var stop = BlockCard("skill", 1, 0) with { CardType = "Skill" };
        var untouched = BlockCard("untouched", 1, 0) with { CardType = "Skill" };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(30, 30, 0, [pillage], [first, second, stop, untouched], energy: 0)),
            pillage, "enemy-0", null);

        Assert.Equal(new[] { "attack-1", "attack-2", "skill" }, result.Hand.Select(card => card.InstanceId));
        Assert.Equal("untouched", Assert.Single(result.DrawPile).InstanceId);
        Assert.Equal(24m, result.Enemies[0].Hp);
    }

    [Fact]
    public void FillHandGenerationStopsAtTenCards()
    {
        var debris = new CardState(
            "generated:debris", "DEBRIS", "Debris", 1, TargetKind.None,
            [], CardDestination.Exhaust, CardType: "Status");
        var crash = new CardState(
            "crash", "CRASH_LANDING", "Crash Landing", 0, TargetKind.AllEnemies,
            [new EffectSpec(EffectKind.GenerateCards, StatusId: "FILL_HAND", GeneratedCard: debris)],
            CardType: "Attack");
        var kept = BlockCard("kept", 1, 0);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(30, 30, 0, [crash, kept], energy: 0)),
            crash, null, null);

        Assert.Equal(10, result.Hand.Count);
        Assert.Equal(9, result.Hand.Count(card => card.ModelId == "DEBRIS"));
        Assert.Equal(9, result.CardsGeneratedSinceSnapshot);
    }

    [Fact]
    public void SelectedRetainMutationKeepsOnlyTheChosenCard()
    {
        var snap = new CardState(
            "snap", "SNAP", "Snap", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.ModifySelectedHandCard, 1, "ADD_RETAIN")],
            CardType: "Attack");
        var chosen = BlockCard("chosen", 1, 0);
        var other = BlockCard("other", 1, 0);
        var state = MutableCombatState.FromSnapshot(Snapshot(30, 30, 0, [snap, chosen, other], energy: 0));
        var choices = CombatSearchSession.BuildDynamicChoices(state, snap);

        var result = new DeterministicSimulator().PlayCard(
            state, snap, "enemy-0", choices.Single(choice => choice.CardInstanceId == "chosen"));

        Assert.True(result.Hand.Single(card => card.InstanceId == "chosen").RetainAtTurnEnd);
        Assert.False(result.Hand.Single(card => card.InstanceId == "other").RetainAtTurnEnd);
    }

    [Fact]
    public void EscapePlanUnknownShuffleBranchesPreserveItsDrawCondition()
    {
        var escape = new CardState(
            "escape", "ESCAPE_PLAN", "Escape Plan", 0, TargetKind.Self,
            [
                new EffectSpec(EffectKind.Draw, 1),
                new EffectSpec(EffectKind.Block, 3, Condition: "LAST_DRAWN_CARD_SKILL")
            ], CardType: "Skill");
        var skill = BlockCard("skill", 1, 0) with { CardType = "Skill" };
        var attack = DamageCard("attack", 1, 0) with { CardType = "Attack" };
        var snapshot = CombatSnapshot.Create(
            "fixture",
            new PlayerState(30, 30, 0, 0, 0, EmptyStatuses, CardsPerTurn: 0),
            [new CreatureState("enemy-0", "Enemy", 30, 30, 0, EmptyStatuses, [], 0)],
            [escape], discardPile: [skill, attack], rngState: 0);

        var outcomes = new DeterministicSimulator().PlayCardOutcomes(
            MutableCombatState.FromSnapshot(snapshot), escape, null, null);

        Assert.Equal(2, outcomes.Length);
        Assert.Contains(outcomes, outcome => outcome.State.Player.Block == 3m &&
                                             outcome.State.Hand.Single().InstanceId == "skill");
        Assert.Contains(outcomes, outcome => outcome.State.Player.Block == 0m &&
                                             outcome.State.Hand.Single().InstanceId == "attack");
        Assert.All(outcomes, outcome =>
            Assert.Single(outcome.State.DiscardPile, card => card.InstanceId == "escape"));
    }

    [Fact]
    public void FiendFireDealsOncePerCardExhaustedFromHand()
    {
        var fiendFire = new CardState(
            "fiend-fire", "FIEND_FIRE", "Fiend Fire", 0, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.ExhaustHand),
                new EffectSpec(EffectKind.Damage, 7, RepeatByExhaustedCount: true)
            ],
            Destination: CardDestination.Exhaust,
            CardType: "Attack");
        var first = DamageCard("first", 1, 0);
        var second = BlockCard("second", 1, 0);
        var state = MutableCombatState.FromSnapshot(
            Snapshot(30, 100, 0, [fiendFire, first, second], energy: 0));

        var result = new DeterministicSimulator().PlayCard(state, fiendFire, "enemy-0", null);

        Assert.Equal(86m, result.Enemies[0].Hp);
        Assert.Equal(3, result.CardsExhaustedSinceSnapshot);
        Assert.Contains(result.ExhaustPile, card => card.InstanceId == "fiend-fire");
        Assert.Contains(result.ExhaustPile, card => card.InstanceId == "first");
        Assert.Contains(result.ExhaustPile, card => card.InstanceId == "second");
    }

    [Fact]
    public void JuggernautTriggersForEachPositiveBlockGainAndAdvancesCombatTargets()
    {
        var statuses = EmptyStatuses.Add(
            "TRIGGER_BLOCK_GAINED_RANDOM_DAMAGE",
            new StatusState(
                "TRIGGER_BLOCK_GAINED_RANDOM_DAMAGE",
                6,
                RandomSource: RngSnapshotSet.CombatTargets));
        var block = BlockCard("block", 5, 0);
        var snapshot = CombatSnapshot.Create(
            "juggernaut",
            new PlayerState(30, 30, 0, 0, 0, statuses),
            [
                new CreatureState("enemy-0", "Enemy 0", 30, 30, 0, EmptyStatuses, [], 0),
                new CreatureState("enemy-1", "Enemy 1", 30, 30, 0, EmptyStatuses, [], 0)
            ],
            [block],
            rngStreams: KnownTargetRng());
        var state = MutableCombatState.FromSnapshot(snapshot);
        var before = state.RngStreams.Get(RngSnapshotSet.CombatTargets);

        var result = new DeterministicSimulator().PlayCard(state, block, null, null);

        Assert.Equal(5m, result.Player.Block);
        Assert.Equal(6m, 60m - result.Enemies.Sum(enemy => enemy.Hp));
        Assert.NotEqual(before, result.RngStreams.Get(RngSnapshotSet.CombatTargets));
    }

    [Fact]
    public void SerpentFormAndStrangleUsePrePlaySnapshots()
    {
        var serpent = new CardState(
            "serpent", "SERPENT_FORM", "Serpent Form", 0, TargetKind.Self,
            [new EffectSpec(
                EffectKind.ApplyStatus,
                4,
                "TRIGGER_CARD_PLAYED_RANDOM_DAMAGE",
                TargetOverride: TargetKind.Self,
                RandomSource: RngSnapshotSet.CombatTargets)],
            CardDestination.Remove,
            CardType: "Power");
        var strangle = new CardState(
            "strangle", "STRANGLE", "Strangle", 0, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 8),
                new EffectSpec(
                    EffectKind.ApplyStatus,
                    2,
                    "TRIGGER_CARD_PLAYED_HP_LOSS",
                    Duration: 1,
                    IsDebuff: true,
                    TargetOverride: TargetKind.Enemy)
            ],
            CardType: "Attack");
        var followUp = BlockCard("follow-up", 1, 0);
        var state = MutableCombatState.FromSnapshot(
            Snapshot(30, 40, 0, [serpent, strangle, followUp], energy: 0));
        var simulator = new DeterministicSimulator();

        var afterSerpent = simulator.PlayCard(state, serpent, null, null);
        Assert.Equal(40m, afterSerpent.Enemies[0].Hp);

        var afterStrangle = simulator.PlayCard(afterSerpent, strangle, "enemy-0", null);
        Assert.Equal(28m, afterStrangle.Enemies[0].Hp); // 8 from Strangle, then 4 from the pre-existing Serpent Form.

        var afterFollowUp = simulator.PlayCard(afterStrangle, followUp, null, null);
        Assert.Equal(22m, afterFollowUp.Enemies[0].Hp); // 4 from Serpent Form and 2 HP loss from Strangle.

        var nextTurn = simulator.ProjectToNextPlayerTurn(afterFollowUp);
        Assert.DoesNotContain("TRIGGER_CARD_PLAYED_HP_LOSS", nextTurn.Enemies[0].Statuses.Keys);
    }

    [Fact]
    public void EnvenomRequiresUnblockedDamageAndAppliesPerHit()
    {
        var statuses = EmptyStatuses.Add(
            "TRIGGER_ATTACK_UNBLOCKED_POISON",
            new StatusState("TRIGGER_ATTACK_UNBLOCKED_POISON", 2));
        var attack = new CardState(
            "attack", "MULTI", "Multi", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 4, Repeat: 2)],
            CardType: "Attack");
        var snapshot = CombatSnapshot.Create(
            "envenom",
            new PlayerState(30, 30, 0, 0, 0, statuses),
            [new CreatureState("enemy-0", "Enemy", 30, 30, 5, EmptyStatuses, [], 0)],
            [attack],
            rngStreams: KnownTargetRng());

        var simulator = new DeterministicSimulator();
        var result = simulator.PlayCard(
            MutableCombatState.FromSnapshot(snapshot), attack, "enemy-0", null);

        Assert.Equal(27m, result.Enemies[0].Hp);
        Assert.Equal(2, result.Enemies[0].Statuses["POISON"].Amount);
    }

    [Fact]
    public void EnvenomAndMonarchsGazeRespectArtifactAtTheirDifferentTriggerBoundaries()
    {
        var statuses = EmptyStatuses
            .Add("TRIGGER_ATTACK_UNBLOCKED_POISON", new StatusState("TRIGGER_ATTACK_UNBLOCKED_POISON", 2))
            .Add("TRIGGER_ATTACK_TEMP_STRENGTH_LOSS", new StatusState("TRIGGER_ATTACK_TEMP_STRENGTH_LOSS", 1));
        var attack = new CardState(
            "attack", "MULTI", "Multi", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 3, Repeat: 2)],
            CardType: "Attack");
        var enemyStatuses = EmptyStatuses.Add("ARTIFACT", new StatusState("ARTIFACT", 1));
        var snapshot = CombatSnapshot.Create(
            "artifact-triggers",
            new PlayerState(30, 30, 0, 0, 0, statuses),
            [new CreatureState("enemy-0", "Enemy", 30, 30, 100, enemyStatuses, [], 0)],
            [attack],
            rngStreams: KnownTargetRng());

        var simulator = new DeterministicSimulator();
        var result = simulator.PlayCard(
            MutableCombatState.FromSnapshot(snapshot), attack, "enemy-0", null);

        Assert.Equal(30m, result.Enemies[0].Hp);
        Assert.Equal(94m, result.Enemies[0].Block);
        Assert.DoesNotContain("ARTIFACT", result.Enemies[0].Statuses.Keys);
        Assert.DoesNotContain("POISON", result.Enemies[0].Statuses.Keys);
        Assert.Equal(1, result.Enemies[0].Statuses["TEMP_STRENGTH_LOSS"].Amount);

        var nextTurn = simulator.ProjectToNextPlayerTurn(result);
        Assert.DoesNotContain("TEMP_STRENGTH_LOSS", nextTurn.Enemies[0].Statuses.Keys);
    }

    [Fact]
    public void StatusRandomSourceParticipatesInExactStateIdentity()
    {
        var first = MutableCombatState.FromSnapshot(Snapshot(30, 30, 0, [], energy: 0));
        first.Player = first.Player with
        {
            Statuses = EmptyStatuses.Add(
                "TRIGGER_CARD_PLAYED_RANDOM_DAMAGE",
                new StatusState("TRIGGER_CARD_PLAYED_RANDOM_DAMAGE", 4, RandomSource: RngSnapshotSet.CombatTargets))
        };
        var second = first.Clone();
        second.Player = second.Player with
        {
            Statuses = second.Player.Statuses.SetItem(
                "TRIGGER_CARD_PLAYED_RANDOM_DAMAGE",
                new StatusState("TRIGGER_CARD_PLAYED_RANDOM_DAMAGE", 4, RandomSource: "OTHER"))
        };

        Assert.NotEqual(first.ExactKey(), second.ExactKey());
    }

    [Fact]
    public void ContinueResumesTheExistingFrontier()
    {
        var cards = Enumerable.Range(0, 9)
            .Select(index => DamageCard($"s{index}", 2 + index % 3, cost: index % 2))
            .ToArray();
        var snapshot = Snapshot(50, 80, 12, cards, energy: 5);
        var session = new CombatSearchSession(snapshot, Options(maximumActions: 12));

        var first = session.Continue(TimeSpan.FromMilliseconds(1));
        var resumed = session.Continue(TimeSpan.FromMilliseconds(500));

        Assert.True(resumed.Progress.ExpandedNodes >= first.Progress.ExpandedNodes);
        Assert.Equal(snapshot.Fingerprint, resumed.Progress.SnapshotFingerprint);
        Assert.NotEmpty(resumed.Balanced);
    }

    [Fact]
    public void ReportsExpandedNodeLimitSeparatelyFromCompletedSearch()
    {
        var card = DamageCard("strike", 6, cost: 0);
        var options = Options(maximumActions: 8) with { MaximumExpandedNodes = 1 };
        var session = new CombatSearchSession(Snapshot(30, 30, 0, [card], energy: 0), options);

        var result = session.Continue(TimeSpan.FromMilliseconds(500));

        Assert.Equal(1, result.Progress.ExpandedNodes);
        Assert.Equal(SearchStopReason.ExpandedNodeLimit, result.Progress.StopReason);
        Assert.False(result.Progress.IsComplete);
        Assert.True(result.Progress.FrontierNodes > 0);
    }

    [Fact]
    public void ReportsFrontierExhaustionWhenCurrentTurnSearchIsComplete()
    {
        var card = DamageCard("strike", 6, cost: 0);
        var result = Complete(Snapshot(30, 30, 0, [card], energy: 0));

        Assert.True(result.Progress.IsComplete);
        Assert.Equal(SearchStopReason.FrontierExhausted, result.Progress.StopReason);
    }

    [Fact]
    public void OptionalTerminalCapturePreservesProjectedNextTurnState()
    {
        var card = DamageCard("strike", 6, cost: 0);
        var snapshot = Snapshot(30, 20, 0, [card], energy: 0);
        var session = new CombatSearchSession(
            snapshot,
            MutableCombatState.FromSnapshot(snapshot),
            Options(maximumActions: 4));
        SearchResults result;
        do
        {
            result = session.Continue(TimeSpan.FromMilliseconds(500));
        } while (!result.Progress.IsComplete && result.Progress.ExpandedNodes < 50_000);

        var candidate = Assert.Single(session.GetTerminalCandidates().Where(item =>
            item.Line.Steps.Any(step => step.SourceInstanceId == "strike")));

        Assert.Equal(14m, candidate.State.Enemies[0].Hp);
        Assert.Equal(candidate.Line.Terminal!.StateKey, candidate.State.ExactKey());
    }

    [Fact]
    public void NormalTurnSearchDoesNotEnableTerminalStateCapture()
    {
        var snapshot = Snapshot(30, 20, 0, [DamageCard("strike", 6, cost: 0)], energy: 0);
        var session = new CombatSearchSession(snapshot, Options(maximumActions: 2));

        Assert.Throws<InvalidOperationException>(() => session.GetTerminalCandidates());
    }

    [Fact]
    public void DetectsAProvenResourceNeutralDamageLoop()
    {
        var loopEffects = ImmutableArray.Create(
            new EffectSpec(EffectKind.Damage, 1),
            new EffectSpec(EffectKind.Draw, 1));
        var a = new CardState("a", "A", "A", 0, TargetKind.Enemy, loopEffects);
        var b = new CardState("b", "B", "B", 0, TargetKind.Enemy, loopEffects);
        var snapshot = Snapshot(50, 100, 0, [a], discardPile: [b], energy: 0);

        var results = Complete(snapshot, maximumActions: 12);

        Assert.NotEmpty(results.Infinite);
        Assert.True(results.Infinite[0].IsInfinite);
        Assert.Equal(new[] { "a", "b" }, results.Infinite[0].SafeInfiniteCycle.Select(step => step.SourceInstanceId));
    }

    [Fact]
    public void ToricToughnessProvidesImmediateAndRecurringTurnStartBlock()
    {
        var toric = new CardState(
            "toric", "TORIC_TOUGHNESS", "Toric Toughness", 2, TargetKind.Self,
            [
                new EffectSpec(EffectKind.Block, 5),
                new EffectSpec(EffectKind.ApplyStatus, 5, "TORIC_TOUGHNESS", Duration: 2, TargetOverride: TargetKind.Self)
            ]);
        var snapshot = Snapshot(40, 50, 0, [toric], energy: 2);
        var sim = new DeterministicSimulator();
        var initial = MutableCombatState.FromSnapshot(snapshot);
        var afterPlay = sim.PlayCard(initial, toric, null, null);
        Assert.Equal(5m, afterPlay.Player.Block);
        Assert.True(afterPlay.Player.Statuses.ContainsKey("TORIC_TOUGHNESS"));

        var nextTurn = sim.ProjectToNextPlayerTurn(afterPlay);
        Assert.Equal(5m, nextTurn.Player.Block);
        Assert.Equal(1, nextTurn.Player.Statuses["TORIC_TOUGHNESS"].Duration);

        var thirdTurn = sim.ProjectToNextPlayerTurn(nextTurn);
        Assert.Equal(5m, thirdTurn.Player.Block);
        Assert.False(thirdTurn.Player.Statuses.ContainsKey("TORIC_TOUGHNESS"));
    }

    [Fact]
    public void TheBombDetonatesAfterThreeTurnsDealingAllEnemyDamage()
    {
        var theBomb = new CardState(
            "bomb", "THE_BOMB", "The Bomb", 2, TargetKind.Self,
            [
                new EffectSpec(EffectKind.ApplyStatus, 40, "THE_BOMB", Duration: 3, TargetOverride: TargetKind.Self)
            ]);
        var snapshot = Snapshot(40, 50, 0, [theBomb], energy: 2);
        var sim = new DeterministicSimulator();
        var state = MutableCombatState.FromSnapshot(snapshot);
        var afterPlay = sim.PlayCard(state, theBomb, null, null);
        Assert.True(afterPlay.Player.Statuses.ContainsKey("THE_BOMB"));
        Assert.Equal(50m, afterPlay.Enemies[0].Hp);

        var turn2 = sim.ProjectToNextPlayerTurn(afterPlay);
        Assert.Equal(50m, turn2.Enemies[0].Hp);
        Assert.Equal(2, turn2.Player.Statuses["THE_BOMB"].Duration);

        var turn3 = sim.ProjectToNextPlayerTurn(turn2);
        Assert.Equal(50m, turn3.Enemies[0].Hp);
        Assert.Equal(1, turn3.Player.Statuses["THE_BOMB"].Duration);

        var turn4 = sim.ProjectToNextPlayerTurn(turn3);
        Assert.Equal(10m, turn4.Enemies[0].Hp);
        Assert.False(turn4.Player.Statuses.ContainsKey("THE_BOMB"));
    }

    [Fact]
    public void CuriousPowerReducesPowerCardEnergyCost()
    {
        var powerCard = new CardState(
            "power", "POWER_CARD", "Power Card", 2, TargetKind.Self, [],
            CardType: "Power");
        var attackCard = new CardState(
            "attack", "ATTACK_CARD", "Attack Card", 2, TargetKind.Enemy, [],
            CardType: "Attack");
        var snapshot = Snapshot(40, 50, 0, [powerCard, attackCard], energy: 3);
        var state = MutableCombatState.FromSnapshot(snapshot);
        state.Player = state.Player with
        {
            Statuses = state.Player.Statuses.Add("POWERS_COST_DELTA", new StatusState("POWERS_COST_DELTA", 1))
        };

        Assert.Equal(1, DeterministicSimulator.EnergyCostToPlay(state, powerCard));
        Assert.Equal(2, DeterministicSimulator.EnergyCostToPlay(state, attackCard));
    }

    [Fact]
    public void DisintegrationDamagesPlayerAtTurnEnd()
    {
        var disintegration = new CardState(
            "disintegration", "DISINTEGRATION", "Disintegration", 0, TargetKind.None, [],
            IsPlayable: false,
            TurnEndInHandEffects: [new EffectSpec(EffectKind.Damage, 6, TargetOverride: TargetKind.Self)]);
        var snapshot = Snapshot(40, 50, 0, [disintegration], energy: 3);
        var sim = new DeterministicSimulator();
        var state = MutableCombatState.FromSnapshot(snapshot);
        var nextTurn = sim.ProjectToNextPlayerTurn(state);

        Assert.Equal(34m, nextTurn.Player.Hp);
    }

    [Fact]
    public void TheHuntDealsDamageAndExhausts()
    {
        var card = new CardState(
            "hunt", "THE_HUNT", "The Hunt", 1, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 10),
                new EffectSpec(EffectKind.ExhaustCards, 1, TargetOverride: TargetKind.Self)
            ]);
        var snapshot = Snapshot(50, 30, 0, [card], energy: 3);
        var sim = new DeterministicSimulator();
        var state = MutableCombatState.FromSnapshot(snapshot);

        var afterPlay = sim.PlayCard(state, card, "enemy-0", null);

        Assert.Equal(20m, afterPlay.Enemies[0].Hp);
        Assert.DoesNotContain(afterPlay.Hand, c => c.InstanceId == "hunt");
    }

    [Fact]
    public void CrescentSpearDealsBonusDamagePerStarCostCard()
    {
        var card = new CardState(
            "spear", "CRESCENT_SPEAR", "Crescent Spear", 1, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 8)],
            CombatDamageBonus: 6); // 2 bonus * 3 star cost cards evaluated at snapshot
        var snapshot = Snapshot(50, 30, 0, [card], energy: 3);
        var sim = new DeterministicSimulator();
        var state = MutableCombatState.FromSnapshot(snapshot);

        var afterPlay = sim.PlayCard(state, card, "enemy-0", null);

        Assert.Equal(16m, afterPlay.Enemies[0].Hp); // 30 - (8 + 6) = 16
    }

    [Fact]
    public void ArmamentsGainsBlockAndUpgradesHandCard()
    {
        var strike = new CardState("strike", "STRIKE", "Strike", 1, TargetKind.Enemy, [new EffectSpec(EffectKind.Damage, 6)]);
        var armaments = new CardState("arm", "ARMAMENTS", "Armaments", 1, TargetKind.Self,
            [
                new EffectSpec(EffectKind.Block, 5),
                new EffectSpec(EffectKind.UpgradeCards, 1, "HAND_ONE")
            ]);
        var snapshot = Snapshot(50, 30, 0, [armaments, strike], energy: 3);
        var sim = new DeterministicSimulator();
        var state = MutableCombatState.FromSnapshot(snapshot);

        var afterPlay = sim.PlayCard(state, armaments, null, null);

        Assert.Equal(5m, afterPlay.Player.Block);
        var remainingStrike = Assert.Single(afterPlay.Hand);
        Assert.True(remainingStrike.IsUpgraded);
    }

    [Fact]
    public void DebilitateDoublesVulnerableMultiplierOnTarget()
    {
        var attack = new CardState("atk", "STRIKE", "Strike", 1, TargetKind.Enemy, [new EffectSpec(EffectKind.Damage, 10)]);
        var snapshot = Snapshot(50, 30, 0, [attack], energy: 3);
        var sim = new DeterministicSimulator();
        var state = MutableCombatState.FromSnapshot(snapshot);

        // Apply VULNERABLE (normally 1.5x => floor(10*1.5) = 15) and DEBILITATE (doubles vulnerable => 2.0x => 20)
        state.Enemies[0] = state.Enemies[0] with
        {
            Statuses = state.Enemies[0].Statuses
                .SetItem("VULNERABLE", new StatusState("VULNERABLE", 2, 2, IsDebuff: true))
                .SetItem("DEBILITATE", new StatusState("DEBILITATE", 2, 2, IsDebuff: true))
        };

        var afterPlay = sim.PlayCard(state, attack, "enemy-0", null);

        // 30 - (10 * 2.0) = 10
        Assert.Equal(10m, afterPlay.Enemies[0].Hp);
    }

    [Fact]
    public void ConquerorDoublesPoweredAttackDamage()
    {
        var attack = new CardState("atk", "STRIKE", "Strike", 1, TargetKind.Enemy, [new EffectSpec(EffectKind.Damage, 10)], CardType: "Attack");
        var snapshot = Snapshot(50, 30, 0, [attack], energy: 3);
        var sim = new DeterministicSimulator();
        var state = MutableCombatState.FromSnapshot(snapshot);

        state.Player = state.Player with
        {
            Statuses = state.Player.Statuses.SetItem("KINGS_BLADE_DOUBLE_DAMAGE", new StatusState("KINGS_BLADE_DOUBLE_DAMAGE", 2, 1))
        };

        var afterPlay = sim.PlayCard(state, attack, "enemy-0", null);

        // 30 - (10 * 2) = 10
        Assert.Equal(10m, afterPlay.Enemies[0].Hp);
    }

    [Fact]
    public void OmnisliceDealsDamageToTargetAndAllOtherEnemies()
    {
        var omni = new CardState("omni", "OMNISLICE", "Omnislice", 0, TargetKind.Enemy,
        [
            new EffectSpec(EffectKind.Damage, 8),
            new EffectSpec(EffectKind.Damage, 0, StatusId: "ALL_OTHER_ENEMIES_EQUAL_DAMAGE")
        ], CardType: "Attack");

        var snapshot = CombatSnapshot.Create(
            "fixture",
            new PlayerState(50, 50, 0, 3, 3, EmptyStatuses),
            [
                new CreatureState("enemy-0", "Louse", 20, 20, 0, EmptyStatuses, [], 0),
                new CreatureState("enemy-1", "Louse", 20, 20, 0, EmptyStatuses, [], 0)
            ],
            [omni]);

        var sim = new DeterministicSimulator();
        var state = MutableCombatState.FromSnapshot(snapshot);
        var afterPlay = sim.PlayCard(state, omni, "enemy-0", null);

        // Primary target: 20 - 8 = 12
        Assert.Equal(12m, afterPlay.Enemies[0].Hp);
        // Other target: 20 - 8 = 12
        Assert.Equal(12m, afterPlay.Enemies[1].Hp);
    }

    [Fact]
    public void SummonForthMovesKingsBladeFromDiscardToHand()
    {
        var kb = new CardState("kb-1", "KINGS_BLADE", "君王之剑", 1, TargetKind.Enemy, [new EffectSpec(EffectKind.Damage, 10)], CardType: "Attack");
        var summon = new CardState("sum-1", "SUMMON_FORTH", "Summon Forth", 1, TargetKind.Self,
        [
            new EffectSpec(EffectKind.MoveKingsBladeToHand),
            new EffectSpec(EffectKind.ApplyStatus, 8, "FORGE")
        ], CardType: "Skill");

        var snapshot = Snapshot(50, 20, 0, [summon], discardPile: [kb]);

        var sim = new DeterministicSimulator();
        var state = MutableCombatState.FromSnapshot(snapshot);
        var afterPlay = sim.PlayCard(state, summon, null, null);
        Assert.Contains(afterPlay.Hand, c => c.InstanceId == "kb-1");
        Assert.DoesNotContain(afterPlay.DiscardPile, c => c.InstanceId == "kb-1");
    }

    [Fact]
    public void CompactTransformsStatusCardsInHandToFuel()
    {
        var burn = new CardState("burn-1", "BURN", "灼伤", 0, TargetKind.None, [], CardType: "Status");
        var compact = new CardState("compact-1", "COMPACT", "Compact", 1, TargetKind.Self,
        [
            new EffectSpec(EffectKind.Block, 6),
            new EffectSpec(EffectKind.TransformCards, StatusId: "HAND_STATUS_TO_FUEL")
        ], CardType: "Skill");

        var snapshot = Snapshot(50, 20, 0, [compact, burn]);
        var sim = new DeterministicSimulator();
        var state = MutableCombatState.FromSnapshot(snapshot);
        var afterPlay = sim.PlayCard(state, compact, null, null);

        Assert.Equal(6m, afterPlay.Player.Block);
        Assert.DoesNotContain(afterPlay.Hand, c => c.ModelId == "BURN");
        Assert.Contains(afterPlay.Hand, c => c.ModelId == "FUEL");
    }

    [Fact]
    public void DrainPowerUpgradesCardsInDiscardPile()
    {
        var strike = new CardState("stk-1", "STRIKE", "Strike", 1, TargetKind.Enemy, [new EffectSpec(EffectKind.Damage, 6)], CardType: "Attack", IsUpgraded: false);
        var drain = new CardState("dp-1", "DRAIN_POWER", "Drain Power", 1, TargetKind.Enemy,
        [
            new EffectSpec(EffectKind.Damage, 10),
            new EffectSpec(EffectKind.UpgradeCards, 2, "DISCARD_RANDOM")
        ], CardType: "Attack");

        var snapshot = Snapshot(50, 30, 0, [drain], discardPile: [strike]);
        var sim = new DeterministicSimulator();
        var state = MutableCombatState.FromSnapshot(snapshot);
        var afterPlay = sim.PlayCard(state, drain, "enemy-0", null);

        // 30 - 10 = 20
        Assert.Equal(20m, afterPlay.Enemies[0].Hp);
        var upgradedStrike = Assert.Single(afterPlay.DiscardPile, c => c.InstanceId == "stk-1");
        Assert.True(upgradedStrike.IsUpgraded);
    }

    private static SearchResults Complete(CombatSnapshot snapshot, int maximumActions = 16)
    {
        var session = new CombatSearchSession(snapshot, Options(maximumActions));
        SearchResults result;
        do
        {
            result = session.Continue(TimeSpan.FromMilliseconds(500));
        } while (!result.Progress.IsComplete && result.Progress.ExpandedNodes < 500_000);
        return result;
    }

    private static SearchOptions Options(int maximumActions) => new(
        TimeSpan.FromMilliseconds(500),
        5,
        new ScoreWeights(),
        MaximumActions: maximumActions);

    private static CombatSnapshot Snapshot(
        decimal hp,
        decimal enemyHp,
        decimal enemyDamage,
        IEnumerable<CardState> hand,
        IEnumerable<CardState>? drawPile = null,
        IEnumerable<CardState>? discardPile = null,
        int energy = 3) => CombatSnapshot.Create(
        "fixture",
        new PlayerState(hp, hp, 0, energy, energy, EmptyStatuses),
        [new CreatureState(
            "enemy-0",
            "Enemy",
            enemyHp,
            enemyHp,
            0,
            EmptyStatuses,
            [new IntentState("Attack", enemyDamage, enemyDamage > 0 ? 1 : 0)],
            enemyDamage)],
        hand,
        drawPile,
        discardPile,
        rngState: 42,
        rngStreams: KnownTargetRng());

    private static CardState DamageCard(string id, decimal damage, int cost = 1) => new(
        id,
        "STRIKE",
        "Strike",
        cost,
        TargetKind.Enemy,
        [new EffectSpec(EffectKind.Damage, damage)]);

    private static CardState BlockCard(string id, decimal block, int cost = 1) => new(
        id,
        "DEFEND",
        "Defend",
        cost,
        TargetKind.Self,
        [new EffectSpec(EffectKind.Block, block)]);

    private static ImmutableDictionary<string, StatusState> EmptyStatuses { get; } =
        ImmutableDictionary<string, StatusState>.Empty;

    private static RngSnapshotSet KnownTargetRng()
    {
        var target = new RngStreamSnapshot(RngSnapshotSet.CombatTargets, 1, 2, 3, 4);
        return new RngSnapshotSet(
            ImmutableDictionary<string, RngStreamSnapshot>.Empty.Add(target.Name, target));
    }

    [Fact]
    public void TurnStartAllEnemyPoisonAppliesToEachLivingEnemy()
    {
        var statuses = EmptyStatuses.Add(
            "TURN_START_ALL_ENEMY_POISON",
            new StatusState("TURN_START_ALL_ENEMY_POISON", 2, FutureValuePerTurn: 4m));
        var snapshot = Snapshot(30, 40, 0, [], energy: 0) with
        {
            Player = new PlayerState(30, 30, 0, 0, 0, statuses),
            Enemies =
            [
                new CreatureState("enemy-a", "A", 40, 40, 0, EmptyStatuses, [], 0),
                new CreatureState("enemy-b", "B", 40, 40, 0, EmptyStatuses, [], 0)
            ]
        };

        var result = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(snapshot));

        Assert.Equal(2, result.Enemies[0].Statuses["POISON"].Amount);
        Assert.Equal(2, result.Enemies[1].Statuses["POISON"].Amount);
        Assert.Equal(2, result.Player.Statuses["TURN_START_ALL_ENEMY_POISON"].Amount);
    }

    [Fact]
    public void DelayedReturnSelfToHandReturnsOnlyPlayedInstanceOnNextTurn()
    {
        var bolasCard1 = new CardState(
            "inst:bolas:1",
            "BOLAS",
            "流星锤",
            0,
            TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 3), new EffectSpec(EffectKind.DelayedReturnSelfToHand)],
            CardType: "Attack");
        var bolasCard2 = new CardState(
            "inst:bolas:2",
            "BOLAS",
            "流星锤",
            0,
            TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 3), new EffectSpec(EffectKind.DelayedReturnSelfToHand)],
            CardType: "Attack");

        var snapshot = Snapshot(50, 50, 0, [bolasCard1, bolasCard2], energy: 3);
        var sim = new DeterministicSimulator();
        var state = MutableCombatState.FromSnapshot(snapshot);

        // Play only card1
        var afterPlay = sim.PlayCard(state, bolasCard1, "enemy-1", null);
        Assert.Contains(afterPlay.DiscardPile, c => c.InstanceId == "inst:bolas:1");
        Assert.Contains(afterPlay.Hand, c => c.InstanceId == "inst:bolas:2");
        Assert.Contains("inst:bolas:1", afterPlay.PendingTurnStartReturnCardInstanceIds);

        // Project to next turn
        var nextTurn = sim.ProjectToNextPlayerTurn(afterPlay);
        Assert.Contains(nextTurn.Hand, c => c.InstanceId == "inst:bolas:1");
    }

    [Fact]
    public void ForgeCreatesAndGrowsSovereignBlade()
    {
        var forge = new CardState(
            "forge-1", "WROUGHT_IN_WAR", "铸造", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.Forge, 8)], CardType: "Skill");
        var snapshot = Snapshot(50, 100, 0, [forge], energy: 0);
        var simulator = new DeterministicSimulator();

        var first = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), forge, null, null);
        var blade = Assert.Single(first.Hand, card => card.ModelId == "SOVEREIGN_BLADE");
        Assert.Equal(8, blade.CombatDamageBonus);
        Assert.Equal(8, first.Player.Statuses["FORGE"].Amount);

        first.Hand.Add(forge with { InstanceId = "forge-2" });
        var second = simulator.PlayCard(first, first.Hand.Single(card => card.InstanceId == "forge-2"), null, null);
        Assert.Single(second.Hand, card => card.ModelId == "SOVEREIGN_BLADE");
        Assert.Equal(16, second.Hand.Single(card => card.ModelId == "SOVEREIGN_BLADE").CombatDamageBonus);
    }

    [Fact]
    public void NightmareQueuesSelectedInstanceForNextTurnCopies()
    {
        var target = DamageCard("target", 7, 0);
        var nightmare = new CardState(
            "nightmare", "NIGHTMARE", "夜魇", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.CopyChosenHandCard, 3, "NEXT_TURN")],
            CardType: "Skill",
            Choices: [new ChoiceSpec("target", "复制目标", [], CardInstanceId: "target")]);
        var snapshot = Snapshot(50, 100, 0, [nightmare, target], energy: 0);
        var simulator = new DeterministicSimulator();

        var afterPlay = simulator.PlayCard(
            MutableCombatState.FromSnapshot(snapshot),
            nightmare,
            null,
            nightmare.SafeChoices.Single());
        Assert.Equal(3, afterPlay.PendingTurnStartCopies.Count);
        Assert.DoesNotContain(afterPlay.Hand, card => card.ModelId == "NIGHTMARE");

        var nextTurn = simulator.ProjectToNextPlayerTurn(afterPlay);
        Assert.Equal(4, nextTurn.Hand.Count(card => card.ModelId == "STRIKE"));
        Assert.Equal(3, nextTurn.Hand.Count(card => card.InstanceId.StartsWith("copy:nightmare:", StringComparison.Ordinal)));
    }
}
