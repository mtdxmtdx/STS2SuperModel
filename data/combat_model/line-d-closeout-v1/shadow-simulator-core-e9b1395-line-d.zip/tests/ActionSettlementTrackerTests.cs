using STS2BestChoice.Core.Execution;
using Xunit;

namespace STS2BestChoice.Tests;

public sealed class ActionSettlementTrackerTests
{
    [Fact]
    public void InitialIdlePollCannotCompleteBeforeActionStartsOrStateChanges()
    {
        var tracker = new ActionSettlementTracker("before");

        Assert.False(tracker.Observe(isBusy: false, fingerprint: "before"));
        Assert.False(tracker.Observe(isBusy: true, fingerprint: "before"));
        Assert.True(tracker.Observe(isBusy: false, fingerprint: "after"));
    }

    [Fact]
    public void VeryFastActionCanCompleteFromObservedStateChangeWithoutBusyPoll()
    {
        var tracker = new ActionSettlementTracker("before");

        Assert.True(tracker.Observe(isBusy: false, fingerprint: "after"));
    }

    [Fact]
    public void BusyActionMustReturnToIdleBeforeCompletion()
    {
        var tracker = new ActionSettlementTracker("before");

        Assert.False(tracker.Observe(isBusy: true, fingerprint: "after"));
        Assert.True(tracker.Observe(isBusy: false, fingerprint: "after"));
    }
}
