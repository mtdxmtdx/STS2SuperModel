using System.Collections.Immutable;
using STS2BestChoice.Core.Model;
using STS2BestChoice.Core.Simulation;
using Xunit;

namespace STS2BestChoice.Tests;

public sealed class DrawDistributionTests
{
    [Fact]
    public void DuplicatePoolUsesMultivariateHypergeometricProbability()
    {
        var result = DrawDistribution.Enumerate(
            [Card("a0", "A"), Card("a1", "A"), Card("b0", "B")], 2, 10);

        Assert.True(result.Exact);
        Assert.Equal(2, result.Outcomes.Length);
        Assert.Equal(1m, result.ProbabilityMassCovered);
        var aa = Assert.Single(result.Outcomes, outcome => Models(outcome.Drawn) == "A,A");
        var ab = Assert.Single(result.Outcomes, outcome => Models(outcome.Drawn) == "A,B");
        Assert.InRange(Math.Abs(aa.Probability - 1m / 3m), 0m, 0.000000001m);
        Assert.InRange(Math.Abs(ab.Probability - 2m / 3m), 0m, 0.000000001m);
    }

    [Fact]
    public void TypicalTwentyCardPoolEnumeratesHandMultisetsRatherThanPoolPermutations()
    {
        var pool = Pool(6, 5, 4, 2, 2, 1);

        var result = DrawDistribution.Enumerate(pool, 5, 1000);

        Assert.True(result.Exact);
        Assert.InRange(result.Outcomes.Length, 1, 299);
        Assert.Equal(1m, result.ProbabilityMassCovered);
        Assert.Equal(result.Outcomes.Length, result.TotalOutcomeCount);
    }

    [Fact]
    public void TruncationKeepsHighestProbabilityOutcomesWithoutRenormalizing()
    {
        var result = DrawDistribution.Enumerate(Pool(6, 5, 4, 2, 2, 1), 5, 10);

        Assert.False(result.Exact);
        Assert.Equal(10, result.Outcomes.Length);
        Assert.True(result.ProbabilityMassCovered < 1m);
        Assert.Equal(result.Outcomes.Sum(static outcome => outcome.Probability), result.ProbabilityMassCovered);
        Assert.All(result.Outcomes.Zip(result.Outcomes.Skip(1)), pair =>
            Assert.True(pair.First.Probability >= pair.Second.Probability));
    }

    [Fact]
    public void BoundaryCasesAndRepeatedCallsAreCanonical()
    {
        var pool = new[] { Card("b1", "B"), Card("a1", "A"), Card("a0", "A") };
        var none = DrawDistribution.Enumerate(pool, 0, 10);
        var all = DrawDistribution.Enumerate(pool, 99, 10);
        var first = DrawDistribution.Enumerate(pool, 2, 10);
        var second = DrawDistribution.Enumerate(pool, 2, 10);

        Assert.Empty(Assert.Single(none.Outcomes).Drawn);
        Assert.Equal("A,A,B", Models(Assert.Single(none.Outcomes).Remaining));
        Assert.Equal("A,A,B", Models(Assert.Single(all.Outcomes).Drawn));
        Assert.Empty(Assert.Single(all.Outcomes).Remaining);
        Assert.Equal(
            first.Outcomes.Select(static outcome =>
                $"{Models(outcome.Drawn)}|{Models(outcome.Remaining)}|{outcome.Probability}"),
            second.Outcomes.Select(static outcome =>
                $"{Models(outcome.Drawn)}|{Models(outcome.Remaining)}|{outcome.Probability}"));
    }

    [Fact]
    public void OversizedPoolIsRejectedInsteadOfOverflowing()
    {
        var pool = Enumerable.Range(0, DrawDistribution.MaximumSupportedPoolSize + 1)
            .Select(index => Card($"a{index}", "A"))
            .ToArray();

        Assert.Throws<ArgumentOutOfRangeException>(() => DrawDistribution.Enumerate(pool, 5, 10));
    }

    [Fact]
    public void SmallPoolMatchesFullPermutationDrawMultisetDistribution()
    {
        var pool = new[]
        {
            Card("a0", "A"), Card("a1", "A"), Card("b0", "B"), Card("c0", "C")
        };
        var expected = Permutations(pool)
            .GroupBy(permutation => string.Join(',', permutation.Take(2)
                .Select(static card => card.ModelId)
                .Order(StringComparer.Ordinal)), StringComparer.Ordinal)
            .ToDictionary(
                static group => group.Key,
                static group => (decimal)group.Count() / 24m,
                StringComparer.Ordinal);

        var actual = DrawDistribution.Enumerate(pool, 2, 100).Outcomes
            .ToDictionary(
                outcome => Models(outcome.Drawn),
                static outcome => outcome.Probability,
                StringComparer.Ordinal);

        Assert.Equal(expected.Keys.Order(StringComparer.Ordinal), actual.Keys.Order(StringComparer.Ordinal));
        foreach (var pair in expected)
            Assert.InRange(Math.Abs(pair.Value - actual[pair.Key]), 0m, 0.000000001m);
    }

    private static CardState[] Pool(params int[] counts) => counts
        .SelectMany((count, group) => Enumerable.Range(0, count)
            .Select(index => Card($"{group}:{index}", $"T{group}")))
        .ToArray();

    private static CardState Card(string instanceId, string modelId) => new(
        instanceId,
        modelId,
        modelId,
        1,
        TargetKind.None,
        ImmutableArray<EffectSpec>.Empty);

    private static string Models(IEnumerable<CardState> cards) =>
        string.Join(',', cards.Select(static card => card.ModelId));

    private static IEnumerable<CardState[]> Permutations(CardState[] cards)
    {
        var remaining = cards.ToList();
        var prefix = new CardState[cards.Length];
        return Visit(0);

        IEnumerable<CardState[]> Visit(int depth)
        {
            if (depth == prefix.Length)
            {
                yield return prefix.ToArray();
                yield break;
            }
            for (var index = 0; index < remaining.Count; index++)
            {
                var card = remaining[index];
                remaining.RemoveAt(index);
                prefix[depth] = card;
                foreach (var result in Visit(depth + 1)) yield return result;
                remaining.Insert(index, card);
            }
        }
    }
}
