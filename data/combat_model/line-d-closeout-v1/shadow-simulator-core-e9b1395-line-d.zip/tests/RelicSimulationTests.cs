using System.Collections.Immutable;
using STS2BestChoice.Core.Model;
using STS2BestChoice.Core.Simulation;
using Xunit;

namespace STS2BestChoice.Tests;

public sealed class RelicSimulationTests
{
    private static PlayerState MakePlayer(int hp = 80, int maxHp = 80, int block = 0, int energy = 3, int maxEnergy = 3) =>
        new(hp, maxHp, block, energy, maxEnergy, ImmutableDictionary<string, StatusState>.Empty);

    private static CreatureState MakeEnemy(string id = "CULTIST:1", int hp = 50, int maxHp = 50, int block = 0) =>
        new(id, "Cultist", hp, maxHp, block, ImmutableDictionary<string, StatusState>.Empty, []);

    private static CardState MakeStrike(string instanceId = "strike_1") =>
        new(instanceId, "STRIKE_IRONCLAD", "打击", 1, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 6)], CardType: "Attack");

    private static CardState MakeDefend(string instanceId = "defend_1") =>
        new(instanceId, "DEFEND_IRONCLAD", "防御", 1, TargetKind.Self,
            [new EffectSpec(EffectKind.Block, 5)], CardType: "Skill");

    [Fact]
    public void RelicsOrderDoesNotAffectStateExactKey()
    {
        var relicA = new RelicState("ANCHOR", SupportStatus: RelicEffectSupportStatus.SimulatorSupported);
        var relicB = new RelicState("VAJRA", SupportStatus: RelicEffectSupportStatus.SimulatorSupported);

        var snap1 = CombatSnapshot.Create(
            "fp1", MakePlayer(), [MakeEnemy()], [MakeStrike()],
            relics: [relicA, relicB]);

        var snap2 = CombatSnapshot.Create(
            "fp2", MakePlayer(), [MakeEnemy()], [MakeStrike()],
            relics: [relicB, relicA]);

        var state1 = MutableCombatState.FromSnapshot(snap1);
        var state2 = MutableCombatState.FromSnapshot(snap2);

        Assert.Equal(state1.ExactKey(), state2.ExactKey());
        Assert.Equal(state1.CycleKeyWithoutProgress(), state2.CycleKeyWithoutProgress());
    }

    [Fact]
    public void RelicCounterAndDynamicVarsAffectStateExactKey()
    {
        var relic1 = new RelicState("NUNCHAKU", Counter: 3);
        var relic2 = new RelicState("NUNCHAKU", Counter: 4);

        var snap1 = CombatSnapshot.Create("fp1", MakePlayer(), [MakeEnemy()], [MakeStrike()], relics: [relic1]);
        var snap2 = CombatSnapshot.Create("fp2", MakePlayer(), [MakeEnemy()], [MakeStrike()], relics: [relic2]);

        var state1 = MutableCombatState.FromSnapshot(snap1);
        var state2 = MutableCombatState.FromSnapshot(snap2);

        Assert.NotEqual(state1.ExactKey(), state2.ExactKey());
    }

    [Fact]
    public void PureDisplayFieldsDoNotAffectStateExactKey()
    {
        var relic1 = new RelicState("ANCHOR", Counter: null, Name: "锚", Description: "获得10点格挡");
        var relic2 = new RelicState("ANCHOR", Counter: null, Name: "Anchor", Description: "Gain 10 Block");

        var snap1 = CombatSnapshot.Create("fp1", MakePlayer(), [MakeEnemy()], [MakeStrike()], relics: [relic1]);
        var snap2 = CombatSnapshot.Create("fp2", MakePlayer(), [MakeEnemy()], [MakeStrike()], relics: [relic2]);

        var state1 = MutableCombatState.FromSnapshot(snap1);
        var state2 = MutableCombatState.FromSnapshot(snap2);

        Assert.Equal(state1.ExactKey(), state2.ExactKey());
    }

    [Fact]
    public void NunchakuGrantsEnergyOnTenthAttack()
    {
        var sim = new DeterministicSimulator();
        var nunchaku = new RelicState("NUNCHAKU", Counter: 8, SupportStatus: RelicEffectSupportStatus.SimulatorSupported);
        var strike1 = MakeStrike("s1");
        var strike2 = MakeStrike("s2");

        var snap = CombatSnapshot.Create(
            "fp", MakePlayer(energy: 3), [MakeEnemy(hp: 100)],
            hand: [strike1, strike2],
            relics: [nunchaku]);

        var state = MutableCombatState.FromSnapshot(snap);

        // 9th attack: counter goes to 9, energy goes from 3 to 2
        state = sim.PlayCard(state, strike1, "CULTIST:1", null);
        var relicAfter1 = state.Relics.First(r => r.Id == "NUNCHAKU");
        Assert.Equal(9, relicAfter1.Counter);
        Assert.Equal(2, state.Player.Energy);

        // 10th attack: counter resets to 0, energy spends 1 but gains 1 (stays at 2)
        state = sim.PlayCard(state, strike2, "CULTIST:1", null);
        var relicAfter2 = state.Relics.First(r => r.Id == "NUNCHAKU");
        Assert.Equal(0, relicAfter2.Counter);
        Assert.Equal(2, state.Player.Energy);
    }

    [Fact]
    public void PenNibDoublesDamageOnTenthAttack()
    {
        var sim = new DeterministicSimulator();
        var penNib = new RelicState("PEN_NIB", Counter: 8, SupportStatus: RelicEffectSupportStatus.SimulatorSupported);
        var strike1 = MakeStrike("s1");
        var strike2 = MakeStrike("s2");

        var snap = CombatSnapshot.Create(
            "fp", MakePlayer(), [MakeEnemy(hp: 100)],
            hand: [strike1, strike2],
            relics: [penNib]);

        var state = MutableCombatState.FromSnapshot(snap);

        // 9th attack: counter goes to 9, deals normal 6 damage
        state = sim.PlayCard(state, strike1, "CULTIST:1", null);
        var relicAfter1 = state.Relics.First(r => r.Id == "PEN_NIB");
        Assert.Equal(9, relicAfter1.Counter);
        Assert.Equal(94, state.Enemies[0].Hp);

        // 10th attack: counter resets to 0, deals double 12 damage (94 - 12 = 82)
        state = sim.PlayCard(state, strike2, "CULTIST:1", null);
        var relicAfter2 = state.Relics.First(r => r.Id == "PEN_NIB");
        Assert.Equal(0, relicAfter2.Counter);
        Assert.Equal(82, state.Enemies[0].Hp);
    }

    [Fact]
    public void OrichalcumGrantsSixBlockWhenZeroBlockAtTurnEnd()
    {
        var sim = new DeterministicSimulator();
        var orichalcum = new RelicState("ORICHALCUM", SupportStatus: RelicEffectSupportStatus.SimulatorSupported);

        var snap = CombatSnapshot.Create(
            "fp", MakePlayer(block: 0), [MakeEnemy()],
            hand: [],
            relics: [orichalcum]);

        var state = MutableCombatState.FromSnapshot(snap);
        var nextTurn = sim.ProjectToNextPlayerTurn(state);

        // Orichalcum triggered before enemies act, granting 6 block
        Assert.True(nextTurn.Player.Hp > 0);
    }

    [Fact]
    public void ArtOfWarGrantsOneEnergyWhenNoAttacksPlayed()
    {
        var sim = new DeterministicSimulator();
        var artOfWar = new RelicState("ART_OF_WAR", SupportStatus: RelicEffectSupportStatus.SimulatorSupported);
        var defend = MakeDefend("d1");

        var snap = CombatSnapshot.Create(
            "fp", MakePlayer(energy: 3, maxEnergy: 3), [MakeEnemy()],
            hand: [defend],
            relics: [artOfWar]);

        var state = MutableCombatState.FromSnapshot(snap);
        state = sim.PlayCard(state, defend, null, null);

        var nextTurn = sim.ProjectToNextPlayerTurn(state);

        // Next turn energy should be MaxEnergy (3) + Art of War bonus (1) = 4
        Assert.Equal(4, nextTurn.Player.Energy);
    }

    [Fact]
    public void ArtOfWarDoesNotGrantEnergyWhenAttackWasPlayed()
    {
        var sim = new DeterministicSimulator();
        var artOfWar = new RelicState("ART_OF_WAR", SupportStatus: RelicEffectSupportStatus.SimulatorSupported);
        var strike = MakeStrike("s1");

        var snap = CombatSnapshot.Create(
            "fp", MakePlayer(energy: 3, maxEnergy: 3), [MakeEnemy()],
            hand: [strike],
            relics: [artOfWar]);

        var state = MutableCombatState.FromSnapshot(snap);
        state = sim.PlayCard(state, strike, "CULTIST:1", null);

        var nextTurn = sim.ProjectToNextPlayerTurn(state);

        // Next turn energy should remain standard MaxEnergy (3)
        Assert.Equal(3, nextTurn.Player.Energy);
    }

    [Fact]
    public void HappyFlowerGrantsEnergyEveryThreeTurns()
    {
        var sim = new DeterministicSimulator();
        var happyFlower = new RelicState("HAPPY_FLOWER", Counter: 1, SupportStatus: RelicEffectSupportStatus.SimulatorSupported);

        var snap = CombatSnapshot.Create(
            "fp", MakePlayer(maxEnergy: 3), [MakeEnemy()],
            hand: [],
            relics: [happyFlower]);

        var state = MutableCombatState.FromSnapshot(snap);

        // Turn 1 advance: counter becomes 2, energy is 3
        var turn2 = sim.ProjectToNextPlayerTurn(state);
        Assert.Equal(2, turn2.Relics.First(r => r.Id == "HAPPY_FLOWER").Counter);
        Assert.Equal(3, turn2.Player.Energy);

        // Turn 2 advance: counter becomes 0, energy is 3 + 1 = 4
        var turn3 = sim.ProjectToNextPlayerTurn(turn2);
        Assert.Equal(0, turn3.Relics.First(r => r.Id == "HAPPY_FLOWER").Counter);
        Assert.Equal(4, turn3.Player.Energy);
    }

    [Fact]
    public void IncenseBurnerGrantsIntangibleEverySixTurns()
    {
        var sim = new DeterministicSimulator();
        var incenseBurner = new RelicState("INCENSE_BURNER", Counter: 4, SupportStatus: RelicEffectSupportStatus.SimulatorSupported);

        var snap = CombatSnapshot.Create(
            "fp", MakePlayer(), [MakeEnemy()],
            hand: [],
            relics: [incenseBurner]);

        var state = MutableCombatState.FromSnapshot(snap);

        // Advance 1: counter goes to 5, no intangible
        var turn2 = sim.ProjectToNextPlayerTurn(state);
        Assert.Equal(5, turn2.Relics.First(r => r.Id == "INCENSE_BURNER").Counter);
        Assert.False(turn2.Player.Statuses.ContainsKey("INTANGIBLE"));

        // Advance 2: counter goes to 0, grants Intangible
        var turn3 = sim.ProjectToNextPlayerTurn(turn2);
        Assert.Equal(0, turn3.Relics.First(r => r.Id == "INCENSE_BURNER").Counter);
        Assert.True(turn3.Player.Statuses.TryGetValue("INTANGIBLE", out var intangible) && intangible.Amount > 0);
    }

    [Fact]
    public void SundialGrantsEnergyOnThirdShuffle()
    {
        var sim = new DeterministicSimulator();
        var sundial = new RelicState("SUNDIAL", Counter: 1, SupportStatus: RelicEffectSupportStatus.SimulatorSupported);

        var strike1 = MakeStrike("s1");
        var strike2 = MakeStrike("s2");
        var strike3 = MakeStrike("s3");

        // Set up empty draw pile, 3 cards in discard pile
        var snap = CombatSnapshot.Create(
            "fp", MakePlayer(energy: 1), [MakeEnemy()],
            hand: [],
            drawPile: [],
            discardPile: [strike1, strike2, strike3],
            relics: [sundial]);

        var state = MutableCombatState.FromSnapshot(snap);

        // Play card that forces draw (which forces shuffle)
        // First draw forces 1st shuffle -> counter goes from 1 to 2
        // We simulate card draw directly or via card effect
        var drawCard = new CardState("draw_card", "DRAW_CARD", "过牌", 0, TargetKind.None,
            [new EffectSpec(EffectKind.Draw, 1)], CardType: "Skill");
        state.Hand.Add(drawCard);

        state = sim.PlayCard(state, drawCard, null, null);
        var relicAfter1 = state.Relics.First(r => r.Id == "SUNDIAL");
        Assert.Equal(2, relicAfter1.Counter);
        Assert.Equal(1, state.Player.Energy);

        // Discard all and draw again -> 2nd shuffle (counter becomes 0, +2 energy)
        state.DiscardPile.AddRange(state.DrawPile);
        state.DiscardPile.AddRange(state.Hand);
        state.DrawPile.Clear();
        state.Hand.Clear();

        var drawCard2 = new CardState("draw_card2", "DRAW_CARD", "过牌", 0, TargetKind.None,
            [new EffectSpec(EffectKind.Draw, 1)], CardType: "Skill");
        state.Hand.Add(drawCard2);

        state = sim.PlayCard(state, drawCard2, null, null);
        var relicAfter2 = state.Relics.First(r => r.Id == "SUNDIAL");
        Assert.Equal(0, relicAfter2.Counter);
        Assert.Equal(3, state.Player.Energy); // 1 + 2 = 3 energy
    }

    [Fact]
    public void CentennialPuzzleDrawsThreeCardsOnFirstHpDamage()
    {
        var sim = new DeterministicSimulator();
        var puzzle = new RelicState("CENTENNIAL_PUZZLE", UsesThisCombat: 0, SupportStatus: RelicEffectSupportStatus.SimulatorSupported);

        var strike1 = MakeStrike("s1");
        var strike2 = MakeStrike("s2");
        var strike3 = MakeStrike("s3");

        var snap = CombatSnapshot.Create(
            "fp", MakePlayer(hp: 80, block: 0), [MakeEnemy()],
            hand: [],
            drawPile: [strike1, strike2, strike3],
            relics: [puzzle]);

        var state = MutableCombatState.FromSnapshot(snap);

        // Take damage from enemy intent during turn transition
        var enemy = MakeEnemy("CULTIST:1", hp: 50) with
        {
            Intents = [new IntentState("Attack", 10, 1)]
        };
        state.Enemies[0] = enemy;

        var nextTurn = sim.ProjectToNextPlayerTurn(state);

        // Player took unblocked damage, Centennial Puzzle triggered and drew 3 cards (plus standard turn draw)
        var pzAfter = nextTurn.Relics.First(r => r.Id == "CENTENNIAL_PUZZLE");
        Assert.Equal(1, pzAfter.UsesThisCombat);
        Assert.True(nextTurn.Hand.Count >= 3);
    }
}
