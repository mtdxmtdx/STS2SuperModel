using System.Text;
using STS2BestChoice.Core.Data;
using Xunit;

namespace STS2BestChoice.Tests;

public sealed class VersionedCardDatabaseTests
{
    [Fact]
    public void GeneratedDatabasesContainKnownVersionedCardCorrections()
    {
        var root = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", "..", ".."));
        CardDatabaseDocument Load(string version)
        {
            using var stream = File.OpenRead(Path.Combine(root, "data", "cards", "generated", version, "cards.json"));
            return VersionedCardDatabase.Read(stream);
        }

        var v0108 = new VersionedCardDatabase([Load("0.108.0")]);
        var v0109 = new VersionedCardDatabase([Load("0.109.0")]);
        var v0110 = new VersionedCardDatabase([Load("0.110.0")]);
        var v0111 = new VersionedCardDatabase([Load("0.111.0")]);

        Assert.True(v0108.TryResolve("MOMENTUM_STRIKE", true, "0.108.0", out var momentum));
        Assert.Equal("造成15点伤害。这张牌的耗能降为0能量。", momentum!.Description);
        Assert.True(v0109.TryResolve("PILLAR_OF_CREATION", false, "0.109.0", out var firstPillar));
        Assert.Equal("你每回合第一次生成一张卡牌时，获得5点格挡。", firstPillar!.Description);
        Assert.True(v0110.TryResolve("PILLAR_OF_CREATION", true, "0.110.0", out var currentPillar));
        Assert.Equal("每当你生成一张卡牌时，获得3点格挡。", currentPillar!.Description);
        Assert.True(v0111.TryResolve("ROCKET_PUNCH", false, "0.111.0", out var rocketPunch));
        Assert.Contains("下一次打出前减少1能量", rocketPunch!.Description, StringComparison.Ordinal);
        Assert.True(v0111.TryResolve("EIDOLON", true, "0.111.0", out var eidolon));
        Assert.Equal("二", eidolon!.Cost);
        Assert.Equal("打出你消耗牌堆中的所有虚无牌。消耗。", eidolon.Description);
    }

    [Fact]
    public void SelectsTheCompatibleDatabaseAndUpgradeText()
    {
        var older = Read(Document("0.109.0", "0.109.1", "3", "4"));
        var current = Read(Document("0.110.0", "0.110.1", "4", "6"));
        var database = new VersionedCardDatabase([older, current]);

        Assert.True(database.TryResolve("SHIV", upgraded: false, "0.109.1", out var oldShiv));
        Assert.Equal("造成3点伤害。", oldShiv!.Description);
        Assert.Null(oldShiv.StarCost);
        Assert.True(database.TryResolve("shiv", upgraded: true, "v0.110.1-beta", out var currentShiv));
        Assert.Equal("造成6点伤害。", currentShiv!.Description);
        Assert.Equal("0.110.0", currentShiv.DataVersion);
    }

    [Fact]
    public void FallsBackToNewestDatabaseWhenRuntimeVersionIsUnknown()
    {
        var database = new VersionedCardDatabase([
            Read(Document("0.109.0", "0.109.1", "3", "4")),
            Read(Document("0.110.0", "0.110.1", "4", "6")),
            Read(Document("0.111.0", "0.111.0", "5", "7"))
        ]);

        Assert.True(database.TryResolve("SHIV", upgraded: false, null, out var shiv));
        Assert.Equal("0.111.0", shiv!.DataVersion);
        Assert.True(database.TryResolveByName("小刀+", false, "0.110.0", null, out var byName));
        Assert.True(byName!.IsUpgraded);
        Assert.Equal("造成6点伤害。", byName.Description);
    }

    [Fact]
    public void SelectsTheExact0111DatabaseInsteadOfFallingBackTo0110()
    {
        var database = new VersionedCardDatabase([
            Read(Document("0.110.0", "0.110.1", "4", "6", "public-beta")),
            Read(Document("0.111.0", "0.111.0", "5", "7", "public-beta", 2))
        ]);

        Assert.True(database.TryResolve("SHIV", upgraded: true, "v0.111.0", "public-beta", out var shiv));
        Assert.Equal("0.111.0", shiv!.DataVersion);
        Assert.Equal("造成7点伤害。", shiv.Description);
        Assert.Equal(2, shiv.StarCost);
    }

    [Fact]
    public void PrefersTheMatchingReleaseBranchWhenVersionsOverlap()
    {
        var publicData = Read(Document("0.99.1", "0.99.1", "3", "4", "public"));
        var betaData = Read(Document("0.99.1", "0.99.1", "5", "7", "public-beta"));
        var database = new VersionedCardDatabase([publicData, betaData]);

        Assert.True(database.TryResolve("SHIV", false, "0.99.1", "public-beta", out var shiv));

        Assert.Equal("造成5点伤害。", shiv!.Description);
        Assert.Equal("public-beta", shiv.Branch);
        Assert.Equal("public", database.SelectDocument("0.99.1").Branch);
    }

    private static CardDatabaseDocument Read(string json)
    {
        using var stream = new MemoryStream(Encoding.UTF8.GetBytes(json));
        return VersionedCardDatabase.Read(stream);
    }

    private static string Document(
        string version,
        string through,
        string baseDamage,
        string upgradedDamage,
        string branch = "public",
        int? starCost = null) => $$"""
        {
          "schema_version": 1,
          "game_version": "{{version}}",
          "compatible_through": "{{through}}",
          "branch": "{{branch}}",
          "reconstructability": "exact",
          "source_url": "fixture",
          "source_page_revision": 1,
          "source_data_revision": 2,
          "captured_at_utc": "2026-08-12T00:00:00Z",
          "license": "fixture",
          "cards": [{
            "id": "SHIV",
            "wiki_id": "shiv",
            "name_zh": "小刀",
            "character": "衍生",
            "rarity": "衍生",
            "type": "攻击",
            "cost": "零",
            "star_cost": {{(starCost?.ToString() ?? "null")}},
            "description": "造成{{baseDamage}}点伤害。",
            "upgraded": {"id":"SHIV_UPGRADE","cost":"零","star_cost":{{(starCost?.ToString() ?? "null")}},"description":"造成{{upgradedDamage}}点伤害。"},
            "page": "小刀",
            "multiplayer_only": false
          }]
        }
        """;
}
