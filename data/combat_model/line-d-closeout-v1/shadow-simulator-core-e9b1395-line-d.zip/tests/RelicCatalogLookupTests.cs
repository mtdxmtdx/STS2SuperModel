using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Loader;
using System.Text.Json;
using MegaCrit.Sts2.Core.Helpers;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.TestSupport;
using Xunit;
using Xunit.Abstractions;

namespace STS2BestChoice.Tests;

public sealed class RelicCatalogLookupTests
{
    private readonly ITestOutputHelper _output;

    public RelicCatalogLookupTests(ITestOutputHelper output)
    {
        _output = output;
    }

    [Fact]
    public void LookupChineseNames()
    {
        RelicCatalogTests.EnsureModelDbInitialized();
        var zhsJsonPath = @"D:\STS2BestChoice\STS2SuperModel\sts2-cli-v0111\localization_zhs\relics.json";
        var zhs = JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(zhsJsonPath))!;

        string[] searchTerms = ["香炉", "日盘", "金刚杵", "平滑石", "锚", "赤牛", "弹珠袋", "孙子兵法", "积木", "双截棍", "钢笔尖", "蛇之戒指", "灯笼", "奥利哈钢", "花"];
        foreach (var term in searchTerms)
        {
            var matched = zhs.Where(kv => kv.Key.EndsWith(".title") && kv.Value.Contains(term)).ToArray();
            foreach (var m in matched)
            {
                var relicId = m.Key.Replace(".title", "");
                _output.WriteLine($"Term: {term} -> RelicId: {relicId} ({m.Value})");
            }
        }
    }
}
