using System.Collections.Immutable;
using STS2BestChoice.Core.Model;
using STS2BestChoice.Core.Simulation;
using Xunit;

namespace STS2BestChoice.Tests;

/// <summary>
/// v0.111 turn-boundary keyword semantics pinned by the card batch C1
/// fixtures: the public observation exposes the played card's own exhaust and
/// the end-of-turn Ethereal exhaust synchronously, Retain keeps a card in
/// hand across the boundary, and Ethereal status cards (Dazed family) discard
/// like normal cards instead of exhausting.
/// </summary>
public sealed class CardExhaustTimingTests
{
    private static PlayerState MakePlayer(int energy = 3) =>
        new(80, 80, 0, energy, 3, ImmutableDictionary<string, StatusState>.Empty);

    private static CreatureState MakeEnemy() =>
        new("SEAPUNK:1", "Seapunk", 50, 50, 0, ImmutableDictionary<string, StatusState>.Empty, []);

    private static CardState MakeSelfExhaustAttack(string instanceId = "molten_1") =>
        new(instanceId, "MOLTEN_FIST", "熔岩拳", 1, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 10)], CardDestination.Exhaust, CardType: "Attack");

    private static CardState MakeEtherealAttack(string instanceId = "defile_1") =>
        new(instanceId, "DEFILE", "湮灭", 1, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 13)], CardType: "Attack", ExhaustAtTurnEnd: true);

    private static CardState MakeEtherealStatus(string instanceId = "dazed_1") =>
        new(instanceId, "DAZED", "晕眩", 0, TargetKind.None, [], CardType: "Status", ExhaustAtTurnEnd: true);

    private static CardState MakeRetainSkill(string instanceId = "snakebite_1") =>
        new(instanceId, "SNAKEBITE", "蛇咬", 1, TargetKind.Enemy,
            [new EffectSpec(EffectKind.ApplyStatus, 7, "POISON")], CardType: "Skill", RetainAtTurnEnd: true);

    private static CardState MakeStrike(string instanceId = "strike_1") =>
        new(instanceId, "STRIKE_IRONCLAD", "打击", 1, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 6)], CardType: "Attack");

    private static MutableCombatState MakeState(params CardState[] hand)
    {
        // A non-empty draw pile keeps the turn-start draw from reshuffling the
        // discard back into the hand, so the boundary assertions stay direct.
        var drawPile = Enumerable.Range(0, 5)
            .Select(i => MakeStrike($"draw_fill_{i}"))
            .ToImmutableArray();
        var snapshot = CombatSnapshot.Create(
            "card-exhaust-timing", MakePlayer(), [MakeEnemy()], hand,
            drawPile: drawPile);
        return MutableCombatState.FromSnapshot(snapshot);
    }

    [Fact]
    public void PlayedSelfExhaustEntersPileImmediately()
    {
        var strike = MakeStrike();
        var selfExhaust = MakeSelfExhaustAttack();
        var state = MakeState(selfExhaust, strike);
        var simulator = new DeterministicSimulator();

        var projected = simulator.PlayCard(state, selfExhaust, "SEAPUNK:1", null);

        Assert.Single(projected.ExhaustPile);
        Assert.Equal("molten_1", projected.ExhaustPile[0].InstanceId);
        Assert.DoesNotContain(projected.Hand, card => card.InstanceId == "molten_1");
    }

    [Fact]
    public void EtherealCardExhaustsAtTurnEndAndSkipsDiscard()
    {
        var ethereal = MakeEtherealAttack();
        var strike = MakeStrike("strike_1");
        var state = MakeState(ethereal, strike);
        var simulator = new DeterministicSimulator();

        var nextTurn = simulator.ProjectToNextPlayerTurn(state);

        Assert.DoesNotContain(nextTurn.Hand, card => card.InstanceId == "defile_1");
        Assert.Equal("defile_1", nextTurn.ExhaustPile.Single().InstanceId);
        Assert.Equal("strike_1", nextTurn.DiscardPile.Single().InstanceId);
    }

    [Fact]
    public void RetainedCardStaysInHandAcrossTurnBoundary()
    {
        var retain = MakeRetainSkill();
        var strike = MakeStrike("strike_2");
        var state = MakeState(retain, strike);
        var simulator = new DeterministicSimulator();

        var nextTurn = simulator.ProjectToNextPlayerTurn(state);

        var retained = nextTurn.Hand.Single(card => card.InstanceId == "snakebite_1");
        Assert.False(retained.TemporaryRetainAtTurnEnd);
        Assert.Equal("strike_2", nextTurn.DiscardPile.Single().InstanceId);
        Assert.DoesNotContain(nextTurn.ExhaustPile, card => card.InstanceId == "snakebite_1");
    }

    [Fact]
    public void ExhaustAtTurnEndStatusCardIsMirrorInputOnly()
    {
        // The shadow honors the flag it is given; the Dazed carve-out lives in
        // the ShadowDiff snapshot mapping (status cards keep Destination
        // Discard), so a status card flagged ExhaustAtTurnEnd would still
        // exhaust here — this test pins that the flag drives the pipeline.
        var dazed = MakeEtherealStatus();
        var state = MakeState(dazed);
        var simulator = new DeterministicSimulator();

        var nextTurn = simulator.ProjectToNextPlayerTurn(state);

        Assert.Equal("dazed_1", nextTurn.ExhaustPile.Single().InstanceId);
        Assert.Empty(nextTurn.DiscardPile);
    }
}
