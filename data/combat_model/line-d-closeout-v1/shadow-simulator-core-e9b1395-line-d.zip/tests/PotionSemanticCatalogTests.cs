using System.Collections.Immutable;
using System.Collections;
using System.Reflection;
using STS2BestChoice.Core.Data;
using STS2BestChoice.Core.Model;
using STS2BestChoice.Core.Search;
using STS2BestChoice.Core.Simulation;
using Xunit;

namespace STS2BestChoice.Tests;

public sealed class PotionSemanticCatalogTests
{
    [Fact]
    public void FirePotionUsesRuntimeDynamicVarWithoutHardcodedFallback()
    {
        var mapping = PotionSemanticCatalog.Resolve(
            "FIRE_POTION",
            new Dictionary<string, decimal> { ["Damage"] = 21m });

        Assert.True(mapping.IsSupported);
        var effect = Assert.Single(mapping.Effects);
        Assert.Equal(EffectKind.Damage, effect.Kind);
        Assert.Equal(21m, effect.Amount);
    }

    [Fact]
    public void MissingRequiredDynamicVarRemainsExplicitlyUnsupported()
    {
        var mapping = PotionSemanticCatalog.Resolve(
            "FIRE_POTION",
            ImmutableDictionary<string, decimal>.Empty);

        Assert.False(mapping.IsSupported);
        Assert.Empty(mapping.Effects);
        Assert.Contains("Damage", mapping.UnsupportedReason);
    }

    [Fact]
    public void CureAllMapsEnergyAndDrawFromRuntimeValues()
    {
        var mapping = PotionSemanticCatalog.Resolve(
            "CURE_ALL",
            new Dictionary<string, decimal> { ["Energy"] = 2m, ["Cards"] = 4m });

        Assert.True(mapping.IsSupported);
        Assert.Collection(
            mapping.Effects,
            effect =>
            {
                Assert.Equal(EffectKind.GainEnergy, effect.Kind);
                Assert.Equal(2m, effect.Amount);
            },
            effect =>
            {
                Assert.Equal(EffectKind.Draw, effect.Kind);
                Assert.Equal(4m, effect.Amount);
            });
    }

    [Fact]
    public void UnknownPotionPriorityIsDistinctFromKnownZero()
    {
        var unknown = new PotionState(
            "unknown", "UNKNOWN", "Unknown", TargetKind.Self, [], 0m, PriorityHint: null);
        var knownZero = new PotionState(
            "known", "KNOWN", "Known", TargetKind.Self, [], 0m, PriorityHint: 0m);

        Assert.Equal(CombatSearchSession.UnknownPotionPriorityFallback,
            CombatSearchSession.ResolvePotionPriorityHint(unknown));
        Assert.Equal(0m, CombatSearchSession.ResolvePotionPriorityHint(knownZero));
        Assert.True(CombatSearchSession.ResolvePotionPriorityHint(unknown) >
                    CombatSearchSession.ResolvePotionPriorityHint(knownZero));
    }

    [Fact]
    public void PotionUseDoesNotSpendEnergyOrIncrementCardPlayCounters()
    {
        var potion = new PotionState(
            "potion", "ENERGY_POTION", "Energy Potion", TargetKind.Self,
            [new EffectSpec(EffectKind.GainEnergy, 2m)], 0m);
        var snapshot = CombatSnapshot.Create(
            "potion-resource-contract",
            new PlayerState(50m, 50m, 0m, 3, 3, ImmutableDictionary<string, StatusState>.Empty),
            [new CreatureState("enemy", "Enemy", 20m, 20m, 0m, ImmutableDictionary<string, StatusState>.Empty, [], 0m)],
            [],
            potions: [potion],
            historyCounters: new CombatHistoryCounters(CardsPlayedThisTurn: 2));
        var state = MutableCombatState.FromSnapshot(snapshot);
        var beforeCards = state.CardsPlayedBeforeTurn + state.CardsPlayedSinceSnapshot;

        var result = new DeterministicSimulator().UsePotion(state, potion, null);

        Assert.Equal(5, result.Player.Energy);
        Assert.Equal(beforeCards, result.CardsPlayedBeforeTurn + result.CardsPlayedSinceSnapshot);
    }

    [Fact]
    public void PotionUseAccumulatesNamedOpportunityCostWithoutSpendingEnergyOrCardCount()
    {
        var potion = new PotionState(
            "potion", "BLOCK_POTION", "Block Potion", TargetKind.Self,
            [new EffectSpec(EffectKind.Block, 5m)], OpportunityCost: 8m);
        var snapshot = CombatSnapshot.Create(
            "potion-cost-contract",
            new PlayerState(50m, 50m, 0m, 3, 3, ImmutableDictionary<string, StatusState>.Empty),
            [new CreatureState("enemy", "Enemy", 20m, 20m, 0m, ImmutableDictionary<string, StatusState>.Empty, [], 0m)],
            [],
            potions: [potion],
            historyCounters: new CombatHistoryCounters(CardsPlayedThisTurn: 2));
        var state = MutableCombatState.FromSnapshot(snapshot);
        state.PotionCostSpent = 1.5m;
        var beforeCards = state.CardsPlayedBeforeTurn + state.CardsPlayedSinceSnapshot;

        var result = new DeterministicSimulator().UsePotion(state, potion, null);

        Assert.Equal(3, result.Player.Energy);
        Assert.Equal(beforeCards, result.CardsPlayedBeforeTurn + result.CardsPlayedSinceSnapshot);
        Assert.Equal(9.5m, result.PotionCostSpent);
    }

    [Fact]
    public void ActualSearchActionConsumerOrdersKnownStrongUnknownAndKnownZeroHintsSeparately()
    {
        var knownZero = new PotionState(
            "known-zero", "KNOWN_ZERO", "Known Zero", TargetKind.Enemy, [], 0m, PriorityHint: 0m);
        var unknown = new PotionState(
            "unknown", "UNKNOWN", "Unknown", TargetKind.Enemy, [], 0m, PriorityHint: null);
        var knownStrong = new PotionState(
            "known-strong", "KNOWN_STRONG", "Known Strong", TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 10m)], 0m, PriorityHint: 10m);
        var snapshot = CombatSnapshot.Create(
            "potion-priority-consumer",
            new PlayerState(50m, 50m, 0m, 3, 3, ImmutableDictionary<string, StatusState>.Empty),
            [new CreatureState("enemy", "Enemy", 30m, 30m, 0m, ImmutableDictionary<string, StatusState>.Empty, [], 0m)],
            [],
            potions: [knownZero, unknown, knownStrong]);
        var state = MutableCombatState.FromSnapshot(snapshot);
        var session = new CombatSearchSession(snapshot);
        var generate = typeof(CombatSearchSession).GetMethod(
            "GenerateActions", BindingFlags.Instance | BindingFlags.NonPublic)!;
        var actions = ((IEnumerable)generate.Invoke(session, [state])!).Cast<object>()
            .Select(action => new
            {
                Potion = (PotionState)action.GetType().GetProperty("Potion")!.GetValue(action)!,
                Priority = (decimal)action.GetType().GetProperty("Priority")!.GetValue(action)!
            })
            .OrderByDescending(action => action.Priority)
            .ToArray();

        Assert.Equal(["known-strong", "unknown", "known-zero"],
            actions.Select(action => action.Potion.InstanceId).ToArray());
        Assert.True(actions[0].Priority > actions[1].Priority);
        Assert.True(actions[1].Priority > actions[2].Priority);
    }
}
