using System.Collections.Immutable;
using System.Text.Json;
using STS2BestChoice.Core.Model;
using STS2BestChoice.Core.Simulation;
using Xunit;

namespace STS2BestChoice.Tests;

public sealed class P0TrainingContractTests
{
    [Fact]
    public void PowerStateIsPreservedAndAffectsBothSearchKeys()
    {
        var baseSnapshot = Snapshot([
            new PowerState(
                Id: "PANACHE_POWER",
                OwnerId: "player",
                ApplierId: "player",
                Amount: 1,
                DynamicVars: ImmutableDictionary<string, string>.Empty.Add("Cards", "5"),
                Counters: ImmutableDictionary<string, decimal>.Empty.Add("UsesThisTurn", 0),
                TriggerPhases: ["CardPlay"],
                SourceId: "LIVE_POWER",
                Support: SemanticSupportStatus.SimulatorSupported,
                Evidence: EvidenceLevel.LiveObserved,
                SourceVersion: "v0.111.0")
        ]);
        var changedSnapshot = baseSnapshot with
        {
            Powers = [baseSnapshot.Powers[0] with { Amount = 2 }]
        };

        var first = MutableCombatState.FromSnapshot(baseSnapshot);
        var second = MutableCombatState.FromSnapshot(changedSnapshot);

        Assert.Single(first.Powers);
        Assert.Equal("PANACHE_POWER", first.Powers[0].Id);
        Assert.NotEqual(first.ExactKey(), second.ExactKey());
        Assert.NotEqual(first.CycleKeyWithoutProgress(), second.CycleKeyWithoutProgress());
        Assert.Equal(first.Powers[0], first.Clone().Powers[0]);
    }

    [Fact]
    public void TrainingContractsSerializeWithStableActionIdentity()
    {
        var action = new ActionCandidate(
            ActionCandidateKind.PlayCard,
            ActionId: "play:STRIKE:deck-0003:enemy-0",
            SourceModelId: "STRIKE",
            SourceInstanceId: "deck-0003",
            TargetId: "enemy-0",
            EffectiveEnergyCost: 1,
            SelectedCardInstanceIds: []);
        var record = new TrainingDecisionRecord(
            "record-1", 1, "v0.111.0", "41cef1ea", "assembly", "0.2.0", "sim", "score", "config",
            "episode-1", "Ironclad", 0, 1, 1, "combat-1", 1, "public-hash", "teacher-hash",
            [action], [action.ActionId],
            ImmutableDictionary<string, decimal>.Empty.Add(action.ActionId, 4.5m),
            PredictionConfidence.Reliable, true);

        var json = JsonSerializer.Serialize(record);
        var restored = JsonSerializer.Deserialize<TrainingDecisionRecord>(json);

        Assert.NotNull(restored);
        Assert.Equal(action.ActionId, restored!.SafeLegalActions.Single().ActionId);
        Assert.Equal(action.ActionId, restored.SafeTeacherBestActions.Single());
    }

    [Fact]
    public void DatasetManifestCarriesAllVersionFields()
    {
        var manifest = new DatasetManifest(
            "d", 1, "v0.111.0", "41cef1ea", "hash", "0.2.0", "sim", "score", "features", "seed_group",
            1, 1, 1, 1, 0, 0, [], DateTimeOffset.UnixEpoch,
            SemanticDatabaseVersion: "cards-v0111",
            FeatureSchemaVersion: "1",
            ModelVersion: "none");
        var json = JsonSerializer.Serialize(manifest);
        Assert.Contains("SemanticDatabaseVersion", json);
        Assert.Contains("FeatureSchemaVersion", json);
        Assert.Contains("ModelVersion", json);
    }

    [Fact]
    public void ApplyingStatusSynchronizesStructuredPowerState()
    {
        var card = new CardState(
            "bash-1",
            "BASH",
            "Bash",
            2,
            TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 8),
                new EffectSpec(EffectKind.ApplyStatus, 2, "VULNERABLE", Duration: 2, IsDebuff: true),
            ],
            CardType: "Attack");
        var snapshot = CombatSnapshot.Create(
            "power-transition",
            new PlayerState(30, 30, 0, 3, 3, ImmutableDictionary<string, StatusState>.Empty),
            [new CreatureState("enemy-0", "Enemy", 30, 30, 0, ImmutableDictionary<string, StatusState>.Empty, [])],
            [card], [], [], [], [], globalRestrictions: []);

        var projected = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), card, "enemy-0", null);

        var power = Assert.Single(projected.Powers);
        Assert.Equal("VULNERABLE_POWER", power.Id);
        Assert.Equal("enemy-0", power.OwnerId);
        Assert.Equal("player", power.ApplierId);
        Assert.Equal(2m, power.Amount);
        Assert.Equal("1.5", power.SafeDynamicVars["DamageIncrease"]);
        Assert.Equal(SemanticSupportStatus.SimulatorSupported, power.Support);
    }

    private static CombatSnapshot Snapshot(IEnumerable<PowerState> powers) => CombatSnapshot.Create(
        fingerprint: "p0",
        player: new PlayerState(30, 30, 0, 3, 3, ImmutableDictionary<string, StatusState>.Empty),
        enemies: [new CreatureState("enemy-0", "Enemy", 10, 10, 0,
            ImmutableDictionary<string, StatusState>.Empty, [new IntentState("Sleep")])],
        hand: [],
        drawPile: [],
        discardPile: [],
        exhaustPile: [],
        potions: [],
        globalRestrictions: [],
        powers: powers);
}
