using System.Collections.Immutable;
using STS2BestChoice.Core.Execution;
using STS2BestChoice.Core.Model;
using Xunit;

namespace STS2BestChoice.Tests;

public sealed class ExecutionEligibilityTests
{
    [Theory]
    [InlineData(PredictionConfidence.Reliable)]
    [InlineData(PredictionConfidence.Estimated)]
    [InlineData(PredictionConfidence.Uncalculable)]
    public void FiniteLinesCanExecuteAtEveryConfidence(PredictionConfidence confidence)
    {
        var line = Line(confidence);

        Assert.True(ExecutionEligibility.CanExecute(line));
        Assert.Equal(confidence == PredictionConfidence.Reliable,
            ExecutionEligibility.RequiresStrictCheckpoints(line));
    }

    [Fact]
    public void InfiniteAndEndTurnOnlyLinesRemainDisabled()
    {
        Assert.False(ExecutionEligibility.CanExecute(Line(PredictionConfidence.Estimated) with { IsInfinite = true }));
        Assert.False(ExecutionEligibility.CanExecute(new ActionLine(
            [new ActionStep(ActionKind.EndTurn, "end", "end", "End Turn")],
            PredictionConfidence.Estimated,
            ImmutableArray<RestrictionReason>.Empty,
            null,
            null)));
    }

    [Fact]
    public void CheckpointDivergenceIsDiagnosticAndDoesNotAbortNextLiveValidAction()
    {
        Assert.True(ExecutionEligibility.ShouldContinueAfterCheckpoint(matchesPrediction: false));
    }

    private static ActionLine Line(PredictionConfidence confidence) => new(
        [new ActionStep(ActionKind.PlayCard, "card", "card", "Card")],
        confidence,
        ImmutableArray<RestrictionReason>.Empty,
        null,
        null);
}
