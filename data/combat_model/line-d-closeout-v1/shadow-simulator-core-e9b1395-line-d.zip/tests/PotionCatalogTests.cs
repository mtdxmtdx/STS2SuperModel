using System.Collections;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using MegaCrit.Sts2.Core.Models;
using STS2BestChoice.Core.Data;
using Xunit;

namespace STS2BestChoice.Tests;

public sealed class PotionCatalogTests
{
    private const string ExpectedSha256 = "0861BFA1DF347538D932F22D580E75420F08082792EB914E53B4882764ACDBE9";

    [Fact]
    public void ExportAuthoritativePotionRegistry()
    {
        RelicCatalogTests.EnsureModelDbInitialized();

        var property = typeof(ModelDb).GetProperty(
            "AllPotions",
            BindingFlags.Public | BindingFlags.Static);
        Assert.NotNull(property);
        var potions = Assert.IsAssignableFrom<IEnumerable>(property.GetValue(null));

        var entries = new List<object>();
        foreach (var potion in potions)
        {
            Assert.NotNull(potion);
            var type = potion.GetType();
            var id = ReadId(potion);
            var dynamicVars = ReadDynamicVars(potion);
            var semantics = PotionSemanticCatalog.Resolve(id, dynamicVars);
            var methods = type
                .GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly)
                .Where(method => !method.IsSpecialName)
                .OrderBy(method => method.Name, StringComparer.Ordinal)
                .ThenBy(method => method.MetadataToken)
                .Select(method => new
                {
                    name = method.Name,
                    signature = method.ToString(),
                    il_sha256 = HashIl(method),
                    has_il = method.GetMethodBody()?.GetILAsByteArray() is { Length: > 0 }
                })
                .ToArray();

            entries.Add(new
            {
                potion_id = id,
                runtime_type = type.FullName,
                rarity = ReadProperty(potion, "Rarity")?.ToString() ?? "Unknown",
                target_type = ReadProperty(potion, "TargetType")?.ToString() ?? "Unknown",
                dynamic_var_names = dynamicVars.Keys.ToArray(),
                dynamic_vars = dynamicVars,
                simulator_supported = semantics.IsSupported,
                unsupported_reason = semantics.UnsupportedReason,
                effects = semantics.Effects.Select(effect => new
                {
                    kind = effect.Kind.ToString(),
                    amount = effect.Amount,
                    status_id = effect.StatusId,
                    duration = effect.Duration,
                    is_debuff = effect.IsDebuff,
                    source_id = effect.SourceId
                }).ToArray(),
                declared_methods = methods
            });
        }

        var ordered = entries
            .OrderBy(entry => (string)entry.GetType().GetProperty("potion_id")!.GetValue(entry)!, StringComparer.Ordinal)
            .ToArray();
        Assert.NotEmpty(ordered);
        Assert.Equal(ordered.Length, ordered.Select(entry => entry.GetType().GetProperty("potion_id")!.GetValue(entry)).Distinct().Count());

        var assemblyPath = typeof(ModelDb).Assembly.Location;
        using var assemblyStream = File.OpenRead(assemblyPath);
        var assemblySha = Convert.ToHexString(SHA256.HashData(assemblyStream));
        Assert.Equal(ExpectedSha256, assemblySha);

        var output = new
        {
            schema_version = 1,
            source = "MegaCrit.Sts2.Core.Models.ModelDb.AllPotions",
            authoritative_denominator = true,
            game_version = "v0.111.0",
            game_commit = "41cef1ea",
            assembly_sha256 = assemblySha,
            total_potions = ordered.Length,
            potions = ordered
        };
        var outputPath = @"D:\STS2BestChoice\STS2SuperModel\data\potions\v0.111\potion-runtime-catalog.json";
        Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
        var serialized = JsonSerializer.Serialize(output, new JsonSerializerOptions { WriteIndented = true }) + Environment.NewLine;
        File.WriteAllText(outputPath, serialized);
        File.WriteAllText(Path.Combine(Path.GetDirectoryName(outputPath)!, "potion-catalog.json"), serialized);
    }

    private static object? ReadProperty(object value, string name) =>
        value.GetType().GetProperty(name, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)?.GetValue(value);

    private static string ReadId(object potion)
    {
        var id = ReadProperty(potion, "Id");
        Assert.NotNull(id);
        var entry = ReadProperty(id, "Entry")?.ToString();
        Assert.False(string.IsNullOrWhiteSpace(entry));
        return entry!;
    }

    private static SortedDictionary<string, decimal> ReadDynamicVars(object potion)
    {
        var result = new SortedDictionary<string, decimal>(StringComparer.Ordinal);
        var dynamicVars = ReadProperty(potion, "DynamicVars");
        var values = dynamicVars is null ? null : ReadProperty(dynamicVars, "Values") as IEnumerable;
        if (values is null)
            return result;

        foreach (var item in values)
        {
            if (item is null) continue;
            var key = ReadProperty(item, "Name")?.ToString();
            var baseValue = ReadProperty(item, "BaseValue");
            if (!string.IsNullOrWhiteSpace(key) && baseValue is not null)
                result[key] = Convert.ToDecimal(baseValue, System.Globalization.CultureInfo.InvariantCulture);
        }
        return result;
    }

    private static string? HashIl(MethodInfo method)
    {
        var bytes = method.GetMethodBody()?.GetILAsByteArray();
        return bytes is { Length: > 0 } ? Convert.ToHexString(SHA256.HashData(bytes)) : null;
    }
}
