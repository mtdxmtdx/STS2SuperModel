using STS2BestChoice.Core.Semantics;
using Xunit;

namespace STS2BestChoice.Tests;

public sealed class CardTextSemanticCompilerTests
{
    [Fact]
    public void CompilesImmediateDamageBlockAndDebuffClauses()
    {
        var result = CardTextSemanticCompiler.Compile("造成8点伤害。获得7点格挡。给予2层易伤。消耗。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsImmediatelyExecutable);
        Assert.Collection(result.Operations,
            damage => Assert.Equal(CardSemanticKind.Damage, damage.Kind),
            block => Assert.Equal(CardSemanticKind.Block, block.Kind),
            status => Assert.Equal("VULNERABLE", status.Id),
            keyword => Assert.Equal("消耗", keyword.Id));
    }

    [Fact]
    public void CompilesTransfigureHandReplayAndCostAsOneSelection()
    {
        var result = CardTextSemanticCompiler.Compile("给一张手牌添加重放。其耗能增加1能量。消耗。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        Assert.Collection(result.Operations,
            selection =>
            {
                Assert.Equal(CardSemanticKind.SelectCard, selection.Kind);
                Assert.Equal("HAND_ANY_ADD_REPLAY", selection.Id);
                Assert.Equal(1, selection.Amount);
                Assert.Equal(1, selection.XBonus);
            },
            keyword => Assert.Equal("消耗", keyword.Id));
    }

    [Fact]
    public void CompilesNumericRadiance()
    {
        var result = CardTextSemanticCompiler.Compile("获得9辉星。消耗。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        Assert.Equal(9m, result.Operations[0].Amount);
        Assert.Equal("RADIANCE", result.Operations[0].Id);
    }

    [Fact]
    public void CompilesAllEnemyPairedStatusesWithDistinctAmounts()
    {
        var result = CardTextSemanticCompiler.Compile("给予所有敌人21层灾厄和1层虚弱");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        Assert.Collection(result.Operations,
            doom =>
            {
                Assert.Equal("DOOM", doom.Id);
                Assert.Equal(21m, doom.Amount);
                Assert.Equal(SemanticTarget.AllEnemies, doom.Target);
            },
            weak =>
            {
                Assert.Equal("WEAK", weak.Id);
                Assert.Equal(1m, weak.Amount);
                Assert.Equal(SemanticTarget.AllEnemies, weak.Target);
            });
    }

    [Fact]
    public void CompilesTurnStartRandomDoom()
    {
        var result = CardTextSemanticCompiler.Compile("在你的回合开始时，给予随机敌人6层灾厄");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal("TURN_START_RANDOM_DOOM", operation.Id);
        Assert.Equal("persistent_turn_start", operation.Timing);
        Assert.Equal(6m, operation.Amount);
    }

    [Fact]
    public void CompilesUnitlessIntangibleStatus()
    {
        var result = CardTextSemanticCompiler.Compile("获得2无实体。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        Assert.Equal("INTANGIBLE", Assert.Single(result.Operations).Id);
        Assert.Equal(2m, result.Operations[0].Amount);
    }

    [Fact]
    public void CompilesHistoricalAddShivsToHandWording()
    {
        var result = CardTextSemanticCompiler.Compile("添加3张小刀到你的手牌。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.GenerateCard, operation.Kind);
        Assert.Equal("SHIV", operation.Id);
        Assert.Equal(SemanticTarget.Hand, operation.Target);
        Assert.Equal(3m, operation.Amount);
    }

    [Fact]
    public void CompilesSelfCostReduction()
    {
        var result = CardTextSemanticCompiler.Compile("这张牌的耗能减少1。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ModifyCost, operation.Kind);
        Assert.Equal("SELF", operation.Id);
        Assert.Equal(-1m, operation.Amount);
    }

    [Fact]
    public void CompilesSelfCostReductionOnDraw()
    {
        var result = CardTextSemanticCompiler.Compile(
            "造成27点伤害。每当你抽到这张牌时，这张牌的耗能减少1。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations.Where(item => item.Kind == CardSemanticKind.ModifyCost));
        Assert.Equal("SELF_DRAWN", operation.Trigger);
        Assert.Equal("SELF", operation.Id);
        Assert.Equal(-1m, operation.Amount);
    }

    [Theory]
    [InlineData("在回合开始时，获得能量。", 1)]
    [InlineData("在回合开始时，获得能量能量。", 2)]
    public void CompilesTurnStartEnergyWithoutOwnerPronoun(string text, int amount)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal("TURN_START_ENERGY", operation.Id);
        Assert.Equal(amount, operation.Amount);
        Assert.Equal("persistent_turn_start", operation.Timing);
    }

    [Fact]
    public void CompilesFixedNextTurnBlock()
    {
        var result = CardTextSemanticCompiler.Compile("在下一回合获得5点格挡。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.Block, operation.Kind);
        Assert.Equal("next_turn", operation.Timing);
        Assert.Equal(5m, operation.Amount);
    }

    [Fact]
    public void SeparatesStructuredButUnsupportedGenerationFromUnknownText()
    {
        var generation = CardTextSemanticCompiler.Compile("将3张小刀加入你的手牌。");
        var unknown = CardTextSemanticCompiler.Compile("如果敌人正在跳舞，造成9点伤害。");

        Assert.True(generation.IsFullyStructured);
        Assert.False(generation.IsImmediatelyExecutable);
        Assert.Equal("SHIV", Assert.Single(generation.Operations).Id);
        Assert.False(unknown.IsFullyStructured);
        Assert.Equal("如果敌人正在跳舞，造成9点伤害", Assert.Single(unknown.UnparsedClauses));
    }

    [Fact]
    public void PreservesGeneratedCardUpgradeIdentity()
    {
        var result = CardTextSemanticCompiler.Compile("将2张小刀+加入你的手牌。");

        Assert.True(result.IsSimulatorExecutable);
        Assert.Equal("SHIV_UPGRADE", Assert.Single(result.Operations).Id);
    }

    [Theory]
    [InlineData("你每打出一张无色牌，都获得1点力量", "COLORLESS_CARD_PLAYED", "STRENGTH")]
    [InlineData("每当你生成一张牌，就获得1点力量", "CARD_GENERATED", "STRENGTH")]
    [InlineData("你每回合第一次生成一张卡牌时，获得5点格挡", "CARD_GENERATED", null)]
    [InlineData("每当你生成一张状态牌时，对所有敌人造成5点伤害", "STATUS_CARD_GENERATED", null)]
    [InlineData("每当你生成状态牌时，此牌的耗能将在下一次打出前减少1能量", "STATUS_CARD_GENERATED", "SELF_BY_STATUS_GENERATED")]
    public void CompilesGeneratedCardHookFamilies(string text, string trigger, string? id)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(trigger, operation.Trigger);
        if (id is not null) Assert.Equal(id, operation.Id);
    }

    [Theory]
    [InlineData("将2张伤口加入你的弃牌堆。", "伤口", 2)]
    [InlineData("将一张晕眩添加到你的弃牌堆中。", "晕眩", 1)]
    [InlineData("在你的弃牌堆中加入一张黏液。", "黏液", 1)]
    public void CompilesDeterministicDiscardPileGeneration(string text, string card, int amount)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.GenerateCard, operation.Kind);
        Assert.Equal(SemanticTarget.DiscardPile, operation.Target);
        Assert.Equal(card, operation.Id);
        Assert.Equal(amount, operation.Amount);
    }

    [Fact]
    public void CompilesSelfCopyWithoutRecursiveCardResolution()
    {
        var result = CardTextSemanticCompiler.Compile("造成6点伤害。将一张此牌的复制品加入你的弃牌堆。");

        Assert.True(result.IsSimulatorExecutable);
        Assert.Equal("SELF_COPY", result.Operations[1].Id);
        Assert.Equal(SemanticTarget.DiscardPile, result.Operations[1].Target);
    }

    [Fact]
    public void SplitsACompoundClauseOnlyWhenEveryPartIsStructured()
    {
        var result = CardTextSemanticCompiler.Compile("对所有敌人造成4点伤害，给予1层易伤。");

        Assert.True(result.IsSimulatorExecutable);
        Assert.Collection(result.Operations,
            damage => Assert.Equal(SemanticTarget.AllEnemies, damage.Target),
            vulnerable => Assert.Equal("VULNERABLE", vulnerable.Id));
    }

    [Theory]
    [InlineData("造成你当前格挡值的伤害。", "PLAYER_BLOCK")]
    [InlineData("造成你抽牌堆中剩余牌数的伤害。", "DRAW_PILE_COUNT")]
    [InlineData("造成等量于该敌人身上的灾厄层数的伤害。", "TARGET_STATUS:DOOM")]
    public void CompilesDamageDerivedFromCurrentCombatState(string text, string source)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.DynamicDamage, operation.Kind);
        Assert.Equal(source, operation.Id);
    }

    [Fact]
    public void CompilesStrengthFromTargetVulnerableStacks()
    {
        var result = CardTextSemanticCompiler.Compile("敌人身上每有一层易伤，就获得1点力量");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal(SemanticTarget.Self, operation.Target);
        Assert.Equal("STRENGTH", operation.Id);
        Assert.True(operation.AmountByTargetVulnerableStacks);
    }

    [Theory]
    [InlineData("如果你在本回合消耗过卡牌，则获得3能量", "GainEnergy")]
    [InlineData("获得8点格挡。如果你在本回合消耗过卡牌，则额外获得8点格挡", "Block")]
    public void CompilesExhaustedThisTurnConditions(string text, string expectedKind)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = result.Operations.Single(item => item.Condition == "CARD_EXHAUSTED_THIS_TURN");
        Assert.Equal(expectedKind, operation.Kind.ToString());
    }

    [Fact]
    public void CompilesSelfExhaustEnergyTrigger()
    {
        var result = CardTextSemanticCompiler.Compile("抽2张牌。这张牌被消耗时，获得能量能量。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations.Where(item => item.Trigger == "SELF_EXHAUSTED"));
        Assert.Equal(CardSemanticKind.GainEnergy, operation.Kind);
        Assert.Equal(2m, operation.Amount);
    }

    [Fact]
    public void CompilesHistoricalDrumTurnStartDrawTopExhaust()
    {
        var result = CardTextSemanticCompiler.Compile("抽2张牌。在你的回合开始时，消耗你的抽牌堆顶部的牌。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations.Where(item => item.Id == "DRAW_TOP_TO_EXHAUST"));
        Assert.Equal(CardSemanticKind.MoveCard, operation.Kind);
        Assert.Equal("turn_start", operation.Timing);
    }

    [Fact]
    public void CompilesViciousVulnerableAppliedDrawTrigger()
    {
        var result = CardTextSemanticCompiler.Compile("每当你给予易伤时，抽2张牌。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.Draw, operation.Kind);
        Assert.Equal("VULNERABLE_APPLIED", operation.Trigger);
        Assert.Equal(2m, operation.Amount);
    }

    [Fact]
    public void CompilesInfernoPlayerTurnHpLossTrigger()
    {
        var result = CardTextSemanticCompiler.Compile(
            "在你的回合开始时，失去1点生命。每当你在你的回合内失去生命时，对所有敌人造成6点伤害。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var trigger = Assert.Single(result.Operations.Where(item => item.Trigger == "PLAYER_HP_LOST"));
        Assert.Equal(CardSemanticKind.Damage, trigger.Kind);
        Assert.Equal(SemanticTarget.AllEnemies, trigger.Target);
        Assert.Equal(6m, trigger.Amount);
    }

    [Theory]
    [InlineData("每当你在你的回合失去生命值时, 获得1点力量。", 1)]
    [InlineData("每当你在你的回合失去生命值时, 获得2点力量。", 2)]
    public void CompilesRupturePlayerTurnHpLossStrengthTrigger(string text, int amount)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var trigger = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, trigger.Kind);
        Assert.Equal(SemanticTarget.Self, trigger.Target);
        Assert.Equal("STRENGTH", trigger.Id);
        Assert.Equal("PLAYER_HP_LOST", trigger.Trigger);
        Assert.Equal(amount, trigger.Amount);
    }

    [Fact]
    public void CompilesEnemyStatusMultiplication()
    {
        var result = CardTextSemanticCompiler.Compile("将该敌人身上的易伤层数翻倍。");

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.MultiplyStatus, operation.Kind);
        Assert.Equal("VULNERABLE", operation.Id);
        Assert.Equal(2m, operation.Amount);
    }

    [Fact]
    public void CompilesRepeatedAllEnemyDamageAndPairedDebuffs()
    {
        var damage = CardTextSemanticCompiler.Compile("对所有敌人造成6点伤害两次。");
        var statuses = CardTextSemanticCompiler.Compile("给予所有敌人3层虚弱和易伤。");

        Assert.True(damage.IsSimulatorExecutable);
        Assert.Equal(2, Assert.Single(damage.Operations).Repeat);
        Assert.True(statuses.IsSimulatorExecutable);
        Assert.Equal(new[] { "WEAK", "VULNERABLE" }, statuses.Operations.Select(operation => operation.Id));
    }

    [Theory]
    [InlineData("造成5点伤害。如果你在本回合失去过生命值，则攻击2次。", 2)]
    [InlineData("造成5点伤害。如果你在本回合失去过生命值，则攻击3次。", 3)]
    public void CompilesHpLossConditionalAttackRepeat(string text, int repeat)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.Damage, operation.Kind);
        Assert.Equal(repeat, operation.Repeat);
        Assert.Equal("PLAYER_HP_LOST_THIS_TURN", operation.Condition);
    }

    [Fact]
    public void CompilesDoomAsAnEnemyStatus()
    {
        var result = CardTextSemanticCompiler.Compile("给予所有敌人11层灾厄。");

        Assert.True(result.IsSimulatorExecutable);
        Assert.Equal("DOOM", Assert.Single(result.Operations).Id);
    }

    [Fact]
    public void CompilesBlightStrikeDoomFromDamage()
    {
        var result = CardTextSemanticCompiler.Compile("给予等量于所造成伤害的灾厄");

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal("DOOM_EQUAL_DAMAGE", operation.Id);
        Assert.Equal(SemanticTarget.SelectedEnemy, operation.Target);
    }

    [Theory]
    [InlineData("给予自身3层灾厄。获得能量。")]
    [InlineData("给予自身3层灾厄。 获得[能量]。")]
    [InlineData("给予自身3层灾厄。 获得16px|link=。")]
    [InlineData("给予自身3层灾厄。 获得16px|link=能量。")]
    public void CompilesHistoricalBorrowedTimeSelfDoomAndEnergy(string text)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        Assert.Collection(result.Operations,
            doom =>
            {
                Assert.Equal(CardSemanticKind.ApplyStatus, doom.Kind);
                Assert.Equal(SemanticTarget.Self, doom.Target);
                Assert.Equal("DOOM", doom.Id);
                Assert.Equal(3m, doom.Amount);
            },
            energy =>
            {
                Assert.Equal(CardSemanticKind.GainEnergy, energy.Kind);
                Assert.Equal(1m, energy.Amount);
            });
    }

    [Fact]
    public void CompilesNeurosurgeAsPersistentTurnStartSelfDoom()
    {
        var result = CardTextSemanticCompiler.Compile("获得能量能量能量。抽2张牌。在你的回合开始时，给予自身3层灾厄。");

        Assert.True(result.IsSimulatorExecutable);
        var doom = Assert.Single(result.Operations, operation => operation.Id == "DOOM");
        Assert.Equal(CardSemanticKind.ApplyStatus, doom.Kind);
        Assert.Equal(SemanticTarget.Self, doom.Target);
        Assert.Equal("turn_start", doom.Timing);
        Assert.Equal(3m, doom.Amount);
    }

    [Fact]
    public void NormalizesHistoricalNumericEnergyIconArtifact()
    {
        var result = CardTextSemanticCompiler.Compile("获得416px|link=。");

        Assert.True(result.IsSimulatorExecutable);
        var energy = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.GainEnergy, energy.Kind);
        Assert.Equal(4m, energy.Amount);
    }

    [Fact]
    public void CompilesVoidOnDrawAndBurnTurnEndTriggers()
    {
        var voidCard = CardTextSemanticCompiler.Compile("不能被打出。虚无。每当你抽到这张牌时，失去能量。");
        var burn = CardTextSemanticCompiler.Compile("不能被打出。在你的回合结束时，如果这张牌在你的手牌中，你受到2点伤害。");

        Assert.True(voidCard.IsSimulatorExecutable);
        Assert.Contains(voidCard.Operations, operation =>
            operation.Trigger == "SELF_DRAWN" && operation.Kind == CardSemanticKind.GainEnergy && operation.Amount == -1);
        Assert.True(burn.IsSimulatorExecutable);
        Assert.Contains(burn.Operations, operation =>
            operation.Timing == "turn_end" && operation.Condition == "SELF_IN_HAND" && operation.Amount == 2);
    }

    [Fact]
    public void CompilesMultiCardHandAndDiscardPileSelections()
    {
        var discard = CardTextSemanticCompiler.Compile("弃两张牌。");
        var dredge = CardTextSemanticCompiler.Compile("将3张牌从弃牌堆加入你的手牌。消耗。");

        Assert.True(discard.IsSimulatorExecutable);
        Assert.Equal(2m, Assert.Single(discard.Operations).Amount);
        Assert.True(dredge.IsSimulatorExecutable);
        var movement = Assert.Single(dredge.Operations.Where(operation => operation.Kind == CardSemanticKind.MoveCard));
        Assert.Equal("CHOOSE_DISCARD_ANY_TO_HAND", movement.Id);
        Assert.Equal(3m, movement.Amount);
    }

    [Theory]
    [InlineData("造成8点伤害X次。", SemanticTarget.SelectedEnemy, 0)]
    [InlineData("对所有敌人造成5点伤害X+1次。", SemanticTarget.AllEnemies, 1)]
    public void CompilesEnergyScaledDamageRepeats(string text, SemanticTarget target, int bonus)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.True(operation.RepeatByEnergySpent);
        Assert.Equal(target, operation.Target);
        Assert.Equal(bonus, operation.XBonus);
    }

    [Fact]
    public void CompilesEnergyScaledDebuffs()
    {
        var result = CardTextSemanticCompiler.Compile("敌人失去X+1点力量。给予X+1层虚弱。消耗。");

        Assert.True(result.IsSimulatorExecutable);
        Assert.All(result.Operations.Take(2), operation =>
        {
            Assert.True(operation.AmountByEnergySpent);
            Assert.Equal(1, operation.XBonus);
        });
        Assert.Equal(-1m, result.Operations[0].Amount);
        Assert.Equal("STRENGTH", result.Operations[0].Id);
        Assert.Equal("WEAK", result.Operations[1].Id);
    }

    [Theory]
    [InlineData("获得1层无实体。", "INTANGIBLE")]
    [InlineData("获得4点荆棘。", "THORNS")]
    [InlineData("获得6层覆甲。", "PLATED_ARMOR")]
    public void CompilesDefensivePersistentStatuses(string text, string status)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        Assert.Equal(status, Assert.Single(result.Operations).Id);
    }

    [Theory]
    [InlineData("获得等量于与你当前弃牌堆中牌数+3的格挡值。", "DISCARD_PILE_COUNT", 3)]
    [InlineData("获得等同于所有敌人中毒层数的格挡。", "ALL_ENEMY_STATUS:POISON", 0)]
    public void CompilesBlockDerivedFromCombatState(string text, string source, int bonus)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.DynamicBlock, operation.Kind);
        Assert.Equal(source, operation.Id);
        Assert.Equal(bonus, operation.XBonus);
    }

    [Fact]
    public void CompilesSingleSelectionAndDiscardRedrawSeparately()
    {
        var selection = CardTextSemanticCompiler.Compile("丢弃1张牌。");
        var redraw = CardTextSemanticCompiler.Compile("丢弃你的所有手牌，然后抽相同数量的牌。");

        Assert.True(selection.IsSimulatorExecutable);
        Assert.Equal(CardSemanticKind.DiscardCards, Assert.Single(selection.Operations).Kind);
        Assert.True(redraw.IsSimulatorExecutable);
        Assert.Equal(CardSemanticKind.DiscardHandThenDrawSame, Assert.Single(redraw.Operations).Kind);
    }

    [Fact]
    public void CompilesRebootShuffleClause()
    {
        var result = CardTextSemanticCompiler.Compile("将你的所有未消耗的卡牌重新洗牌放入抽牌堆。抽4张牌。消耗。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        Assert.Contains(result.Operations, operation => operation.Kind == CardSemanticKind.Reboot);
        Assert.Contains(result.Operations, operation => operation.Kind == CardSemanticKind.Draw && operation.Amount == 4);
    }

    [Theory]
    [InlineData("每丢弃一张牌，就将一张小刀添加至你的手牌。", "SHIV")]
    [InlineData("每丢弃一张牌，就将一张小刀+添加至你的手牌。", "SHIV_UPGRADE")]
    public void CompilesStormOfSteelDiscardGeneration(string text, string generatedId)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.DiscardHandAndGenerate, operation.Kind);
        Assert.Equal(generatedId, operation.Id);
        Assert.True(operation.All);
        Assert.Equal(SemanticTarget.Hand, operation.Target);
    }

    [Theory]
    [InlineData("小刀额外造成4点伤害", 4)]
    [InlineData("小刀额外造成6点伤害", 6)]
    public void CompilesShivDamageBonus(string text, int amount)
    {
        var result = CardTextSemanticCompiler.Compile(text + "。");

        var operation = Assert.Single(result.Operations);
        Assert.True(result.IsSimulatorExecutable);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal("SHIV_DAMAGE_BONUS", operation.Id);
        Assert.Equal(amount, operation.Amount);
        Assert.Equal("persistent_combat", operation.Timing);
    }

    [Fact]
    public void CompilesShivsAttackAllEnemies()
    {
        var result = CardTextSemanticCompiler.Compile("小刀现在会攻击所有敌人。将4张小刀添加到你的手牌。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        Assert.Contains(result.Operations, operation =>
            operation.Kind == CardSemanticKind.ApplyStatus &&
            operation.Id == "SHIV_ALL_ENEMIES" &&
            operation.Timing == "persistent_combat");
        Assert.Contains(result.Operations, operation =>
            operation.Kind == CardSemanticKind.GenerateCard &&
            operation.Id == "SHIV" &&
            operation.Amount == 4);
    }

    [Theory]
    [InlineData("小刀获得保留。你在每回合打出的第一张小刀额外造成9点伤害。", 9)]
    [InlineData("小刀获得保留。你在每回合打出的第一张小刀额外造成12点伤害。", 12)]
    public void CompilesPhantomBladesClauses(string text, int amount)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        Assert.Contains(result.Operations, operation =>
            operation.Kind == CardSemanticKind.ApplyStatus && operation.Id == "SHIV_RETAIN");
        var firstShiv = Assert.Single(result.Operations,
            operation => operation.Id == "FIRST_SHIV_DAMAGE_BONUS");
        Assert.Equal(amount, firstShiv.Amount);
        Assert.Equal("persistent_combat", firstShiv.Timing);
    }

    [Fact]
    public void CompilesJugglingThirdAttackCopy()
    {
        var result = CardTextSemanticCompiler.Compile(
            "将你在每回合打出的第三张攻击牌的复制品加入你的手牌。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal("JUGGLING", operation.Id);
        Assert.Equal("THIRD_ATTACK_PLAYED", operation.Trigger);
        Assert.Equal("persistent_combat", operation.Timing);
    }

    [Theory]
    [InlineData("中毒会额外触发1次。", 1)]
    [InlineData("中毒会额外触发2次。", 2)]
    public void CompilesAccelerantPoisonTriggers(string text, int amount)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal("ACCELERANT", operation.Id);
        Assert.Equal(amount, operation.Amount);
    }

    [Theory]
    [InlineData("每当你给予3次中毒，就对所有敌人造成11点伤害。", 11)]
    [InlineData("每当你给予3次中毒，就对所有敌人造成15点伤害。", 15)]
    public void CompilesOutbreakPoisonBurst(string text, int amount)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.Outbreak, operation.Kind);
        Assert.Equal("OUTBREAK", operation.Id);
        Assert.Equal(SemanticTarget.AllEnemies, operation.Target);
        Assert.Equal(3, operation.Repeat);
        Assert.Equal(amount, operation.Amount);
    }

    [Fact]
    public void CompilesMakeItSoSkillThresholdListener()
    {
        var result = CardTextSemanticCompiler.Compile(
            "造成6点伤害。你每在一回合内打出3张技能牌，就将这张牌放入你的手牌。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var listener = Assert.Single(result.Operations,
            operation => operation.Id == "RETURN_SELF_TO_HAND_AFTER_SKILLS");
        Assert.Equal(CardSemanticKind.Keyword, listener.Kind);
        Assert.Equal(3, listener.Amount);
        Assert.Equal("SKILL_PLAYED", listener.Trigger);
    }

    [Fact]
    public void CompilesMementoMoriDiscardCounter()
    {
        var result = CardTextSemanticCompiler.Compile("造成9点伤害。本回合每丢弃过一张牌，则增加4点额外伤害。");

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.DynamicDamage, operation.Kind);
        Assert.Equal("CARDS_DISCARDED_THIS_TURN", operation.Id);
        Assert.Equal(4, operation.XBonus);
    }

    [Fact]
    public void CompilesTearAsunderDamageReceivedCounter()
    {
        var result = CardTextSemanticCompiler.Compile(
            "造成5点伤害。在本场战斗中，你每失去过一次生命值，这张牌就额外造成一次伤害");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations,
            operation => operation.Kind == CardSemanticKind.DynamicDamage);
        Assert.Equal(1, operation.Amount);
        Assert.Equal("PLAYER_DAMAGE_RECEIVED_THIS_COMBAT", operation.Id);
        Assert.True(operation.RepeatByHistoryCounter);
    }

    [Fact]
    public void CompilesMelancholyCreatureDeathCostListener()
    {
        var result = CardTextSemanticCompiler.Compile(
            "获得13点格挡。每当有任何生物死亡时，这张牌的耗能减少能量");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations,
            operation => operation.Kind == CardSemanticKind.ModifyCost);
        Assert.Equal("SELF_DEATH_COST_DELTA", operation.Id);
        Assert.Equal("CREATURE_DIED", operation.Trigger);
        Assert.Equal(-1, operation.Amount);
    }

    [Fact]
    public void CompilesDeathsDoorDoomCondition()
    {
        var result = CardTextSemanticCompiler.Compile(
            "获得6点格挡。如果你在本回合中曾给予过灾厄，则额外获得2次格挡");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations,
            operation => operation.Kind == CardSemanticKind.Block && operation.Condition is not null);
        Assert.Equal(2, operation.Amount);
        Assert.Equal("DOOM_APPLIED_THIS_TURN", operation.Condition);
    }

    [Theory]
    [InlineData("造成10点伤害。斩杀时，永久获得3点最大生命值。消耗。", 3)]
    [InlineData("造成12点伤害。斩杀时，永久获得4点最大生命值。消耗。", 4)]
    public void CompilesFeedKillMaxHpReward(string text, int amount)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations,
            operation => operation.Kind == CardSemanticKind.ModifyMaxHp);
        Assert.Equal(amount, operation.Amount);
        Assert.Equal("SOURCE_CARD_KILLED", operation.Condition);
    }

    [Theory]
    [InlineData("有易伤状态的敌人额外受到25%的伤害。", 25)]
    [InlineData("有易伤状态的敌人额外受到50%的伤害。", 50)]
    public void CompilesCrueltyAsEnemyVulnerableMultiplierBonus(string text, int amount)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        var operation = Assert.Single(result.Operations);
        Assert.True(result.IsSimulatorExecutable);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal(SemanticTarget.AllEnemies, operation.Target);
        Assert.Equal("BONUS_VULNERABLE_POWERED_ATTACK_DAMAGE_PERCENT", operation.Id);
        Assert.Equal(amount, operation.Amount);
    }

    [Fact]
    public void CompilesHangAsATargetSpecificPersistentMultiplier()
    {
        var result = CardTextSemanticCompiler.Compile(
            "造成10点伤害。让所有“吊杀”牌对这名敌人造成的伤害翻倍。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations,
            operation => operation.Kind == CardSemanticKind.ApplyStatus);
        Assert.Equal(SemanticTarget.SelectedEnemy, operation.Target);
        Assert.Equal("HANG_DAMAGE_MULTIPLIER", operation.Id);
        Assert.Equal(2, operation.Amount);
        Assert.Equal("persistent_combat", operation.Timing);
    }

    [Fact]
    public void CompilesRandomExhaustAsAChanceOperation()
    {
        var result = CardTextSemanticCompiler.Compile("随机消耗1张牌。");

        Assert.True(result.IsSimulatorExecutable);
        Assert.Equal(CardSemanticKind.RandomExhaustCards, Assert.Single(result.Operations).Kind);
    }

    [Theory]
    [InlineData("如果你的手牌中没有攻击牌，抽3张牌。", "HAND_NO_ATTACKS")]
    [InlineData("如果你的消耗牌堆拥有大于等于3张牌，则对所有敌人造成17点伤害。", "EXHAUST_AT_LEAST_3")]
    [InlineData("如果敌方拥有中毒，则给予9层中毒。", "TARGET_HAS_POISON")]
    [InlineData("如果敌人的意图是攻击，则给予2层虚弱。", "TARGET_INTENDS_ATTACK")]
    public void CompilesSupportedRuntimeConditions(string text, string condition)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        Assert.Equal(condition, Assert.Single(result.Operations).Condition);
    }

    [Theory]
    [InlineData("从抽牌堆中选择一张攻击牌放入你的手牌。", "CHOOSE_DRAW_ATTACK_TO_HAND")]
    [InlineData("从抽牌堆中选择一张技能牌放入你的手牌。", "CHOOSE_DRAW_SKILL_TO_HAND")]
    [InlineData("从你的抽牌堆中选择一张牌将其消耗。", "CHOOSE_DRAW_ANY_TO_EXHAUST")]
    public void CompilesImmediateDrawPileSelections(string text, string operationId)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        Assert.Equal(operationId, Assert.Single(result.Operations).Id);
    }

    [Fact]
    public void CompilesCollisionCourseDebrisGenerationUsingTheToVariant()
    {
        var result = CardTextSemanticCompiler.Compile(
            "造成11点伤害。将一张碎屑添加至你的手牌。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        Assert.Collection(result.Operations,
            damage => Assert.Equal(CardSemanticKind.Damage, damage.Kind),
            debris =>
            {
                Assert.Equal(CardSemanticKind.GenerateCard, debris.Kind);
                Assert.Equal("碎屑", debris.Id);
                Assert.Equal(SemanticTarget.Hand, debris.Target);
                Assert.Equal(1, debris.Amount);
            });
    }

    [Fact]
    public void CompilesFisticuffsDamageToBlockConversion()
    {
        var result = CardTextSemanticCompiler.Compile(
            "造成7点伤害。获得等量于所造成伤害的格挡。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations.Skip(1));
        Assert.Equal(CardSemanticKind.DynamicBlock, operation.Kind);
        Assert.Equal("DAMAGE_DEALT_THIS_CARD", operation.Id);
        Assert.Equal(SemanticTarget.Self, operation.Target);
    }

    [Fact]
    public void CompilesEchoingSlashKillRepeats()
    {
        var result = CardTextSemanticCompiler.Compile(
            "对所有敌人造成10点伤害。每有一名敌人被击杀，就重复此效果。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.Damage, operation.Kind);
        Assert.True(operation.RepeatByKillCount);
        Assert.Equal(SemanticTarget.AllEnemies, operation.Target);
        Assert.Equal(10, operation.Amount);
    }

    [Theory]
    [InlineData("每当有一张牌被消耗，抽1张牌。", CardSemanticKind.Draw)]
    [InlineData("每当有一张牌被消耗，获得4点格挡。", CardSemanticKind.Block)]
    public void CompilesExhaustTriggersAsSimulatorOperations(string text, CardSemanticKind kind)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal("CARD_EXHAUSTED", operation.Trigger);
        Assert.Equal(kind, operation.Kind);
    }

    [Fact]
    public void PreservesKnownTimingAndTriggerSemanticsWithoutCallingThemImmediate()
    {
        var result = CardTextSemanticCompiler.Compile(
            "在你的回合开始时，抽1张牌。每当你打出一张牌，都获得1点格挡。");

        Assert.True(result.IsFullyStructured);
        Assert.False(result.IsImmediatelyExecutable);
        Assert.False(result.IsSimulatorExecutable);
        Assert.Equal("turn_start", result.Operations[0].Timing);
        Assert.Equal("CARD_PLAYED", result.Operations[1].Trigger);
    }

    [Fact]
    public void NextTurnEnergyAndDrawAreSimulatorExecutable()
    {
        var result = CardTextSemanticCompiler.Compile("在下个回合，获得能量能量。下一回合抽1张牌。");

        Assert.True(result.IsFullyStructured);
        Assert.False(result.IsImmediatelyExecutable);
        Assert.True(result.IsSimulatorExecutable);
        Assert.All(result.Operations, operation => Assert.Equal("next_turn", operation.Timing));
    }

    [Fact]
    public void CompilesRandomDamageAndAllEnemyDebuffTargets()
    {
        var result = CardTextSemanticCompiler.Compile("随机对敌人造成4点伤害3次。给予所有敌人2层虚弱。");

        Assert.True(result.IsFullyStructured);
        Assert.Equal(SemanticTarget.RandomEnemy, result.Operations[0].Target);
        Assert.Equal(3, result.Operations[0].Repeat);
        Assert.Equal(SemanticTarget.AllEnemies, result.Operations[1].Target);
        Assert.True(result.IsSimulatorExecutable);
    }

    [Theory]
    [InlineData("生成1个闪电充能球。", "闪电")]
    [InlineData("生成2个冰霜充能球。", "冰霜")]
    [InlineData("生成1个黑暗充能球。", "黑暗")]
    [InlineData("生成1个等离子充能球。", "等离子")]
    public void ImmediateKnownOrbGenerationIsSimulatorExecutable(string text, string orb)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ChannelOrb, operation.Kind);
        Assert.Equal(orb, operation.Id);
    }

    [Theory]
    [InlineData("激发你最右侧的充能球两次。", "RIGHTMOST", 2, false, 0)]
    [InlineData("激发你的所有充能球两次。", "ALL", 2, false, 0)]
    [InlineData("激发你最右侧的充能球X+1次。", "RIGHTMOST", 1, true, 1)]
    public void CompilesKnownOrbEvokeForms(string text, string position, int amount, bool byEnergy, int bonus)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.EvokeOrb, operation.Kind);
        Assert.Equal(position, operation.Id);
        Assert.Equal(amount, operation.Amount);
        Assert.Equal(byEnergy, operation.AmountByEnergySpent);
        Assert.Equal(bonus, operation.XBonus);
    }

    [Theory]
    [InlineData("获得2个充能球栏位。", 2)]
    [InlineData("失去1个充能球栏位。", -1)]
    public void CompilesOrbCapacityChanges(string text, int delta)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ModifyOrbCapacity, operation.Kind);
        Assert.Equal(delta, operation.Amount);
    }

    [Theory]
    [InlineData("生成X个闪电充能球。", "闪电", true, false, 0)]
    [InlineData("生成X+1个闪电充能球。", "闪电", true, false, 1)]
    [InlineData("当前每有一名敌人，就生成1个冰霜充能球。", "冰霜", false, true, 0)]
    public void CompilesScaledOrbGeneration(string text, string orb, bool byEnergy, bool byEnemies, int bonus)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ChannelOrb, operation.Kind);
        Assert.Equal(orb, operation.Id);
        Assert.Equal(byEnergy, operation.AmountByEnergySpent);
        Assert.Equal(byEnemies, operation.AmountByAliveEnemyCount);
        Assert.Equal(bonus, operation.XBonus);
    }

    [Fact]
    public void CompilesDamageRepeatedByCurrentOrbCount()
    {
        var result = CardTextSemanticCompiler.Compile("当前每有一个充能球，造成5点伤害。");

        Assert.True(result.IsSimulatorExecutable);
        Assert.True(Assert.Single(result.Operations).RepeatByOrbCount);
    }

    [Theory]
    [InlineData("触发所有黑暗充能球的被动。", "黑暗", SemanticTarget.Self, 1)]
    [InlineData("触发所有黑暗充能球的被动两次。", "黑暗", SemanticTarget.Self, 2)]
    [InlineData("对该敌人触发你的所有闪电充能球的被动 两次。", "闪电", SemanticTarget.SelectedEnemy, 2)]
    public void CompilesExplicitOrbPassiveTriggers(string text, string orb, SemanticTarget target, int repeat)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.TriggerOrbPassive, operation.Kind);
        Assert.Equal(orb, operation.Id);
        Assert.Equal(target, operation.Target);
        Assert.Equal(repeat, operation.Amount);
    }

    [Theory]
    [InlineData("你每有一种不同的充能球，就抽一张牌。", CardSemanticKind.Draw, 1, "immediate")]
    [InlineData("你每有一种不同的充能球，就在本回合获得2点集中。", CardSemanticKind.ApplyStatus, 2, "this_turn")]
    [InlineData("在你的回合开始时，你每有一种不同的充能球，就获得3点格挡。", CardSemanticKind.DynamicBlock, 3, "turn_start")]
    public void CompilesEffectsScaledByDistinctOrbTypes(string text, CardSemanticKind kind, int amount, string timing)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(kind, operation.Kind);
        Assert.Equal(amount, operation.Amount);
        Assert.Equal(timing, operation.Timing);
        Assert.True(operation.AmountByDistinctOrbTypes);
    }

    [Theory]
    [InlineData("获得15点格挡。你每拥有一点力量，这张牌就额外获得5点格挡。", 15, 5)]
    [InlineData("获得16点格挡。你每拥有1点力量，此牌就额外获得8点格挡。", 16, 8)]
    public void CompilesExpectAFightStrengthScaledBlock(string text, int baseBlock, int blockPerStrength)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        Assert.Equal(2, result.Operations.Length);
        Assert.Equal(baseBlock, result.Operations[0].Amount);
        Assert.Equal(CardSemanticKind.DynamicBlock, result.Operations[1].Kind);
        Assert.Equal(blockPerStrength, result.Operations[1].Amount);
        Assert.Equal("PLAYER_STRENGTH", result.Operations[1].Id);
    }

    [Fact]
    public void CompilesHyperbeamTemporaryFocusLoss()
    {
        var result = CardTextSemanticCompiler.Compile(
            "对所有敌人造成24点伤害。在本回合失去3点集中。");

        Assert.True(result.IsSimulatorExecutable);
        Assert.Equal(2, result.Operations.Length);
        var focus = result.Operations[1];
        Assert.Equal(CardSemanticKind.ApplyStatus, focus.Kind);
        Assert.Equal("FOCUS", focus.Id);
        Assert.Equal(-3m, focus.Amount);
        Assert.Equal("this_turn", focus.Timing);
    }

    [Fact]
    public void CompilesVerifiedDelayedOrbEffects()
    {
        var frostDamage = CardTextSemanticCompiler.Compile(
            "在你的回合结束时，如果你有冰霜充能球，则对所有敌人造成6点伤害。");
        var rightmost = CardTextSemanticCompiler.Compile(
            "在你的回合开始时，触发你最右侧的一个充能球的被动能力2次。");
        var scheduled = CardTextSemanticCompiler.Compile(
            "在下2个回合开始时,生成1个闪电充能球。");

        Assert.True(frostDamage.IsSimulatorExecutable);
        Assert.Equal("HAS_FROST_ORB", Assert.Single(frostDamage.Operations).Condition);
        Assert.True(rightmost.IsSimulatorExecutable);
        Assert.Equal("RIGHTMOST_ANY", Assert.Single(rightmost.Operations).Id);
        Assert.True(scheduled.IsSimulatorExecutable);
        Assert.Equal("next_2_turn_starts", Assert.Single(scheduled.Operations).Timing);
    }

    [Fact]
    public void CompilesRandomOrbGenerationAsAChanceCapableOperation()
    {
        var result = CardTextSemanticCompiler.Compile("生成2个随机充能球。");

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ChannelOrb, operation.Kind);
        Assert.Equal("RANDOM", operation.Id);
        Assert.Equal(2m, operation.Amount);
    }

    [Theory]
    [InlineData("你在本回合内不能再抽任何牌。", CardSemanticKind.ApplyStatus, "CANNOT_DRAW")]
    [InlineData("你在本回合内不能再获得能量。", CardSemanticKind.ApplyStatus, "CANNOT_GAIN_ENERGY")]
    [InlineData("将你的能量翻倍。", CardSemanticKind.GainEnergy, "CURRENT_ENERGY")]
    [InlineData("将你当前的格挡翻倍。", CardSemanticKind.DynamicBlock, "PLAYER_BLOCK")]
    [InlineData("击晕该敌人。", CardSemanticKind.ApplyStatus, "STUN")]
    public void CompilesCurrentTurnRuleAndDynamicResourceEffects(string text, CardSemanticKind kind, string id)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(kind, operation.Kind);
        Assert.Equal(id, operation.Id);
    }

    [Fact]
    public void CompilesHandCostEnemyResetAndMaximumHpEffects()
    {
        var result = CardTextSemanticCompiler.Compile(
            "你手牌中的所有牌在本回合免费打出。去除敌人身上的所有格挡值和人工制品。失去1点最大生命。");

        Assert.True(result.IsSimulatorExecutable);
        Assert.Collection(result.Operations,
            operation => Assert.Equal(CardSemanticKind.ModifyHandCosts, operation.Kind),
            operation => Assert.Equal(CardSemanticKind.ClearEnemyBlockAndArtifact, operation.Kind),
            operation =>
            {
                Assert.Equal(CardSemanticKind.ModifyMaxHp, operation.Kind);
                Assert.Equal(-1m, operation.Amount);
            });
    }

    [Fact]
    public void CompilesPermanentSelfCostIncreaseAndAttackCountEnergy()
    {
        var cost = CardTextSemanticCompiler.Compile("这张牌的耗能加1。");
        var energy = CardTextSemanticCompiler.Compile("你的手牌中每有一张攻击牌，就获得能量。");

        Assert.True(cost.IsSimulatorExecutable);
        Assert.Equal(CardSemanticKind.ModifyCost, Assert.Single(cost.Operations).Kind);
        Assert.True(energy.IsSimulatorExecutable);
        Assert.True(Assert.Single(energy.Operations).AmountByHandAttackCount);
    }

    [Fact]
    public void NormalizesLeadingConjunctionAndNextTurnDrawEnergy()
    {
        var result = CardTextSemanticCompiler.Compile("造成5点伤害。并给予2层易伤。下个回合，抽2张牌并获得能量能量。");

        Assert.True(result.IsFullyStructured);
        Assert.Equal(3, result.Operations.Length);
        Assert.Equal("next_turn", result.Operations[2].Timing);
        Assert.Equal("能量能量", result.Operations[2].Id);
    }

    [Fact]
    public void CompilesUpToDiscardPileRecoveryAsVariableChoice()
    {
        var result = CardTextSemanticCompiler.Compile("将你弃牌堆中的至多2张牌放入你的手牌。");

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.MoveCard, operation.Kind);
        Assert.Equal("CHOOSE_DISCARD_UP_TO_TO_HAND", operation.Id);
        Assert.Equal(2m, operation.Amount);
    }

    [Fact]
    public void CompilesDiscardPileTopdeckEnemyStrengthAndInHandHpLossVariants()
    {
        var topdeck = CardTextSemanticCompiler.Compile("将你弃牌堆中的一张牌放到抽牌堆顶部。");
        var strength = CardTextSemanticCompiler.Compile("该敌人获得1点力量。");
        var hpLoss = CardTextSemanticCompiler.Compile("在你的回合结束时，如果这张牌在你的手牌中，你失去6点生命。");

        Assert.True(topdeck.IsSimulatorExecutable);
        Assert.Equal("CHOOSE_DISCARD_ANY_TO_DRAW_TOP", Assert.Single(topdeck.Operations).Id);
        Assert.True(strength.IsSimulatorExecutable);
        Assert.Equal("STRENGTH", Assert.Single(strength.Operations).Id);
        Assert.True(hpLoss.IsSimulatorExecutable);
        var loss = Assert.Single(hpLoss.Operations);
        Assert.Equal("turn_end", loss.Timing);
        Assert.Equal(6m, loss.Amount);
    }

    [Theory]
    [InlineData("造成6点伤害。你每有一张名字中含有“打击”的牌，伤害+2。", "STRIKE_CARD_COUNT", 6, 2)]
    [InlineData("造成6点伤害。你的消耗牌堆中每有一张牌，伤害增加3。", "EXHAUST_PILE_COUNT", 6, 3)]
    [InlineData("造成4点伤害。该敌人身上每有一层易伤就额外造成2点伤害。", "TARGET_STATUS:VULNERABLE", 4, 2)]
    public void FusesAdditiveDamageModifiersIntoOneAttack(string text, string source, int baseDamage, int perItem)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.DynamicDamage, operation.Kind);
        Assert.Equal(source, operation.Id);
        Assert.Equal(baseDamage, operation.Amount);
        Assert.Equal(perItem, operation.XBonus);
    }

    [Fact]
    public void CompilesConditionalExtraHitByCopyingThePreviousAttack()
    {
        var result = CardTextSemanticCompiler.Compile("造成8点伤害。如果该敌人有易伤状态，则攻击两次。");

        Assert.True(result.IsSimulatorExecutable);
        Assert.Equal(2, result.Operations.Length);
        Assert.Equal(8m, result.Operations[1].Amount);
        Assert.Equal("TARGET_HAS_VULNERABLE", result.Operations[1].Condition);
    }

    [Fact]
    public void CompilesSecondWindAsAnAtomicFilteredExhaust()
    {
        var result = CardTextSemanticCompiler.Compile("消耗手牌中所有非攻击牌，每张获得5点格挡。");

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ExhaustNonAttacksAndBlock, operation.Kind);
        Assert.Equal(5m, operation.Amount);
    }

    [Fact]
    public void CompilesSelfTopdeckAndAllZeroCostDiscardRecovery()
    {
        var topdeck = CardTextSemanticCompiler.Compile("将这张牌放置于你的抽牌堆顶部。");
        var recovery = CardTextSemanticCompiler.Compile("将你弃牌堆中的所有0能量牌放入你的手牌。");

        Assert.True(topdeck.IsSimulatorExecutable);
        Assert.Equal("SELF_TO_DRAW_TOP", Assert.Single(topdeck.Operations).Id);
        Assert.True(recovery.IsSimulatorExecutable);
        var operation = Assert.Single(recovery.Operations);
        Assert.Equal("ALL_ZERO_COST_DISCARD_TO_HAND", operation.Id);
        Assert.True(operation.All);
    }

    [Theory]
    [InlineData("你打出的下一张攻击牌耗能变为0能量。", "NEXT_FREE_ATTACK")]
    [InlineData("你的下一张技能牌耗能变为0能量。", "NEXT_FREE_SKILL")]
    [InlineData("你打出的下一张能力牌耗能变为0能量。", "NEXT_FREE_POWER")]
    [InlineData("你打出的下一张虚无牌耗能变为0能量。", "NEXT_FREE_ETHEREAL")]
    public void CompilesOneShotTypeLimitedFreeCardRules(string text, string status)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal(status, operation.Id);
        Assert.Equal("this_turn", operation.Timing);
    }

    [Theory]
    [InlineData("你在本回合中每打出过一张攻击牌，其耗能减少1能量。", "SELF_BY_ATTACKS_PLAYED")]
    [InlineData("你在本回合中每打出过一张技能牌，其耗能减少1能量。", "SELF_BY_SKILLS_PLAYED")]
    public void CompilesCostReductionByCardsPlayedAfterSnapshot(string text, string id)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ModifyCost, operation.Kind);
        Assert.Equal(id, operation.Id);
    }

    [Fact]
    public void CompilesBlurAndSnapshotCurrentBlockForNextTurn()
    {
        var blur = CardTextSemanticCompiler.Compile("你的下一回合开始时格挡不会消失。");
        var prolong = CardTextSemanticCompiler.Compile("在下个回合获得等量于你当前格挡值的格挡。");

        Assert.True(blur.IsSimulatorExecutable);
        Assert.Equal("BLUR", Assert.Single(blur.Operations).Id);
        Assert.True(prolong.IsSimulatorExecutable);
        var operation = Assert.Single(prolong.Operations);
        Assert.Equal(CardSemanticKind.DynamicBlock, operation.Kind);
        Assert.Equal("next_turn_snapshot", operation.Timing);
    }

    [Fact]
    public void CompilesReboundFixedSoulGenerationAndSelfCopy()
    {
        var rebound = CardTextSemanticCompiler.Compile("将你在本回合打出的下一张牌放置到你的抽牌堆顶部。");
        var soul = CardTextSemanticCompiler.Compile("将一张灵魂放入你的抽牌堆中。");
        var upgradedSoul = CardTextSemanticCompiler.Compile("将一张灵魂+加入你的抽牌堆。");
        var captureSouls = CardTextSemanticCompiler.Compile("将3张灵魂加入你的抽牌堆。");
        var copy = CardTextSemanticCompiler.Compile("在弃牌堆放入一张此牌的复制品。");
        var threePiles = CardTextSemanticCompiler.Compile("将一张灵魂分别加入你的抽牌堆，手牌和弃牌堆中。");

        Assert.True(rebound.IsSimulatorExecutable);
        Assert.Equal("NEXT_CARD_TO_DRAW_TOP", Assert.Single(rebound.Operations).Id);
        Assert.True(soul.IsSimulatorExecutable);
        Assert.Equal(SemanticTarget.DrawPile, Assert.Single(soul.Operations).Target);
        Assert.True(upgradedSoul.IsSimulatorExecutable);
        Assert.Equal("灵魂+", Assert.Single(upgradedSoul.Operations).Id);
        Assert.True(captureSouls.IsSimulatorExecutable);
        Assert.Equal(3m, Assert.Single(captureSouls.Operations).Amount);
        Assert.Equal(SemanticTarget.DrawPile, Assert.Single(captureSouls.Operations).Target);
        Assert.True(copy.IsSimulatorExecutable);
        Assert.Equal("SELF_COPY", Assert.Single(copy.Operations).Id);
        Assert.True(threePiles.IsSimulatorExecutable);
        Assert.Equal(3, threePiles.Operations.Length);
    }

    [Fact]
    public void CompilesPersistentTurnStartEnergyAndDraw()
    {
        var energy = CardTextSemanticCompiler.Compile("在每个回合开始时获得能量。");
        var draw = CardTextSemanticCompiler.Compile("在你的回合开始时，额外抽1张牌。");
        var combined = CardTextSemanticCompiler.Compile("在你的回合开始时，获得能量并额外多抽1张牌。");

        Assert.True(energy.IsSimulatorExecutable);
        Assert.Equal("TURN_START_ENERGY", Assert.Single(energy.Operations).Id);
        Assert.True(draw.IsSimulatorExecutable);
        Assert.Equal("TURN_START_DRAW", Assert.Single(draw.Operations).Id);
        Assert.True(combined.IsSimulatorExecutable);
        Assert.Equal(["TURN_START_ENERGY", "TURN_START_DRAW"], combined.Operations.Select(static operation => operation.Id));
        Assert.All(combined.Operations, operation => Assert.Equal("persistent_turn_start", operation.Timing));
    }

    [Theory]
    [InlineData("你每打出一张牌，都获得1点格挡。", CardSemanticKind.Block, "CARD_PLAYED", 1)]
    [InlineData("当你打出一张能力牌时，获得能量。", CardSemanticKind.GainEnergy, "POWER_PLAYED", 1)]
    [InlineData("每当你打出一张能力牌时，生成2个闪电充能球。", CardSemanticKind.ChannelOrb, "POWER_PLAYED", 2)]
    [InlineData("每当你打出一张虚无牌时，获得5点格挡。", CardSemanticKind.Block, "ETHEREAL_PLAYED", 5)]
    public void CompilesSupportedCardPlayedTriggers(string text, CardSemanticKind kind, string trigger, int amount)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(kind, operation.Kind);
        Assert.Equal(trigger, operation.Trigger);
        Assert.Equal(amount, operation.Amount);
    }

    [Theory]
    [InlineData("每当你打出一张耗能大于等于能量能量的牌时，获得4点格挡。", 4)]
    [InlineData("每当你打出耗能为能量能量或以上的牌，获得6点格挡。", 6)]
    public void CompilesActualEnergyThresholdBlockTrigger(string text, int amount)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.Block, operation.Kind);
        Assert.Equal("ENERGY_THRESHOLD_PLAYED", operation.Trigger);
        Assert.Equal("ENERGY_AT_LEAST_2", operation.Id);
        Assert.Equal(amount, operation.Amount);
    }

    [Fact]
    public void CompilesCorruptionAsPersistentSkillCostAndDestinationRules()
    {
        var result = CardTextSemanticCompiler.Compile("技能牌消耗变为0能量。每当你打出一张技能牌时，将其消耗。");

        Assert.True(result.IsSimulatorExecutable);
        Assert.Equal(["SKILLS_COST_ZERO", "SKILLS_EXHAUST_ON_PLAY"], result.Operations.Select(static operation => operation.Id));
        Assert.All(result.Operations, operation => Assert.Equal("persistent_combat", operation.Timing));
    }

    [Theory]
    [InlineData("你每回合打出的第一张耗能为0能量的攻击牌，会放回你的手牌。", "FERAL_ZERO_COST_ATTACK_RETURN")]
    [InlineData("你每回合打出的第一张 耗能为016px|link=能量的攻击牌， 会放回你的手牌。", "FERAL_ZERO_COST_ATTACK_RETURN")]
    [InlineData("The first time you play a 0[能量] Attack each turn, return it to your Hand.", "FERAL_ZERO_COST_ATTACK_RETURN")]
    [InlineData("The first time you play a 016px|link= Attack each turn, return it to your Hand.", "FERAL_ZERO_COST_ATTACK_RETURN")]
    [InlineData("每回合首次打出攻击或技能牌时，将其置于你的抽牌堆顶端。", "NOSTALGIA_ATTACK_SKILL_TOPDECK")]
    [InlineData("将你每回合打出第一张攻击或技能牌，置于你的抽牌堆顶端。", "NOSTALGIA_ATTACK_SKILL_TOPDECK")]
    public void CompilesPerTurnCardDestinationPowers(string text, string statusId)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal(statusId, operation.Id);
        Assert.Equal("persistent_combat", operation.Timing);
        Assert.Equal(1m, operation.Amount);
    }

    [Theory]
    [InlineData("你每回合打出的第一张牌会被打出两次。", "ECHO_FORM_REPLAY_FIRST_CARDS", 1, "persistent_combat")]
    [InlineData("你的下一张能力牌会额外打出一次。", "NEXT_POWER_REPLAY", 1, "persistent_until_consumed")]
    [InlineData("在这个回合，你打出的下1张攻击牌会被额外打出一次。", "NEXT_ATTACK_REPLAY", 1, "this_turn")]
    [InlineData("在这个回合，你打出的下2张攻击牌会被额外打出一次。", "NEXT_ATTACK_REPLAY", 2, "this_turn")]
    [InlineData("在这个回合，你打出的下一张技能牌会被额外打出一次。", "NEXT_SKILL_REPLAY", 1, "this_turn")]
    [InlineData("在这个回合，你打出的下张技能牌会被额外打出一次。", "NEXT_SKILL_REPLAY", 1, "this_turn")]
    [InlineData("在这个回合，你打出的下2张技能牌会被额外打出一次。", "NEXT_SKILL_REPLAY", 2, "this_turn")]
    [InlineData("This turn, your next Skill is played an extra time.", "NEXT_SKILL_REPLAY", 1, "this_turn")]
    [InlineData("This turn, your next 2 Skills are played an extra time.", "NEXT_SKILL_REPLAY", 2, "this_turn")]
    public void CompilesCardReplayRulesAcrossHistoricalWording(string text, string statusId, int amount, string timing)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal(statusId, operation.Id);
        Assert.Equal(amount, operation.Amount);
        Assert.Equal(timing, operation.Timing);
    }

    [Theory]
    [InlineData("格挡不再在你的回合开始时消失。", CardSemanticKind.ApplyStatus, "BARRICADE", SemanticTarget.Self)]
    [InlineData("将此牌返回你的手牌。", CardSemanticKind.MoveCard, "SELF_TO_HAND", SemanticTarget.Hand)]
    [InlineData("将弃牌堆中的一张牌放到你的抽牌堆的顶部。", CardSemanticKind.MoveCard, "CHOOSE_DISCARD_ANY_TO_DRAW_TOP", SemanticTarget.DiscardPile)]
    [InlineData("将你手牌中的1张牌放到抽牌堆顶部。", CardSemanticKind.MoveCard, "CHOOSE_HAND_ANY_TO_DRAW_TOP", SemanticTarget.Hand)]
    [InlineData("将手牌中的一张牌放到抽牌堆顶部。", CardSemanticKind.MoveCard, "CHOOSE_HAND_ANY_TO_DRAW_TOP", SemanticTarget.Hand)]
    [InlineData("将手牌中的一张牌放到你的抽牌堆的顶端。", CardSemanticKind.MoveCard, "CHOOSE_HAND_ANY_TO_DRAW_TOP", SemanticTarget.Hand)]
    public void CompilesDeterministicBlockAndCardMovementRules(
        string text,
        CardSemanticKind kind,
        string id,
        SemanticTarget target)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(kind, operation.Kind);
        Assert.Equal(id, operation.Id);
        Assert.Equal(target, operation.Target);
    }

    [Theory]
    [InlineData("将这张牌的一张0能量复制品添加到你的弃牌堆。")]
    [InlineData("将这张牌的一张0[能量]复制品添加到你的弃牌堆。")]
    [InlineData("将这张牌的一张016px|link=复制品添加到你的弃牌堆。")]
    [InlineData("将这张牌的一张016px|link=能量复制品添加到你的弃牌堆。")]
    public void CompilesAdaptiveStrikeZeroCostSelfCopyAcrossCapturedWording(string text)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.GenerateCard, operation.Kind);
        Assert.Equal("SELF_COPY_ZERO_COST", operation.Id);
        Assert.Equal(SemanticTarget.DiscardPile, operation.Target);
    }

    [Fact]
    public void CompilesHeirloomHammerSelectionAndSelectedCardCopyAsTwoTypedStages()
    {
        var result = CardTextSemanticCompiler.Compile(
            "造成20点伤害。选择你手牌中的一张无色牌。将这张牌的一张复制品放入你的手牌。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        Assert.Collection(
            result.Operations,
            damage => Assert.Equal(CardSemanticKind.Damage, damage.Kind),
            select =>
            {
                Assert.Equal(CardSemanticKind.SelectCard, select.Kind);
                Assert.Equal("HAND_COLORLESS", select.Id);
                Assert.Equal(SemanticTarget.Hand, select.Target);
            },
            copy =>
            {
                Assert.Equal(CardSemanticKind.CopySelectedCard, copy.Kind);
                Assert.Equal("SELECTED_TO_HAND", copy.Id);
                Assert.Equal(SemanticTarget.Hand, copy.Target);
            });
    }

    [Theory]
    [InlineData("卡牌在本回合耗能增加能量。")]
    [InlineData("所有卡牌在本回合耗能增加能量。")]
    public void CompilesBorrowedTimeAsCurrentTurnGlobalCostIncrease(string clause)
    {
        var result = CardTextSemanticCompiler.Compile(clause);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal("ALL_CARD_COST_DELTA", operation.Id);
        Assert.Equal(1m, operation.Amount);
        Assert.Equal("this_turn", operation.Timing);
    }

    [Theory]
    [InlineData("只有在手牌中每一张牌都是攻击牌时才能被打出。", "HAND_ALL_ATTACKS")]
    [InlineData("只有当你的抽牌堆中没有牌时才能打出。", "DRAW_PILE_EMPTY")]
    public void CompilesStateDependentPlayRestrictions(string text, string id)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.PlayRestriction, operation.Kind);
        Assert.Equal(id, operation.Id);
    }

    [Theory]
    [InlineData("使一名敌人在本回合失去9点力量。", SemanticTarget.SelectedEnemy, 9)]
    [InlineData("让一名敌人在本回合内失去11点力量。", SemanticTarget.SelectedEnemy, 11)]
    [InlineData("所有敌人在本回合中失去9点力量。", SemanticTarget.AllEnemies, 9)]
    [InlineData("所有敌人在本回合失去6点力量。", SemanticTarget.AllEnemies, 6)]
    public void CompilesTemporaryEnemyStrengthLoss(string text, SemanticTarget target, int amount)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal("TEMP_STRENGTH_LOSS", operation.Id);
        Assert.Equal("this_turn", operation.Timing);
        Assert.Equal(target, operation.Target);
        Assert.Equal(amount, operation.Amount);
    }

    [Fact]
    public void CompilesPreciseCutAsBaseDamageMinusRemainingHandCount()
    {
        var result = CardTextSemanticCompiler.Compile(
            "造成13点伤害。你的手牌中每有一张牌，此牌的伤害就降低2点。");

        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.DynamicDamage, operation.Kind);
        Assert.Equal("HAND_CARD_COUNT", operation.Id);
        Assert.Equal(13m, operation.Amount);
        Assert.Equal(-2, operation.XBonus);
    }

    [Theory]
    [InlineData("造成24点伤害。如果这张牌击杀了敌人，则获得能量能量能量。")]
    [InlineData("造成24点伤害。 如果这张牌击杀了敌人，则获得[能量][能量][能量]。")]
    [InlineData("造成24点伤害。 如果这张牌击杀了敌人，则获得16px|link=16px|link=16px|link=。")]
    public void CompilesSunderKillEnergyAcrossCapturedIconForms(string text)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsSimulatorExecutable);
        Assert.Collection(result.Operations,
            damage => Assert.Equal(CardSemanticKind.Damage, damage.Kind),
            energy =>
            {
                Assert.Equal(CardSemanticKind.GainEnergy, energy.Kind);
                Assert.Equal(3m, energy.Amount);
                Assert.Equal("SOURCE_CARD_KILLED", energy.Condition);
            });
    }

    [Fact]
    public void CompilesDoomExecutionBlockDoublingAndEnemyHpLoss()
    {
        var doom = CardTextSemanticCompiler.Compile(
            "给予所有敌人29层灾厄。杀死所有灾厄大于等于当前生命值的敌人。");
        var shadowmeld = CardTextSemanticCompiler.Compile("本回合你获得的格挡值翻倍。");
        var hpLoss = CardTextSemanticCompiler.Compile("敌人失去3点生命。");

        Assert.True(doom.IsSimulatorExecutable);
        Assert.Equal(CardSemanticKind.KillAllDoomedEnemies, doom.Operations[1].Kind);
        Assert.Equal("DOOM_AT_LEAST_HP", doom.Operations[1].Id);
        Assert.True(shadowmeld.IsSimulatorExecutable);
        Assert.Equal("DOUBLE_BLOCK_GAINED", Assert.Single(shadowmeld.Operations).Id);
        Assert.True(hpLoss.IsSimulatorExecutable);
        Assert.Equal(CardSemanticKind.LoseEnemyHp, Assert.Single(hpLoss.Operations).Kind);
    }

    [Theory]
    [InlineData("手牌中每有一张技能牌，造成5点伤害。", "HAND_SKILL_COUNT", 5)]
    [InlineData("在这个回合内每打出过一张攻击牌，就造成8点伤害一次。", "ATTACKS_PLAYED_THIS_TURN", 8)]
    [InlineData("本回合中每打出过一张技能牌，此牌额外造成4点伤害一次。", "SKILLS_PLAYED_THIS_TURN", 4)]
    [InlineData("本场战斗中每打出过一张虚无牌，此牌就造成7点伤害一次。", "ETHEREAL_PLAYED_THIS_COMBAT", 7)]
    public void CompilesCounterBasedRepeatedDamage(string text, string counter, int damage)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.DynamicDamage, operation.Kind);
        Assert.Equal(counter, operation.Id);
        Assert.Equal(damage, operation.Amount);
        Assert.True(operation.RepeatByHistoryCounter);
    }

    [Theory]
    [InlineData("造成本场战斗中所打出牌数的伤害。", "CARDS_PLAYED_THIS_COMBAT", 1, 0)]
    [InlineData("造成1点伤害。你在本场战斗中每抽过一张牌，此牌就额外造成1点伤害。", "CARDS_DRAWN_THIS_COMBAT", 1, 1)]
    [InlineData("造成5点伤害。你在本场战斗中每生成过一张牌，这张牌就额外造成4点伤害。", "CARDS_GENERATED_THIS_COMBAT", 5, 4)]
    public void CompilesCombatHistoryCounterDamage(string text, string counter, int baseDamage, int multiplier)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.DynamicDamage, operation.Kind);
        Assert.Equal(counter, operation.Id);
        Assert.Equal(baseDamage, operation.Amount);
        Assert.Equal(multiplier, operation.XBonus);
        Assert.False(operation.RepeatByHistoryCounter);
    }

    [Theory]
    [InlineData("你每抽10张牌，获得能量。", "AUTOMATION_DRAW_ENERGY", 10)]
    [InlineData("你每花费4能量，就获得能量。", "ORBIT_ENERGY_REBATE", 4)]
    public void CompilesPersistentEnergyCounterPowers(string text, string statusId, int threshold)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal(statusId, operation.Id);
        Assert.Equal(1m, operation.Amount);
        Assert.Equal(threshold, operation.XBonus);
        Assert.Equal("persistent_combat", operation.Timing);
    }

    [Theory]
    [InlineData("本场战斗中每打出过一张虚无牌，此牌的耗能就减少能量能量。")]
    [InlineData("本场战斗中每打出过一张虚无牌，此牌费用就减少[能量][能量]。")]
    [InlineData("本场战斗中每打出过一张虚无牌，此牌费用就减少16px|link=16px|link=。")]
    [InlineData("本场战斗中每打出过一张虚无牌，此牌费用就减少16px|link=能量16px|link=能量。")]
    public void CompilesBansheesCryEtherealCostProgressionAcrossVersions(string text)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ModifyCost, operation.Kind);
        Assert.Equal("SELF_BY_ETHEREAL_PLAYED", operation.Id);
        Assert.Equal(-2m, operation.Amount);
    }

    [Theory]
    [InlineData("获得3点活力。", 3, "immediate")]
    [InlineData("在你的回合开始时，获得6点活力。", 6, "turn_start")]
    public void CompilesImmediateAndRecurringVigor(string text, int amount, string timing)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal("VIGOR", operation.Id);
        Assert.Equal(amount, operation.Amount);
        Assert.Equal(timing, operation.Timing);
    }

    [Fact]
    public void CompilesInfiniteBladesAsTurnStartShivGeneration()
    {
        var result = CardTextSemanticCompiler.Compile(
            "在你的回合开始时，在你的手牌中加入1张小刀。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.GenerateCard, operation.Kind);
        Assert.Equal("SHIV", operation.Id);
        Assert.Equal(SemanticTarget.Hand, operation.Target);
        Assert.Equal("turn_start", operation.Timing);
    }

    [Theory]
    [InlineData(8)]
    [InlineData(10)]
    public void CompilesCrimsonMantleAsOrderedTurnStartHpLossAndBlock(int block)
    {
        var result = CardTextSemanticCompiler.Compile(
            $"在你的回合开始时，失去1点生命并获得{block}点格挡。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        Assert.Collection(result.Operations,
            loseHp =>
            {
                Assert.Equal(CardSemanticKind.LoseHp, loseHp.Kind);
                Assert.Equal(1m, loseHp.Amount);
                Assert.Equal("turn_start", loseHp.Timing);
            },
            gainBlock =>
            {
                Assert.Equal(CardSemanticKind.Block, gainBlock.Kind);
                Assert.Equal(block, gainBlock.Amount);
                Assert.Equal("turn_start", gainBlock.Timing);
            });
    }

    [Theory]
    [InlineData("每回合失去1点能量", "MAX_ENERGY_DELTA")]
    [InlineData("每回合少抽1张牌", "HAND_DRAW_DELTA")]
    public void CompilesPersistentDerivedResourcePenalties(string text, string statusId)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal(statusId, operation.Id);
        Assert.Equal(-1m, operation.Amount);
        Assert.Equal("persistent_combat", operation.Timing);
    }

    [Theory]
    [InlineData("随机对敌人造成5点伤害X次", 5)]
    [InlineData("随机对敌人造成14点伤害X次", 14)]
    public void CompilesRandomEnergySpentDamage(string text, int amount)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.Damage, operation.Kind);
        Assert.Equal(SemanticTarget.RandomEnemy, operation.Target);
        Assert.Equal(amount, operation.Amount);
        Assert.True(operation.RepeatByEnergySpent);
        Assert.Equal("CombatTargets", operation.RandomSource);
    }

    [Theory]
    [InlineData("每回合你第一次抽到状态牌时，抽2张牌", 2)]
    [InlineData("每回合你第一次抽到状态牌时，抽3张牌", 3)]
    public void CompilesIterationFirstStatusDrawTrigger(string text, int amount)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal("ITERATION_DRAW", operation.Id);
        Assert.Equal(amount, operation.Amount);
        Assert.Equal("persistent_combat", operation.Timing);
    }

    [Theory]
    [InlineData("每当你抽到一张虚无牌时, 抽1张牌")]
    [InlineData("每当你抽到一张虚无牌时，抽1张牌")]
    public void CompilesPagestormEtherealDrawTrigger(string text)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal("PAGESTORM_DRAW", operation.Id);
        Assert.Equal(1, operation.Amount);
        Assert.Equal("persistent_combat", operation.Timing);
    }

    [Theory]
    [InlineData("打出此牌后，你在这个回合内每打出一张攻击牌，获得3点格挡。", 3)]
    [InlineData("打出此牌后，你在这个回合内每打出一张攻击牌，获得5点格挡。", 5)]
    public void CompilesRageAttackBlockTrigger(string text, int amount)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal("TRIGGER_ATTACK_PLAYED_BLOCK", operation.Id);
        Assert.Equal(amount, operation.Amount);
        Assert.Equal("this_turn", operation.Timing);
    }

    [Theory]
    [InlineData("每当你在本回合打出卡牌时，在本回合获得1点力量。")]
    [InlineData("每当你在本回合打出卡牌时, 在本回合获得1点力量。")]
    public void CompilesMonologueCardPlayedTemporaryStrength(string text)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal("STRENGTH", operation.Id);
        Assert.Equal(SemanticTarget.Self, operation.Target);
        Assert.Equal(1m, operation.Amount);
        Assert.Equal("this_turn", operation.Timing);
        Assert.Equal("CARD_PLAYED", operation.Trigger);
    }

    [Fact]
    public void CompilesMonologueUpgradeWithHistoricalClauseSpacing()
    {
        var result = CardTextSemanticCompiler.Compile(
            "保留。 每当你在本回合打出卡牌时，在本回合获得1点力量。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        Assert.Collection(result.Operations,
            retain =>
            {
                Assert.Equal(CardSemanticKind.Keyword, retain.Kind);
                Assert.Equal("保留", retain.Id);
            },
            strength =>
            {
                Assert.Equal(CardSemanticKind.ApplyStatus, strength.Kind);
                Assert.Equal("STRENGTH", strength.Id);
                Assert.Equal("CARD_PLAYED", strength.Trigger);
                Assert.Equal("this_turn", strength.Timing);
            });
    }

    [Theory]
    [InlineData("打出此牌后，你在本回合内每打出一张牌，就给予该敌人3层灾厄。", 3)]
    [InlineData("你在本回合内每打出一张牌，就给予该敌人3层灾厄。", 3)]
    [InlineData("打出此牌后, 你在本回合内每打出一张牌, 就给予该敌人4层灾厄。", 4)]
    [InlineData("你在本回合内每打出一张牌，就给予该敌人4层灾厄。", 4)]
    public void CompilesOblivionCurrentAndHistoricalWording(string text, int amount)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal("DOOM", operation.Id);
        Assert.Equal(SemanticTarget.SelectedEnemy, operation.Target);
        Assert.Equal(amount, operation.Amount);
        Assert.Equal("this_turn", operation.Timing);
        Assert.Equal("CARD_PLAYED", operation.Trigger);
    }

    [Theory]
    [InlineData("打出此牌后，你在本回合每抽到一张牌，就给予所有敌人2层中毒。", 2)]
    [InlineData("打出此牌后, 你在本回合每抽到一张牌, 就给予所有敌人3层中毒。", 3)]
    [InlineData("打出此牌后，你在本回合每抽到一张牌，就给予所有敌人4层中毒。", 4)]
    public void CompilesCorrosiveWaveDrawPoisonAcrossVersions(string text, int amount)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal("POISON", operation.Id);
        Assert.Equal(SemanticTarget.AllEnemies, operation.Target);
        Assert.Equal(amount, operation.Amount);
        Assert.Equal("this_turn", operation.Timing);
        Assert.Equal("CARD_DRAWN", operation.Trigger);
    }

    [Theory]
    [InlineData("每当你在回合进行中抽到一张牌时，对所有敌人造成2点伤害。", 2)]
    [InlineData("固有。每当你在回合进行中抽到一张牌时，对所有敌人造成2点伤害。", 2)]
    [InlineData("每当你在回合进行中抽到一张牌时, 对所有敌人造成3点伤害。", 3)]
    public void CompilesSpeedsterNonHandDrawDamageAcrossVersions(string text, int amount)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations.Where(item => item.Kind == CardSemanticKind.Damage));
        Assert.Equal(SemanticTarget.AllEnemies, operation.Target);
        Assert.Equal(amount, operation.Amount);
        Assert.Equal("immediate", operation.Timing);
        Assert.Equal("NON_HAND_CARD_DRAWN", operation.Trigger);
    }

    [Theory]
    [InlineData("获得12点格挡。你在这个回合每受到一次攻击，都会对攻击者造成4点伤害。", 12, 4)]
    [InlineData("获得12点格挡。 你在这个回合每受到一次攻击，都会对攻击者造成4点伤害。", 12, 4)]
    [InlineData("获得16点格挡。你在这个回合每受到一次攻击, 都会对攻击者造成6点伤害。", 16, 6)]
    public void CompilesFlameBarrierBlockAndPoweredAttackRetaliation(string text, int block, int damage)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        Assert.Collection(result.Operations,
            blockOperation =>
            {
                Assert.Equal(CardSemanticKind.Block, blockOperation.Kind);
                Assert.Equal(block, blockOperation.Amount);
            },
            retaliation =>
            {
                Assert.Equal(CardSemanticKind.Damage, retaliation.Kind);
                Assert.Equal(SemanticTarget.SelectedEnemy, retaliation.Target);
                Assert.Equal(damage, retaliation.Amount);
                Assert.Equal("this_turn", retaliation.Timing);
                Assert.Equal("POWERED_ATTACK_RECEIVED", retaliation.Trigger);
            });
    }

    [Fact]
    public void CompilesSculptingStrikeHandEtherealMutationAsAChoice()
    {
        var result = CardTextSemanticCompiler.Compile(
            "造成9点伤害。为一张手牌添加虚无。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        Assert.Collection(result.Operations,
            damage => Assert.Equal(CardSemanticKind.Damage, damage.Kind),
            select =>
            {
                Assert.Equal(CardSemanticKind.SelectCard, select.Kind);
                Assert.Equal("HAND_ANY_ADD_ETHEREAL", select.Id);
                Assert.Equal(SemanticTarget.Hand, select.Target);
            });
    }

    [Fact]
    public void CompilesPanicButtonCardBlockLockDuration()
    {
        var result = CardTextSemanticCompiler.Compile(
            "获得30点格挡。你在接下来的2回合内无法再从卡牌中获得格挡。消耗。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        Assert.Collection(result.Operations,
            block =>
            {
                Assert.Equal(CardSemanticKind.Block, block.Kind);
                Assert.Equal(30m, block.Amount);
            },
            lockout =>
            {
                Assert.Equal(CardSemanticKind.ApplyStatus, lockout.Kind);
                Assert.Equal("NO_BLOCK_FROM_CARDS", lockout.Id);
                Assert.Equal(SemanticTarget.Self, lockout.Target);
                Assert.Equal(2m, lockout.Amount);
            },
            exhaust => Assert.Equal("消耗", exhaust.Id));
    }

    [Fact]
    public void CompilesShadowStepNextTurnAttackDoubling()
    {
        var result = CardTextSemanticCompiler.Compile(
            "丢弃所有手牌。在下个回合，你所有的攻击伤害翻倍");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations.Where(item => item.Id == "NEXT_TURN_DOUBLE_DAMAGE"));
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal("next_turn", operation.Timing);
        Assert.Equal(SemanticTarget.Self, operation.Target);
    }

    [Fact]
    public void CompilesReaperFormAttackDamageDoomTrigger()
    {
        var result = CardTextSemanticCompiler.Compile(
            "每当你的攻击造成伤害时，同时给予等量的灾厄");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal("TRIGGER_ATTACK_DAMAGE_DOOM", operation.Id);
        Assert.Equal("persistent_combat", operation.Timing);
    }

    [Fact]
    public void CompilesColossusVulnerableEnemyAttackReduction()
    {
        var result = CardTextSemanticCompiler.Compile(
            "获得5点格挡。在本回合中，有易伤状态的敌人对你造成的伤害降低50%。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations.Where(item => item.Id == "REDUCE_VULNERABLE_ATTACK_DAMAGE"));
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal("this_turn", operation.Timing);
    }

    [Fact]
    public void CompilesReflectBlockedAttackDamageTrigger()
    {
        var result = CardTextSemanticCompiler.Compile(
            "获得15点格挡。在本回合将你格挡掉的攻击伤害反弹给攻击者。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations.Where(item => item.Id == "REFLECT_BLOCKED_ATTACK_DAMAGE"));
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal("this_turn", operation.Timing);
        Assert.Equal(SemanticTarget.Self, operation.Target);
    }

    [Theory]
    [InlineData("对虚弱状态的敌人，你所造成的攻击伤害翻倍。")]
    [InlineData("对虚弱状态的敌人，造成的攻击伤害翻倍。")]
    [InlineData("有虚弱状态的敌人，所受的攻击伤害翻倍。")]
    public void CompilesTrackingWeakTargetPoweredAttackBonus(string text)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal("BONUS_WEAK_TARGET_POWERED_ATTACK_DAMAGE_PERCENT", operation.Id);
        Assert.Equal(50m, operation.Amount);
        Assert.Equal("persistent_combat", operation.Timing);
    }

    [Fact]
    public void CompilesUnmovableFirstCardBlockDoubling()
    {
        var result = CardTextSemanticCompiler.Compile("翻倍你每回合第一次从卡牌中获得的格挡。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal("UNMOVABLE", operation.Id);
        Assert.Equal(1m, operation.Amount);
        Assert.Equal("persistent_combat", operation.Timing);
    }

    [Fact]
    public void CompilesScrapeDrawnNonZeroCostDiscard()
    {
        var result = CardTextSemanticCompiler.Compile("丢弃抽到的牌中耗能不为0能量的牌。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.Keyword, operation.Kind);
        Assert.Equal("DISCARD_DRAWN_NONZERO_COST", operation.Id);
    }

    [Theory]
    [InlineData("抽牌直至你的手牌有6张牌。", "TO_HAND_SIZE_RETAIN_DRAWN", 6)]
    [InlineData("抽牌直到抽满手牌。", "TO_HAND_SIZE", 10)]
    [InlineData("抽牌直到你抽到一张非攻击牌。", "UNTIL_NON_ATTACK", 1)]
    public void CompilesBoundedDrawForms(string text, string id, int amount)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.Draw, operation.Kind);
        Assert.Equal(id, operation.Id);
        Assert.Equal(amount, operation.Amount);
    }

    [Fact]
    public void CompilesEscapePlanDrawCondition()
    {
        var result = CardTextSemanticCompiler.Compile(
            "抽1张牌。如果抽到的是技能牌，则获得3点格挡。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        Assert.Collection(result.Operations,
            draw => Assert.Equal(CardSemanticKind.Draw, draw.Kind),
            block =>
            {
                Assert.Equal(CardSemanticKind.Block, block.Kind);
                Assert.Equal(3m, block.Amount);
                Assert.Equal("LAST_DRAWN_CARD_SKILL", block.Condition);
            });
    }

    [Fact]
    public void CompilesFillHandAndSelectedRetain()
    {
        var fill = CardTextSemanticCompiler.Compile("用碎屑填满你的手牌。");
        var retain = CardTextSemanticCompiler.Compile("给手牌中的一张牌添加保留。");

        Assert.True(fill.IsFullyStructured);
        Assert.True(fill.IsSimulatorExecutable);
        var generation = Assert.Single(fill.Operations);
        Assert.Equal(CardSemanticKind.GenerateCard, generation.Kind);
        Assert.Equal("碎屑", generation.Id);
        Assert.True(generation.All);

        Assert.True(retain.IsFullyStructured);
        Assert.True(retain.IsSimulatorExecutable);
        var selection = Assert.Single(retain.Operations);
        Assert.Equal(CardSemanticKind.SelectCard, selection.Kind);
        Assert.Equal("HAND_ANY_ADD_RETAIN", selection.Id);
    }

    [Fact]
    public void CompilesFiendFirePerExhaustedCardDamage()
    {
        var result = CardTextSemanticCompiler.Compile(
            "消耗所有手牌。每张被消耗的牌造成7点伤害。消耗。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var damage = Assert.Single(result.Operations,
            operation => operation.Kind == CardSemanticKind.Damage);
        Assert.Equal(7m, damage.Amount);
        Assert.True(damage.RepeatByExhaustedCount);
    }

    [Theory]
    [InlineData("每当你获得格挡时，对随机敌人造成6点伤害。", "BLOCK_GAINED", 6)]
    [InlineData("你每打出一张牌，就对随机一名敌人造成4点伤害。", "CARD_PLAYED", 4)]
    public void CompilesRandomEnemyPowerTriggers(string text, string trigger, int amount)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.Damage, operation.Kind);
        Assert.Equal(SemanticTarget.RandomEnemy, operation.Target);
        Assert.Equal(trigger, operation.Trigger);
        Assert.Equal(amount, operation.Amount);
        Assert.Equal("CombatTargets", operation.RandomSource);
        Assert.Equal("combat", operation.Duration);
    }

    [Theory]
    [InlineData("你在这个回合内每出一张牌，该名敌人都会失去2点生命。", CardSemanticKind.LoseEnemyHp, "CARD_PLAYED", null, 2)]
    [InlineData("每有一次攻击造成未被格挡的伤害，就给予1层中毒。", CardSemanticKind.ApplyStatus, "POWERED_ATTACK_UNBLOCKED_DAMAGE", "POISON", 1)]
    [InlineData("每当你攻击敌人的时候，这名敌人在本回合失去1点力量。", CardSemanticKind.ApplyStatus, "POWERED_ATTACK", "TEMP_STRENGTH_LOSS", 1)]
    public void CompilesTargetBoundCombatTriggers(
        string text,
        CardSemanticKind kind,
        string trigger,
        string? id,
        int amount)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(kind, operation.Kind);
        Assert.Equal(SemanticTarget.SelectedEnemy, operation.Target);
        Assert.Equal(trigger, operation.Trigger);
        Assert.Equal(id, operation.Id);
        Assert.Equal(amount, operation.Amount);
    }

    [Fact]
    public void CompilesTheGambitDeathTrigger()
    {
        var result = CardTextSemanticCompiler.Compile(
            "获得50点格挡。如果你在本场战斗中受到未被格挡的攻击伤害，则立刻死亡。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations,
            item => item.Id == "THE_GAMBIT");
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal(SemanticTarget.Self, operation.Target);
        Assert.Equal("POWERED_ATTACK_UNBLOCKED_DAMAGE_RECEIVED", operation.Trigger);
    }

    [Fact]
    public void CompilesLethalityFirstAttackBonus()
    {
        var result = CardTextSemanticCompiler.Compile("虚无。每回合的第一张攻击牌会造成50%额外伤害。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations, item => item.Id == "LETHALITY");
        Assert.Equal(50m, operation.Amount);
        Assert.Equal("FIRST_ATTACK_PLAYED", operation.Trigger);
    }

    [Fact]
    public void CompilesPaleBlueDotThreshold()
    {
        var result = CardTextSemanticCompiler.Compile(
            "如果你在一回合内打出了大于等于5张牌，在下个回合开始时抽1张牌。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations, item => item.Id == "PALE_BLUE_DOT");
        Assert.Equal("ATTACK_COUNT_REACHED_5", operation.Trigger);
    }

    [Fact]
    public void CompilesOneForAllZeroCostAttackBonus()
    {
        var result = CardTextSemanticCompiler.Compile("所有人的0能量费攻击牌额外造成3点伤害。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations, item => item.Id == "ONE_FOR_ALL");
        Assert.Equal(3m, operation.Amount);
    }

    [Fact]
    public void CompilesOutrageSelfCopyToDiscard()
    {
        var result = CardTextSemanticCompiler.Compile("在所有人的弃牌堆中加入一张此牌的复制品。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.GenerateCard, operation.Kind);
        Assert.Equal("SELF_COPY", operation.Id);
        Assert.Equal(SemanticTarget.DiscardPile, operation.Target);
    }

    [Fact]
    public void CompilesFastenDefendBonus()
    {
        var result = CardTextSemanticCompiler.Compile("从“防御”牌中额外获得4点格挡。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal("FASTEN", operation.Id);
        Assert.Equal(4m, operation.Amount);
    }

    [Fact]
    public void CompilesTheBombDelayedDamage()
    {
        var baseResult = CardTextSemanticCompiler.Compile("在3回合结束后，对所有敌人造成40点伤害。");
        var upgResult = CardTextSemanticCompiler.Compile("在3回合结束后，对所有敌人造成50点伤害。");

        Assert.True(baseResult.IsFullyStructured);
        Assert.True(baseResult.IsSimulatorExecutable);
        Assert.True(upgResult.IsFullyStructured);
        Assert.True(upgResult.IsSimulatorExecutable);

        var baseOp = Assert.Single(baseResult.Operations);
        Assert.Equal("THE_BOMB", baseOp.Id);
        Assert.Equal(40m, baseOp.Amount);
        Assert.Equal("3", baseOp.Duration);

        var upgOp = Assert.Single(upgResult.Operations);
        Assert.Equal("THE_BOMB", upgOp.Id);
        Assert.Equal(50m, upgOp.Amount);
        Assert.Equal("3", upgOp.Duration);
    }

    [Fact]
    public void CompilesToricToughnessRecurringBlock()
    {
        var result = CardTextSemanticCompiler.Compile("获得5点格挡。在接下来的2个回合开始时，获得5点格挡。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        Assert.Equal(2, result.Operations.Length);
        Assert.Equal(CardSemanticKind.Block, result.Operations[0].Kind);
        Assert.Equal(5m, result.Operations[0].Amount);
        Assert.Equal("TORIC_TOUGHNESS", result.Operations[1].Id);
        Assert.Equal(5m, result.Operations[1].Amount);
        Assert.Equal("2", result.Operations[1].Duration);
    }

    [Fact]
    public void CompilesMadScienceCuriousPowerCostReduction()
    {
        var baseResult = CardTextSemanticCompiler.Compile("能力牌的耗能减少1能量。");
        var upgResult = CardTextSemanticCompiler.Compile("固有。能力牌的耗能减少1能量。");

        Assert.True(baseResult.IsFullyStructured);
        Assert.True(baseResult.IsSimulatorExecutable);
        Assert.True(upgResult.IsFullyStructured);
        Assert.True(upgResult.IsSimulatorExecutable);

        var op = Assert.Single(baseResult.Operations);
        Assert.Equal("POWERS_COST_DELTA", op.Id);
        Assert.Equal(1m, op.Amount);
    }

    [Fact]
    public void CompilesDisintegrationTurnEndDamage()
    {
        var result = CardTextSemanticCompiler.Compile("在你的回合结束时，受到6点伤害。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var op = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.Damage, op.Kind);
        Assert.Equal(6m, op.Amount);
        Assert.Equal("turn_end", op.Timing);
        Assert.Equal("SELF_IN_HAND", op.Condition);
    }

    [Fact]
    public void CompilesWellLaidPlansRetainUpToCards()
    {
        var baseResult = CardTextSemanticCompiler.Compile("在你的回合结束时，保留最多1张牌。");
        var upgResult = CardTextSemanticCompiler.Compile("在你的回合结束时，保留最多2张牌。");

        Assert.True(baseResult.IsFullyStructured);
        Assert.True(baseResult.IsSimulatorExecutable);
        Assert.True(upgResult.IsFullyStructured);
        Assert.True(upgResult.IsSimulatorExecutable);

        var baseOp = Assert.Single(baseResult.Operations);
        Assert.Equal("WELL_LAID_PLANS", baseOp.Id);
        Assert.Equal(1m, baseOp.Amount);

        var upgOp = Assert.Single(upgResult.Operations);
        Assert.Equal("WELL_LAID_PLANS", upgOp.Id);
        Assert.Equal(2m, upgOp.Amount);

        var newTextResult = CardTextSemanticCompiler.Compile("在你的回合结束时，你不再丢弃你的手牌。");
        Assert.True(newTextResult.IsFullyStructured);
        Assert.True(newTextResult.IsSimulatorExecutable);
        var newOp = Assert.Single(newTextResult.Operations);
        Assert.Equal("WELL_LAID_PLANS", newOp.Id);
        Assert.Equal(1m, newOp.Amount);
    }

    [Fact]
    public void CompilesToolsOfTheTradeDrawDiscard()
    {
        var baseResult = CardTextSemanticCompiler.Compile("在你的回合开始时，抽1张牌，丢弃1张牌。");
        var upgResult = CardTextSemanticCompiler.Compile("固有。在你的回合开始时，抽1张牌，丢弃1张牌。");

        Assert.True(baseResult.IsFullyStructured);
        Assert.True(baseResult.IsSimulatorExecutable);
        Assert.True(upgResult.IsFullyStructured);
        Assert.True(upgResult.IsSimulatorExecutable);

        var baseOp = Assert.Single(baseResult.Operations);
        Assert.Equal("TOOLS_OF_THE_TRADE", baseOp.Id);
        Assert.Equal(1m, baseOp.Amount);
    }

    [Fact]
    public void CompilesCrescentSpearBonusDamagePerStarCostCard()
    {
        var baseResult = CardTextSemanticCompiler.Compile("造成8点伤害。你每有一张拥有辉星耗能的卡牌，这张牌就额外造成2点伤害。");
        var upgResult = CardTextSemanticCompiler.Compile("造成8点伤害。你每有一张拥有辉星耗能的卡牌，这张牌就额外造成3点伤害。");

        Assert.True(baseResult.IsFullyStructured);
        Assert.True(baseResult.IsSimulatorExecutable);
        Assert.True(upgResult.IsFullyStructured);
        Assert.True(upgResult.IsSimulatorExecutable);

        Assert.Equal(2, baseResult.Operations.Length);
        Assert.Equal(CardSemanticKind.Damage, baseResult.Operations[0].Kind);
        Assert.Equal(8m, baseResult.Operations[0].Amount);
        Assert.Equal("BONUS_DAMAGE_PER_STAR_COST_CARD", baseResult.Operations[1].Id);
        Assert.Equal(2m, baseResult.Operations[1].Amount);
    }

    [Fact]
    public void CompilesTheHuntAndHandOfGreedFatalRewards()
    {
        var theHunt = CardTextSemanticCompiler.Compile("造成10点伤害。斩杀时，额外获得一次卡牌奖励。消耗。");
        var greed = CardTextSemanticCompiler.Compile("造成20点伤害。斩杀时，获得20金币。");

        Assert.True(theHunt.IsFullyStructured);
        Assert.True(theHunt.IsSimulatorExecutable);
        Assert.True(greed.IsFullyStructured);
        Assert.True(greed.IsSimulatorExecutable);

        Assert.Equal(3, theHunt.Operations.Length);
        Assert.Equal(CardSemanticKind.Damage, theHunt.Operations[0].Kind);
        Assert.Equal("EXTRA_CARD_REWARD", theHunt.Operations[1].Id);
        Assert.Equal("SOURCE_CARD_KILLED", theHunt.Operations[1].Condition);
        Assert.Equal("消耗", theHunt.Operations[2].Id);

        Assert.Equal(2, greed.Operations.Length);
        Assert.Equal(CardSemanticKind.Damage, greed.Operations[0].Kind);
        Assert.Equal("GOLD_REWARD", greed.Operations[1].Id);
        Assert.Equal(20m, greed.Operations[1].Amount);
    }

    [Fact]
    public void CompilesArmamentsAndApotheosisUpgrades()
    {
        var armBase = CardTextSemanticCompiler.Compile("获得5点格挡。升级你手牌中的一张牌。");
        var armUpg = CardTextSemanticCompiler.Compile("获得5点格挡。升级你手牌中的所有牌。");
        var apo = CardTextSemanticCompiler.Compile("固有。升级你的全部卡牌。消耗。");

        Assert.True(armBase.IsFullyStructured);
        Assert.True(armBase.IsSimulatorExecutable);
        Assert.True(armUpg.IsFullyStructured);
        Assert.True(armUpg.IsSimulatorExecutable);
        Assert.True(apo.IsFullyStructured);
        Assert.True(apo.IsSimulatorExecutable);

        Assert.Equal(2, armBase.Operations.Length);
        Assert.Equal(CardSemanticKind.Block, armBase.Operations[0].Kind);
        Assert.Equal(CardSemanticKind.UpgradeCard, armBase.Operations[1].Kind);
        Assert.Equal("HAND_ONE", armBase.Operations[1].Id);

        Assert.Equal("HAND_ALL", armUpg.Operations[1].Id);

        Assert.Equal("固有", apo.Operations[0].Id);
        Assert.Equal(CardSemanticKind.UpgradeCard, apo.Operations[1].Kind);
        Assert.Equal("ALL_COMBAT_CARDS", apo.Operations[1].Id);
        Assert.Equal("消耗", apo.Operations[2].Id);
    }

    [Fact]
    public void CompilesAlchemizeDebilitateConqueror()
    {
        var alch = CardTextSemanticCompiler.Compile("获得一瓶随机药水。消耗。");
        var deb = CardTextSemanticCompiler.Compile("造成10点伤害。在接下来的2回合内，该敌人身上的易伤与虚弱效果翻倍。");
        var conq = CardTextSemanticCompiler.Compile("铸造3。君王之剑在本回合对敌人造成双倍伤害。");

        Assert.True(alch.IsFullyStructured);
        Assert.True(alch.IsSimulatorExecutable);
        Assert.True(deb.IsFullyStructured);
        Assert.True(deb.IsSimulatorExecutable);
        Assert.True(conq.IsFullyStructured);
        Assert.True(conq.IsSimulatorExecutable);

        Assert.Equal("RANDOM_POTION_REWARD", alch.Operations[0].Id);
        Assert.Equal("DEBILITATE", deb.Operations[1].Id);
        Assert.Equal(2m, deb.Operations[1].Amount);
        Assert.Equal("2", deb.Operations[1].Duration);
        Assert.Equal("KINGS_BLADE_DOUBLE_DAMAGE", conq.Operations[1].Id);
    }

    [Fact]
    public void CompilesBatch3SinglePlayerCards()
    {
        var omni = CardTextSemanticCompiler.Compile("造成8点伤害。对所有其他敌人造成等量的伤害。");
        var conv = CardTextSemanticCompiler.Compile("在本回合保留你的手牌。在下个回合，获得能量与辉星。");
        var convPlus = CardTextSemanticCompiler.Compile("在本回合保留你的手牌。在下个回合，获得能量与辉星辉星。");
        var seek = CardTextSemanticCompiler.Compile("铸造7。君王之剑现在会对所有敌人造成伤害。");
        var summon = CardTextSemanticCompiler.Compile("不论何处，将君王之剑放入你的手牌。铸造8。");
        var royalties = CardTextSemanticCompiler.Compile("在战斗结束时，获得30金币。");
        var parry = CardTextSemanticCompiler.Compile("君王之剑现在能让你获得10点格挡。");
        var sage = CardTextSemanticCompiler.Compile("君王之剑获得重放1。");

        Assert.True(omni.IsFullyStructured);
        Assert.True(omni.IsSimulatorExecutable);
        Assert.True(conv.IsFullyStructured);
        Assert.True(conv.IsSimulatorExecutable);
        Assert.True(convPlus.IsFullyStructured);
        Assert.True(convPlus.IsSimulatorExecutable);
        Assert.True(seek.IsFullyStructured);
        Assert.True(seek.IsSimulatorExecutable);
        Assert.True(summon.IsFullyStructured);
        Assert.True(summon.IsSimulatorExecutable);
        Assert.True(royalties.IsFullyStructured);
        Assert.True(royalties.IsSimulatorExecutable);
        Assert.True(parry.IsFullyStructured);
        Assert.True(parry.IsSimulatorExecutable);
        Assert.True(sage.IsFullyStructured);
        Assert.True(sage.IsSimulatorExecutable);

        Assert.Equal("ALL_OTHER_ENEMIES_EQUAL_DAMAGE", omni.Operations[1].Id);
        Assert.Equal("RETAIN_HAND", conv.Operations[0].Id);
        Assert.Equal(CardSemanticKind.GainEnergy, conv.Operations[1].Kind);
        Assert.Equal("STARS", conv.Operations[2].Id);
        Assert.Equal(1m, conv.Operations[2].Amount);
        Assert.Equal(2m, convPlus.Operations[2].Amount);
        Assert.Equal("KINGS_BLADE_ALL_ENEMIES", seek.Operations[1].Id);
        Assert.Equal("KINGS_BLADE_TO_HAND", summon.Operations[0].Id);
        Assert.Equal("GOLD_REWARD", royalties.Operations[0].Id);
        Assert.Equal("KINGS_BLADE_BLOCK", parry.Operations[0].Id);
        Assert.Equal(10m, parry.Operations[0].Amount);
        Assert.Equal("KINGS_BLADE_REPLAY", sage.Operations[0].Id);
        Assert.Equal(1m, sage.Operations[0].Amount);
    }

    [Fact]
    public void CompilesBatch4SinglePlayerCards()
    {
        var bh = CardTextSemanticCompiler.Compile("每当你花费或获得辉星时，对所有敌人造成3点伤害。");
        var cos = CardTextSemanticCompiler.Compile("每当你花费辉星时，每花费一点辉星，获得2点格挡。");
        var dp = CardTextSemanticCompiler.Compile("造成10点伤害。随机升级你弃牌堆中的2张牌。");
        var compact = CardTextSemanticCompiler.Compile("获得6点格挡。将你手牌中的全部状态牌变化为燃料。");
        var compactPlus = CardTextSemanticCompiler.Compile("获得7点格挡。将你手牌中的全部状态牌变化为燃料+。");
        var helix = CardTextSemanticCompiler.Compile("在本回合中，每个被使用的能量，都会使此牌造成3点伤害一次。");

        Assert.True(bh.IsFullyStructured);
        Assert.True(bh.IsSimulatorExecutable);
        Assert.True(cos.IsFullyStructured);
        Assert.True(cos.IsSimulatorExecutable);
        Assert.True(dp.IsFullyStructured);
        Assert.True(dp.IsSimulatorExecutable);
        Assert.True(compact.IsFullyStructured);
        Assert.True(compact.IsSimulatorExecutable);
        Assert.True(compactPlus.IsFullyStructured);
        Assert.True(compactPlus.IsSimulatorExecutable);
        Assert.True(helix.IsFullyStructured);
        Assert.True(helix.IsSimulatorExecutable);

        Assert.Equal("BLACK_HOLE", bh.Operations[0].Id);
        Assert.Equal(3m, bh.Operations[0].Amount);
        Assert.Equal("CHILD_OF_THE_STARS", cos.Operations[0].Id);
        Assert.Equal(2m, cos.Operations[0].Amount);
        Assert.Equal("DISCARD_RANDOM", dp.Operations[1].Id);
        Assert.Equal(2m, dp.Operations[1].Amount);
        Assert.Equal("HAND_STATUS_TO_FUEL", compact.Operations[1].Id);
        Assert.Equal("HAND_STATUS_TO_FUEL_PLUS", compactPlus.Operations[1].Id);
        Assert.True(helix.Operations[0].RepeatByEnergySpent);
        Assert.Equal(3m, helix.Operations[0].Amount);
    }

    [Fact]
    public void CompilesBatch5SinglePlayerCards()
    {
        var mp = CardTextSemanticCompiler.Compile("当你打出技能牌时，该牌获得奇巧。");
        var ttt = CardTextSemanticCompiler.Compile("每当你生成状态牌的时候，随机生成一个充能球。");
        var shroud = CardTextSemanticCompiler.Compile("每当你给予灾厄时，获得3点格挡。");
        var sof = CardTextSemanticCompiler.Compile("每当你给予一个敌人负面状态时，使其受到9点伤害。");
        var thunder = CardTextSemanticCompiler.Compile("每当你激发闪电充能球时，对被命中的敌人造成8点伤害。");
        var invoke = CardTextSemanticCompiler.Compile("在下个回合召唤2并获得能量能量。");
        var invokePlus = CardTextSemanticCompiler.Compile("在下个回合召唤3并获得能量能量能量。");

        Assert.True(mp.IsFullyStructured);
        Assert.True(mp.IsSimulatorExecutable);
        Assert.True(ttt.IsFullyStructured);
        Assert.True(ttt.IsSimulatorExecutable);
        Assert.True(shroud.IsFullyStructured);
        Assert.True(shroud.IsSimulatorExecutable);
        Assert.True(sof.IsFullyStructured);
        Assert.True(sof.IsSimulatorExecutable);
        Assert.True(thunder.IsFullyStructured);
        Assert.True(thunder.IsSimulatorExecutable);
        Assert.True(invoke.IsFullyStructured);
        Assert.True(invoke.IsSimulatorExecutable);
        Assert.True(invokePlus.IsFullyStructured);
        Assert.True(invokePlus.IsSimulatorExecutable);

        Assert.Equal("MASTER_PLANNER", mp.Operations[0].Id);
        Assert.Equal("TRASH_TO_TREASURE", ttt.Operations[0].Id);
        Assert.Equal("SHROUD", shroud.Operations[0].Id);
        Assert.Equal(3m, shroud.Operations[0].Amount);
        Assert.Equal("SLEIGHT_OF_FLESH", sof.Operations[0].Id);
        Assert.Equal(9m, sof.Operations[0].Amount);
        Assert.Equal("THUNDER", thunder.Operations[0].Id);
        Assert.Equal(8m, thunder.Operations[0].Amount);
        Assert.Equal(CardSemanticKind.Summon, invoke.Operations[0].Kind);
        Assert.Equal(2m, invoke.Operations[0].Amount);
        Assert.Equal(CardSemanticKind.GainEnergy, invoke.Operations[1].Kind);
        Assert.Equal(2m, invoke.Operations[1].Amount);
        Assert.Equal(3m, invokePlus.Operations[0].Amount);
        Assert.Equal(3m, invokePlus.Operations[1].Amount);
    }

    [Fact]
    public void CompilesBatch6SinglePlayerCards()
    {
        var agg = CardTextSemanticCompiler.Compile("在你的回合开始时，将你弃牌堆的一张随机攻击牌放入你的手牌并将其升级。");
        var calc = CardTextSemanticCompiler.Compile("奥斯提的攻击额外造成4点伤害。");
        var mad = CardTextSemanticCompiler.Compile("在战斗结束时，升级你牌组中的一张随机牌。");
        var mis = CardTextSemanticCompiler.Compile("造成7点伤害。给予其他敌人该名敌人身上的所有负面效果。");
        var nec = CardTextSemanticCompiler.Compile("召唤5。每当奥斯提失去生命值时，所有敌人失去等量生命值。");
        var ht = CardTextSemanticCompiler.Compile("获得7点格挡。在本回合给你手牌中的一张技能牌添加奇巧。");

        Assert.True(agg.IsFullyStructured);
        Assert.True(agg.IsSimulatorExecutable);
        Assert.True(calc.IsFullyStructured);
        Assert.True(calc.IsSimulatorExecutable);
        Assert.True(mad.IsFullyStructured);
        Assert.True(mad.IsSimulatorExecutable);
        Assert.True(mis.IsFullyStructured);
        Assert.True(mis.IsSimulatorExecutable);
        Assert.True(nec.IsFullyStructured);
        Assert.True(nec.IsSimulatorExecutable);
        Assert.True(ht.IsFullyStructured);
        Assert.True(ht.IsSimulatorExecutable);

        Assert.Equal("DISCARD_ATTACK_TO_HAND_UPGRADED", agg.Operations[0].Id);
        Assert.Equal("CALCIFY", calc.Operations[0].Id);
        Assert.Equal(4m, calc.Operations[0].Amount);
        Assert.Equal("DECK_RANDOM", mad.Operations[0].Id);
        Assert.Equal(1m, mad.Operations[0].Amount);
        Assert.Equal("TRANSFER_TARGET_DEBUFFS_TO_OTHERS", mis.Operations[1].Id);
        Assert.Equal("NECRO_MASTERY", nec.Operations[1].Id);
        Assert.Equal("HAND_SKILL_FINESSE", ht.Operations[1].Id);
    }

    [Fact]
    public void CompilesBatch7SinglePlayerCards()
    {
        var bd = CardTextSemanticCompiler.Compile("打出你弃牌堆中的3张随机攻击牌。");
        var hf = CardTextSemanticCompiler.Compile("奥斯提对所有敌人造成11点伤害并给予它们2层易伤。");
        var pf = CardTextSemanticCompiler.Compile("将手牌中的所有攻击牌变化为巨石。");
        var pfPlus = CardTextSemanticCompiler.Compile("将手牌中的所有攻击牌变化为巨石+。");
        var hg = CardTextSemanticCompiler.Compile("你抽牌堆中的一张没有重放的随机牌获得2层重放。");
        var rad = CardTextSemanticCompiler.Compile("你在本回合每获得一点辉星，此牌就对所有敌人造成3点伤害一次。");
        var cotv = CardTextSemanticCompiler.Compile("在你的回合开始时，将1张随机牌添加到你的手牌中。添加的牌会获得虚无。");
        var rb = CardTextSemanticCompiler.Compile("在你的回合开始时，对所有敌人造成5点伤害，然后将该伤害增加5点。");

        Assert.True(bd.IsFullyStructured);
        Assert.True(bd.IsSimulatorExecutable);
        Assert.True(hf.IsFullyStructured);
        Assert.True(hf.IsSimulatorExecutable);
        Assert.True(pf.IsFullyStructured);
        Assert.True(pf.IsSimulatorExecutable);
        Assert.True(pfPlus.IsFullyStructured);
        Assert.True(pfPlus.IsSimulatorExecutable);
        Assert.True(hg.IsFullyStructured);
        Assert.True(hg.IsSimulatorExecutable);
        Assert.True(rad.IsFullyStructured);
        Assert.True(rad.IsSimulatorExecutable);
        Assert.True(cotv.IsFullyStructured);
        Assert.True(cotv.IsSimulatorExecutable);
        Assert.True(rb.IsFullyStructured);
        Assert.True(rb.IsSimulatorExecutable);

        Assert.Equal("DISCARD_RANDOM_ATTACK", bd.Operations[0].Id);
        Assert.Equal(3m, bd.Operations[0].Amount);
        Assert.Equal(CardSemanticKind.CompanionDamage, hf.Operations[0].Kind);
        Assert.Equal(11m, hf.Operations[0].Amount);
        Assert.Equal("VULNERABLE", hf.Operations[1].Id);
        Assert.Equal("HAND_ATTACKS_TO_GIANT_ROCK", pf.Operations[0].Id);
        Assert.Equal("HAND_ATTACKS_TO_GIANT_ROCK_PLUS", pfPlus.Operations[0].Id);
        Assert.Equal("DRAW_CARD_REPLAY", hg.Operations[0].Id);
        Assert.True(rad.Operations[0].RepeatByStarsGained);
        Assert.Equal("RANDOM_ANY", cotv.Operations[0].Id);
        Assert.Equal("虚无", cotv.Operations[1].Id);
        Assert.Equal("ROLLING_BOULDER", rb.Operations[0].Id);
        Assert.Equal(5m, rb.Operations[0].Amount);
    }

    [Fact]
    public void CompilesBatch8SinglePlayerCards()
    {
        var bis = CardTextSemanticCompiler.Compile("造成5点伤害。铸造5。本回合内，你此前每击中过该敌人一次，这张牌就额外铸造5点。");
        var beg = CardTextSemanticCompiler.Compile("选择你手牌中的一张牌，将其变化为仆从打击。");
        var begPlus = CardTextSemanticCompiler.Compile("选择你手牌中的一张牌，将其变化为仆从打击+。");
        var fc = CardTextSemanticCompiler.Compile("在下个回合，从你的抽牌堆中选择2张牌放入你的手牌。");
        var fg = CardTextSemanticCompiler.Compile("在战斗结束时，你可以从你的牌组中选一张牌移除。永恒。");
        var ent = CardTextSemanticCompiler.Compile("在你的回合开始时，变化你手牌中的1张牌。");
        var sic = CardTextSemanticCompiler.Compile("奥斯提造成5点伤害。在本回合内，每当奥斯提攻击这名敌人时，召唤3。");

        Assert.True(bis.IsFullyStructured);
        Assert.True(bis.IsSimulatorExecutable);
        Assert.True(beg.IsFullyStructured);
        Assert.True(beg.IsSimulatorExecutable);
        Assert.True(begPlus.IsFullyStructured);
        Assert.True(begPlus.IsSimulatorExecutable);
        Assert.True(fc.IsFullyStructured);
        Assert.True(fc.IsSimulatorExecutable);
        Assert.True(fg.IsFullyStructured);
        Assert.True(fg.IsSimulatorExecutable);
        Assert.True(ent.IsFullyStructured);
        Assert.True(ent.IsSimulatorExecutable);
        Assert.True(sic.IsFullyStructured);
        Assert.True(sic.IsSimulatorExecutable);

        Assert.Equal(CardSemanticKind.Forge, bis.Operations[2].Kind);
        Assert.True(bis.Operations[2].RepeatByHistoryCounter);
        Assert.Equal("HAND_ONE_TO_MINION_STRIKE", beg.Operations[0].Id);
        Assert.Equal("HAND_ONE_TO_MINION_STRIKE_PLUS", begPlus.Operations[0].Id);
        Assert.Equal("DRAW_CHOOSE_TO_HAND", fc.Operations[0].Id);
        Assert.Equal("COMBAT_END_REMOVE_CARD", fg.Operations[0].Id);
        Assert.Equal("TURN_START_TRANSFORM_RANDOM", ent.Operations[0].Id);
        Assert.Equal("SIC_EM", sic.Operations[1].Id);
    }

    [Fact]
    public void CompilesBatch9SinglePlayerCards()
    {
        var disc = CardTextSemanticCompiler.Compile("从3张随机牌中选择1张加入你的手牌。这张牌在本回合可以免费打出。消耗。");
        var quas = CardTextSemanticCompiler.Compile("从3张随机无色牌中选择1张加入你的手牌。");
        var spl = CardTextSemanticCompiler.Compile("从3张其他角色的攻击牌中选择1张加入你的手牌。这张牌在本回合免费打出。");
        var ss = CardTextSemanticCompiler.Compile("造成9点伤害。从抽牌堆的随机3张牌中选择一张加入你的手牌。");
        var nm = CardTextSemanticCompiler.Compile("选择一张牌。在下个回合将这张牌的3张复制品加入你的手牌。消耗。");
        var dd = CardTextSemanticCompiler.Compile("抽3张牌。选择你手牌中的一张技能牌，并将其打出3次。消耗。");

        Assert.True(disc.IsFullyStructured);
        Assert.True(disc.IsSimulatorExecutable);
        Assert.True(quas.IsFullyStructured);
        Assert.True(quas.IsSimulatorExecutable);
        Assert.True(spl.IsFullyStructured);
        Assert.True(spl.IsSimulatorExecutable);
        Assert.True(ss.IsFullyStructured);
        Assert.True(ss.IsSimulatorExecutable);
        Assert.True(nm.IsFullyStructured);
        Assert.True(nm.IsSimulatorExecutable);
        Assert.True(dd.IsFullyStructured);
        Assert.True(dd.IsSimulatorExecutable);

        Assert.Equal("DISCOVERY", disc.Operations[0].Id);
        Assert.Equal("QUASAR_COLORLESS", quas.Operations[0].Id);
        Assert.Equal("SPLASH_OTHER_ATTACK", spl.Operations[0].Id);
        Assert.Equal("SEEKER_STRIKE_DRAW_CHOOSE", ss.Operations[1].Id);
        Assert.Equal("NIGHTMARE_CHOOSE", nm.Operations[0].Id);
        Assert.Equal("NIGHTMARE_COPIES", nm.Operations[1].Id);
        Assert.Equal("HAND_SKILL_REPLAY_3", dd.Operations[1].Id);
    }

    [Fact]
    public void CompilesBatch10SinglePlayerCards()
    {
        var ch = CardTextSemanticCompiler.Compile("选择你抽牌堆中的2张牌，将其变化为仆从俯冲。");
        var gd = CardTextSemanticCompiler.Compile("将你手牌中的任意张牌变化为仆从捐躯。消耗。");
        var tyr = CardTextSemanticCompiler.Compile("在你的回合开始时，抽一张牌，并从你的手牌中消耗1张牌。");
        var vf = CardTextSemanticCompiler.Compile("虚无。结束你的回合。你可以免费打出每回合的前2张牌。");
        var volt = CardTextSemanticCompiler.Compile("生成等量于你在这场战斗中生成过的闪电充能球数量的闪电充能球。消耗。");
        var strat = CardTextSemanticCompiler.Compile("每当你的抽牌堆打乱洗牌时，选择一张牌放入你的手牌。");

        Assert.True(ch.IsFullyStructured);
        Assert.True(ch.IsSimulatorExecutable);
        Assert.True(gd.IsFullyStructured);
        Assert.True(gd.IsSimulatorExecutable);
        Assert.True(tyr.IsFullyStructured);
        Assert.True(tyr.IsSimulatorExecutable);
        Assert.True(vf.IsFullyStructured);
        Assert.True(vf.IsSimulatorExecutable);
        Assert.True(volt.IsFullyStructured);
        Assert.True(volt.IsSimulatorExecutable);
        Assert.True(strat.IsFullyStructured);
        Assert.True(strat.IsSimulatorExecutable);

        Assert.Equal("DRAW_TWO_TO_MINION_DIVE_BOMB", ch.Operations[0].Id);
        Assert.Equal("HAND_ANY_TO_MINION_SACRIFICE", gd.Operations[0].Id);
        Assert.Equal(CardSemanticKind.Draw, tyr.Operations[0].Kind);
        Assert.Equal(CardSemanticKind.ExhaustCards, tyr.Operations[1].Kind);
        Assert.Equal("END_TURN", vf.Operations[1].Id);
        Assert.Equal("FIRST_CARDS_FREE_EACH_TURN", vf.Operations[2].Id);
        Assert.True(volt.Operations[0].RepeatByHistoryCounter);
        Assert.Equal("SHUFFLE_CHOOSE_TO_HAND", strat.Operations[0].Id);
    }

    [Fact]
    public void CompilesBatch11SinglePlayerCards()
    {
        var unl = CardTextSemanticCompiler.Compile("奥斯提造成6点伤害。这张牌额外造成等量于奥斯提当前生命值的伤害。");
        var prot = CardTextSemanticCompiler.Compile("奥斯提造成10点伤害。额外造成等量于奥斯提最大生命值的伤害。");
        var flat = CardTextSemanticCompiler.Compile("奥斯提造成12点伤害。如果奥斯提本回合攻击过，则这张牌的耗能变为0能量。");
        var fet = CardTextSemanticCompiler.Compile("奥斯提造成3点伤害。如果这是这张牌第一次在本回合被打出，则抽1张牌。");
        var rat = CardTextSemanticCompiler.Compile("奥斯提造成7点伤害。本回合每使用过一次奥斯提攻击牌，此牌就额外造成一次伤害。");
        var sq = CardTextSemanticCompiler.Compile("奥斯提造成25点伤害。你每有一张奥斯提的攻击牌，这张牌就额外造成5点伤害。");

        Assert.True(unl.IsFullyStructured);
        Assert.True(unl.IsSimulatorExecutable);
        Assert.True(prot.IsFullyStructured);
        Assert.True(prot.IsSimulatorExecutable);
        Assert.True(flat.IsFullyStructured);
        Assert.True(flat.IsSimulatorExecutable);
        Assert.True(fet.IsFullyStructured);
        Assert.True(fet.IsSimulatorExecutable);
        Assert.True(rat.IsFullyStructured);
        Assert.True(rat.IsSimulatorExecutable);
        Assert.True(sq.IsFullyStructured);
        Assert.True(sq.IsSimulatorExecutable);

        Assert.Equal("OSTY_CURRENT_HP_DAMAGE", unl.Operations[0].DynamicAmountId);
        Assert.Equal("OSTY_MAX_HP_DAMAGE", prot.Operations[0].DynamicAmountId);
        Assert.Equal("OSTY_ATTACKED_THIS_TURN_ZERO_COST", flat.Operations[1].Id);
        Assert.Equal("FIRST_PLAYED_THIS_TURN_DRAW", fet.Operations[1].Id);
        Assert.Equal("OSTY_ATTACK_COUNT_REPEAT", rat.Operations[1].Id);
        Assert.Equal("OSTY_ATTACK_CARDS_IN_DECK_DAMAGE", sq.Operations[0].DynamicAmountId);
    }

    [Fact]
    public void CompilesBatch12SinglePlayerCards()
    {
        var bs = CardTextSemanticCompiler.Compile("如果奥斯提存活，则他对所有敌人造成9点伤害并且你获得9点格挡。然后奥斯提死去。");
        var sac = CardTextSemanticCompiler.Compile("保留。如果奥斯提存活，则他死去，然后你获得等量于其双倍最大生命值的格挡。");
        var spur = CardTextSemanticCompiler.Compile("保留。召唤3。奥斯提回复5点生命。");
        var sean = CardTextSemanticCompiler.Compile("虚无。将你抽牌堆中的一张牌变化为灵魂。");
        var dirge = CardTextSemanticCompiler.Compile("召唤3X次。将X张灵魂添加到你的抽牌堆中。消耗。");
        var ne = CardTextSemanticCompiler.Compile("给予10层灾厄，敌人身上每有10层灾厄，则额外给予这名敌人5层灾厄。");

        Assert.True(bs.IsFullyStructured);
        Assert.True(bs.IsSimulatorExecutable);
        Assert.True(sac.IsFullyStructured);
        Assert.True(sac.IsSimulatorExecutable);
        Assert.True(spur.IsFullyStructured);
        Assert.True(spur.IsSimulatorExecutable);
        Assert.True(sean.IsFullyStructured);
        Assert.True(sean.IsSimulatorExecutable);
        Assert.True(dirge.IsFullyStructured);
        Assert.True(dirge.IsSimulatorExecutable);
        Assert.True(ne.IsFullyStructured);
        Assert.True(ne.IsSimulatorExecutable);

        Assert.Equal(CardSemanticKind.CompanionDamage, bs.Operations[0].Kind);
        Assert.Equal("KILL_OSTY", bs.Operations[2].Id);
        Assert.Equal("OSTY_MAX_HP_BLOCK", sac.Operations[2].Id);
        Assert.Equal("HEAL_OSTY", spur.Operations[2].Id);
        Assert.Equal("DRAW_ONE_TO_SOUL", sean.Operations[1].Id);
        Assert.Equal("SUMMON_X", dirge.Operations[0].Id);
        Assert.Equal("SOUL", dirge.Operations[1].Id);
        Assert.Equal("DOOM_PER_TEN_DOOM", ne.Operations[1].Id);
    }

    [Fact]
    public void CompilesBatch13SinglePlayerCards()
    {
        var sg = CardTextSemanticCompiler.Compile("虚无。奥斯提对随机一名敌人造成10点伤害。消耗。");
        var rhh = CardTextSemanticCompiler.Compile("奥斯提造成4点伤害。每当你打出耗能为能量能量或以上的牌，将此牌从弃牌堆放回你的手牌。");
        var grp = CardTextSemanticCompiler.Compile("造成7点伤害。当你在本回合获得格挡时，对该敌人造成5点伤害。");
        var fe = CardTextSemanticCompiler.Compile("远离。将沙坑的计数加1。这张牌的耗能加1。");
        var debt = CardTextSemanticCompiler.Compile("不能被打出。在你的回合结束时，如果这张牌在你的手牌中，你失去10金币。");
        var enth = CardTextSemanticCompiler.Compile("如果这张牌在你的手牌中，你必须优先打出这张牌。永恒。");
        var gty = CardTextSemanticCompiler.Compile("不能被打出。在5场战斗后从你的牌组中移除。");
        var egg = CardTextSemanticCompiler.Compile("不能被打出。能在休息处被孵化。");
        var lk = CardTextSemanticCompiler.Compile("不能被打出。在下一阶段解锁一个特殊事件。");
        var sm = CardTextSemanticCompiler.Compile("不能被打出。在下一阶段的地图上，标记一个有600额外金币的地点。");
        var abn = CardTextSemanticCompiler.Compile("从3张能力牌中选择1张加入你的手牌。这张牌在本回合可以免费打出。消耗。");
        var dows = CardTextSemanticCompiler.Compile("不能被打出。在进入5个?房间后，这张牌变化为富足。");

        Assert.True(sg.IsFullyStructured);
        Assert.True(sg.IsSimulatorExecutable);
        Assert.True(rhh.IsFullyStructured);
        Assert.True(rhh.IsSimulatorExecutable);
        Assert.True(grp.IsFullyStructured);
        Assert.True(grp.IsSimulatorExecutable);
        Assert.True(fe.IsFullyStructured);
        Assert.True(fe.IsSimulatorExecutable);
        Assert.True(debt.IsFullyStructured);
        Assert.True(debt.IsSimulatorExecutable);
        Assert.True(enth.IsFullyStructured);
        Assert.True(enth.IsSimulatorExecutable);
        Assert.True(gty.IsFullyStructured);
        Assert.True(gty.IsSimulatorExecutable);
        Assert.True(egg.IsFullyStructured);
        Assert.True(egg.IsSimulatorExecutable);
        Assert.True(lk.IsFullyStructured);
        Assert.True(lk.IsSimulatorExecutable);
        Assert.True(sm.IsFullyStructured);
        Assert.True(sm.IsSimulatorExecutable);
        Assert.True(abn.IsFullyStructured);
        Assert.True(abn.IsSimulatorExecutable);
        Assert.True(dows.IsFullyStructured);
        Assert.True(dows.IsSimulatorExecutable);

        Assert.Equal("OSTY_RANDOM_DAMAGE", sg.Operations[1].Id);
        Assert.Equal("DISCARD_SELF_TO_HAND_ON_HIGH_COST", rhh.Operations[1].Id);
        Assert.Equal("GAIN_BLOCK_DAMAGE", grp.Operations[1].Id);
        Assert.Equal("FLEE", fe.Operations[0].Id);
        Assert.Equal("LOSE_GOLD", debt.Operations[1].Id);
        Assert.Equal("MUST_PLAY_FIRST", enth.Operations[0].Id);
        Assert.Equal("REMOVE_FROM_DECK_AFTER_COMBATS", gty.Operations[1].Id);
        Assert.Equal("HATCH_AT_REST_SITE", egg.Operations[1].Id);
        Assert.Equal("UNLOCK_SPECIAL_EVENT", lk.Operations[1].Id);
        Assert.Equal("MAP_BONUS_GOLD_LOCATION", sm.Operations[1].Id);
        Assert.Equal("ABUNDANCE_POWER_CHOICE", abn.Operations[0].Id);
        Assert.Equal("TRANSFORM_TO_ABUNDANCE", dows.Operations[1].Id);
    }

    [Theory]
    [InlineData("造成7点伤害。在本回合内获得2点力量。", "STRENGTH", 2)]
    [InlineData("造成9点伤害。在本回合内获得3点力量。", "STRENGTH", 3)]
    [InlineData("在本回合获得2点敏捷。", "DEXTERITY", 2)]
    [InlineData("在本回合获得3点敏捷。", "DEXTERITY", 3)]
    public void CompilesCurrentTurnTemporaryStrengthAndDexterity(string text, string id, int amount)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations,
            operation => operation.Id == id);
        Assert.Equal(amount, operation.Amount);
        Assert.Equal("this_turn", operation.Timing);
    }

    [Fact]
    public void CompilesTurnStartStrength()
    {
        var result = CardTextSemanticCompiler.Compile("在你的回合开始时，获得2点力量。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal("STRENGTH", operation.Id);
        Assert.Equal("turn_start", operation.Timing);
    }

    [Fact]
    public void CompilesTurnStartAllEnemyPoison()
    {
        var result = CardTextSemanticCompiler.Compile("在你的回合开始时，给予所有敌人2层中毒。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        var operation = Assert.Single(result.Operations);
        Assert.Equal(CardSemanticKind.ApplyStatus, operation.Kind);
        Assert.Equal(SemanticTarget.AllEnemies, operation.Target);
        Assert.Equal("POISON", operation.Id);
        Assert.Equal("turn_start", operation.Timing);
        Assert.Equal(2m, operation.Amount);
    }

    [Fact]
    public void CompilesTurnStartFocusLoss()
    {
        var result = CardTextSemanticCompiler.Compile("获得4点集中。在你的回合开始时，失去1点集中。");

        Assert.True(result.IsFullyStructured);
        Assert.True(result.IsSimulatorExecutable);
        Assert.Collection(result.Operations,
            gain => Assert.Equal("FOCUS", gain.Id),
            loss =>
            {
                Assert.Equal("FOCUS", loss.Id);
                Assert.Equal(-1m, loss.Amount);
                Assert.Equal("turn_start", loss.Timing);
            });
    }

    [Fact]
    public void CompilesBatch1DelayedReturnAndDiscardChoices()
    {
        var bolas = CardTextSemanticCompiler.Compile("造成3点伤害。在你的下个回合开始时，将此卡返回你的手牌。");
        var bolasPlus = CardTextSemanticCompiler.Compile("造成5点伤害。在你的下个回合开始时，将此卡返回你的手牌。");
        var hatchet = CardTextSemanticCompiler.Compile("造成11点伤害。在你的下个回合开始时，将此卡返回你的手牌。");
        var hatchetPlus = CardTextSemanticCompiler.Compile("造成14点伤害。在你的下个回合开始时，将此卡返回你的手牌。");
        var graveblast = CardTextSemanticCompiler.Compile("造成4点伤害。将弃牌堆中的一张牌放入你的手牌。消耗。");
        var graveblastPlus = CardTextSemanticCompiler.Compile("造成6点伤害。将弃牌堆中的一张牌放入你的手牌。");
        var hologram = CardTextSemanticCompiler.Compile("获得3点格挡。将弃牌堆中的一张牌放入你的手牌。消耗。");
        var hologramPlus = CardTextSemanticCompiler.Compile("获得5点格挡。将弃牌堆中的一张牌放入你的手牌。");

        Assert.True(bolas.IsFullyStructured && bolas.IsSimulatorExecutable);
        Assert.True(bolasPlus.IsFullyStructured && bolasPlus.IsSimulatorExecutable);
        Assert.True(hatchet.IsFullyStructured && hatchet.IsSimulatorExecutable);
        Assert.True(hatchetPlus.IsFullyStructured && hatchetPlus.IsSimulatorExecutable);
        Assert.True(graveblast.IsFullyStructured && graveblast.IsSimulatorExecutable);
        Assert.True(graveblastPlus.IsFullyStructured && graveblastPlus.IsSimulatorExecutable);
        Assert.True(hologram.IsFullyStructured && hologram.IsSimulatorExecutable);
        Assert.True(hologramPlus.IsFullyStructured && hologramPlus.IsSimulatorExecutable);

        Assert.Equal("SELF", bolas.Operations[1].Id);
        Assert.Equal("next_turn_start", bolas.Operations[1].Timing);
        Assert.Equal("CHOOSE_DISCARD_ANY_TO_HAND", graveblast.Operations[1].Id);
        Assert.Equal("CHOOSE_DISCARD_ANY_TO_HAND", hologram.Operations[1].Id);
    }

    [Fact]
    public void CompilesBatch2ExistingOrbsAndDeterministicGeneratedCards()
    {
        var cs = CardTextSemanticCompiler.Compile("生成2个黑暗充能球。在你的回合结束时，激发你最左侧的充能球。");
        var csPlus = CardTextSemanticCompiler.Compile("生成3个黑暗充能球。在你的回合结束时，激发你最左侧的充能球。");
        var sm = CardTextSemanticCompiler.Compile("在你的回合开始时，将1张扫荡凝视加入你的手牌。");
        var smPlus = CardTextSemanticCompiler.Compile("在你的回合开始时，将2张扫荡凝视加入你的手牌。");
        var dl = CardTextSemanticCompiler.Compile("每当你打出一张灵魂时，召唤1。");
        var dlPlus = CardTextSemanticCompiler.Compile("每当你打出一张灵魂时，召唤2。");

        Assert.True(cs.IsFullyStructured && cs.IsSimulatorExecutable);
        Assert.True(csPlus.IsFullyStructured && csPlus.IsSimulatorExecutable);
        Assert.True(sm.IsFullyStructured && sm.IsSimulatorExecutable);
        Assert.True(smPlus.IsFullyStructured && smPlus.IsSimulatorExecutable);
        Assert.True(dl.IsFullyStructured);
        Assert.True(dlPlus.IsFullyStructured);

        Assert.Equal("LEFTMOST", cs.Operations[1].Id);
        Assert.Equal("turn_end", cs.Operations[1].Timing);
        Assert.Equal("扫荡凝视", sm.Operations[0].Id);
        Assert.Equal("turn_start", sm.Operations[0].Timing);
        Assert.Equal("SOUL_PLAYED", dl.Operations[0].Trigger);
    }

    [Fact]
    public void CompilesBatch3FinesseKeywordClan()
    {
        var abrasive = CardTextSemanticCompiler.Compile("奇巧。获得1点敏捷。获得4点荆棘。");
        var flickFlack = CardTextSemanticCompiler.Compile("奇巧。对所有敌人造成6点伤害。");
        var haze = CardTextSemanticCompiler.Compile("奇巧。给予所有敌人4层中毒。");
        var reflex = CardTextSemanticCompiler.Compile("奇巧。抽2张牌。");
        var tactician = CardTextSemanticCompiler.Compile("奇巧。获得能量。");
        var tacticianPlus = CardTextSemanticCompiler.Compile("奇巧。获得能量能量。");
        var untouchable = CardTextSemanticCompiler.Compile("奇巧。获得6点格挡。");
        var ricochet = CardTextSemanticCompiler.Compile("奇巧。随机对敌人造成3点伤害4次。");

        Assert.True(abrasive.IsFullyStructured && abrasive.IsSimulatorExecutable);
        Assert.True(flickFlack.IsFullyStructured && flickFlack.IsSimulatorExecutable);
        Assert.True(haze.IsFullyStructured && haze.IsSimulatorExecutable);
        Assert.True(reflex.IsFullyStructured && reflex.IsSimulatorExecutable);
        Assert.True(tactician.IsFullyStructured && tactician.IsSimulatorExecutable);
        Assert.True(tacticianPlus.IsFullyStructured && tacticianPlus.IsSimulatorExecutable);
        Assert.True(untouchable.IsFullyStructured && untouchable.IsSimulatorExecutable);
        Assert.True(ricochet.IsFullyStructured && ricochet.IsSimulatorExecutable);

        Assert.Equal("奇巧", abrasive.Operations[0].Id);
        Assert.Equal(CardSemanticKind.Keyword, abrasive.Operations[0].Kind);
    }

    [Fact]
    public void CompilesBatch4StarsForgeAndGlassOrb()
    {
        var genesis = CardTextSemanticCompiler.Compile("在你的回合开始时，获得辉星辉星。");
        var genesisPlus = CardTextSemanticCompiler.Compile("在你的回合开始时，获得辉星辉星辉星。");
        var cache = CardTextSemanticCompiler.Compile("获得辉星。在下个回合获得辉星辉星辉星。");
        var cachePlus = CardTextSemanticCompiler.Compile("获得辉星。在下个回合获得辉星辉星辉星辉星。");
        var throne = CardTextSemanticCompiler.Compile("你每打出一张牌，获得辉星。");
        var furnace = CardTextSemanticCompiler.Compile("在你的回合开始时，铸造5。");
        var furnacePlus = CardTextSemanticCompiler.Compile("在你的回合开始时，铸造7。");
        var spinner = CardTextSemanticCompiler.Compile("在你的回合开始时，生成1个玻璃充能球。");
        var spinnerPlus = CardTextSemanticCompiler.Compile("生成1个玻璃充能球。在你的回合开始时，生成1个玻璃充能球。");

        Assert.True(genesis.IsFullyStructured && genesis.IsSimulatorExecutable);
        Assert.True(genesisPlus.IsFullyStructured && genesisPlus.IsSimulatorExecutable);
        Assert.True(cache.IsFullyStructured && cache.IsSimulatorExecutable);
        Assert.True(cachePlus.IsFullyStructured && cachePlus.IsSimulatorExecutable);
        Assert.True(throne.IsFullyStructured && throne.IsSimulatorExecutable);
        Assert.True(furnace.IsFullyStructured && furnace.IsSimulatorExecutable);
        Assert.True(furnacePlus.IsFullyStructured && furnacePlus.IsSimulatorExecutable);
        Assert.True(spinner.IsFullyStructured && spinner.IsSimulatorExecutable);
        Assert.True(spinnerPlus.IsFullyStructured && spinnerPlus.IsSimulatorExecutable);
    }

    [Fact]
    public void CompilesBatch5RandomCardGenerationPowerPool()
    {
        var calamity = CardTextSemanticCompiler.Compile("每当你打出一张攻击牌时，将一张随机攻击牌添加到你的手牌。");
        var creativeAi = CardTextSemanticCompiler.Compile("在你的回合开始时，将一张随机能力牌加入你的手牌。");
        var helloWorld = CardTextSemanticCompiler.Compile("在你的回合开始时，将一张随机普通牌加入你的手牌。");
        var helloWorldPlus = CardTextSemanticCompiler.Compile("固有。在你的回合开始时，将一张随机普通牌加入你的手牌。");
        var spectrum = CardTextSemanticCompiler.Compile("在你的回合开始时，将1张随机无色牌添加到你的手牌中。");
        var voidCall = CardTextSemanticCompiler.Compile("在你的回合开始时，将1张随机牌添加到你的手牌中。添加的牌会获得虚无。");
        var voidCallPlus = CardTextSemanticCompiler.Compile("固有。在你的回合开始时，将1张随机牌添加到你的手牌中。添加的牌会获得虚无。");

        Assert.True(calamity.IsFullyStructured && calamity.IsSimulatorExecutable);
        Assert.True(creativeAi.IsFullyStructured && creativeAi.IsSimulatorExecutable);
        Assert.True(helloWorld.IsFullyStructured && helloWorld.IsSimulatorExecutable);
        Assert.True(helloWorldPlus.IsFullyStructured && helloWorldPlus.IsSimulatorExecutable);
        Assert.True(spectrum.IsFullyStructured && spectrum.IsSimulatorExecutable);
        Assert.True(voidCall.IsFullyStructured && voidCall.IsSimulatorExecutable);
        Assert.True(voidCallPlus.IsFullyStructured && voidCallPlus.IsSimulatorExecutable);
    }

    [Fact]
    public void CompilesBatch6And7ChoicePoolsAndInstanceDuplications()
    {
        var jackpot = CardTextSemanticCompiler.Compile("造成25点伤害。将3张随机0能量的牌加入你的手牌。");
        var jackpotPlus = CardTextSemanticCompiler.Compile("造成30点伤害。将3张随机升级过的0能量的牌加入你的手牌。");
        var manifest = CardTextSemanticCompiler.Compile("获得7点格挡。将一张随机无色牌加入你的手牌。");
        var manifestPlus = CardTextSemanticCompiler.Compile("获得8点格挡。将一张随机升级过的无色牌加入你的手牌。");
        var quasar = CardTextSemanticCompiler.Compile("从3张随机无色牌中选择1张加入你的手牌。");
        var quasarPlus = CardTextSemanticCompiler.Compile("从3张随机升级过的无色牌中选择1张加入你的手牌。");
        var splash = CardTextSemanticCompiler.Compile("从3张其他角色的攻击牌中选择1张加入你的手牌。这张牌在本回合免费打出。");
        var splashPlus = CardTextSemanticCompiler.Compile("从3张其他角色的升级过的攻击牌中选择1张加入你的手牌。这张牌在本回合免费打出。");
        var dirge = CardTextSemanticCompiler.Compile("召唤3X次。将X张灵魂添加到你的抽牌堆中。消耗。");
        var nightmare = CardTextSemanticCompiler.Compile("选择一张牌。在下个回合将这张牌的3张复制品加入你的手牌。消耗。");

        Assert.True(jackpot.IsFullyStructured && jackpot.IsSimulatorExecutable);
        Assert.True(jackpotPlus.IsFullyStructured && jackpotPlus.IsSimulatorExecutable);
        Assert.True(manifest.IsFullyStructured && manifest.IsSimulatorExecutable);
        Assert.True(manifestPlus.IsFullyStructured && manifestPlus.IsSimulatorExecutable);
        Assert.True(quasar.IsFullyStructured && quasar.IsSimulatorExecutable);
        Assert.True(quasarPlus.IsFullyStructured && quasarPlus.IsSimulatorExecutable);
        Assert.True(splash.IsFullyStructured && splash.IsSimulatorExecutable);
        Assert.True(splashPlus.IsFullyStructured && splashPlus.IsSimulatorExecutable);
        Assert.True(dirge.IsFullyStructured);
        Assert.True(nightmare.IsFullyStructured && nightmare.IsSimulatorExecutable);
    }
}


