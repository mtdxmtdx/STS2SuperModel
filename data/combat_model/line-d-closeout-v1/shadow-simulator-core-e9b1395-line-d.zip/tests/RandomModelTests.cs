using System.Collections.Immutable;
using System.Reflection;
using STS2BestChoice.Core.Model;
using Xunit;

namespace STS2BestChoice.Tests;

public sealed class RandomModelTests
{
    [Fact]
    public void XoshiroStateMatchesReferenceVector()
    {
        var stream = new RngStreamSnapshot("test", 1, 2, 3, 4);

        var value = stream.NextUnsignedLong(out var next);

        Assert.Equal(11520UL, value);
        Assert.Equal(1, next.Counter);
        Assert.Equal(7UL, next.State0);
        Assert.Equal(0UL, next.State1);
        Assert.Equal(262146UL, next.State2);
        Assert.Equal(211106232532992UL, next.State3);
    }

    [Fact]
    public void AdvancingOneNamedStreamLeavesEveryOtherStreamUntouched()
    {
        var shuffle = new RngStreamSnapshot(RngSnapshotSet.Shuffle, 1, 2, 3, 4);
        var targets = new RngStreamSnapshot(RngSnapshotSet.CombatTargets, 5, 6, 7, 8);
        var set = new RngSnapshotSet(ImmutableDictionary<string, RngStreamSnapshot>.Empty
            .Add(shuffle.Name, shuffle)
            .Add(targets.Name, targets));

        _ = set.Get(RngSnapshotSet.Shuffle)!.NextUnsignedLong(out var advanced);
        var updated = set.With(advanced);

        Assert.NotEqual(shuffle, updated.Get(RngSnapshotSet.Shuffle));
        Assert.Equal(targets, updated.Get(RngSnapshotSet.CombatTargets));
        Assert.Equal(targets, set.Get(RngSnapshotSet.CombatTargets));
    }

    [Fact]
    public void CoreGeneratorMatchesInstalledGameRng()
    {
        var gameDll = Path.Combine(
            Environment.GetEnvironmentVariable("STS2_DIR") ?? @"D:\steam\steamapps\common\Slay the Spire 2",
            "data_sts2_windows_x86_64",
            "sts2.dll");
        Assert.True(File.Exists(gameDll), $"Installed game assembly not found: {gameDll}");
        var assembly = Assembly.LoadFrom(gameDll);
        var serializableType = assembly.GetType("MegaCrit.Sts2.Core.Saves.SerializableRng", throwOnError: true)!;
        var rngType = assembly.GetType("MegaCrit.Sts2.Core.Random.Rng", throwOnError: true)!;
        var serializable = Activator.CreateInstance(serializableType)!;
        SetField("state0", 1UL);
        SetField("state1", 2UL);
        SetField("state2", 3UL);
        SetField("state3", 4UL);
        SetField("counter", 0);
        var game = Activator.CreateInstance(rngType, serializable)!;
        var nextUnsignedLong = rngType.GetMethod("NextUnsignedLong", Type.EmptyTypes)!;
        var nextInt = rngType.GetMethod("NextInt", [typeof(int)])!;
        var core = new RngStreamSnapshot("test", 1, 2, 3, 4);

        for (var index = 0; index < 8; index++)
        {
            var expected = (ulong)nextUnsignedLong.Invoke(game, null)!;
            var actual = core.NextUnsignedLong(out core);
            Assert.Equal(expected, actual);
        }

        // Recreate both streams because NextInt may use bounded rejection rather
        // than a raw modulo operation.
        SetField("state0", 11UL);
        SetField("state1", 22UL);
        SetField("state2", 33UL);
        SetField("state3", 44UL);
        SetField("counter", 0);
        game = Activator.CreateInstance(rngType, serializable)!;
        core = new RngStreamSnapshot("test", 11, 22, 33, 44);
        foreach (var maximum in new[] { 2, 3, 7, 17, 1000 })
        {
            var expected = (int)nextInt.Invoke(game, [maximum])!;
            var actual = core.NextInt(maximum, out core);
            Assert.Equal(expected, actual);
        }

        void SetField(string name, object value) => serializableType
            .GetField(name, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)!
            .SetValue(serializable, value);
    }

    [Fact]
    public void CoreFisherYatesMatchesInstalledStableShuffle()
    {
        var gameDll = Path.Combine(
            Environment.GetEnvironmentVariable("STS2_DIR") ?? @"D:\steam\steamapps\common\Slay the Spire 2",
            "data_sts2_windows_x86_64",
            "sts2.dll");
        var assembly = Assembly.LoadFrom(gameDll);
        var serializableType = assembly.GetType("MegaCrit.Sts2.Core.Saves.SerializableRng", true)!;
        var rngType = assembly.GetType("MegaCrit.Sts2.Core.Random.Rng", true)!;
        var serializable = Activator.CreateInstance(serializableType)!;
        foreach (var (name, value) in new[]
                 {
                     ("state0", (object)11UL), ("state1", 22UL), ("state2", 33UL), ("state3", 44UL), ("counter", 0)
                 })
            serializableType.GetField(name, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)!.SetValue(serializable, value);
        var gameRng = Activator.CreateInstance(rngType, serializable)!;
        var gameList = Enumerable.Range(0, 6).ToList();
        var extensionType = assembly.GetType("MegaCrit.Sts2.Core.Extensions.ListExtensions", true)!;
        var stableShuffle = extensionType.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static)
            .Single(method => method.Name == "StableShuffle")
            .MakeGenericMethod(typeof(int));
        _ = stableShuffle.Invoke(null, [gameList, gameRng]);

        var coreList = Enumerable.Range(0, 6).ToList();
        var core = new RngStreamSnapshot(RngSnapshotSet.Shuffle, 11, 22, 33, 44);
        for (var index = coreList.Count - 1; index > 0; index--)
        {
            var swap = core.NextInt(index + 1, out core);
            (coreList[index], coreList[swap]) = (coreList[swap], coreList[index]);
        }

        Assert.Equal(gameList, coreList);
    }
}
