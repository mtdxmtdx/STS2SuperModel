using STS2BestChoice.Core.Model;
using STS2BestChoice.Core.Search;
using Xunit;

namespace STS2BestChoice.Tests;

public sealed class ExpectimaxEngineTests
{
    [Fact]
    public void ComputesWeightedValueForFiftyFiftyDraw()
    {
        var engine = new ExpectimaxEngine<State, string>(
            new DrawProblem(),
            new ExpectimaxOptions(TimeSpan.FromSeconds(1), MaximumDepth: 2));

        var result = engine.Search(new State("root", 0, false));

        Assert.True(result.IsComplete);
        Assert.Equal(-3m, result.Value);
        Assert.Equal("draw", Assert.Single(result.PrincipalVariation));
    }

    [Fact]
    public void ChoosesTheBestDecisionBeforeChanceResolution()
    {
        var engine = new ExpectimaxEngine<State, string>(
            new DecisionProblem(),
            new ExpectimaxOptions(TimeSpan.FromSeconds(1), MaximumDepth: 2));

        var result = engine.Search(new State("root", 0, false));

        Assert.Equal(4m, result.Value);
        Assert.Equal("safe", Assert.Single(result.PrincipalVariation));
    }

    [Fact]
    public void ChoosesHigherExpectedRandomActionOverLowerFixedAction()
    {
        var result = new ExpectimaxEngine<State, string>(
                new PositiveRandomDecisionProblem(),
                new ExpectimaxOptions(TimeSpan.FromSeconds(1), MaximumDepth: 2))
            .Search(new State("root", 0m, false));

        Assert.Equal(6m, result.Value);
        Assert.Equal("random", Assert.Single(result.PrincipalVariation));
    }

    [Fact]
    public void ReusesTransposedStateAtTheSameDepth()
    {
        var problem = new TranspositionProblem();
        var engine = new ExpectimaxEngine<State, string>(
            problem,
            new ExpectimaxOptions(TimeSpan.FromSeconds(1), MaximumDepth: 3));

        var result = engine.Search(new State("root", 0, false));

        Assert.Equal(9m, result.Value);
        Assert.Equal(1, problem.SharedExpansionCount);
    }

    [Fact]
    public void DeterministicallyStratifiesChanceSetsLargerThanLimit()
    {
        var options = new ExpectimaxOptions(
            TimeSpan.FromSeconds(2),
            MaximumDepth: 2,
            MaximumChanceBranches: 32);

        var first = new ExpectimaxEngine<State, string>(new ManyBranchProblem(64), options)
            .Search(new State("root", 0m, false));
        var second = new ExpectimaxEngine<State, string>(new ManyBranchProblem(64), options)
            .Search(new State("root", 0m, false));

        Assert.False(first.IsComplete);
        Assert.Equal(PredictionConfidence.Estimated, first.Confidence);
        Assert.Equal(first.Value, second.Value);
        var sample = Assert.Single(first.ChanceSampling);
        var repeatSample = Assert.Single(second.ChanceSampling);
        Assert.Equal(sample.SamplingSeed, repeatSample.SamplingSeed);
        Assert.True(sample.SampledBranchLabels.SequenceEqual(repeatSample.SampledBranchLabels));
        Assert.Equal(64, sample.BranchCount);
        Assert.Equal(32, sample.SampleCount);
        Assert.Equal(1m / 64m * sample.SampledBranchLabels.Distinct().Count(), sample.ProbabilityMassCovered);
        Assert.Contains(sample.SampledBranchLabels, label => int.Parse(label.AsSpan("branch-".Length)) >= 32);
        Assert.True(sample.Variance > 0m);
        Assert.True(sample.ConfidenceInterval95Lower < sample.Mean);
        Assert.True(sample.ConfidenceInterval95Upper > sample.Mean);
    }

    [Fact]
    public void EnumeratesExactlyThirtyTwoChanceBranchesWithoutSampling()
    {
        var result = new ExpectimaxEngine<State, string>(
                new ManyBranchProblem(32),
                new ExpectimaxOptions(TimeSpan.FromSeconds(2), MaximumDepth: 2, MaximumChanceBranches: 32))
            .Search(new State("root", 0m, false));

        Assert.True(result.IsComplete);
        Assert.Equal(PredictionConfidence.Reliable, result.Confidence);
        Assert.Empty(result.ChanceSampling);
        Assert.Equal(15.5m, result.Value);
    }

    [Fact]
    public void MissingProbabilityModelIsNotTreatedAsUniform()
    {
        var result = new ExpectimaxEngine<State, string>(
                new UnknownProbabilityProblem(),
                new ExpectimaxOptions(TimeSpan.FromSeconds(2), MaximumDepth: 2, MaximumChanceBranches: 32))
            .Search(new State("root", 123m, false));

        Assert.False(result.IsComplete);
        Assert.Equal(PredictionConfidence.Uncalculable, result.Confidence);
        Assert.Equal(123m, result.Value);
        Assert.Empty(result.PrincipalVariation);
    }

    [Fact]
    public void MergesEquivalentChanceStatesBeforeEvaluation()
    {
        var result = new ExpectimaxEngine<State, string>(
                new DuplicateBranchProblem(),
                new ExpectimaxOptions(TimeSpan.FromSeconds(1), MaximumDepth: 2))
            .Search(new State("root", 0m, false));

        Assert.True(result.IsComplete);
        Assert.Equal(7m, result.Value);
    }

    [Fact]
    public void SampledOutcomeMetadataCannotProduceReliableResult()
    {
        var result = new ExpectimaxEngine<State, string>(
                new SampledMetadataProblem(),
                new ExpectimaxOptions(TimeSpan.FromSeconds(1), MaximumDepth: 2))
            .Search(new State("root", 0m, false));

        Assert.False(result.IsComplete);
        Assert.Equal(PredictionConfidence.Estimated, result.Confidence);
        Assert.Equal(6m, result.Value);
    }

    [Fact]
    public void UncalculableOutcomeMetadataCannotBeDowngradedToEstimated()
    {
        var result = new ExpectimaxEngine<State, string>(
                new UncalculableMetadataProblem(),
                new ExpectimaxOptions(TimeSpan.FromSeconds(1), MaximumDepth: 2))
            .Search(new State("root", 0m, false));

        Assert.False(result.IsComplete);
        Assert.Equal(PredictionConfidence.Uncalculable, result.Confidence);
    }

    [Fact]
    public void EstimatedLosingActionDoesNotContaminateReliableWinningAction()
    {
        var result = new ExpectimaxEngine<State, string>(
                new MixedConfidenceDecisionProblem(),
                new ExpectimaxOptions(TimeSpan.FromSeconds(1), MaximumDepth: 2))
            .Search(new State("root", 0m, false));

        Assert.False(result.IsComplete);
        Assert.Equal(10m, result.Value);
        Assert.Equal("reliable", Assert.Single(result.PrincipalVariation));
        Assert.Equal(PredictionConfidence.Reliable, result.Confidence);
    }

    [Fact]
    public void AnalyticTruncationKeepsCoverageAndDeterministicValueBounds()
    {
        var result = new ExpectimaxEngine<State, string>(
                new TruncatedMassProblem(),
                new ExpectimaxOptions(
                    TimeSpan.FromSeconds(1),
                    MaximumDepth: 2,
                    MinimumEvaluationValue: -10m,
                    MaximumEvaluationValue: 30m))
            .Search(new State("root", 0m, false));

        Assert.False(result.IsComplete);
        Assert.Equal(PredictionConfidence.Estimated, result.Confidence);
        Assert.Equal(15m, result.Value);
        var interval = Assert.Single(result.ChanceSampling);
        Assert.Equal("EstimatedTruncated", interval.OutcomeQuality);
        Assert.Equal(0.6m, interval.ProbabilityMassCovered);
        Assert.Equal(5m, interval.ConfidenceInterval95Lower);
        Assert.Equal(21m, interval.ConfidenceInterval95Upper);
        Assert.Equal(2, interval.BranchCount);
        Assert.Equal(2, interval.SampleCount);
        Assert.Equal(0UL, interval.SamplingSeed);
    }

    private sealed record State(string Id, decimal Value, bool Terminal);

    private sealed class TruncatedMassProblem : IExpectimaxProblem<State, string>
    {
        public IEnumerable<string> Actions(State state) => state.Terminal ? [] : ["truncated"];

        public IEnumerable<ChanceBranch<State>> Apply(State state, string action) =>
        [
            new("a", 0.3m, new State("a", 10m, true),
                OutcomeQuality: "Estimated", ProbabilityMassCovered: 0.6m),
            new("b", 0.3m, new State("b", 20m, true),
                OutcomeQuality: "Estimated", ProbabilityMassCovered: 0.6m)
        ];

        public bool IsTerminal(State state) => state.Terminal;
        public decimal Evaluate(State state) => state.Value;
        public string Key(State state) => state.Id;
    }

    private sealed class DrawProblem : IExpectimaxProblem<State, string>
    {
        public IEnumerable<string> Actions(State state) => state.Terminal ? [] : ["draw"];

        public IEnumerable<ChanceBranch<State>> Apply(State state, string action) =>
        [
            new("Strike", 0.5m, new State("strike", 0m, true)),
            new("Bane", 0.5m, new State("bane", -6m, true))
        ];

        public bool IsTerminal(State state) => state.Terminal;
        public decimal Evaluate(State state) => state.Value;
        public string Key(State state) => state.Id;
    }

    private sealed class DecisionProblem : IExpectimaxProblem<State, string>
    {
        public IEnumerable<string> Actions(State state) => state.Terminal ? [] : ["risky", "safe"];

        public IEnumerable<ChanceBranch<State>> Apply(State state, string action) => action switch
        {
            "risky" =>
            [
                new("high", 0.5m, new State("high", 10m, true)),
                new("low", 0.5m, new State("low", -10m, true))
            ],
            _ => [new("fixed", 1m, new State("fixed", 4m, true))]
        };

        public bool IsTerminal(State state) => state.Terminal;
        public decimal Evaluate(State state) => state.Value;
        public string Key(State state) => state.Id;
    }

    private sealed class SampledMetadataProblem : IExpectimaxProblem<State, string>
    {
        public IEnumerable<string> Actions(State state) => state.Terminal ? [] : ["sampled"];

        public IEnumerable<ChanceBranch<State>> Apply(State state, string action) =>
        [
            new("low", 0.5m, new State("low", 4m, true), OutcomeKind.Stochastic,
                ProbabilityKnown: true, OutcomeQuality: "Sampled", ProbabilityMassCovered: 0.5m,
                EffectiveSampleSize: 1m),
            new("high", 0.5m, new State("high", 8m, true), OutcomeKind.Stochastic,
                ProbabilityKnown: true, OutcomeQuality: "Sampled", ProbabilityMassCovered: 0.5m,
                EffectiveSampleSize: 1m)
        ];

        public bool IsTerminal(State state) => state.Terminal;
        public decimal Evaluate(State state) => state.Value;
        public string Key(State state) => state.Id;
    }

    private sealed class UncalculableMetadataProblem : IExpectimaxProblem<State, string>
    {
        public IEnumerable<string> Actions(State state) => state.Terminal ? [] : ["unknown"];

        public IEnumerable<ChanceBranch<State>> Apply(State state, string action) =>
        [
            new("unknown", 1m, new State("done", 4m, true), OutcomeKind.Stochastic,
                ProbabilityKnown: false, RngSource: "unknown", OutcomeQuality: "Uncalculable")
        ];

        public bool IsTerminal(State state) => state.Terminal;
        public decimal Evaluate(State state) => state.Value;
        public string Key(State state) => state.Id;
    }

    private sealed class MixedConfidenceDecisionProblem : IExpectimaxProblem<State, string>
    {
        public IEnumerable<string> Actions(State state) =>
            state.Terminal ? [] : ["estimated", "reliable"];

        public IEnumerable<ChanceBranch<State>> Apply(State state, string action) => action switch
        {
            "estimated" => [new ChanceBranch<State>(
                "estimated", 1m, new State("estimated", 1m, true),
                OutcomeKind.Stochastic, ProbabilityKnown: true, OutcomeQuality: "Estimated")],
            _ => [new ChanceBranch<State>(
                "reliable", 1m, new State("reliable", 10m, true))]
        };

        public bool IsTerminal(State state) => state.Terminal;
        public decimal Evaluate(State state) => state.Value;
        public string Key(State state) => state.Id;
    }

    private sealed class PositiveRandomDecisionProblem : IExpectimaxProblem<State, string>
    {
        public IEnumerable<string> Actions(State state) => state.Terminal ? [] : ["fixed", "random"];

        public IEnumerable<ChanceBranch<State>> Apply(State state, string action) => action == "random"
            ? [
                new("high", 0.5m, new State("high", 10m, true)),
                new("low", 0.5m, new State("low", 2m, true))
            ]
            : [new("fixed", 1m, new State("fixed", 4m, true))];

        public bool IsTerminal(State state) => state.Terminal;
        public decimal Evaluate(State state) => state.Value;
        public string Key(State state) => state.Id;
    }

    private sealed class TranspositionProblem : IExpectimaxProblem<State, string>
    {
        public int SharedExpansionCount { get; private set; }

        public IEnumerable<string> Actions(State state)
        {
            if (state.Id == "shared") SharedExpansionCount++;
            return state.Id switch
            {
                "root" => ["left", "right"],
                "shared" => ["finish"],
                _ => []
            };
        }

        public IEnumerable<ChanceBranch<State>> Apply(State state, string action) => state.Id switch
        {
            "root" => [new ChanceBranch<State>(action, 1m, new State("shared", 0m, false))],
            "shared" => [new ChanceBranch<State>("done", 1m, new State("done", 9m, true))],
            _ => []
        };

        public bool IsTerminal(State state) => state.Terminal;
        public decimal Evaluate(State state) => state.Value;
        public string Key(State state) => state.Id;
    }

    private sealed class ManyBranchProblem(int branchCount) : IExpectimaxProblem<State, string>
    {
        public IEnumerable<string> Actions(State state) => state.Terminal ? [] : ["draw"];

        public IEnumerable<ChanceBranch<State>> Apply(State state, string action) =>
            Enumerable.Range(0, branchCount)
                .Select(index => new ChanceBranch<State>(
                    $"branch-{index}",
                    1m / branchCount,
                    new State($"terminal-{index}", index, true)));

        public bool IsTerminal(State state) => state.Terminal;
        public decimal Evaluate(State state) => state.Value;
        public string Key(State state) => state.Id;
    }

    private sealed class UnknownProbabilityProblem : IExpectimaxProblem<State, string>
    {
        public IEnumerable<string> Actions(State state) => state.Terminal ? [] : ["unknown"];

        public IEnumerable<ChanceBranch<State>> Apply(State state, string action) =>
        [
            new("unknown-a", 0m, new State("a", -100m, true), ProbabilityKnown: false, RngSource: "unknown"),
            new("unknown-b", 0m, new State("b", 100m, true), ProbabilityKnown: false, RngSource: "unknown")
        ];

        public bool IsTerminal(State state) => state.Terminal;
        public decimal Evaluate(State state) => state.Value;
        public string Key(State state) => state.Id;
    }

    private sealed class DuplicateBranchProblem : IExpectimaxProblem<State, string>
    {
        public IEnumerable<string> Actions(State state) => state.Terminal ? [] : ["draw"];

        public IEnumerable<ChanceBranch<State>> Apply(State state, string action) =>
        [
            new("same-a", 0.25m, new State("done", 7m, true)),
            new("same-b", 0.75m, new State("done", 7m, true))
        ];

        public bool IsTerminal(State state) => state.Terminal;
        public decimal Evaluate(State state) => state.Value;
        public string Key(State state) => state.Id;
    }
}
