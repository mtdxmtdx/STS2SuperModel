using System.Collections.Immutable;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Serialization;
using MegaCrit.Sts2.Core.Helpers;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Models.Powers;
using MegaCrit.Sts2.Core.TestSupport;
using STS2BestChoice.Core.Model;
using Xunit;
using Xunit.Abstractions;

namespace STS2BestChoice.Tests;

public sealed class PowerCatalogTests
{
    public const string ExpectedSha256 = "0861BFA1DF347538D932F22D580E75420F08082792EB914E53B4882764ACDBE9";
    public const string GameVersion = "0.111.0";
    public const string GameCommit = "41cef1ea";
    public const string CliProtocolVersion = "0.2.0";

    private readonly ITestOutputHelper _output;

    public PowerCatalogTests(ITestOutputHelper output)
    {
        _output = output;
    }

    [ModuleInitializer]
    internal static void InitAssemblyResolver()
    {
        var sts2Dir = @"D:\steam\steamapps\common\Slay the Spire 2\data_sts2_windows_x86_64";
        AssemblyLoadContext.Default.Resolving += (context, name) =>
        {
            var path = Path.Combine(sts2Dir, name.Name + ".dll");
            if (File.Exists(path))
            {
                return context.LoadFromAssemblyPath(path);
            }
            return null;
        };
    }

    private static readonly object _initLock = new();
    private static bool _initialized = false;
    internal static void EnsureModelDbInitialized()
    {
        lock (_initLock)
        {
            if (_initialized) return;
            TestMode.IsOn = true;

            var reflectionHelper = typeof(ReflectionHelper);
            var allTypes = reflectionHelper.GetField("_allTypes", BindingFlags.Static | BindingFlags.NonPublic);
            var modTypes = reflectionHelper.GetField("_modTypes", BindingFlags.Static | BindingFlags.NonPublic);
            allTypes?.SetValue(null, Array.Empty<Type>());
            modTypes?.SetValue(null, Array.Empty<Type>());

            var subtypes = AbstractModelSubtypes.All;
            for (int i = 0; i < subtypes.Count; i++)
            {
                try
                {
                    ModelDb.Inject(subtypes[i]);
                }
                catch
                {
                }
            }
            _initialized = true;
        }
    }

    public sealed record PowerCatalogEntry(
        string StableId,
        string CanonicalName,
        string LocalizedNameZh,
        string Description,
        string DynamicDescription,
        string RuntimeType,
        string OwnerType,
        string ApplierType,
        bool AmountSupported,
        ImmutableArray<string> DynamicVarNames,
        ImmutableDictionary<string, decimal> DynamicVars,
        ImmutableArray<string> InternalCounters,
        ImmutableArray<string> TriggerPhases,
        ImmutableArray<string> CanonicalStatusIds,
        bool AffectsCurrentTurn,
        bool StateCaptureSupport,
        string SimulatorSupport,
        string Evidence,
        string SourceVersion,
        string AssemblySha256,
        string Notes);

    public sealed record PowerCatalogDocument(
        int SchemaVersion,
        string GameVersion,
        string GameCommit,
        string AssemblySha256,
        string CliProtocolVersion,
        string GeneratedAtUtc,
        ImmutableArray<PowerCatalogEntry> Powers);

    [Fact]
    public void GenerateAndExportFullPowerCatalog()
    {
        EnsureModelDbInitialized();

        var workspaceRoot = FindWorkspaceRoot();
        var zhsJsonPath = Path.Combine(workspaceRoot, "STS2SuperModel", "sts2-cli-v0111", "localization_zhs", "powers.json");
        var engJsonPath = Path.Combine(workspaceRoot, "STS2SuperModel", "sts2-cli-v0111", "localization_eng", "powers.json");
        var zhs = JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(zhsJsonPath))!;
        var eng = JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(engJsonPath))!;

        // Declared by existing simulator mappings. This catalog exporter does
        // not behaviorally prove complete support for these powers.
        var simulatorDeclaredSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "STRENGTH", "DEXTERITY", "FOCUS", "WEAK", "VULNERABLE", "POISON", "DOOM",
            "DEMON_FORM", "BUFFER", "THORNS", "SLOTH", "PANACHE", "HAUNT", "CORRUPTION",
            "BARRICADE", "BORROWED_TIME", "NO_BLOCK", "SHADOW_STEP", "DOUBLE_DAMAGE",
            "COLOSSUS", "TRACKING", "UNMOVABLE", "NEUROSURGE", "SHADOWMELD", "AFTERIMAGE",
            "RAGE", "SPIRIT_OF_ASH", "STORM", "SUBROUTINE", "DANSE_MACABRE", "VIGOR",
            "PREP_TIME", "CRIMSON_MANTLE", "INFINITE_BLADES", "WASTE_AWAY", "MIND_ROT",
            "ITERATION", "PAGESTORM", "VICIOUS", "INFERNO", "RUPTURE", "ACCURACY",
            "FAN_OF_KNIVES", "PHANTOM_BLADES", "JUGGLING", "ACCELERANT", "THE_GAMBIT",
            "LETHALITY", "PALE_BLUE_DOT", "ONE_FOR_ALL", "FASTEN", "HELLRAISER",
            "STAMPEDE", "REAPER_FORM", "JUGGERNAUT", "SERPENT_FORM", "ENVENOM",
            "MONARCHS_GAZE", "MONOLOGUE", "CORROSIVE_WAVE", "SPEEDSTER", "FLAME_BARRIER",
            "AUTOMATION", "ORBIT", "FERAL", "NOSTALGIA", "ECHO_FORM", "BURST",
            "ONE_TWO_PUNCH", "SIGNAL_BOOST", "DUPLICATION", "ARTIFACT", "METALLICIZE", "PLATING"
        };
        var runtimeProbedSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            // P0 live probes with zero-mismatch CLI/Core differentials:
            // Zero-mismatch v0.111 CLI/Core behavior probes. This set is the
            // promotion gate from simulator_declared to simulator_supported.
            "VULNERABLE", "WEAK", "STRENGTH", "VIGOR", "DEXTERITY",
            "DEMON_FORM", "BARRICADE", "RUPTURE", "AFTERIMAGE",
            // P1 batch 1 verified powers:
            "THORNS", "ACCURACY", "PLATING", "POISON", "PANACHE",
            // P1 batch 2 verified powers:
            "RAGE", "FLAME_BARRIER", "CORRUPTION", "INFINITE_BLADES", "ENVENOM", "BUFFER"
        };

        var powerModelType = typeof(MegaCrit.Sts2.Core.Models.PowerModel);
        var sts2Assembly = powerModelType.Assembly;
        var powerTypes = sts2Assembly.GetTypes()
            .Where(t => !t.IsAbstract && powerModelType.IsAssignableFrom(t))
            .OrderBy(t => t.Name, StringComparer.Ordinal)
            .ToArray();

        _output.WriteLine($"Discovered {powerTypes.Length} concrete PowerModel classes in sts2.dll");

        var catalogEntries = new List<PowerCatalogEntry>();

        foreach (var type in powerTypes)
        {
            PowerModel? instance = null;
            try
            {
                instance = Activator.CreateInstance(type) as PowerModel;
            }
            catch
            {
                try
                {
                    instance = System.Runtime.CompilerServices.RuntimeHelpers.GetUninitializedObject(type) as PowerModel;
                }
                catch { }
            }

            string? rawId = null;
            if (instance != null)
            {
                try
                {
                    var idProp = type.GetProperty("Id", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                    var idVal = idProp?.GetValue(instance);
                    if (idVal != null)
                    {
                        var entryProp = idVal.GetType().GetProperty("Entry");
                        rawId = entryProp?.GetValue(idVal)?.ToString() ?? idVal.ToString();
                    }
                }
                catch { }
            }

            if (string.IsNullOrWhiteSpace(rawId) || rawId == "ModelId")
            {
                rawId = type.Name;
            }

            if (rawId.EndsWith("Power", StringComparison.OrdinalIgnoreCase) && rawId.Length > 5)
            {
                // Convert PascalCase to UPPER_SNAKE_CASE
                var nameWithoutPower = rawId[..^5];
                rawId = string.Concat(nameWithoutPower.Select((c, i) => i > 0 && char.IsUpper(c) ? "_" + c : c.ToString())).ToUpperInvariant();
            }
            else
            {
                rawId = rawId.ToUpperInvariant();
            }

            var stableId = rawId.EndsWith("_POWER", StringComparison.OrdinalIgnoreCase) ? rawId[..^6] : rawId;

            // Lookup localization
            string nameZh = stableId;
            string nameEn = stableId;
            string descZh = string.Empty;
            string descEn = string.Empty;

            var lookupKeys = new[]
            {
                $"{stableId}_POWER",
                stableId,
                $"{rawId}_POWER",
                rawId
            };

            foreach (var key in lookupKeys)
            {
                if (zhs.TryGetValue($"{key}.title", out var titleZh)) { nameZh = titleZh; }
                if (eng.TryGetValue($"{key}.title", out var titleEn)) { nameEn = titleEn; }
                if (zhs.TryGetValue($"{key}.description", out var dZh)) { descZh = dZh; }
                if (eng.TryGetValue($"{key}.description", out var dEn)) { descEn = dEn; }
                if (!string.IsNullOrEmpty(descZh)) break;
            }

            // Methods inspection
            var methods = type.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.DeclaredOnly)
                .Select(m => m.Name)
                .Where(m => !m.StartsWith("<") && !m.StartsWith("get_") && !m.StartsWith("set_"))
                .ToArray();

            var triggerPhases = new List<string>();
            if (methods.Any(m => m.Contains("SideTurnStart") || m.Contains("RoundStart") || m.Contains("CombatStart") || m.Contains("PrePlayPhase")))
                triggerPhases.Add("TurnStart");
            if (methods.Any(m => m.Contains("TurnEnd") || m.Contains("SideTurnEnd") || m.Contains("CombatEnd")))
                triggerPhases.Add("TurnEnd");
            if (methods.Any(m => m.Contains("Card") || m.Contains("Play") || m.Contains("Action")))
                triggerPhases.Add("CardPlay");
            if (methods.Any(m => m.Contains("Damage") || m.Contains("Hp") || m.Contains("Attacked") || m.Contains("Hit")))
                triggerPhases.Add("DamageReceived");
            if (methods.Any(m => m.Contains("Block")))
                triggerPhases.Add("BlockGain");
            if (triggerPhases.Count == 0)
                triggerPhases.Add("Passive");

            // DynamicVars
            var dynVarNamesBuilder = ImmutableArray.CreateBuilder<string>();
            var dynVarsBuilder = ImmutableDictionary.CreateBuilder<string, decimal>(StringComparer.Ordinal);
            try
            {
                if (instance?.DynamicVars?.Values is not null)
                {
                    foreach (var v in instance.DynamicVars.Values)
                    {
                        dynVarNamesBuilder.Add(v.Name);
                        dynVarsBuilder[v.Name] = (decimal)v.BaseValue;
                    }
                }
            }
            catch { }

            // Counters
            var counters = new List<string>();
            foreach (var prop in type.GetProperties(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance))
            {
                if (prop.Name is "Counter" or "Uses" or "Remaining" or "Charges" or "TimesTriggered")
                    counters.Add(prop.Name);
            }

            // Owner / Applier
            string ownerType = "Creature";
            if (stableId.Contains("PLAYER") || type.Name.Contains("Player")) ownerType = "Player";
            else if (stableId.Contains("MONSTER") || stableId.Contains("ENEMY") || type.Name.Contains("Monster") || type.Name.Contains("Enemy")) ownerType = "Enemy";

            bool isSimulatorDeclared = simulatorDeclaredSet.Contains(stableId);
            bool affectsCurrentTurn = isSimulatorDeclared || triggerPhases.Any(p => p is "TurnStart" or "CardPlay" or "DamageReceived" or "BlockGain");
            string simStatus = runtimeProbedSet.Contains(stableId)
                ? "simulator_supported"
                : isSimulatorDeclared ? "simulator_declared" : "state_captured_only";
            string evidence = runtimeProbedSet.Contains(stableId)
                ? "LiveObserved"
                : methods.Length > 0 || dynVarNamesBuilder.Count > 0
                    ? "HeuristicInferred"
                    : "Unknown";

            catalogEntries.Add(new PowerCatalogEntry(
                StableId: stableId,
                CanonicalName: string.IsNullOrEmpty(nameEn) ? stableId : nameEn,
                LocalizedNameZh: string.IsNullOrEmpty(nameZh) ? stableId : nameZh,
                Description: descEn,
                DynamicDescription: descZh,
                RuntimeType: type.FullName ?? type.Name,
                OwnerType: ownerType,
                ApplierType: "Creature",
                AmountSupported: true,
                DynamicVarNames: dynVarNamesBuilder.ToImmutable(),
                DynamicVars: dynVarsBuilder.ToImmutable(),
                InternalCounters: counters.ToImmutableArray(),
                TriggerPhases: triggerPhases.ToImmutableArray(),
                CanonicalStatusIds: ImmutableArray.Create(stableId),
                AffectsCurrentTurn: affectsCurrentTurn,
                StateCaptureSupport: true,
                SimulatorSupport: simStatus,
                Evidence: evidence,
                SourceVersion: GameVersion,
                AssemblySha256: ExpectedSha256,
                Notes: methods.Length > 0 ? $"Declared methods: {string.Join(", ", methods)}" : "Passive / state-only power."));
        }

        var sortedEntries = catalogEntries.OrderBy(e => e.StableId, StringComparer.Ordinal).ToImmutableArray();
        var document = new PowerCatalogDocument(
            SchemaVersion: 1,
            GameVersion: GameVersion,
            GameCommit: GameCommit,
            AssemblySha256: ExpectedSha256,
            CliProtocolVersion: CliProtocolVersion,
            GeneratedAtUtc: "2026-08-26T00:00:00Z",
            Powers: sortedEntries);

        var jsonOptions = new JsonSerializerOptions
        {
            WriteIndented = true,
            PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
        };

        var catalogJson = JsonSerializer.Serialize(document, jsonOptions);

        // Power Schema
        var schemaJson = @"{
  ""$schema"": ""https://json-schema.org/draft/2020-12/schema"",
  ""title"": ""PowerCatalogSchemaV1"",
  ""type"": ""object"",
  ""required"": [""schema_version"", ""game_version"", ""game_commit"", ""assembly_sha256"", ""cli_protocol_version"", ""powers""],
  ""properties"": {
    ""schema_version"": { ""type"": ""integer"", ""const"": 1 },
    ""game_version"": { ""type"": ""string"", ""const"": ""0.111.0"" },
    ""game_commit"": { ""type"": ""string"", ""const"": ""41cef1ea"" },
    ""assembly_sha256"": { ""type"": ""string"", ""const"": ""0861BFA1DF347538D932F22D580E75420F08082792EB914E53B4882764ACDBE9"" },
    ""cli_protocol_version"": { ""type"": ""string"", ""const"": ""0.2.0"" },
    ""generated_at_utc"": { ""type"": ""string"" },
    ""powers"": {
      ""type"": ""array"",
      ""items"": {
        ""type"": ""object"",
        ""required"": [
          ""stable_id"", ""canonical_name"", ""localized_name_zh"", ""runtime_type"",
          ""owner_type"", ""applier_type"", ""amount_supported"", ""trigger_phases"",
          ""canonical_status_ids"", ""affects_current_turn"", ""state_capture_support"",
          ""simulator_support"", ""evidence"", ""source_version"", ""assembly_sha256""
        ],
        ""properties"": {
          ""stable_id"": { ""type"": ""string"" },
          ""canonical_name"": { ""type"": ""string"" },
          ""localized_name_zh"": { ""type"": ""string"" },
          ""runtime_type"": { ""type"": ""string"" },
          ""owner_type"": { ""type"": ""string"" },
          ""applier_type"": { ""type"": ""string"" },
          ""amount_supported"": { ""type"": ""boolean"" },
          ""trigger_phases"": { ""type"": ""array"", ""items"": { ""type"": ""string"" } },
          ""canonical_status_ids"": { ""type"": ""array"", ""items"": { ""type"": ""string"" } },
          ""affects_current_turn"": { ""type"": ""boolean"" },
          ""state_capture_support"": { ""type"": ""boolean"" },
          ""simulator_support"": {
            ""type"": ""string"",
            ""enum"": [""simulator_supported"", ""partially_supported"", ""state_captured_only"", ""no_combat_effect"", ""unsupported_known_effect"", ""unknown""]
          },
          ""evidence"": {
            ""type"": ""string"",
            ""enum"": [""ILConfirmed"", ""LiveObserved"", ""OfficialPatchNote"", ""VersionedText"", ""HeuristicInferred"", ""Unknown""]
          },
          ""source_version"": { ""type"": ""string"" },
          ""assembly_sha256"": { ""type"": ""string"" }
        }
      }
    }
  }
}";

        // Coverage Report
        var total = document.Powers.Length;
        var simulatorDeclaredCount = document.Powers.Count(p => p.SimulatorSupport == "simulator_declared");
        var simSupportedCount = document.Powers.Count(p => p.SimulatorSupport == "simulator_supported");
        var stateCapturedCount = total;
        var ilInspectedCount = 0;
        var runtimeProbedCount = runtimeProbedSet.Count;
        var noCombatCount = 0;
        var stateCapturedOnlyCount = document.Powers.Count(p => p.SimulatorSupport == "state_captured_only");
        var unknownCount = document.Powers.Count(p => p.Evidence == "Unknown");

        var coverageReport = new
        {
            schema_version = 1,
            game_version = GameVersion,
            game_commit = GameCommit,
            assembly_sha256 = ExpectedSha256,
            cli_protocol_version = CliProtocolVersion,
            generated_at_utc = "2026-08-26T00:00:00Z",
            summary = new
            {
                total_powers = total,
                cataloged_count = total,
                state_captured_count = stateCapturedCount,
                il_inspected_count = ilInspectedCount,
                runtime_probed_count = runtimeProbedCount,
                simulator_supported_count = simSupportedCount,
                simulator_declared_count = simulatorDeclaredCount,
                no_combat_effect_count = noCombatCount,
                state_captured_only_count = stateCapturedOnlyCount,
                unknown_count = unknownCount
            },
            powers = document.Powers.Select(p => new
            {
                stable_id = p.StableId,
                canonical_name = p.CanonicalName,
                localized_name_zh = p.LocalizedNameZh,
                runtime_type = p.RuntimeType,
                cataloged = true,
                state_captured = p.StateCaptureSupport,
                il_inspected = false,
                runtime_probed = runtimeProbedSet.Contains(p.StableId),
                simulator_declared = p.SimulatorSupport == "simulator_declared",
                simulator_supported = p.SimulatorSupport == "simulator_supported",
                evidence_level = p.Evidence,
                support_status = p.SimulatorSupport,
                affects_current_turn = p.AffectsCurrentTurn
            }).ToArray()
        };

        var coverageJson = JsonSerializer.Serialize(coverageReport, jsonOptions);

        // README Markdown
        var md = new System.Text.StringBuilder();
        md.AppendLine("# Slay the Spire 2 v0.111.0 Power 覆盖率与目录报告");
        md.AppendLine();
        md.AppendLine($"- **游戏版本**: `{GameVersion}` (commit `{GameCommit}`)");
        md.AppendLine($"- **程序集 SHA-256**: `{ExpectedSha256}`");
        md.AppendLine($"- **CLI 协议**: `{CliProtocolVersion}`");
        md.AppendLine($"- **生成时间 (UTC)**: `2026-08-26T00:00:00Z`");
        md.AppendLine();
        md.AppendLine("## 汇总统计");
        md.AppendLine();
        md.AppendLine("| 指标 | 数量 | 占比 |");
        md.AppendLine("| :--- | :--- | :--- |");
        md.AppendLine($"| 游戏目录 Power 总数 | **{total}** | 100.0% |");
        md.AppendLine($"| 已结构化数量 | **{total}** | 100.0% |");
        md.AppendLine($"| 已捕获状态数量 | **{stateCapturedCount}** | 100.0% |");
        md.AppendLine($"| 已检查 IL 语义数量 | **{ilInspectedCount}** | 0.0% |");
        md.AppendLine($"| 已完成运行时探针数量 | **{runtimeProbedCount}** | {Math.Round(100.0 * runtimeProbedCount / total, 1)}% |");
        md.AppendLine($"| 模拟器声明映射数量（未由本目录验证行为完整性） | **{simulatorDeclaredCount}** | {Math.Round(100.0 * simulatorDeclaredCount / total, 1)}% |");
        md.AppendLine($"| 模拟器行为验证完整支持数量 | **{simSupportedCount}** | {Math.Round(100.0 * simSupportedCount / total, 1)}% |");
        md.AppendLine($"| 仅状态捕获数量 | **{stateCapturedOnlyCount}** | {Math.Round(100.0 * stateCapturedOnlyCount / total, 1)}% |");
        md.AppendLine($"| 无战斗动作影响数量 | **{noCombatCount}** | {Math.Round(100.0 * noCombatCount / total, 1)}% |");
        md.AppendLine($"| 未知证据 Power 数量 | **{unknownCount}** | {Math.Round(100.0 * unknownCount / total, 1)}% |");
        md.AppendLine();
        md.AppendLine("## 模拟器已声明映射 Power（仍需行为差分）");
        md.AppendLine();
        md.AppendLine("| Stable ID | 中文名 | 英文名 | 触发阶段 | 证据等级 | 状态映射 |");
        md.AppendLine("| :--- | :--- | :--- | :--- | :--- | :--- |");
        foreach (var p in document.Powers.Where(p => p.SimulatorSupport is "simulator_declared" or "simulator_supported"))
        {
            md.AppendLine($"| `{p.StableId}` | {p.LocalizedNameZh} | {p.CanonicalName} | {string.Join(", ", p.TriggerPhases)} | `{p.Evidence}` | `{string.Join(", ", p.CanonicalStatusIds)}` |");
        }
        md.AppendLine();

        // Write outputs
        var outDir = Path.Combine(workspaceRoot, "STS2SuperModel", "data", "powers", "v0.111");
        Directory.CreateDirectory(outDir);

        var utf8WithoutBom = new System.Text.UTF8Encoding(false);
        File.WriteAllText(Path.Combine(outDir, "power-catalog.json"), catalogJson, utf8WithoutBom);
        File.WriteAllText(Path.Combine(outDir, "power-coverage.json"), coverageJson, utf8WithoutBom);
        File.WriteAllText(Path.Combine(outDir, "power-schema.json"), schemaJson, utf8WithoutBom);
        File.WriteAllText(Path.Combine(outDir, "README.md"), md.ToString(), utf8WithoutBom);

        _output.WriteLine($"Saved power catalog and coverage artifacts to {outDir}");
        Assert.True(total > 100, $"Expected >100 powers, found {total}");
    }

    private static string FindWorkspaceRoot()
    {
        var directory = new DirectoryInfo(AppContext.BaseDirectory);
        while (directory is not null)
        {
            if (Directory.Exists(Path.Combine(directory.FullName, "STS2SuperModel")) &&
                Directory.Exists(Path.Combine(directory.FullName, "STS2BestChoice")))
                return directory.FullName;
            directory = directory.Parent;
        }
        throw new DirectoryNotFoundException("Could not locate STS2BestChoice workspace root.");
    }
}
