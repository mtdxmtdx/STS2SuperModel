using System.Collections.Immutable;
using STS2BestChoice.Core.Model;
using STS2BestChoice.Core.Search;
using STS2BestChoice.Core.Semantics;
using STS2BestChoice.Core.Simulation;
using Xunit;

namespace STS2BestChoice.Tests;

public sealed class TenBatchSemanticsTests
{
    [Fact]
    public void CurrentTextsFromAllTenBatchesAreStructuredAndExecutable()
    {
        string[] texts =
        [
            "造成5点伤害。如果你在这回合打出的牌数小于3张，抽1张牌。",
            "保留。如果你的手牌为空，则抽2张牌并获得能量能量。",
            "选择一张攻击牌或能力牌。将该牌的一张复制品加入你的手牌。",
            "保留。从手牌中选择最多3张牌消耗。消耗。",
            "造成10点伤害。该名敌人身上每有一种负面效果，就额外造成5点伤害。",
            "造成9点伤害。你的消耗牌堆中每有一张灵魂，伤害增加2。",
            "阻止下1次你受到的生命值损伤。",
            "每当你被攻击时，对攻击者造成3点伤害。",
            "不能被打出。你在本回合不能打出超过3张牌。",
            "你在每个回合不能打出超过3张牌。",
            "每当你在一回合内打出五张牌时，对所有敌人造成10点伤害。",
            "每当你打出一张灵魂时，随机一名敌人失去6点生命。",
            "造成99点伤害。本场战斗，任何人每消耗过一张牌，这张牌的能量费用减少1。",
            "消耗你所有的状态牌。每有一张被消耗的牌，就随机对敌人造成8点伤害。",
            "不能被打出。在你的回合结束时，如果这张牌在你的手牌中, 你受到2点伤害。",
            "不能被打出。在你的回合结束时，如果这张牌在你的手牌中，你失去13点生命。永恒。",
            "不能被打出。在你的回合结束时，如果这张牌在你的手牌中，失去相当于手牌数量的生命。",
            "不能被打出。在你的回合结束时，如果这张牌在你的手牌中，获得1层虚弱。",
            "不能被打出。在你的回合结束时，如果这张牌在你的手牌中，则获得1层脆弱。"
        ];

        foreach (var text in texts)
        {
            var result = CardTextSemanticCompiler.Compile(text);
            Assert.True(result.IsFullyStructured, text);
            Assert.True(result.IsSimulatorExecutable, text);
        }
    }

    [Fact]
    public void CompilerPreservesChoiceDynamicAndTriggerDetails()
    {
        var dualWield = CardTextSemanticCompiler.Compile(
            "选择一张攻击牌或能力牌。将该牌的2张复制品加入你的手牌。");
        var purity = CardTextSemanticCompiler.Compile("从手牌中选择最多5张牌消耗。消耗。");
        var rend = CardTextSemanticCompiler.Compile(
            "造成12点伤害。该名敌人身上每有一种负面效果，就额外造成8点伤害。");
        var soulStorm = CardTextSemanticCompiler.Compile(
            "造成9点伤害。你的消耗牌堆中每有一张灵魂，伤害增加3。");
        var flak = CardTextSemanticCompiler.Compile(
            "消耗你所有的状态牌。每有一张被消耗的牌，就随机对敌人造成11点伤害。");

        var copy = Assert.Single(dualWield.Operations);
        Assert.Equal(CardSemanticKind.SelectCard, copy.Kind);
        Assert.Equal("HAND_ATTACK_OR_POWER_COPY", copy.Id);
        Assert.Equal(2m, copy.Amount);

        var exhaust = Assert.Single(purity.Operations, operation => operation.Kind == CardSemanticKind.ExhaustCards);
        Assert.Equal("UP_TO", exhaust.Id);
        Assert.Equal(5m, exhaust.Amount);

        var rendDamage = Assert.Single(rend.Operations, operation => operation.Kind == CardSemanticKind.DynamicDamage);
        Assert.Equal("TARGET_DEBUFF_TYPE_COUNT", rendDamage.Id);
        Assert.Equal(12m, rendDamage.Amount);
        Assert.Equal(8, rendDamage.XBonus);

        var soulDamage = Assert.Single(soulStorm.Operations, operation => operation.Kind == CardSemanticKind.DynamicDamage);
        Assert.Equal("EXHAUST_SOUL_COUNT", soulDamage.Id);
        Assert.Equal(9m, soulDamage.Amount);
        Assert.Equal(3, soulDamage.XBonus);

        Assert.Contains(flak.Operations, operation =>
            operation.Kind == CardSemanticKind.ExhaustCards && operation.Id == "STATUS_ALL_PILES" && operation.All);
        Assert.Contains(flak.Operations, operation =>
            operation.Kind == CardSemanticKind.Damage && operation.Target == SemanticTarget.RandomEnemy &&
            operation.RepeatByExhaustedCount && operation.RandomSource == "CombatTargets");
    }

    [Fact]
    public void CompilerSeparatesTurnEndDamageHpLossDynamicLossAndDebuffs()
    {
        var burn = CardTextSemanticCompiler.Compile(
            "不能被打出。在你的回合结束时，如果这张牌在你的手牌中, 你受到2点伤害。");
        var badLuck = CardTextSemanticCompiler.Compile(
            "不能被打出。在你的回合结束时，如果这张牌在你的手牌中，你失去13点生命。永恒。");
        var regret = CardTextSemanticCompiler.Compile(
            "不能被打出。在你的回合结束时，如果这张牌在你的手牌中，失去相当于手牌数量的生命。");
        var doubt = CardTextSemanticCompiler.Compile(
            "不能被打出。在你的回合结束时，如果这张牌在你的手牌中，获得1层虚弱。");
        var shame = CardTextSemanticCompiler.Compile(
            "不能被打出。在你的回合结束时，如果这张牌在你的手牌中，则获得1层脆弱。");
        var disintegration = CardTextSemanticCompiler.Compile("在你的回合结束时，受到6点伤害。");

        Assert.Contains(burn.Operations, operation => operation.Kind == CardSemanticKind.Damage && operation.Amount == 2);
        Assert.Contains(badLuck.Operations, operation => operation.Kind == CardSemanticKind.LoseHp && operation.Amount == 13);
        Assert.Contains(regret.Operations, operation => operation.Kind == CardSemanticKind.LoseHp && operation.Id == "HAND_COUNT");
        Assert.Contains(doubt.Operations, operation => operation.Kind == CardSemanticKind.ApplyStatus && operation.Id == "WEAK");
        Assert.Contains(shame.Operations, operation => operation.Kind == CardSemanticKind.ApplyStatus && operation.Id == "FRAIL");
        Assert.True(disintegration.IsFullyStructured);
        Assert.Contains(disintegration.Operations, operation => operation.Kind == CardSemanticKind.Damage && operation.Amount == 6 && operation.Timing == "turn_end");
    }

    [Fact]
    public void FtlAndRestlessnessUseTheVerifiedPreCompletionBoundaries()
    {
        var drawn = BasicCard("drawn", "DRAWN", "Skill");
        var ftl = new CardState(
            "ftl", "FTL", "FTL", 0, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.Damage, 5),
                new EffectSpec(EffectKind.Draw, 1, Condition: "CARD_PLAYS_FINISHED_LT:3")
            ],
            CardType: "Attack");
        var allowed = Snapshot([ftl], drawPile: [drawn], history: new CombatHistoryCounters(CardsPlayedThisTurn: 2));
        var blocked = Snapshot([ftl], drawPile: [drawn], history: new CombatHistoryCounters(CardsPlayedThisTurn: 3));
        var simulator = new DeterministicSimulator();

        var allowedResult = simulator.PlayCard(MutableCombatState.FromSnapshot(allowed), ftl, "enemy-0", null);
        var blockedResult = simulator.PlayCard(MutableCombatState.FromSnapshot(blocked), ftl, "enemy-0", null);

        Assert.Contains(allowedResult.Hand, card => card.InstanceId == "drawn");
        Assert.DoesNotContain(blockedResult.Hand, card => card.InstanceId == "drawn");

        var restlessness = new CardState(
            "restless", "RESTLESSNESS", "Restlessness", 0, TargetKind.Self,
            [
                new EffectSpec(EffectKind.Draw, 2, Condition: "HAND_EMPTY"),
                new EffectSpec(EffectKind.GainEnergy, 2, Condition: "HAND_EMPTY")
            ],
            CardType: "Skill");
        var restSnapshot = Snapshot([restlessness], drawPile: [drawn, drawn with { InstanceId = "drawn-2" }], energy: 0);

        var restResult = simulator.PlayCard(
            MutableCombatState.FromSnapshot(restSnapshot), restlessness, null, null);

        Assert.Equal(2, restResult.Hand.Count);
        Assert.Equal(2, restResult.Player.Energy);
    }

    [Fact]
    public void DualWieldFiltersCandidatesAndPurityAcceptsZeroOrManyChoices()
    {
        var dualWield = new CardState(
            "dual", "DUAL_WIELD", "Dual Wield", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.CopyChosenHandCard, 2, "ATTACK_OR_POWER")],
            CardType: "Skill");
        var attack = BasicCard("attack", "ATTACK", "Attack");
        var power = BasicCard("power", "POWER", "Power");
        var skill = BasicCard("skill", "SKILL", "Skill");
        var state = MutableCombatState.FromSnapshot(Snapshot([dualWield, attack, power, skill], energy: 0));

        var choices = CombatSearchSession.BuildDynamicChoices(state, dualWield);

        Assert.Equal(new[] { "attack", "power" }, choices.Select(choice => choice.CardInstanceId));
        var copied = new DeterministicSimulator().PlayCard(
            state, dualWield, null, choices.Single(choice => choice.CardInstanceId == "attack"));
        Assert.Equal(3, copied.Hand.Count(card => card.ModelId == "ATTACK"));

        var purity = new CardState(
            "purity", "PURITY", "Purity", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ExhaustCards, 3, "UP_TO")],
            CardDestination.Exhaust,
            Choices:
            [
                new ChoiceSpec("none", "None", []),
                new ChoiceSpec("two", "Two", [], CardInstanceIds: ["a", "b"])
            ],
            CardType: "Skill");
        var a = BasicCard("a", "A", "Skill");
        var b = BasicCard("b", "B", "Attack");
        var noneResult = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([purity, a, b], energy: 0)), purity, null, purity.SafeChoices[0]);
        var twoResult = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([purity, a, b], energy: 0)), purity, null, purity.SafeChoices[1]);

        Assert.Equal(2, noneResult.Hand.Count);
        Assert.Equal(3, twoResult.ExhaustPile.Count);
        Assert.Empty(twoResult.Hand);
    }

    [Fact]
    public void CompanionAttacksUseLiveHpAndMaxHpAndTrackAttacks()
    {
        var statuses = EmptyStatuses
            .Add("OSTY_ALIVE", new StatusState("OSTY_ALIVE", 1))
            .Add("OSTY_CURRENT_HP", new StatusState("OSTY_CURRENT_HP", 12))
            .Add("OSTY_MAX_HP", new StatusState("OSTY_MAX_HP", 20))
            .Add("OSTY_ATTACK_CARD_COUNT", new StatusState("OSTY_ATTACK_CARD_COUNT", 2));
        var unleash = new CardState(
            "unleash", "UNLEASH", "Unleash", 0, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.CompanionDamage, 6, TargetOverride: TargetKind.Enemy),
                new EffectSpec(EffectKind.CompanionDamage, 6, "OSTY_CURRENT_HP_DAMAGE", TargetOverride: TargetKind.Enemy)
            ],
            CardType: "Attack");
        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([unleash], playerStatuses: statuses, enemyHp: 100, enemyBlock: 10, energy: 0)),
            unleash,
            "enemy-0",
            null);

        Assert.Equal(86m, result.Enemies[0].Hp);
        Assert.Equal(1, result.Player.Statuses["OSTY_ATTACKS_THIS_TURN"].Amount);
    }

    [Fact]
    public void CompanionSacrificeGainsBlockFromMaxHpBeforeDeath()
    {
        var statuses = EmptyStatuses
            .Add("OSTY_ALIVE", new StatusState("OSTY_ALIVE", 1))
            .Add("OSTY_CURRENT_HP", new StatusState("OSTY_CURRENT_HP", 15))
            .Add("OSTY_MAX_HP", new StatusState("OSTY_MAX_HP", 20));
        var sacrifice = new CardState(
            "sac", "SACRIFICE", "Sacrifice", 0, TargetKind.Self,
            [
                new EffectSpec(EffectKind.KillCompanion, 1, "KILL_OSTY"),
                new EffectSpec(EffectKind.DynamicBlock, 2, "OSTY_MAX_HP_BLOCK", TargetOverride: TargetKind.Self, Condition: "OSTY_ALIVE")
            ],
            CardType: "Skill");
        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([sacrifice], playerStatuses: statuses, energy: 0)),
            sacrifice,
            null,
            null);

        Assert.Equal(40m, result.Player.Block);
        Assert.Equal(0, result.Player.Statuses["OSTY_ALIVE"].Amount);
    }

    [Fact]
    public void NextTurnSummonHappensAtTheNextPlayerTurnStart()
    {
        var statuses = EmptyStatuses
            .Add("OSTY_ALIVE", new StatusState("OSTY_ALIVE", 1))
            .Add("OSTY_CURRENT_HP", new StatusState("OSTY_CURRENT_HP", 10))
            .Add("OSTY_MAX_HP", new StatusState("OSTY_MAX_HP", 10));
        var invoke = new CardState(
            "invoke", "INVOKE", "Invoke", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 2, "SCHEDULED_SUMMON", Duration: 1)],
            CardType: "Skill");
        var simulator = new DeterministicSimulator();
        var afterPlay = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([invoke], playerStatuses: statuses, energy: 0)),
            invoke,
            null,
            null);

        Assert.Equal(10, afterPlay.Player.Statuses["OSTY_MAX_HP"].Amount);
        var nextTurn = simulator.ProjectToNextPlayerTurn(afterPlay);
        Assert.Equal(12, nextTurn.Player.Statuses["OSTY_MAX_HP"].Amount);
        Assert.Equal(12, nextTurn.Player.Statuses["OSTY_CURRENT_HP"].Amount);
    }

    [Fact]
    public void CompanionAttackUsesEnemyVulnerableMultiplier()
    {
        var statuses = EmptyStatuses
            .Add("OSTY_ALIVE", new StatusState("OSTY_ALIVE", 1))
            .Add("OSTY_CURRENT_HP", new StatusState("OSTY_CURRENT_HP", 10))
            .Add("OSTY_MAX_HP", new StatusState("OSTY_MAX_HP", 10));
        var poke = new CardState(
            "poke", "POKE", "Poke", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.CompanionDamage, 6, TargetOverride: TargetKind.Enemy)],
            CardType: "Attack");
        var enemyStatuses = EmptyStatuses.Add("VULNERABLE", new StatusState("VULNERABLE", 2));
        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([poke], playerStatuses: statuses, enemyStatuses: enemyStatuses, enemyHp: 100, energy: 0)),
            poke,
            "enemy-0",
            null);

        Assert.Equal(91m, result.Enemies[0].Hp);
    }

    [Fact]
    public void RattleRepeatsForPriorCompanionAttackCardsAndCountsTheCardOnce()
    {
        var statuses = EmptyStatuses
            .Add("OSTY_ALIVE", new StatusState("OSTY_ALIVE", 1))
            .Add("OSTY_CURRENT_HP", new StatusState("OSTY_CURRENT_HP", 10))
            .Add("OSTY_MAX_HP", new StatusState("OSTY_MAX_HP", 10))
            .Add("OSTY_ATTACKS_THIS_TURN", new StatusState("OSTY_ATTACKS_THIS_TURN", 2));
        var rattle = new CardState(
            "rattle", "RATTLE", "Rattle", 0, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.CompanionDamage, 7, TargetOverride: TargetKind.Enemy),
                new EffectSpec(EffectKind.CompanionDamage, 0, "OSTY_ATTACK_COUNT_REPEAT", TargetOverride: TargetKind.Enemy, RepeatByHistoryCounter: true)
            ],
            CardType: "Attack");

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([rattle], playerStatuses: statuses, enemyHp: 100, energy: 0)),
            rattle,
            "enemy-0",
            null);

        Assert.Equal(79m, result.Enemies[0].Hp);
        Assert.Equal(3, result.Player.Statuses["OSTY_ATTACKS_THIS_TURN"].Amount);
    }

    [Fact]
    public void SoulTriggerSummonsAndSicEmSummonsAfterCompanionAttack()
    {
        var statuses = EmptyStatuses
            .Add("OSTY_ALIVE", new StatusState("OSTY_ALIVE", 1))
            .Add("OSTY_CURRENT_HP", new StatusState("OSTY_CURRENT_HP", 10))
            .Add("OSTY_MAX_HP", new StatusState("OSTY_MAX_HP", 10))
            .Add("DEVOUR_LIFE", new StatusState("DEVOUR_LIFE", 2));
        var soul = new CardState("soul", "SOUL", "Soul", 0, TargetKind.Self, [], CardType: "Status");
        var poke = new CardState(
            "poke", "POKE", "Poke", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.CompanionDamage, 6, TargetOverride: TargetKind.Enemy)],
            CardType: "Attack");
        var enemyStatuses = EmptyStatuses.Add("SIC_EM", new StatusState("SIC_EM", 3, Duration: 1));
        var snapshot = Snapshot([soul, poke], playerStatuses: statuses, enemyStatuses: enemyStatuses, energy: 0);
        var simulator = new DeterministicSimulator();
        var afterSoul = simulator.PlayCard(MutableCombatState.FromSnapshot(snapshot), soul, null, null);
        var afterPoke = simulator.PlayCard(afterSoul, poke, "enemy-0", null);

        Assert.Equal(15, afterPoke.Player.Statuses["OSTY_MAX_HP"].Amount);
        Assert.Equal(15, afterPoke.Player.Statuses["OSTY_CURRENT_HP"].Amount);
    }

    [Fact]
    public void MinionTransformUsesExplicitSelectionAndPreservesPile()
    {
        var strike = BasicCard("strike", "STRIKE", "Attack");
        var begone = new CardState(
            "begone", "BEGONE", "Begone", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.TransformCards, StatusId: "HAND_ONE_TO_MINION_STRIKE")],
            CardType: "Skill",
            Choices: [new ChoiceSpec("strike", "transform", [], CardInstanceIds: ["strike"])]);
        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([begone, strike], energy: 0)),
            begone,
            null,
            begone.SafeChoices[0]);

        var transformed = Assert.Single(result.Hand, card => card.InstanceId == "card:MINION_STRIKE:000");
        Assert.Equal("MINION_STRIKE", transformed.ModelId);
        Assert.Equal(CardDestination.Exhaust, transformed.Destination);
    }

    [Fact]
    public void StunEnemyReplacesVisibleIntentWithoutInventingPower()
    {
        var whistle = new CardState(
            "whistle", "WHISTLE", "Whistle", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.StunEnemy, TargetOverride: TargetKind.Enemy)],
            CardType: "Attack");
        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([whistle], energy: 0)),
            whistle,
            "enemy-0",
            null);

        var intent = Assert.Single(result.Enemies[0].Intents);
        Assert.Equal("Stun", intent.Type);
        Assert.Equal(0m, intent.DamagePerHit);
        Assert.DoesNotContain(result.Powers, power => power.OwnerId == "enemy-0");
    }

    [Fact]
    public void RendCountsDebuffTypesAndSoulStormCountsSoulInstances()
    {
        var rend = new CardState(
            "rend", "REND", "Rend", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.DynamicDamage, 10, "TARGET_DEBUFF_TYPE_COUNT", XBonus: 5)],
            CardType: "Attack");
        var enemyStatuses = EmptyStatuses
            .Add("WEAK", new StatusState("WEAK", 4, IsDebuff: true))
            .Add("POISON", new StatusState("POISON", 7, IsDebuff: true))
            .Add("STRENGTH", new StatusState("STRENGTH", 2));
        var rendResult = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([rend], enemyStatuses: enemyStatuses, energy: 0)),
            rend, "enemy-0", null);
        Assert.Equal(80m, rendResult.Enemies[0].Hp);

        var soulStorm = new CardState(
            "storm", "SOUL_STORM", "Soul Storm", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.DynamicDamage, 9, "EXHAUST_SOUL_COUNT", XBonus: 2)],
            CardType: "Attack");
        var soul = BasicCard("soul-1", "SOUL", "Status") with { Name = "Soul" };
        var soulResult = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(
                [soulStorm],
                exhaustPile: [soul, soul with { InstanceId = "soul-2" }, BasicCard("ash", "ASH", "Status")],
                energy: 0)),
            soulStorm, "enemy-0", null);
        Assert.Equal(87m, soulResult.Enemies[0].Hp);
    }

    [Fact]
    public void BufferPreventsFinalHpLossAndCaltropsRetaliatesPerHit()
    {
        var bufferStatuses = EmptyStatuses.Add("BUFFER", new StatusState("BUFFER", 1));
        var bufferProjection = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(Snapshot(
                [],
                playerHp: 20,
                playerBlock: 2,
                playerStatuses: bufferStatuses,
                enemyIntents: [new IntentState("Attack", 5, 1)])));
        Assert.Equal(20m, bufferProjection.Player.Hp);
        Assert.Equal(0m, bufferProjection.Player.Block);
        Assert.DoesNotContain("BUFFER", bufferProjection.Player.Statuses.Keys);

        var thornsStatuses = EmptyStatuses.Add("THORNS", new StatusState("THORNS", 3));
        var thornsProjection = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(Snapshot(
                [],
                playerHp: 20,
                playerStatuses: thornsStatuses,
                enemyHp: 4,
                enemyIntents: [new IntentState("Attack", 1, 2)])));
        Assert.Equal(0m, thornsProjection.Enemies[0].Hp);
        Assert.Equal(18m, thornsProjection.Player.Hp);
    }

    [Fact]
    public void NormalityAndSlothEnforceTheirDifferentLifetimes()
    {
        var normality = BasicCard("normality", "NORMALITY", "Curse") with
        {
            IsPlayable = false,
            Effects = [new EffectSpec(EffectKind.PlayRestriction, 3, "GLOBAL_CARD_PLAY_LIMIT_WHILE_IN_HAND")]
        };
        var attack = BasicCard("attack", "ATTACK", "Attack");
        var state = MutableCombatState.FromSnapshot(Snapshot(
            [normality, attack],
            history: new CombatHistoryCounters(CardsPlayedThisTurn: 3)));

        Assert.False(DeterministicSimulator.IsCardPlayableNow(state, attack));
        state.Hand.Remove(normality);
        Assert.True(DeterministicSimulator.IsCardPlayableNow(state, attack));

        state.Player = state.Player with
        {
            Statuses = state.Player.Statuses.Add("CARD_PLAY_LIMIT", new StatusState("CARD_PLAY_LIMIT", 3))
        };
        Assert.False(DeterministicSimulator.IsCardPlayableNow(state, attack));
    }

    [Fact]
    public void PanacheDoesNotCountItsOwnInstallationAndResetsAfterFive()
    {
        var panache = new CardState(
            "panache", "PANACHE", "Panache", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 10, "TRIGGER_EVERY_FIVE_CARDS_ALL_DAMAGE", XBonus: 5)],
            CardDestination.Remove,
            CardType: "Power");
        var simulator = new DeterministicSimulator();
        var installed = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([panache], energy: 0)), panache, null, null);
        Assert.Equal(5, installed.Player.Statuses["PANACHE_CARDS_LEFT"].Amount);
        Assert.Equal(100m, installed.Enemies[0].Hp);

        var triggerStatuses = EmptyStatuses
            .Add("TRIGGER_EVERY_FIVE_CARDS_ALL_DAMAGE", new StatusState("TRIGGER_EVERY_FIVE_CARDS_ALL_DAMAGE", 10))
            .Add("PANACHE_CARDS_LEFT", new StatusState("PANACHE_CARDS_LEFT", 1));
        var card = BasicCard("card", "CARD", "Skill");
        var triggered = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([card], playerStatuses: triggerStatuses, energy: 0)),
            card, null, null);
        Assert.Equal(90m, triggered.Enemies[0].Hp);
        Assert.Equal(5, triggered.Player.Statuses["PANACHE_CARDS_LEFT"].Amount);
    }

    [Fact]
    public void HauntUsesDirectHpLossAndAdvancesCombatTargets()
    {
        var statuses = EmptyStatuses.Add(
            "TRIGGER_SOUL_PLAYED_RANDOM_HP_LOSS",
            new StatusState(
                "TRIGGER_SOUL_PLAYED_RANDOM_HP_LOSS",
                6,
                RandomSource: RngSnapshotSet.CombatTargets));
        var soul = BasicCard("soul", "SOUL", "Skill");
        var state = MutableCombatState.FromSnapshot(Snapshot(
            [soul],
            playerStatuses: statuses,
            enemyBlock: 100,
            energy: 0));
        var before = state.RngStreams.Get(RngSnapshotSet.CombatTargets);

        var result = new DeterministicSimulator().PlayCard(state, soul, null, null);

        Assert.Equal(94m, result.Enemies[0].Hp);
        Assert.Equal(100m, result.Enemies[0].Block);
        Assert.NotEqual(before, result.RngStreams.Get(RngSnapshotSet.CombatTargets));
    }

    [Fact]
    public void MidnightTracksSequentialExhaustEventsAcrossPiles()
    {
        var midnight = new CardState(
            "midnight", "MIDNIGHT", "Midnight", 12, TargetKind.Enemy,
            [new EffectSpec(EffectKind.ModifyPlayedCardCost, -1, "SELF_LISTENER_COST_DELTA")],
            CardType: "Attack");
        var exhauster = new CardState(
            "exhauster", "EXHAUSTER", "Exhauster", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.ExhaustHand)],
            CardDestination.Exhaust,
            CardType: "Skill");
        var filler = BasicCard("filler", "FILLER", "Skill");
        var state = MutableCombatState.FromSnapshot(Snapshot(
            [exhauster, filler],
            drawPile: [midnight],
            energy: 0));

        var result = new DeterministicSimulator().PlayCard(state, exhauster, null, null);

        Assert.Equal(10, Assert.Single(result.DrawPile).EnergyCost);
        Assert.Equal(2, result.CardsExhaustedSinceSnapshot);
    }

    [Fact]
    public void FlakCannonExhaustsStatusCardsAcrossPilesThenAttacksPerCard()
    {
        var flak = new CardState(
            "flak", "FLAK_CANNON", "Flak Cannon", 0, TargetKind.Enemy,
            [
                new EffectSpec(EffectKind.ExhaustStatusCards),
                new EffectSpec(
                    EffectKind.RandomEnemyAttackByExhaustedCount,
                    8,
                    RandomSource: RngSnapshotSet.CombatTargets)
            ],
            CardType: "Attack");
        var handStatus = BasicCard("status-hand", "STATUS_HAND", "Status");
        var drawStatus = BasicCard("status-draw", "STATUS_DRAW", "Status");
        var discardStatus = BasicCard("status-discard", "STATUS_DISCARD", "Status");
        var alreadyExhausted = BasicCard("status-old", "STATUS_OLD", "Status");
        var playerStatuses = EmptyStatuses.Add("STRENGTH", new StatusState("STRENGTH", 2));
        var state = MutableCombatState.FromSnapshot(Snapshot(
            [flak, handStatus],
            drawPile: [drawStatus],
            discardPile: [discardStatus],
            exhaustPile: [alreadyExhausted],
            playerStatuses: playerStatuses,
            enemyBlock: 5,
            energy: 0));
        var before = state.RngStreams.Get(RngSnapshotSet.CombatTargets);

        var result = new DeterministicSimulator().PlayCard(state, flak, "enemy-0", null);

        Assert.Equal(4, result.ExhaustPile.Count);
        Assert.Equal(3, result.CardsExhaustedSinceSnapshot);
        Assert.Equal(75m, result.Enemies[0].Hp);
        Assert.Equal(0m, result.Enemies[0].Block);
        Assert.NotEqual(before, result.RngStreams.Get(RngSnapshotSet.CombatTargets));
    }

    [Fact]
    public void TurnEndDamageAndHpLossUseDifferentBlockPaths()
    {
        var burn = BasicCard("burn", "BURN", "Status") with
        {
            TurnEndInHandEffects = [new EffectSpec(EffectKind.Damage, 5, TargetOverride: TargetKind.Self)]
        };
        var beckon = BasicCard("beckon", "BECKON", "Status") with
        {
            TurnEndInHandEffects = [new EffectSpec(EffectKind.LoseHp, 6, TargetOverride: TargetKind.Self)]
        };
        var result = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(Snapshot(
                [burn, beckon],
                playerHp: 20,
                playerBlock: 3)));

        Assert.Equal(12m, result.Player.Hp);
        Assert.Equal(0m, result.Player.Block);
    }

    [Fact]
    public void BufferDoesNotStopLaterTurnEndHandEvents()
    {
        var damage = BasicCard("damage", "BURN", "Status") with
        {
            TurnEndInHandEffects = [new EffectSpec(EffectKind.Damage, 5, TargetOverride: TargetKind.Self)]
        };
        var lossA = BasicCard("loss-a", "BECKON", "Status") with
        {
            TurnEndInHandEffects = [new EffectSpec(EffectKind.LoseHp, 6, TargetOverride: TargetKind.Self)]
        };
        var lossB = lossA with { InstanceId = "loss-b" };
        var statuses = EmptyStatuses.Add("BUFFER", new StatusState("BUFFER", 2));

        var result = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(Snapshot(
                [damage, lossA, lossB],
                playerHp: 20,
                playerStatuses: statuses)));

        Assert.Equal(14m, result.Player.Hp);
        Assert.DoesNotContain("BUFFER", result.Player.Statuses.Keys);
    }

    [Fact]
    public void RegretUsesTheTurnEndStartingHandCount()
    {
        var regret = BasicCard("regret", "REGRET", "Curse") with
        {
            TurnEndInHandEffects =
            [
                new EffectSpec(
                    EffectKind.LoseHp,
                    1,
                    TargetOverride: TargetKind.Self,
                    Condition: "HAND_COUNT")
            ]
        };
        var result = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(Snapshot(
                [regret, BasicCard("a", "A", "Skill"), BasicCard("b", "B", "Skill")],
                playerHp: 20)));

        Assert.Equal(17m, result.Player.Hp);
    }

    [Fact]
    public void DoubtAndShameConsumeArtifactAndPersistIntoTheNextPlayerTurn()
    {
        var doubt = BasicCard("doubt", "DOUBT", "Curse") with
        {
            TurnEndInHandEffects =
            [
                new EffectSpec(
                    EffectKind.ApplyStatus,
                    1,
                    "WEAK",
                    Duration: 2,
                    IsDebuff: true,
                    TargetOverride: TargetKind.Self)
            ]
        };
        var shame = BasicCard("shame", "SHAME", "Curse") with
        {
            TurnEndInHandEffects =
            [
                new EffectSpec(
                    EffectKind.ApplyStatus,
                    1,
                    "FRAIL",
                    Duration: 2,
                    IsDebuff: true,
                    TargetOverride: TargetKind.Self)
            ]
        };
        var artifact = EmptyStatuses.Add("ARTIFACT", new StatusState("ARTIFACT", 1));
        var simulator = new DeterministicSimulator();
        var nextTurn = simulator.ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(Snapshot(
                [doubt, shame],
                playerStatuses: artifact)));

        Assert.DoesNotContain("ARTIFACT", nextTurn.Player.Statuses.Keys);
        Assert.DoesNotContain("WEAK", nextTurn.Player.Statuses.Keys);
        Assert.Equal(1, nextTurn.Player.Statuses["FRAIL"].Duration);

        var block = new CardState(
            "block", "BLOCK", "Block", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.Block, 8)],
            CardType: "Skill");
        nextTurn.Hand.Add(block);
        var afterBlock = simulator.PlayCard(nextTurn, block, null, null);
        Assert.Equal(6m, afterBlock.Player.Block);
    }

    private static CombatSnapshot Snapshot(
        IEnumerable<CardState> hand,
        IEnumerable<CardState>? drawPile = null,
        IEnumerable<CardState>? discardPile = null,
        IEnumerable<CardState>? exhaustPile = null,
        ImmutableDictionary<string, StatusState>? playerStatuses = null,
        ImmutableDictionary<string, StatusState>? enemyStatuses = null,
        IEnumerable<IntentState>? enemyIntents = null,
        CombatHistoryCounters? history = null,
        decimal playerHp = 30,
        decimal playerBlock = 0,
        decimal enemyHp = 100,
        decimal enemyBlock = 0,
        int energy = 3) => CombatSnapshot.Create(
        "ten-batch-fixture",
        new PlayerState(
            playerHp,
            playerHp,
            playerBlock,
            energy,
            energy,
            playerStatuses ?? EmptyStatuses,
            CardsPerTurn: 0),
        [new CreatureState(
            "enemy-0",
            "Enemy",
            enemyHp,
            enemyHp,
            enemyBlock,
            enemyStatuses ?? EmptyStatuses,
            (enemyIntents ?? []).ToImmutableArray(),
            0)],
        hand,
        drawPile,
        discardPile,
        exhaustPile,
        rngState: 42,
        rngStreams: KnownTargetRng(),
        historyCounters: history);

    private static CardState BasicCard(string instanceId, string modelId, string cardType) => new(
        instanceId,
        modelId,
        modelId,
        0,
        TargetKind.Self,
        [],
        CardType: cardType);

    private static RngSnapshotSet KnownTargetRng()
    {
        var target = new RngStreamSnapshot(RngSnapshotSet.CombatTargets, 1, 2, 3, 4);
        return new RngSnapshotSet(
            ImmutableDictionary<string, RngStreamSnapshot>.Empty.Add(target.Name, target));
    }

    private static ImmutableDictionary<string, StatusState> EmptyStatuses { get; } =
        ImmutableDictionary<string, StatusState>.Empty;
}
