using System.Collections.Immutable;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Serialization;
using MegaCrit.Sts2.Core.Helpers;
using MegaCrit.Sts2.Core.HoverTips;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Models.Relics;
using MegaCrit.Sts2.Core.TestSupport;
using STS2BestChoice.Core.Data;
using STS2BestChoice.Core.Model;
using Xunit;
using Xunit.Abstractions;

namespace STS2BestChoice.Tests;

public sealed class RelicCatalogTests
{
    public const string ExpectedSha256 = "0861BFA1DF347538D932F22D580E75420F08082792EB914E53B4882764ACDBE9";
    public const string GameVersion = "0.111.0";
    public const string GameCommit = "41cef1ea";
    public const string CliProtocolVersion = "0.2.0";

    private readonly ITestOutputHelper _output;

    // Runtime hooks whose names do not contain the older narrow "Combat/Card"
    // tokens (for example AfterFlush or ShouldFlush) are still combat
    // semantics. Keep this small, evidence-backed set explicit and combine it
    // with the hook-name classifier below; otherwise active relics such as
    // Bookmark, Data Disk, Lizard Tail, and Runic Pyramid are misclassified as
    // non-combat merely because their hook uses a generic engine callback.
    private static readonly HashSet<string> CombatHookRelicIds = new(StringComparer.OrdinalIgnoreCase)
    {
        "BIIIG_HUG", "BOOKMARK", "BOOK_REPAIR_KNIFE", "DATA_DISK", "DIVINE_RIGHT",
        "EMBER_TEA", "GALACTIC_DUST", "GORGET", "GREMLIN_HORN", "HISTORY_COURSE",
        "LIZARD_TAIL", "PAPER_KRANE", "PAPER_PHROG", "RINGING_TRIANGLE",
        "RUNIC_PYRAMID", "SLING_OF_COURAGE", "STONE_CRACKER", "SWORD_OF_JADE",
        "THE_ABACUS", "GIRYA"
    };

    // A generic AfterRoomEntered override is only a combat hook when the
    // engine condition is a combat/elite room.  Keep the v0.111 list explicit
    // so a shop/rest/map callback cannot be promoted by a name-only scan.
    private static readonly HashSet<string> CombatRoomEntryRelicIds = new(StringComparer.OrdinalIgnoreCase)
    {
        "DATA_DISK", "DIVINE_RIGHT", "EMBER_TEA", "GIRYA", "GORGET",
        "SLING_OF_COURAGE", "STONE_CRACKER", "SWORD_OF_JADE"
    };

    // Hooks are derived from AbstractModel/Hook dispatch.  The old classifier
    // searched for a few substrings (Combat/Card/Turn), which missed callbacks
    // such as AfterFlush and ShouldDieLate.  Exact names are intentionally
    // listed here; unknown callbacks remain reviewable instead of being marked
    // OutOfScope.
    private static readonly HashSet<string> CombatHookMethodNames = new(StringComparer.Ordinal)
    {
        "AfterAttack", "BeforeAttack", "AfterBlockBroken", "AfterBlockCleared",
        "BeforeBlockGained", "AfterBlockGained", "BeforeCardAutoPlayed",
        "AfterCardChangedPiles", "AfterCardChangedPilesLate", "AfterCardDiscarded",
        "AfterCardDrawn", "AfterCardDrawnEarly", "AfterCardEnteredCombat",
        "AfterCardExhausted", "AfterCardGeneratedForCombat", "BeforeCardPlayed",
        "AfterCardPlayed", "AfterCardPlayedLate", "BeforeCombatStart",
        "BeforeCombatStartLate", "AfterCombatEnd", "AfterCombatVictory",
        "AfterCombatVictoryEarly", "AfterCreatureAddedToCombat", "AfterCurrentHpChanged",
        "AfterDamageGiven", "BeforeDamageReceived", "AfterDamageReceived",
        "AfterDamageReceivedLate", "BeforeDeath", "AfterDeath", "AfterDiedToDoom",
        "AfterEnergyReset", "AfterEnergyResetLate", "AfterEnergySpent", "BeforeFlush",
        "BeforeFlushLate", "AfterFlush", "BeforeHandDraw", "BeforeHandDrawLate",
        "AfterHandEmptied", "AfterModifyingBlockAmount", "AfterModifyingCardPlayCount",
        "AfterModifyingDamageAmount",
        "AfterModifyingEnergyGain", "AfterModifyingHandDraw", "AfterModifyingHpLostBeforeOsty",
        "AfterModifyingHpLostAfterOsty", "AfterModifyingOrbPassiveTriggerCount",
        "AfterModifyingPowerAmountGiven", "AfterModifyingPowerAmountReceived",
        "AfterOrbChanneled", "AfterOrbEvoked", "AfterOstyRevived", "BeforePotionUsed",
        "AfterPotionUsed", "AfterPotionDiscarded", "AfterPotionProcured",
        "BeforePowerAmountChanged", "AfterPowerAmountChanged", "AfterPreventingBlockClear",
        "AfterPreventingDeath", "AfterPreventingDraw", "AfterShuffle", "AfterStarsSpent",
        "AfterStarsGained", "AfterSummon", "AfterTakingExtraTurn", "BeforeSideTurnStart",
        "AfterSideTurnStart", "AfterSideTurnStartLate", "AfterPlayerTurnStartEarly",
        "AfterPlayerTurnStart", "AfterPlayerTurnStartLate", "BeforeSideTurnEndVeryEarly",
        "BeforeSideTurnEndEarly", "BeforeSideTurnEnd", "AfterSideTurnEnd",
        "AfterSideTurnEndLate", "AfterForge", "ShouldAllowHitting", "ShouldAllowTargeting",
        "ShouldClearBlock", "ShouldDie", "ShouldDieLate", "ShouldDraw", "ShouldEtherealTrigger",
        "ShouldFlush", "ShouldPlay", "ShouldPlayerResetEnergy", "ShouldStopCombatFromEnding",
        "ShouldTakeExtraTurn", "ShouldGainStars", "ShouldPayExcessEnergyCostWithStars",
        "ShouldPowerBeRemovedOnDeath", "ShouldCreatureBeRemovedFromCombatAfterDeath",
        "ShouldAfflict", "ModifyAttackHitCount", "ModifyBlockAdditive",
        "ModifyBlockMultiplicative", "ModifyCardPlayCount", "ModifyCardPlayResultPileTypeAndPosition",
        "ModifyDamageAdditive", "ModifyDamageCap", "ModifyDamageMultiplicative",
        "ModifyEnergyGain", "ModifyHandDraw", "ModifyHandDrawLate", "ModifyHpLostBeforeOsty",
        "ModifyHpLostBeforeOstyLate", "ModifyHpLostAfterOsty", "ModifyHpLostAfterOstyLate",
        "ModifyMaxEnergy", "ModifyOrbPassiveTriggerCounts", "ModifyOrbValue",
        "ModifyPowerAmountGiven", "ModifyPowerAmountReceived", "ModifySummonAmount",
        "ModifyUnblockedDamageTarget", "ModifyXValue", "ModifyStarCost",
        "TryModifyEnergyCostInCombat", "TryModifyEnergyCostInCombatLate",
        "TryModifyPowerAmountReceived", "TryModifyStarCost"
    };

    private static readonly HashSet<string> SemanticHoldRelicIds = new(StringComparer.OrdinalIgnoreCase)
    {
        "PARRYING_SHIELD"
    };

    private static readonly IReadOnlyDictionary<string, string> SemanticHoldReasons =
        new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            ["PARRYING_SHIELD"] = "evidence_pending: multi-enemy target is observed, but CombatTargets RNG is masked so target identity is not NOSL-Reliable"
        };

    private static readonly string[] EvidenceRoots =
    [
        @"D:\STS2BestChoice\STS2SuperModel\data",
        @"D:\STS2BestChoice\STS2BestChoice\data"
    ];

    private sealed record RelicEvidenceValidation(
        bool ReferencePresent,
        bool ReportsValid,
        bool EvidenceEligible,
        int ReportCount,
        string Reason);

    private static bool HasCombatHook(
        string relicId,
        IReadOnlyCollection<string> declaredMethods,
        string englishDescription,
        string chineseDescription)
    {
        if (CombatHookRelicIds.Contains(relicId)) return true;

        // Lifecycle/modifier callbacks have combat meaning even when the
        // callback name itself does not contain "Combat".  AfterRoomEntered
        // is generic and must be checked against the explicit v0.111 room set.
        foreach (var method in declaredMethods)
        {
            if (method.Equals("AfterRoomEntered", StringComparison.Ordinal))
            {
                if (CombatRoomEntryRelicIds.Contains(relicId))
                    return true;
                continue;
            }

            if (CombatHookMethodNames.Contains(method)
                || method.StartsWith("ModifyWeak", StringComparison.Ordinal)
                || method.StartsWith("ModifyVulnerable", StringComparison.Ordinal))
                return true;
        }

        // Descriptions are retained as inputs for callers that want to emit a
        // review hint, but never decide combat scope on their own.  This
        // prevents reward/deck/map text from creating false positives.
        _ = englishDescription;
        _ = chineseDescription;
        return false;
    }

    private static RelicCombatRelevance DetermineCombatRelevance(
        string relicId,
        IReadOnlyCollection<string> declaredMethods,
        bool hasCombatHooks)
    {
        if (!hasCombatHooks)
            return RelicCombatRelevance.NonCombat;

        if (CombatRoomEntryRelicIds.Contains(relicId)
            || declaredMethods.Contains("BeforeCombatStart", StringComparer.Ordinal)
            || declaredMethods.Contains("BeforeCombatStartLate", StringComparer.Ordinal))
            return RelicCombatRelevance.CombatStart;

        if (declaredMethods.Contains("AfterPlayerTurnStart", StringComparer.Ordinal)
            || declaredMethods.Contains("AfterPlayerTurnStartEarly", StringComparer.Ordinal)
            || declaredMethods.Contains("AfterPlayerTurnStartLate", StringComparer.Ordinal)
            || declaredMethods.Contains("BeforeSideTurnStart", StringComparer.Ordinal)
            || declaredMethods.Contains("AfterSideTurnStart", StringComparer.Ordinal)
            || declaredMethods.Contains("AfterSideTurnStartLate", StringComparer.Ordinal)
            || declaredMethods.Contains("BeforeHandDraw", StringComparer.Ordinal)
            || declaredMethods.Contains("BeforeHandDrawLate", StringComparer.Ordinal)
            || declaredMethods.Contains("ModifyHandDraw", StringComparer.Ordinal)
            || declaredMethods.Contains("ModifyHandDrawLate", StringComparer.Ordinal)
            || declaredMethods.Contains("AfterAutoPrePlayPhaseEntered", StringComparer.Ordinal)
            || declaredMethods.Contains("AfterAutoPostPlayPhaseEntered", StringComparer.Ordinal))
            return RelicCombatRelevance.TurnStart;

        if (declaredMethods.Contains("BeforeFlush", StringComparer.Ordinal)
            || declaredMethods.Contains("BeforeFlushLate", StringComparer.Ordinal)
            || declaredMethods.Contains("AfterFlush", StringComparer.Ordinal)
            || declaredMethods.Contains("ShouldFlush", StringComparer.Ordinal)
            || declaredMethods.Contains("BeforeSideTurnEnd", StringComparer.Ordinal)
            || declaredMethods.Contains("AfterSideTurnEnd", StringComparer.Ordinal)
            || declaredMethods.Contains("AfterSideTurnEndLate", StringComparer.Ordinal))
            return RelicCombatRelevance.TurnEnd;

        if (declaredMethods.Contains("AfterStarsSpent", StringComparer.Ordinal)
            || declaredMethods.Contains("AfterStarsGained", StringComparer.Ordinal)
            || declaredMethods.Contains("AfterEnergySpent", StringComparer.Ordinal)
            || declaredMethods.Contains("AfterEnergyReset", StringComparer.Ordinal)
            || declaredMethods.Contains("AfterEnergyResetLate", StringComparer.Ordinal))
            return RelicCombatRelevance.EnergyTrigger;

        if (declaredMethods.Contains("ShouldDie", StringComparer.Ordinal)
            || declaredMethods.Contains("ShouldDieLate", StringComparer.Ordinal)
            || declaredMethods.Contains("BeforeDeath", StringComparer.Ordinal)
            || declaredMethods.Contains("AfterDeath", StringComparer.Ordinal)
            || declaredMethods.Contains("AfterDiedToDoom", StringComparer.Ordinal)
            || declaredMethods.Contains("AfterPreventingDeath", StringComparer.Ordinal))
            return RelicCombatRelevance.HpTrigger;

        if (declaredMethods.Any(method =>
                method.StartsWith("ModifyWeak", StringComparison.Ordinal)
                || method.StartsWith("ModifyVulnerable", StringComparison.Ordinal)
                || method.StartsWith("ModifyDamage", StringComparison.Ordinal)
                || method is "AfterDamageGiven" or "BeforeDamageReceived" or "AfterDamageReceived" or "AfterDamageReceivedLate"))
            return RelicCombatRelevance.DamageTrigger;

        if (declaredMethods.Contains("AfterOrbChanneled", StringComparer.Ordinal)
            || declaredMethods.Contains("AfterOrbEvoked", StringComparer.Ordinal)
            || declaredMethods.Contains("AfterModifyingOrbPassiveTriggerCount", StringComparer.Ordinal)
            || declaredMethods.Contains("ModifyOrbPassiveTriggerCounts", StringComparer.Ordinal)
            || declaredMethods.Contains("ModifyOrbValue", StringComparer.Ordinal))
            return RelicCombatRelevance.OrbTrigger;

        if (declaredMethods.Contains("AfterShuffle", StringComparer.Ordinal)
            || declaredMethods.Contains("AfterHandEmptied", StringComparer.Ordinal)
            || declaredMethods.Contains("ModifyCardPlayCount", StringComparer.Ordinal)
            || declaredMethods.Contains("TryModifyEnergyCostInCombat", StringComparer.Ordinal)
            || declaredMethods.Contains("TryModifyEnergyCostInCombatLate", StringComparer.Ordinal)
            || declaredMethods.Contains("ModifyXValue", StringComparer.Ordinal)
            || declaredMethods.Any(method => method.StartsWith("AfterCard", StringComparison.Ordinal)
                || method.StartsWith("BeforeCard", StringComparison.Ordinal)))
            return RelicCombatRelevance.CardPlay;

        if (declaredMethods.Contains("AfterCreatureAddedToCombat", StringComparer.Ordinal)
            || declaredMethods.Contains("BeforeCombatStart", StringComparer.Ordinal)
            || declaredMethods.Contains("BeforeCombatStartLate", StringComparer.Ordinal))
            return RelicCombatRelevance.CombatStart;

        if (declaredMethods.Contains("AfterCombatEnd", StringComparer.Ordinal)
            || declaredMethods.Contains("AfterCombatVictory", StringComparer.Ordinal)
            || declaredMethods.Contains("AfterCombatVictoryEarly", StringComparer.Ordinal))
            return RelicCombatRelevance.CombatEnd;

        return RelicCombatRelevance.CombatPassive;
    }

    private static string? ResolveEvidencePath(string fileName)
    {
        if (string.IsNullOrWhiteSpace(fileName)
            || !string.Equals(Path.GetFileName(fileName), fileName, StringComparison.Ordinal))
            return null;

        foreach (var root in EvidenceRoots)
        {
            var candidate = Path.Combine(root, fileName);
            if (File.Exists(candidate))
                return candidate;
        }

        return null;
    }

    private static RelicEvidenceValidation ValidateRelicEvidence(
        string relicId,
        string? references)
    {
        if (string.IsNullOrWhiteSpace(references))
            return new(false, false, false, 0, "evidence_missing: no report reference");

        var names = references
            .Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Distinct(StringComparer.Ordinal)
            .ToArray();
        if (names.Length == 0)
            return new(false, false, false, 0, "evidence_missing: no report reference");

        var reportCount = 0;
        var strictReports = true;
        foreach (var name in names)
        {
            var path = ResolveEvidencePath(name);
            if (path is null)
                return new(false, false, false, reportCount, $"evidence_missing: report not found: {name}");

            reportCount++;
            try
            {
                using var document = JsonDocument.Parse(File.ReadAllText(path));
                var root = document.RootElement;
                if (!HasRequiredString(root, "game_version", GameVersion, $"v{GameVersion}")
                    || !HasRequiredString(root, "game_commit", GameCommit)
                    || !HasRequiredString(root, "assembly_sha256", ExpectedSha256)
                    || !HasRequiredString(root, "cli_protocol_version", CliProtocolVersion)
                    || !HasRequiredInt(root, "schema_version", 1)
                    || !HasRequiredInt(root, "trace_schema", 1)
                    || !HasNonEmptyString(root, "trace_id")
                    || !HasNonEmptyString(root, "fixture")
                    || !HasInt(root, "action_ordinal")
                    || !ReportMentionsRelic(root, relicId))
                {
                    return new(false, false, false, reportCount, $"evidence_invalid: required strict fields or relic identity missing: {name}");
                }

                // Structural validity and Reliable eligibility are separate:
                // an Estimated/Uncalculable report can still be a valid,
                // version-matched record, but it must not qualify as Reliable.
                if (!HasRequiredString(root, "confidence", "Reliable")
                    || !HasRequiredBool(root, "match", true)
                    || !HasRequiredInt(root, "mismatch_count", 0)
                    || !HasRequiredString(root, "outcome_quality", "Exact")
                    || !HasRequiredString(root, "comparison_scope", "strict_public_state", "terminal_summary")
                    || !HasRequiredBool(root, "probability_known", true))
                    strictReports = false;
            }
            catch (Exception ex)
            {
                return new(false, false, false, reportCount, $"evidence_invalid: {name}: {ex.GetType().Name}");
            }
        }

        if (SemanticHoldRelicIds.Contains(relicId))
            return new(true, true, false, reportCount, SemanticHoldReasons[relicId]);

        if (!strictReports)
            return new(true, true, false, reportCount, "evidence_pending: one or more reports are not Reliable/mismatch-free");

        return new(true, true, true, reportCount, "strict_cli_shadow_diff: all referenced reports passed");
    }

    private static bool HasRequiredString(JsonElement root, string property, params string[] expected)
    {
        if (!root.TryGetProperty(property, out var value) || value.ValueKind != JsonValueKind.String)
            return false;
        var actual = value.GetString();
        return expected.Any(item => string.Equals(actual, item, StringComparison.OrdinalIgnoreCase));
    }

    private static bool HasNonEmptyString(JsonElement root, string property) =>
        root.TryGetProperty(property, out var value)
        && value.ValueKind == JsonValueKind.String
        && !string.IsNullOrWhiteSpace(value.GetString());

    private static bool HasRequiredInt(JsonElement root, string property, int expected) =>
        root.TryGetProperty(property, out var value)
        && value.ValueKind == JsonValueKind.Number
        && value.TryGetInt32(out var actual)
        && actual == expected;

    private static bool HasInt(JsonElement root, string property) =>
        root.TryGetProperty(property, out var value)
        && value.ValueKind == JsonValueKind.Number
        && value.TryGetInt32(out _);

    private static bool HasRequiredBool(JsonElement root, string property, bool expected) =>
        root.TryGetProperty(property, out var value)
        && ((value.ValueKind == JsonValueKind.True && expected)
            || (value.ValueKind == JsonValueKind.False && !expected));

    private static bool ReportMentionsRelic(JsonElement root, string relicId)
    {
        if (!root.TryGetProperty("fields", out var fields) || fields.ValueKind != JsonValueKind.Array)
            return false;

        foreach (var field in fields.EnumerateArray())
        {
            if (!field.TryGetProperty("field", out var fieldName)
                || fieldName.ValueKind != JsonValueKind.String)
                continue;
            var name = fieldName.GetString() ?? string.Empty;
            if (name.StartsWith($"relic.{relicId}.", StringComparison.OrdinalIgnoreCase))
                return true;
            if (!name.Equals("relic.ids", StringComparison.OrdinalIgnoreCase)
                || !field.TryGetProperty("actual", out var actual)
                || actual.ValueKind != JsonValueKind.Array)
                continue;
            if (actual.EnumerateArray().Any(value =>
                    value.ValueKind == JsonValueKind.String
                    && string.Equals(value.GetString(), relicId, StringComparison.OrdinalIgnoreCase)))
                return true;
        }

        return false;
    }

    public RelicCatalogTests(ITestOutputHelper output)
    {
        _output = output;
    }

    [ModuleInitializer]
    internal static void InitAssemblyResolver()
    {
        var sts2Dir = @"D:\steam\steamapps\common\Slay the Spire 2\data_sts2_windows_x86_64";
        AssemblyLoadContext.Default.Resolving += (context, name) =>
        {
            var path = Path.Combine(sts2Dir, name.Name + ".dll");
            if (File.Exists(path))
            {
                return context.LoadFromAssemblyPath(path);
            }
            return null;
        };
    }

    private static readonly object _initLock = new();
    private static bool _initialized = false;
    internal static void EnsureModelDbInitialized()
    {
        lock (_initLock)
        {
            if (_initialized) return;
            TestMode.IsOn = true;

            var reflectionHelper = typeof(ReflectionHelper);
            var allTypes = reflectionHelper.GetField("_allTypes", BindingFlags.Static | BindingFlags.NonPublic);
            var modTypes = reflectionHelper.GetField("_modTypes", BindingFlags.Static | BindingFlags.NonPublic);
            allTypes?.SetValue(null, Array.Empty<Type>());
            modTypes?.SetValue(null, Array.Empty<Type>());

            var subtypes = AbstractModelSubtypes.All;
            for (int i = 0; i < subtypes.Count; i++)
            {
                try
                {
                    ModelDb.Inject(subtypes[i]);
                }
                catch
                {
                }
            }
            _initialized = true;
        }
    }

    [Fact]
    public void AssemblySha256MatchesV0111()
    {
        var asmLocation = typeof(ModelDb).Assembly.Location;
        using var stream = File.OpenRead(asmLocation);
        var hash = Convert.ToHexString(SHA256.HashData(stream));
        Assert.Equal(ExpectedSha256, hash);
    }

    [Fact]
    public void VersionedRelicDatabaseLoadsAll299Relics()
    {
        var db = VersionedRelicDatabase.LoadEmbedded(typeof(VersionedRelicDatabase).Assembly);
        Assert.Equal(299, db.AllRelics.Count);
        Assert.True(db.TryResolve("AKABEKO", out var akabeko));
        Assert.NotNull(akabeko);
        Assert.Equal("赤牛", akabeko.LocalizedNameZh);
        Assert.Equal("Akabeko", akabeko.CanonicalName);
        Assert.Equal(RelicEffectSupportStatus.SimulatorSupported, akabeko.SupportStatus);

        Assert.True(db.TryResolveByName("赤牛", out var byZh));
        Assert.NotNull(byZh);
        Assert.Equal("AKABEKO", byZh.RelicId);

        Assert.True(db.TryResolve("BURNING_BLOOD", out var bb));
        Assert.NotNull(bb);
        Assert.Equal(RelicEffectSupportStatus.NoCombatEffect, bb.SupportStatus);
    }

    [Fact]
    public void GenerateAndExportFullRelicCatalog()
    {
        EnsureModelDbInitialized();
        var rawRelics = ModelDb.AllRelics.OrderBy(r => r.Id.Entry, StringComparer.Ordinal).ToArray();
        Assert.Equal(299, rawRelics.Length);

        var zhsJsonPath = @"D:\STS2BestChoice\STS2SuperModel\sts2-cli-v0111\localization_zhs\relics.json";
        var engJsonPath = @"D:\STS2BestChoice\STS2SuperModel\sts2-cli-v0111\localization_eng\relics.json";
        var zhs = JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(zhsJsonPath))!;
        var eng = JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(engJsonPath))!;

        var supportedP1Set = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "AKABEKO", "ANCHOR", "ART_OF_WAR", "BAG_OF_MARBLES", "BAG_OF_PREPARATION",
            "CENTENNIAL_PUZZLE", "HAPPY_FLOWER", "INCENSE_BURNER", "LANTERN",
            "NUNCHAKU", "ODDLY_SMOOTH_STONE", "ORICHALCUM", "PEN_NIB", "RING_OF_THE_SNAKE",
            "SUNDIAL", "VAJRA", "TOUGH_BANDAGES", "TUNGSTEN_ROD", "UNCEASING_TOP",
            "BRONZE_SCALES", "BLOOD_VIAL", "BRIMSTONE",
            // Batch 1 (v0.111 attack/turn relics).
            "SHURIKEN", "KUNAI", "ORNAMENTAL_FAN", "LETTER_OPENER", "RAINBOW_RING",
            "MERCURY_HOURGLASS", "MR_STRUGGLES", "SAI", "CANDELABRA", "CHANDELIER",
            "FAKE_HAPPY_FLOWER", "FAKE_ORICHALCUM",
            // Batch 2 (turn-end / damage-modifier / combat-start-carried).
            "CLOAK_CLASP", "KUSARIGAMA", "PARRYING_SHIELD", "SCREAMING_FLAGON",
            "RIPPLE_BASIN", "PAELS_TEARS", "STRIKE_DUMMY", "FAKE_STRIKE_DUMMY",
            "SNECKO_EYE", "WHISPERING_EARRING", "FAKE_BLOOD_VIAL", "FAKE_ANCHOR",
            "VERY_HOT_COCOA", "PHILOSOPHERS_STONE",
            // Batch 3 (scheduled block/draw, turn-7 strike, exhaust counter,
            // energy carry-over, combat-start carry).
            "SELF_FORMING_CLAY", "STONE_CALENDAR", "JOSS_PAPER", "POCKETWATCH",
            "ICE_CREAM", "NINJA_SCROLL",
            // Batch 4 (combat-start carried: potions / conditional DEX / Confused).
            "DELICATE_FROND", "BELT_BUCKLE", "FAKE_SNECKO_EYE",
            // Batch 5 (damage floor / baked block double / free 5th card).
            "THE_BOOT", "VAMBRACE", "BRILLIANT_SCARF", "PANTOGRAPH",
            // Batch 6 (combat-start effect relics carried by the snapshot).
            "FESTIVE_POPPER", "ROYAL_POISON", "RED_MASK", "TWISTED_FUNNEL",
            // Batch 7 (max-energy growth relics).
            "BREAD", "PAELS_FLESH",
            // Batch 8 (combat-end heals, unlocked by the CLI terminal trace row).
            "BLACK_BLOOD", "MEAT_ON_THE_BONE",
            // Batch 9 (cycle draws + cross-combat carried counters).
            "PENDULUM", "SWORD_OF_STONE", "FISHING_ROD", "TOY_BOX", "WONGOS_MYSTERY_TICKET",
            // Batch 10 (per-play trigger relics).
            "DAUGHTER_OF_THE_WIND", "INTIMIDATING_HELMET", "IVORY_TILE", "IRON_CLUB",
            // Batch 11 (conditional/limit relics).
            "BEATING_REMNANT", "SEAL_OF_GOLD", "VELVET_CHOKER",
            // Batch 12 (teacher-side use-state export unlocked these).
            "GAME_PIECE", "PERMAFROST", "LOST_WISP",
            // Batch 13 (long-sequence counter relic).
            "TUNING_FORK",
            // Batch 14 (turn-N triggers, per-turn draw, max-energy carried).
            "BOOMING_CONCH", "HORN_CLEAT", "CAPTAINS_WHEEL", "SPARKLING_ROUGE",
            "RING_OF_THE_DRAKE", "PAELS_BLOOD", "ECTOPLASM", "SOZU", "PRISMATIC_GEM",
            // Batches 15-16 (block-break, per-turn draw, carried max-energy).
            "HAND_DRILL", "FIDDLE", "VENERABLE_TEA_SET", "FAKE_VENERABLE_TEA_SET",
            "SPIKED_GAUNTLETS", "PUMPKIN_CANDLE", "BIG_MUSHROOM", "BLOOD_SOAKED_ROSE",
            // D2 relic semantics: combat-start effects are materialized by the
            // live root; the remaining hooks are mirrored by the shadow.
            "DIVINE_RIGHT", "DATA_DISK", "GORGET", "EMBER_TEA", "SWORD_OF_JADE",
            "SLING_OF_COURAGE", "GREMLIN_HORN", "BOOK_REPAIR_KNIFE", "LIZARD_TAIL",
            "RUNIC_PYRAMID", "RINGING_TRIANGLE", "PAPER_PHROG", "PAPER_KRANE", "THE_ABACUS"
        };
        var runtimeProbedSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            // Previous zero-mismatch probes
            "ANCHOR", "NUNCHAKU",
            // P0 expansion batch: fixed-seed CLI/Core differentials, all with
            // mismatch_count=0 against STS2SuperModel/data/p0-csharp-*-diff-report*.json
            "VAJRA", "ODDLY_SMOOTH_STONE", "AKABEKO", "BAG_OF_MARBLES",
            "LANTERN", "BAG_OF_PREPARATION", "PEN_NIB", "RING_OF_THE_SNAKE",
            "ART_OF_WAR", "HAPPY_FLOWER", "ORICHALCUM", "CENTENNIAL_PUZZLE",
            // P1 relics:
            "TOUGH_BANDAGES", "TUNGSTEN_ROD", "UNCEASING_TOP",
            "BRONZE_SCALES", "BLOOD_VIAL", "BRIMSTONE",
            // P1 batch 1:
            "SHURIKEN", "KUNAI", "ORNAMENTAL_FAN", "LETTER_OPENER", "RAINBOW_RING",
            "MERCURY_HOURGLASS", "MR_STRUGGLES", "SAI", "CANDELABRA", "CHANDELIER",
            "FAKE_HAPPY_FLOWER", "FAKE_ORICHALCUM",
            // P1 batch 2:
            "CLOAK_CLASP", "KUSARIGAMA", "PARRYING_SHIELD", "SCREAMING_FLAGON",
            "RIPPLE_BASIN", "PAELS_TEARS", "STRIKE_DUMMY", "FAKE_STRIKE_DUMMY",
            "SNECKO_EYE", "WHISPERING_EARRING", "FAKE_BLOOD_VIAL", "FAKE_ANCHOR",
            "VERY_HOT_COCOA", "PHILOSOPHERS_STONE",
            "SELF_FORMING_CLAY", "STONE_CALENDAR", "JOSS_PAPER", "POCKETWATCH",
            "ICE_CREAM", "NINJA_SCROLL",
            "DELICATE_FROND", "BELT_BUCKLE", "FAKE_SNECKO_EYE",
            "THE_BOOT", "VAMBRACE", "BRILLIANT_SCARF", "PANTOGRAPH",
            "FESTIVE_POPPER", "ROYAL_POISON", "RED_MASK", "TWISTED_FUNNEL",
            "BREAD", "PAELS_FLESH",
            "BLACK_BLOOD", "MEAT_ON_THE_BONE",
            "PENDULUM", "SWORD_OF_STONE", "FISHING_ROD", "TOY_BOX", "WONGOS_MYSTERY_TICKET",
            "DAUGHTER_OF_THE_WIND", "INTIMIDATING_HELMET", "IVORY_TILE", "IRON_CLUB",
            "BEATING_REMNANT", "SEAL_OF_GOLD", "VELVET_CHOKER",
            "GAME_PIECE", "PERMAFROST", "LOST_WISP",
            "TUNING_FORK",
            "BOOMING_CONCH", "HORN_CLEAT", "CAPTAINS_WHEEL", "SPARKLING_ROUGE",
            "RING_OF_THE_DRAKE", "PAELS_BLOOD", "ECTOPLASM", "SOZU", "PRISMATIC_GEM",
            // Batches 15-16 (block-break, per-turn draw, carried max-energy).
            "HAND_DRILL", "FIDDLE", "VENERABLE_TEA_SET", "FAKE_VENERABLE_TEA_SET",
            "SPIKED_GAUNTLETS", "PUMPKIN_CANDLE", "BIG_MUSHROOM", "BLOOD_SOAKED_ROSE",
            // D2 version-locked paired/direct runtime witnesses.
            "DIVINE_RIGHT", "DATA_DISK", "GORGET", "EMBER_TEA", "SWORD_OF_JADE",
            "SLING_OF_COURAGE", "GREMLIN_HORN", "BOOK_REPAIR_KNIFE", "LIZARD_TAIL",
            "RUNIC_PYRAMID", "RINGING_TRIANGLE", "PAPER_PHROG", "PAPER_KRANE", "THE_ABACUS"
        };
        var evidenceReferences = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            ["ANCHOR"] = "p1-csharp-relic-anchor-diff-report.json",
            ["NUNCHAKU"] = "p1-csharp-relic-nunchaku-diff-report-0.json; p1-csharp-relic-nunchaku-diff-report-1.json",
            ["VAJRA"] = "p0-csharp-vajra-strength-diff-report.json; p0-csharp-vajra-strength-end-turn-diff-report.json",
            ["ODDLY_SMOOTH_STONE"] = "p0-csharp-smooth-stone-dexterity-diff-report.json",
            ["AKABEKO"] = "p0-csharp-akabeko-vigor-diff-report.json",
            ["BAG_OF_MARBLES"] = "p0-csharp-bag-of-marbles-diff-report.json",
            ["LANTERN"] = "p0-csharp-lantern-diff-report.json",
            ["BAG_OF_PREPARATION"] = "p0-csharp-bag-of-preparation-diff-report.json",
            ["PEN_NIB"] = "p0-csharp-pen-nib-diff-report.json; p0-csharp-pen-nib-double-diff-report-12.json",
            ["RING_OF_THE_SNAKE"] = "p0-csharp-ring-of-the-snake-diff-report.json",
            ["ART_OF_WAR"] = "p0-csharp-art-of-war-diff-report-0.json; p0-csharp-art-of-war-diff-report-1.json",
            ["HAPPY_FLOWER"] = "p0-csharp-happy-flower-diff-report.json",
            ["ORICHALCUM"] = "p0-csharp-orichalcum-diff-report.json",
            ["CENTENNIAL_PUZZLE"] = "p0-csharp-centennial-puzzle-diff-report.json",
            ["TOUGH_BANDAGES"] = "p1-csharp-relic-tough-bandages-diff-report.json",
            ["TUNGSTEN_ROD"] = "p1-csharp-relic-tungsten-rod-diff-report-0.json; p1-csharp-relic-tungsten-rod-diff-report-1.json",
            ["UNCEASING_TOP"] = "p1-csharp-relic-unceasing-top-diff-report-0.json; p1-csharp-relic-unceasing-top-diff-report-1.json; p1-csharp-relic-unceasing-top-diff-report-2.json; p1-csharp-relic-unceasing-top-empty-diff-report-4.json",
            ["BRONZE_SCALES"] = "p1-csharp-relic-bronze-scales-diff-report-0.json; p1-csharp-relic-bronze-scales-diff-report-1.json",
            ["BLOOD_VIAL"] = "p1-csharp-relic-blood-vial-diff-report.json",
            ["BRIMSTONE"] = "p1-csharp-relic-brimstone-diff-report-0.json; p1-csharp-relic-brimstone-diff-report-1.json",
            // P1 batch 1:
            ["SHURIKEN"] = "p1-csharp-relic-attack-counters-diff-report-2.json; p1-csharp-relic-attack-counters-diff-report-3.json; p1-csharp-relic-attack-counters-diff-report-4.json; p1-csharp-relic-attack-counters-diff-report-5.json",
            ["KUNAI"] = "p1-csharp-relic-attack-counters-diff-report-2.json; p1-csharp-relic-attack-counters-diff-report-3.json; p1-csharp-relic-attack-counters-diff-report-4.json; p1-csharp-relic-attack-counters-diff-report-5.json",
            ["ORNAMENTAL_FAN"] = "p1-csharp-relic-attack-counters-diff-report-2.json; p1-csharp-relic-attack-counters-diff-report-3.json; p1-csharp-relic-attack-counters-diff-report-4.json; p1-csharp-relic-attack-counters-diff-report-5.json",
            ["LETTER_OPENER"] = "p1-csharp-relic-letter-opener-diff-report-2.json; p1-csharp-relic-letter-opener-diff-report-3.json",
            ["RAINBOW_RING"] = "p1-csharp-relic-rainbow-ring-diff-report-1.json; p1-csharp-relic-rainbow-ring-diff-report-2.json",
            ["MERCURY_HOURGLASS"] = "p1-csharp-relic-mercury-hourglass-diff-report-0.json; p1-csharp-relic-mercury-hourglass-diff-report-1.json",
            ["MR_STRUGGLES"] = "p1-csharp-relic-mr-struggles-diff-report-0.json; p1-csharp-relic-mr-struggles-diff-report-1.json",
            ["SAI"] = "p1-csharp-relic-sai-diff-report.json",
            ["CANDELABRA"] = "p1-csharp-relic-candelabra-diff-report-0.json; p1-csharp-relic-candelabra-diff-report-1.json",
            ["CHANDELIER"] = "p1-csharp-relic-chandelier-diff-report-0.json; p1-csharp-relic-chandelier-diff-report-1.json",
            ["FAKE_HAPPY_FLOWER"] = "p1-csharp-relic-fake-happy-flower-diff-report-0.json; p1-csharp-relic-fake-happy-flower-diff-report-4.json",
            ["FAKE_ORICHALCUM"] = "p1-csharp-relic-fake-orichalcum-diff-report.json",
            // P1 batch 2:
            ["CLOAK_CLASP"] = "p1-csharp-relic-turn-end-block-diff-report-0.json; p1-csharp-relic-turn-end-block-diff-report-1.json",
            ["RIPPLE_BASIN"] = "p1-csharp-relic-turn-end-block-diff-report-0.json; p1-csharp-relic-turn-end-block-diff-report-1.json",
            ["PARRYING_SHIELD"] = "p1-csharp-relic-parrying-shield-diff-report-2.json; p1-csharp-relic-parrying-shield-multi-diff-report-2.json",
            ["SCREAMING_FLAGON"] = "p1-csharp-relic-screaming-flagon-diff-report-5.json",
            ["KUSARIGAMA"] = "p1-csharp-relic-kusarigama-diff-report-2.json; p1-csharp-relic-kusarigama-diff-report-3.json; p1-csharp-relic-kusarigama-diff-report-4.json; p1-csharp-relic-kusarigama-diff-report-5.json",
            ["PAELS_TEARS"] = "p1-csharp-relic-paels-tears-diff-report-1.json; p1-csharp-relic-paels-tears-diff-report-2.json",
            ["STRIKE_DUMMY"] = "p1-csharp-relic-strike-dummy-diff-report-0.json; p1-csharp-relic-strike-dummy-diff-report-1.json; p1-csharp-relic-strike-dummy-diff-report-2.json; p1-csharp-relic-strike-dummy-diff-report-3.json",
            ["FAKE_STRIKE_DUMMY"] = "p1-csharp-relic-strike-dummy-diff-report-0.json; p1-csharp-relic-strike-dummy-diff-report-1.json; p1-csharp-relic-strike-dummy-diff-report-2.json; p1-csharp-relic-strike-dummy-diff-report-3.json",
            ["SNECKO_EYE"] = "p1-csharp-relic-snecko-eye-diff-report-1.json; p1-csharp-relic-snecko-eye-diff-report-2.json",
            ["WHISPERING_EARRING"] = "p1-csharp-relic-whispering-earring-diff-report-0.json; p1-csharp-relic-whispering-earring-diff-report-1.json",
            ["FAKE_BLOOD_VIAL"] = "p1-csharp-relic-combat-start-carried-diff-report-0.json; p1-csharp-relic-combat-start-carried-diff-report-1.json",
            ["FAKE_ANCHOR"] = "p1-csharp-relic-combat-start-carried-diff-report-0.json; p1-csharp-relic-combat-start-carried-diff-report-1.json",
            ["VERY_HOT_COCOA"] = "p1-csharp-relic-combat-start-carried-diff-report-0.json; p1-csharp-relic-combat-start-carried-diff-report-1.json",
            ["PHILOSOPHERS_STONE"] = "p1-csharp-relic-combat-start-carried-diff-report-0.json; p1-csharp-relic-combat-start-carried-diff-report-1.json",
            // P1 batches 5-16 evidence references.
            ["SELF_FORMING_CLAY"] = "p1-csharp-relic-self-forming-clay-diff-report-0.json; p1-csharp-relic-self-forming-clay-diff-report-1.json",
            ["POCKETWATCH"] = "p1-csharp-relic-pocketwatch-diff-report-0.json; p1-csharp-relic-pocketwatch-diff-report-1.json",
            ["STONE_CALENDAR"] = "p1-csharp-relic-stone-calendar-diff-report-6.json",
            ["JOSS_PAPER"] = "p1-csharp-relic-joss-paper-diff-report-2.json; p1-csharp-relic-joss-paper-diff-report-4.json",
            ["ICE_CREAM"] = "p1-csharp-relic-ice-cream-diff-report-1.json; p1-csharp-relic-ice-cream-diff-report-2.json",
            ["NINJA_SCROLL"] = "p1-csharp-relic-ninja-scroll-diff-report.json",
            ["DELICATE_FROND"] = "p1-csharp-relic-delicate-frond-diff-report-0.json; p1-csharp-relic-delicate-frond-diff-report-1.json",
            ["BELT_BUCKLE"] = "p1-csharp-relic-belt-buckle-diff-report-0.json; p1-csharp-relic-belt-buckle-diff-report-1.json",
            ["FAKE_SNECKO_EYE"] = "p1-csharp-relic-fake-snecko-eye-diff-report-0.json; p1-csharp-relic-fake-snecko-eye-diff-report-1.json",
            ["THE_BOOT"] = "p1-csharp-relic-the-boot-diff-report-0.json; p1-csharp-relic-the-boot-diff-report-1.json; p1-csharp-relic-the-boot-diff-report-2.json",
            ["VAMBRACE"] = "p1-csharp-relic-vambrace-diff-report-0.json; p1-csharp-relic-vambrace-diff-report-1.json",
            ["BRILLIANT_SCARF"] = "p1-csharp-relic-brilliant-scarf-diff-report-3.json; p1-csharp-relic-brilliant-scarf-diff-report-5.json",
            ["PANTOGRAPH"] = "p1-csharp-relic-pantograph-diff-report-0.json; p1-csharp-relic-pantograph-diff-report-1.json",
            ["FESTIVE_POPPER"] = "p1-csharp-relic-festive-popper-diff-report-0.json; p1-csharp-relic-festive-popper-diff-report-1.json",
            ["ROYAL_POISON"] = "p1-csharp-relic-royal-poison-diff-report-0.json; p1-csharp-relic-royal-poison-diff-report-1.json",
            ["RED_MASK"] = "p1-csharp-relic-red-mask-diff-report-0.json; p1-csharp-relic-red-mask-diff-report-1.json",
            ["TWISTED_FUNNEL"] = "p1-csharp-relic-twisted-funnel-diff-report-0.json; p1-csharp-relic-twisted-funnel-diff-report-1.json",
            ["BREAD"] = "p1-csharp-relic-bread-diff-report-0.json; p1-csharp-relic-bread-diff-report-1.json",
            ["PAELS_FLESH"] = "p1-csharp-relic-paels-flesh-diff-report-0.json; p1-csharp-relic-paels-flesh-diff-report-1.json",
            ["BLACK_BLOOD"] = "p1-csharp-relic-combat-end-heal-diff-report-2.json",
            ["MEAT_ON_THE_BONE"] = "p1-csharp-relic-combat-end-heal-diff-report-2.json",
            ["PENDULUM"] = "p1-csharp-relic-pendulum-diff-report-0.json; p1-csharp-relic-pendulum-diff-report-1.json",
            ["SWORD_OF_STONE"] = "p1-csharp-relic-cross-combat-carried-diff-report-0.json; p1-csharp-relic-cross-combat-carried-diff-report-1.json",
            ["FISHING_ROD"] = "p1-csharp-relic-cross-combat-carried-diff-report-0.json; p1-csharp-relic-cross-combat-carried-diff-report-1.json",
            ["TOY_BOX"] = "p1-csharp-relic-cross-combat-carried-diff-report-0.json; p1-csharp-relic-cross-combat-carried-diff-report-1.json",
            ["WONGOS_MYSTERY_TICKET"] = "p1-csharp-relic-cross-combat-carried-diff-report-0.json; p1-csharp-relic-cross-combat-carried-diff-report-1.json",
            ["DAUGHTER_OF_THE_WIND"] = "p1-csharp-relic-wind-block-diff-report-0.json; p1-csharp-relic-wind-block-diff-report-1.json; p1-csharp-relic-wind-block-diff-report-2.json",
            ["INTIMIDATING_HELMET"] = "p1-csharp-relic-cost-gated-diff-report-0.json; p1-csharp-relic-cost-gated-diff-report-1.json; p1-csharp-relic-cost-gated-diff-report-2.json",
            ["IVORY_TILE"] = "p1-csharp-relic-cost-gated-diff-report-0.json; p1-csharp-relic-cost-gated-diff-report-1.json; p1-csharp-relic-cost-gated-diff-report-2.json",
            ["IRON_CLUB"] = "p1-csharp-relic-cost-gated-diff-report-0.json; p1-csharp-relic-cost-gated-diff-report-1.json; p1-csharp-relic-cost-gated-diff-report-2.json",
            ["BEATING_REMNANT"] = "p1-csharp-relic-beating-remnant-diff-report-0.json; p1-csharp-relic-beating-remnant-diff-report-1.json",
            ["SEAL_OF_GOLD"] = "p1-csharp-relic-seal-of-gold-diff-report-0.json; p1-csharp-relic-seal-of-gold-diff-report-1.json",
            ["VELVET_CHOKER"] = "p1-csharp-relic-velvet-choker-diff-report-0.json; p1-csharp-relic-velvet-choker-diff-report-1.json",
            ["GAME_PIECE"] = "p1-csharp-relic-power-triggers-diff-report-0.json; p1-csharp-relic-power-triggers-diff-report-1.json",
            ["PERMAFROST"] = "p1-csharp-relic-power-triggers-diff-report-0.json; p1-csharp-relic-power-triggers-diff-report-1.json",
            ["LOST_WISP"] = "p1-csharp-relic-power-triggers-diff-report-0.json; p1-csharp-relic-power-triggers-diff-report-1.json",
            ["TUNING_FORK"] = "p1-csharp-relic-tuning-fork-diff-report-0.json; p1-csharp-relic-tuning-fork-diff-report-1.json; p1-csharp-relic-tuning-fork-diff-report-2.json; p1-csharp-relic-tuning-fork-diff-report-3.json",
            ["BOOMING_CONCH"] = "p1-csharp-relic-booming-conch-diff-report.json",
            ["HORN_CLEAT"] = "p1-csharp-relic-turn-n-triggers-diff-report-0.json; p1-csharp-relic-turn-n-triggers-diff-report-1.json",
            ["CAPTAINS_WHEEL"] = "p1-csharp-relic-turn-n-triggers-diff-report-0.json; p1-csharp-relic-turn-n-triggers-diff-report-1.json",
            ["SPARKLING_ROUGE"] = "p1-csharp-relic-turn-n-triggers-diff-report-0.json; p1-csharp-relic-turn-n-triggers-diff-report-1.json",
            ["RING_OF_THE_DRAKE"] = "p1-relic-ring-of-the-drake-paired-control-report.json",
            ["PAELS_BLOOD"] = "p1-csharp-relic-per-turn-draw-diff-report-0.json; p1-csharp-relic-per-turn-draw-diff-report-1.json",
            ["ECTOPLASM"] = "p1-csharp-relic-max-energy-carried-diff-report-0.json; p1-csharp-relic-max-energy-carried-diff-report-1.json",
            ["SOZU"] = "p1-csharp-relic-max-energy-carried-diff-report-0.json; p1-csharp-relic-max-energy-carried-diff-report-1.json",
            ["PRISMATIC_GEM"] = "p1-csharp-relic-max-energy-carried-diff-report-0.json; p1-csharp-relic-max-energy-carried-diff-report-1.json",
            ["HAND_DRILL"] = "p1-csharp-relic-hand-drill-diff-report-1.json",
            ["FIDDLE"] = "p1-csharp-relic-fiddle-diff-report-0.json; p1-csharp-relic-fiddle-diff-report-1.json",
            ["VENERABLE_TEA_SET"] = "p1-csharp-relic-tea-carried-diff-report-0.json; p1-csharp-relic-tea-carried-diff-report-1.json",
            ["FAKE_VENERABLE_TEA_SET"] = "p1-csharp-relic-tea-carried-diff-report-0.json; p1-csharp-relic-tea-carried-diff-report-1.json",
            ["SPIKED_GAUNTLETS"] = "p1-csharp-relic-tea-carried-diff-report-0.json; p1-csharp-relic-tea-carried-diff-report-1.json",
            ["PUMPKIN_CANDLE"] = "p1-csharp-relic-tea-carried-diff-report-0.json; p1-csharp-relic-tea-carried-diff-report-1.json",
            ["BIG_MUSHROOM"] = "p1-csharp-relic-tea-carried-diff-report-0.json; p1-csharp-relic-tea-carried-diff-report-1.json",
            ["BLOOD_SOAKED_ROSE"] = "p1-csharp-relic-tea-carried-diff-report-0.json; p1-csharp-relic-tea-carried-diff-report-1.json",
            ["DIVINE_RIGHT"] = "d2-relic-divine-right-paired-report.json",
            ["DATA_DISK"] = "d2-relic-data-disk-paired-report.json",
            ["GORGET"] = "d2-relic-gorget-paired-report.json",
            ["EMBER_TEA"] = "d2-relic-ember-tea-paired-report.json",
            ["SWORD_OF_JADE"] = "d2-relic-sword-of-jade-paired-report.json",
            ["SLING_OF_COURAGE"] = "d2-relic-sling-of-courage-paired-report.json",
            ["GREMLIN_HORN"] = "p1-csharp-relic-d2-gremlin-horn-diff-report.json",
            ["BOOK_REPAIR_KNIFE"] = "d2-relic-book-repair-knife-paired-report.json",
            ["LIZARD_TAIL"] = "d2-relic-lizard-tail-paired-report.json",
            ["RUNIC_PYRAMID"] = "d2-relic-runic-pyramid-paired-report.json",
            ["RINGING_TRIANGLE"] = "d2-relic-ringing-triangle-paired-report.json",
            ["PAPER_PHROG"] = "p1-csharp-relic-d2-paper-phrog-diff-report-1.json",
            ["PAPER_KRANE"] = "d2-relic-paper-krane-paired-report.json",
            ["THE_ABACUS"] = "d2-relic-the-abacus-paired-report.json",
        };

        // Terminal classifications for combat relics that cannot reach
        // SimulatorSupported through the CLI/ShadowDiff evidence loop. Each
        // entry cites the concrete engine limitation observed during batches
        // 8-14 (teacher-snapshot disambiguation, P1_RELIC_VERIFICATION.md).
        var unverifiableByCli = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            // Engine-generated card identity: generated copies / random picks
            // use instance ids the public observation cannot reproduce
            // (verified: Burning Sticks copy appears as engine-minted
            // card:TREMBLE:012; self-exhaust resolution is async — the teacher
            // exhaust pile reads 0 right after the play).
            "BURNING_STICKS", "CHARONS_ASHES", "HELICAL_DART", "MUSIC_BOX",
            "FORGOTTEN_SOUL", "TINGSHA", "MUMMIFIED_HAND", "REGALITE",
            "CROSSBOW", "VEXING_PUZZLEBOX", "POWER_CELL", "ORANGE_DOUGH",
            "BIG_HAT", "CHOICES_PARADOX", "JEWELED_MASK", "GAMBLING_CHIP",
            "FUR_COAT", "BONE_TEA", "RAZOR_TOOTH", "THROWING_AXE",
            "UNSETTLING_LAMP", "FUNERARY_MASK", "TOOLBOX", "BLESSED_ANTLER",
            "RADIANT_PEARL",
        };
        var uncalculable = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            // Stars resource subsystem absent from the shadow.
            "DIVINE_DESTINY", "MINI_REGENT", "LUNAR_PASTRY", "PAELS_TOOTH", "PAELS_WING",
            // Pet / summon subsystem absent.
            "BOUND_PHYLACTERY", "BYRDPIP", "PHYLACTERY_UNBOUND", "PAELS_LEGION", "PAELS_EYE",
            // Orb subsystem interplay not modeled (verified mismatch on
            // turn-boundary orb passives in batch 2 probing).
            "CRACKED_CORE", "INFUSED_CORE", "SYMBIOTIC_VIRUS", "GOLD_PLATED_CABLES",
            "EMOTION_CHIP", "RUNIC_CAPACITOR",
            // Rewards / deck-modification UI subsystems out of combat scope.
            "DINGY_RUG", "GLITTER", "FROZEN_EGG", "MOLTEN_EGG", "TOXIC_EGG",
            "FRESNEL_LENS", "BING_BONG", "BOOK_OF_FIVE_RINGS", "LUCKY_FYSH",
            "DARKSTONE_PERIAPT", "LASTING_CANDY", "LAVA_LAMP", "SILVER_CRUCIBLE",
            "ARCHAIC_TOOTH", "WING_CHARM", "WHITE_BEAST_STATUE",
            // Multiplayer / ally (Osty) hooks.
            "BONE_FLUTE",
            // Enemy-intent gap: the round 3->4 SEAPUNK Buff intent blocks the
            // 4-turn draw transition (POLLINOUS_CORE).
            "POLLINOUS_CORE",
            // CLI snapshot gap: the turn-start draw-pile exhaust makes the
            // end_turn reply lose its public observation (TOASTY_MITTENS).
            "TOASTY_MITTENS",
            // Card semantics not derivable from public observations.
            "DEMON_TONGUE", "FENCING_MANUAL", "GHOST_SEED", "CHEMICAL_X",
            "DIAMOND_DIADEM", "RED_SKULL", "VITRUVIAN_MINION", "MYSTIC_LIGHTER",
            "MINIATURE_CANNON", "UNDYING_SIGIL", "REPTILE_TRINKET", "STURDY_CLAMP",
            // Upgrade-at-combat-start hand semantics not derivable from
            // public observations (BELLOWS).
            "BELLOWS",
            // Orb count trigger (METRONOME) / invisible pickup effect
            // (PETRIFIED_TOAD) / Enchanted state (SILKEN_TRESS) /
            // poison-application interception recursion (SNECKO_SKULL).
            "METRONOME", "PETRIFIED_TOAD", "SILKEN_TRESS", "SNECKO_SKULL",
            // Ruined Helmet doubles the first Strength via the shared power
            // row (same entanglement as RED_SKULL); Tea of Discourtesy's Dazed
            // cards vanish at the turn boundary (verified, batch 13).
            "RUINED_HELMET", "TEA_OF_DISCOURTESY",
            // Combat-end effects beyond the terminal heal comparison
            // (max-HP gain is not a compared field; elite-kill upgrades need
            // cross-combat upgrade state).
            "CHOSEN_CHEESE", "WAR_HAMMER",
        };
        var terminalReasons = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var id in unverifiableByCli)
            terminalReasons[id] = "UnverifiableByCli: engine-generated card identity or async exhaust resolution cannot be reproduced from public observations (teacher-snapshot disambiguation, batches 12-13)";
        foreach (var id in uncalculable)
            terminalReasons[id] = "Uncalculable: requires an engine subsystem the deterministic shadow does not model (Stars/pets/orbs/rewards UI/intent state/card upgrade state)";
        terminalReasons["REPTILE_TRINKET"] = "Uncalculable: the engine surfaces this relic as a REPTILE_TRINKET_POWER power row that the shadow's power-row model does not mirror (potion-use probe, batch 15)";
        terminalReasons["STURDY_CLAMP"] = "Uncalculable: verification transition is blocked by the enemy Shrink power mechanic gap (SHRINK_POWER row not modeled); the block-persist itself matched";
        terminalReasons["DIAMOND_DIADEM"] = "Uncalculable: the half-damage rule has no relic-side damage-modification hook in the v0.111 IL (AfterSideTurnStart only) and the engine-side carrier state is not observable";
        terminalReasons["RED_SKULL"] = "Uncalculable: the conditional Strength contribution is entangled with the shared STRENGTH power row and cannot be decomposed from public observations";
        terminalReasons["CHEMICAL_X"] = "Uncalculable: X-cost effect scaling is card-specific and not decomposable from public observations";
        terminalReasons["GHOST_SEED"] = "Uncalculable: Ethereal injection on Strikes/Defends is a card-keyword modification whose resolution (unlike the Dazed case) has no observable counter-evidence path";
        terminalReasons["THROWING_AXE"] = "Uncalculable: first-card extra-play requires replay-pipeline integration that is not observable in public per-action traces";
        terminalReasons["UNDYING_SIGIL"] = "Uncalculable: enemy Doom-vs-HP comparison requires the enemy Doom accounting the shadow does not track";
        terminalReasons["VITRUVIAN_MINION"] = "Uncalculable: Minion-card doubling is name-tagged card semantics without observable counter-evidence path";
        terminalReasons["MYSTIC_LIGHTER"] = "UnverifiableByCli: the Enchanted card state is not exported in the public observation";
        terminalReasons["DEMON_TONGUE"] = "UnverifiableByCli: card self-HP-loss events are not exported in the public card stats (probe, batch 5)";
        terminalReasons["FENCING_MANUAL"] = "Uncalculable: Forge hand-affecting card semantics at combat start are not modeled";
        terminalReasons["TOASTY_MITTENS"] = "UnverifiableByCli: the turn-start draw-pile exhaust makes the CLI end_turn reply lose its public observation (trace rows without post-state)";
        terminalReasons["BELLOWS"] = "Uncalculable: first-hand upgrade semantics modify card state at combat start without an observable counter path";
        terminalReasons["METRONOME"] = "Uncalculable: orb-count trigger requires the orb subsystem";
        terminalReasons["PETRIFIED_TOAD"] = "UnverifiableByCli: the Potion-Shaped Rock it procures has no observable trace in the combat snapshot (probed, batch 4)";
        terminalReasons["SILKEN_TRESS"] = "UnverifiableByCli: the Enchanted card state is not exported in the public observation";
        terminalReasons["RADIANT_PEARL"] = "UnverifiableByCli: the generated Luminesce cards use engine-minted instance ids that cannot be reproduced from public observations";
                terminalReasons["RUINED_HELMET"] = "Uncalculable: the first-Strength doubling is entangled with the shared STRENGTH power row and cannot be decomposed from public observations";
        terminalReasons["TEA_OF_DISCOURTESY"] = "Uncalculable: the shuffled-in Dazed cards vanish at the turn boundary without exhausting or discarding (verified via teacher snapshots), which the shadow pile model cannot represent";
                terminalReasons["SNECKO_SKULL"] = "Uncalculable: poison-application interception requires a recursion-safe hook in the shared status pipeline not verifiable from public observations";
        terminalReasons["POLLINOUS_CORE"] = "UnverifiableByCli: the 4-turn draw fires on the round 3->4 transition where the SEAPUNK Buff+Defend intent carries no effect amounts in the public observation";

        // Validate every runtime probe before using it as evidence.  A report
        // file that is missing, from another version, or does not mention the
        // relic cannot make an object Reliable.  Semantic holds may have
        // mechanically green reports but remain evidence-ineligible until the
        // required discriminating fixture is present.
        var evidenceValidationByRelic = new Dictionary<string, RelicEvidenceValidation>(StringComparer.OrdinalIgnoreCase);
        foreach (var id in runtimeProbedSet)
        {
            evidenceReferences.TryGetValue(id, out var references);
            var validation = ValidateRelicEvidence(id, references);
            evidenceValidationByRelic[id] = validation;
            Assert.True(
                validation.ReferencePresent && validation.ReportsValid,
                $"Relic {id} has structurally invalid runtime evidence: {validation.Reason}");
        }

        // Every combat-hook relic must be represented as combat-relevant.  This
        // catches omissions such as GIRYA (AfterRoomEntered -> CombatRoom) at
        // catalog-generation time rather than silently producing OutOfScope.
        var missingCombatHookIds = CombatHookRelicIds
            .Where(id => !rawRelics.Any(relic => relic.Id.Entry.Equals(id, StringComparison.OrdinalIgnoreCase)))
            .Order(StringComparer.OrdinalIgnoreCase)
            .ToArray();
        Assert.Empty(missingCombatHookIds);

        var catalogEntries = new List<RelicCatalogEntry>();

        foreach (var r in rawRelics)
        {
            var id = r.Id.Entry;
            var type = r.GetType();
            var methods = type.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.DeclaredOnly)
                .Select(m => m.Name)
                .Where(m => !m.StartsWith("<") && !m.StartsWith("get_") && !m.StartsWith("set_"))
                .ToArray();

            var nameZh = zhs.TryGetValue($"{id}.title", out var nz) ? nz : id;
            var nameEn = eng.TryGetValue($"{id}.title", out var ne) ? ne : id;
            var descZh = zhs.TryGetValue($"{id}.description", out var dz) ? dz : string.Empty;
            var descEn = eng.TryGetValue($"{id}.description", out var de) ? de : string.Empty;

            var hasCombatHooks = HasCombatHook(id, methods, descEn, descZh);

            var keywordsBuilder = ImmutableArray.CreateBuilder<string>();
            if (!string.IsNullOrEmpty(descZh))
            {
                foreach (System.Text.RegularExpressions.Match m in System.Text.RegularExpressions.Regex.Matches(descZh, @"\[(?:gold|purple|blue|red)\](.+?)\[\/(?:gold|purple|blue|red)\]"))
                {
                    var kw = m.Groups[1].Value.Trim();
                    if (!string.IsNullOrWhiteSpace(kw) && !kw.Contains('{') && !kw.Contains('}'))
                    {
                        if (!keywordsBuilder.Contains(kw))
                            keywordsBuilder.Add(kw);
                    }
                }
            }
            var keywords = keywordsBuilder.ToImmutable();

            var aliasesBuilder = ImmutableArray.CreateBuilder<string>();
            if (!string.IsNullOrWhiteSpace(nameZh) && !nameZh.Equals(id, StringComparison.OrdinalIgnoreCase))
                aliasesBuilder.Add(nameZh);
            if (!string.IsNullOrWhiteSpace(nameEn) && !nameEn.Equals(id, StringComparison.OrdinalIgnoreCase))
                aliasesBuilder.Add(nameEn);
            aliasesBuilder.Add(id.ToLowerInvariant());

            var dynVarNamesBuilder = ImmutableArray.CreateBuilder<string>();
            var dynVarsBuilder = ImmutableDictionary.CreateBuilder<string, decimal>(StringComparer.Ordinal);
            try
            {
                foreach (var v in r.DynamicVars.Values)
                {
                    dynVarNamesBuilder.Add(v.Name);
                    dynVarsBuilder[v.Name] = (decimal)v.BaseValue;
                }
            }
            catch { }
            var dynamicVarNames = dynVarNamesBuilder.ToImmutable();
            var dynamicVars = dynVarsBuilder.ToImmutable();

            bool hasCounter = false;
            int? defaultCounter = null;
            try
            {
                hasCounter = r.ShowCounter;
                defaultCounter = hasCounter ? (int?)r.DisplayAmount : null;
            }
            catch { }

            RelicCombatRelevance relevance = DetermineCombatRelevance(id, methods, hasCombatHooks);

            RelicEffectSupportStatus supportStatus;
            string? terminalReason = null;
            if (supportedP1Set.Contains(id))
            {
                // A handler can be implemented while the current fixture is
                // insufficient to prove its full semantics.  Keep those two
                // objects PartiallySupported so downstream Reliable filters
                // cannot mistake a mechanically green report for complete
                // evidence.
                supportStatus = SemanticHoldRelicIds.Contains(id)
                    ? RelicEffectSupportStatus.PartiallySupported
                    : RelicEffectSupportStatus.SimulatorSupported;
            }
            else if (id.Equals("BURNING_BLOOD", StringComparison.OrdinalIgnoreCase))
            {
                supportStatus = RelicEffectSupportStatus.NoCombatEffect;
            }
            else if (unverifiableByCli.Contains(id))
            {
                supportStatus = RelicEffectSupportStatus.UnverifiableByCli;
                terminalReason = terminalReasons[id];
            }
            else if (uncalculable.Contains(id))
            {
                supportStatus = RelicEffectSupportStatus.Uncalculable;
                terminalReason = terminalReasons[id];
            }
            else if (!hasCombatHooks)
            {
                // Batch R3: relics whose declared methods carry no combat hook
                // are map/shop/reward/event or cross-combat effects; they are
                // explicitly out of the single-player combat scope instead of
                // an open "Unknown".
                supportStatus = RelicEffectSupportStatus.OutOfScope;
                terminalReason = "OutOfScope: non-combat relic; no in-combat hooks (map/shop/reward/event or cross-combat effects only)";
            }
            else
            {
                supportStatus = RelicEffectSupportStatus.UnsupportedKnownEffect;
            }

            var notes = hasCombatHooks
                ? $"Declared methods: {string.Join(", ", methods)}"
                : "Non-combat relic; no in-combat action effect.";
            // Batch R1 disambiguation notes for the two semantic holds.  Do
            // not claim that the old single-enemy/partial-hand fixtures prove
            // the full behavior.
            if (id.Equals("PARRYING_SHIELD", StringComparison.OrdinalIgnoreCase))
            {
                notes += " Multi-enemy target trace is present; target identity remains masked by NOSL CombatTargets RNG.";
            }
            else if (id.Equals("UNCEASING_TOP", StringComparison.OrdinalIgnoreCase))
            {
                notes = "AfterHandEmptied handler verified by an empty-hand trace with a draw-pile card available.";
            }

            var wikiUrl = $"https://sts2.huijiwiki.com/wiki/{Uri.EscapeDataString(nameZh)}";

            var evidenceValidation = evidenceValidationByRelic.GetValueOrDefault(id);
            var evidenceEligible = evidenceValidation?.EvidenceEligible == true;
            var evidenceLevel = evidenceEligible
                ? RelicEvidenceLevel.LiveObserved
                : hasCombatHooks
                    ? RelicEvidenceLevel.HeuristicInferred
                    : RelicEvidenceLevel.Unknown;
            var evidenceSource = runtimeProbedSet.Contains(id)
                ? evidenceValidation?.Reason ?? "evidence_pending: validation unavailable"
                : terminalReason ?? "sts2.dll v0.111.0 ModelDb.AllRelics + declared-method reflection";

            var entry = new RelicCatalogEntry(
                RelicId: id,
                CanonicalName: nameEn,
                LocalizedNameZh: nameZh,
                Rarity: r.Rarity.ToString(),
                Description: descEn,
                DynamicDescription: descZh,
                Keywords: keywords,
                Aliases: aliasesBuilder.ToImmutable(),
                WikiUrl: wikiUrl,
                ModelType: type.FullName ?? type.Name,
                RuntimeType: type.Name,
                DynamicVarNames: dynamicVarNames,
                DynamicVars: dynamicVars,
                HasCounter: hasCounter,
                DefaultCounter: defaultCounter,
                CombatRelevance: relevance,
                SupportStatus: supportStatus,
                EvidenceLevel: evidenceLevel,
                EvidenceSource: evidenceSource,
                EvidenceReference: runtimeProbedSet.Contains(id) && evidenceReferences.TryGetValue(id, out var evidenceReference)
                    ? evidenceReference
                    : type.FullName ?? type.Name,
                VerifiedGameVersion: GameVersion,
                Notes: notes);

            catalogEntries.Add(entry);
        }

        var document = new RelicCatalogDocument(
            SchemaVersion: 1,
            GameVersion: GameVersion,
            GameCommit: GameCommit,
            AssemblySha256: ExpectedSha256,
            CliProtocolVersion: CliProtocolVersion,
            GeneratedAtUtc: "2026-08-30T00:00:00Z",
            Relics: catalogEntries.OrderBy(e => e.RelicId, StringComparer.Ordinal).ToImmutableArray());

        var jsonOptions = new JsonSerializerOptions
        {
            WriteIndented = true,
            PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
            Converters = { new JsonStringEnumConverter(JsonNamingPolicy.SnakeCaseLower) }
        };

        var json = JsonSerializer.Serialize(document, jsonOptions);

        // Write to both data directories
        var path1 = @"D:\STS2BestChoice\STS2BestChoice\data\relics\generated\0.111.0\relics.json";
        var path2 = @"D:\STS2BestChoice\STS2SuperModel\data\relics\v0.111\relic-catalog.json";

        Directory.CreateDirectory(Path.GetDirectoryName(path1)!);
        Directory.CreateDirectory(Path.GetDirectoryName(path2)!);

        File.WriteAllText(path1, json, System.Text.Encoding.UTF8);
        File.WriteAllText(path2, json, System.Text.Encoding.UTF8);

        _output.WriteLine($"Saved relic catalog to {path1} and {path2}");

        // Build coverage report
        var total = document.Relics.Length;
        var structured = total;
        var captured = total;
        var ilInspected = 0;
        var probes = runtimeProbedSet.Count;
        var simSupported = document.Relics.Count(r => r.SupportStatus == RelicEffectSupportStatus.SimulatorSupported);
        var noCombatEffect = document.Relics.Count(r => r.SupportStatus == RelicEffectSupportStatus.NoCombatEffect);
        var partialSupported = document.Relics.Count(r => r.SupportStatus == RelicEffectSupportStatus.PartiallySupported);
        var unsupported = document.Relics.Count(r => r.SupportStatus == RelicEffectSupportStatus.UnsupportedKnownEffect);
        var unknown = document.Relics.Count(r => r.SupportStatus == RelicEffectSupportStatus.Unknown);
        var outOfScope = document.Relics.Count(r => r.SupportStatus == RelicEffectSupportStatus.OutOfScope);
        var structurallyValidEvidence = evidenceValidationByRelic.Values.Count(v => v.ReportsValid);
        var evidenceEligibleProbeCount = evidenceValidationByRelic.Values.Count(v => v.EvidenceEligible);
        var semanticHoldCount = SemanticHoldRelicIds.Count(id =>
            evidenceValidationByRelic.TryGetValue(id, out var validation)
            && !validation.EvidenceEligible);
        var reliableEligible = evidenceEligibleProbeCount + noCombatEffect;

        // The runtime-probe set is an implementation inventory, not a
        // Reliable-label whitelist.  Every probe must have a structural
        // reference, while only strict/mismatch-free reports (and the explicit
        // no-combat relic) count as Reliable eligible.
        Assert.Equal(probes, structurallyValidEvidence);
        Assert.DoesNotContain(document.Relics, entry =>
            entry.SupportStatus == RelicEffectSupportStatus.OutOfScope
            && CombatHookRelicIds.Contains(entry.RelicId));
        foreach (var holdId in SemanticHoldRelicIds)
        {
            var holdEntry = document.Relics.Single(entry =>
                entry.RelicId.Equals(holdId, StringComparison.OrdinalIgnoreCase));
            Assert.Equal(RelicEffectSupportStatus.PartiallySupported, holdEntry.SupportStatus);
            Assert.False(evidenceValidationByRelic[holdId].EvidenceEligible);
        }

        var coverageReport = new
        {
            schema_version = 1,
            game_version = GameVersion,
            game_commit = GameCommit,
            assembly_sha256 = ExpectedSha256,
            cli_protocol_version = CliProtocolVersion,
            generated_at_utc = "2026-08-30T00:00:00Z",
            summary = new
            {
                total_relics = total,
                structured_count = structured,
                state_captured_count = captured,
                il_inspected_count = ilInspected,
                probed_count = probes,
                runtime_evidence_valid_count = structurallyValidEvidence,
                evidence_eligible_count = evidenceEligibleProbeCount,
                semantic_hold_count = semanticHoldCount,
                simulator_supported_count = simSupported,
                no_combat_effect_count = noCombatEffect,
                partially_supported_count = partialSupported,
                unsupported_known_count = unsupported,
                unknown_count = unknown,
                out_of_scope_count = outOfScope,
                reliable_eligible_count = reliableEligible,
                reliable_eligibility_definition = "strict version/schema-matched CLI ShadowDiff reports with confidence=Reliable, match=true, mismatch_count=0; semantic holds excluded"
            },
            relics = document.Relics.Select(r => new
            {
                relic_id = r.RelicId,
                canonical_name = r.CanonicalName,
                localized_name_zh = r.LocalizedNameZh,
                rarity = r.Rarity,
                cataloged = true,
                state_captured = true,
                dynamic_state_captured = r.DynamicVarNames.Length > 0,
                il_inspected = false,
                runtime_probed = runtimeProbedSet.Contains(r.RelicId),
                simulator_supported = r.SupportStatus == RelicEffectSupportStatus.SimulatorSupported,
                evidence_reference = r.EvidenceReference,
                combat_relevance = r.CombatRelevance.ToString(),
                evidence_source = r.EvidenceSource,
                notes = r.Notes,
                evidence_report_count = evidenceValidationByRelic.GetValueOrDefault(r.RelicId)?.ReportCount ?? 0,
                evidence_reports_structurally_valid = evidenceValidationByRelic.GetValueOrDefault(r.RelicId)?.ReportsValid ?? false,
                evidence_eligible = evidenceValidationByRelic.GetValueOrDefault(r.RelicId)?.EvidenceEligible ?? false,
                reliable_eligible = r.SupportStatus == RelicEffectSupportStatus.NoCombatEffect
                    || evidenceValidationByRelic.GetValueOrDefault(r.RelicId)?.EvidenceEligible == true,
                no_combat_effect = r.SupportStatus == RelicEffectSupportStatus.NoCombatEffect,
                training_feature_supported = true,
                affects_current_turn = r.CombatRelevance != RelicCombatRelevance.NonCombat,
                evidence_level = r.EvidenceLevel.ToString(),
                support_status = r.SupportStatus.ToString(),
                blocking_reason = r.SupportStatus == RelicEffectSupportStatus.PartiallySupported
                    ? evidenceValidationByRelic.GetValueOrDefault(r.RelicId)?.Reason
                    : r.SupportStatus == RelicEffectSupportStatus.UnsupportedKnownEffect
                        ? "In-combat hook not yet implemented in DeterministicSimulator"
                        : r.SupportStatus == RelicEffectSupportStatus.OutOfScope
                            ? "OutOfScope: non-combat relic; no in-combat hooks"
                            : r.EvidenceSource.StartsWith("UnverifiableByCli") || r.EvidenceSource.StartsWith("Uncalculable")
                                ? r.EvidenceSource
                                : evidenceValidationByRelic.GetValueOrDefault(r.RelicId)?.EvidenceEligible == false
                                    ? evidenceValidationByRelic.GetValueOrDefault(r.RelicId)?.Reason
                                    : null,
                next_action = r.SupportStatus == RelicEffectSupportStatus.PartiallySupported
                    ? "Capture the discriminating CLI fixture before Reliable promotion"
                    : r.SupportStatus == RelicEffectSupportStatus.UnsupportedKnownEffect
                        ? "Implement differential probe and simulator handler in next batch"
                        : r.SupportStatus == RelicEffectSupportStatus.OutOfScope
                            ? "None (OutOfScope)"
                            : evidenceValidationByRelic.GetValueOrDefault(r.RelicId)?.EvidenceEligible == false
                                ? "Repair or extend evidence before Reliable promotion"
                                : "None"
            }).ToArray()
        };

        var coverageJson = JsonSerializer.Serialize(coverageReport, jsonOptions);
        var covJsonPath1 = @"D:\STS2BestChoice\STS2SuperModel\data\relics\v0.111\relic-coverage.json";
        var covJsonPath2 = @"D:\STS2BestChoice\STS2BestChoice\data\relics\v0.111\relic-coverage.json";
        Directory.CreateDirectory(Path.GetDirectoryName(covJsonPath1)!);
        Directory.CreateDirectory(Path.GetDirectoryName(covJsonPath2)!);
        File.WriteAllText(covJsonPath1, coverageJson, System.Text.Encoding.UTF8);
        File.WriteAllText(covJsonPath2, coverageJson, System.Text.Encoding.UTF8);

        // Markdown coverage report
        var md = new System.Text.StringBuilder();
        md.AppendLine("# Slay the Spire 2 v0.111.0 遗物覆盖率报告");
        md.AppendLine();
        md.AppendLine($"- **游戏版本**: `{GameVersion}` (commit `{GameCommit}`)");
        md.AppendLine($"- **程序集 SHA-256**: `{ExpectedSha256}`");
        md.AppendLine($"- **CLI 协议**: `{CliProtocolVersion}`");
        md.AppendLine($"- **生成时间 (UTC)**: `2026-08-30T00:00:00Z`");
        md.AppendLine();
        md.AppendLine("## 汇总统计");
        md.AppendLine();
        md.AppendLine($"| 指标 | 数量 | 占比 |");
        md.AppendLine($"| :--- | :--- | :--- |");
        md.AppendLine($"| 游戏目录遗物总数 | **{total}** | 100.0% |");
        md.AppendLine($"| 已结构化数量 | **{structured}** | 100.0% |");
        md.AppendLine($"| 已捕获状态数量 | **{captured}** | 100.0% |");
        md.AppendLine($"| 已检查 IL 语义数量 | **{ilInspected}** | 0.0% |");
        md.AppendLine($"| 已完成真实引擎差分探针数量 | **{probes}** | {Math.Round(100.0 * probes / total, 1)}% |");
        md.AppendLine($"| 版本/结构字段有效的探针数量 | **{structurallyValidEvidence}** | {Math.Round(100.0 * structurallyValidEvidence / total, 1)}% |");
        md.AppendLine($"| 严格证据合格探针数量（Reliable eligible） | **{evidenceEligibleProbeCount}** | {Math.Round(100.0 * evidenceEligibleProbeCount / total, 1)}% |");
        md.AppendLine($"| 模拟器声明支持数量（不含证据待补的 PartiallySupported） | **{simSupported}** | {Math.Round(100.0 * simSupported / total, 1)}% |");
        md.AppendLine($"| 语义证据待补数量 | **{semanticHoldCount}** | {Math.Round(100.0 * semanticHoldCount / total, 1)}% |");
        md.AppendLine($"| 明确不影响当前回合数量 | **{noCombatEffect}** | {Math.Round(100.0 * noCombatEffect / total, 1)}% |");
        md.AppendLine($"| 能够产生 Reliable 教师标签数量 | **{reliableEligible}** | {Math.Round(100.0 * reliableEligible / total, 1)}% |");
        md.AppendLine($"| 已知不支持数量 (存在未支持战斗钩子) | **{unsupported}** | {Math.Round(100.0 * unsupported / total, 1)}% |");
        md.AppendLine($"| 未知遗物数量 | **{unknown}** | {Math.Round(100.0 * unknown / total, 1)}% |");
        md.AppendLine($"| 明确 OutOfScope 非战斗遗物数量 | **{outOfScope}** | {Math.Round(100.0 * outOfScope / total, 1)}% |");
        md.AppendLine();
        md.AppendLine("## P1 已验证支持遗物列表");
        md.AppendLine();
        md.AppendLine("| Relic ID | 中文名 | 英文名 | 稀有度 | 效果概览 | 证据等级 |");
        md.AppendLine("| :--- | :--- | :--- | :--- | :--- | :--- |");
        foreach (var r in document.Relics.Where(r => r.SupportStatus == RelicEffectSupportStatus.SimulatorSupported))
        {
            md.AppendLine($"| `{r.RelicId}` | {r.LocalizedNameZh} | {r.CanonicalName} | {r.Rarity} | {r.DynamicDescription.Replace("\n", " ")} | `{r.EvidenceLevel}` |");
        }
        md.AppendLine();

        var covMdPath1 = @"D:\STS2BestChoice\STS2SuperModel\data\relics\v0.111\relic-coverage.md";
        var covMdPath2 = @"D:\STS2BestChoice\STS2BestChoice\data\relics\v0.111\relic-coverage.md";
        File.WriteAllText(covMdPath1, md.ToString(), System.Text.Encoding.UTF8);
        File.WriteAllText(covMdPath2, md.ToString(), System.Text.Encoding.UTF8);

        _output.WriteLine($"Saved coverage report to {covJsonPath1} and {covMdPath1}");
    }

    [Fact]
    public void KnownCombatHookRelicsAreNeverClassifiedOutOfScope()
    {
        foreach (var id in CombatHookRelicIds)
        {
            var methods = id.Equals("GIRYA", StringComparison.OrdinalIgnoreCase)
                ? new[] { "AfterRoomEntered" }
                : id.Equals("PARRYING_SHIELD", StringComparison.OrdinalIgnoreCase)
                    ? new[] { "AfterSideTurnEnd" }
                    : new[] { "AfterShuffle" };
            Assert.True(
                HasCombatHook(id, methods, string.Empty, string.Empty),
                $"Known combat relic {id} was not recognized by the classifier.");
        }
    }

    [Fact]
    public void EvidenceValidationSeparatesStaleReferencesAndSemanticHolds()
    {
        var valid = ValidateRelicEvidence(
            "ANCHOR",
            "p1-csharp-relic-anchor-diff-report.json");
        Assert.True(valid.ReferencePresent && valid.ReportsValid && valid.EvidenceEligible, valid.Reason);

        var stale = ValidateRelicEvidence(
            "NINJA_SCROLL",
            "p1-csharp-relic-ninja-scroll-diff-report-0.json");
        Assert.False(stale.ReferencePresent);
        Assert.False(stale.EvidenceEligible);

        // Estimated reports remain structurally valid but are not eligible for
        // the Reliable whitelist (this is expected for unknown RNG outcomes).
        var estimated = ValidateRelicEvidence(
            "NINJA_SCROLL",
            "p1-csharp-relic-ninja-scroll-diff-report.json");
        Assert.True(estimated.ReferencePresent && estimated.ReportsValid, estimated.Reason);
        Assert.False(estimated.EvidenceEligible);

        var hold = ValidateRelicEvidence(
            "PARRYING_SHIELD",
            "p1-csharp-relic-parrying-shield-diff-report-2.json");
        Assert.True(hold.ReferencePresent && hold.ReportsValid, hold.Reason);
        Assert.False(hold.EvidenceEligible);
        Assert.StartsWith("evidence_pending:", hold.Reason, StringComparison.OrdinalIgnoreCase);
    }
}
