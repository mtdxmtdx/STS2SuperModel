using System.Collections.Immutable;
using STS2BestChoice.Core.Model;
using STS2BestChoice.Core.Simulation;
using Xunit;

namespace STS2BestChoice.Tests;

/// <summary>
/// Batch 2 relic handlers (v0.111.0): side-turn-end relics, Kusarigama
/// attack counter, Snecko Eye turn-start draw, Whispering Earring energy,
/// Paels' Tears pending-energy bonus, and Strike Dummy damage additives.
/// </summary>
public sealed class RelicBatch2SimulationTests
{
    private static PlayerState MakePlayer(int hp = 80, int maxHp = 80, int block = 0, int energy = 9, int maxEnergy = 3) =>
        new(hp, maxHp, block, energy, maxEnergy, ImmutableDictionary<string, StatusState>.Empty);

    private static CreatureState MakeEnemy(string id = "CULTIST:1", int hp = 50, int maxHp = 50, int block = 0) =>
        new(id, "Cultist", hp, maxHp, block, ImmutableDictionary<string, StatusState>.Empty, []);

    private static CardState MakeStrike(string instanceId = "strike_1") =>
        new(instanceId, "STRIKE_IRONCLAD", "打击", 1, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 6)], CardType: "Attack");

    private static CardState MakeDefend(string instanceId = "defend_1") =>
        new(instanceId, "DEFEND_IRONCLAD", "防御", 1, TargetKind.Self,
            [new EffectSpec(EffectKind.Block, 5)], CardType: "Skill");

    private static RelicState Relic(string id) =>
        new(id, SupportStatus: RelicEffectSupportStatus.SimulatorSupported);

    private static MutableCombatState MakeState(
        PlayerState player,
        CreatureState enemy,
        CardState[] hand,
        params RelicState[] relics)
    {
        var snap = CombatSnapshot.Create("fp", player, [enemy], hand, relics: relics);
        return MutableCombatState.FromSnapshot(snap);
    }

    private static CreatureState AttackingEnemy(int damage = 10) => MakeEnemy("CULTIST:1", hp: 50) with
    {
        Intents = [new IntentState("Attack", damage, 1)]
    };

    [Fact]
    public void CloakClaspGrantsBlockPerHandCardAtTurnEnd()
    {
        var sim = new DeterministicSimulator();
        var state = MakeState(MakePlayer(), AttackingEnemy(),
            [MakeDefend("d1"), MakeDefend("d2"), MakeDefend("d3")],
            Relic("CLOAK_CLASP"));

        var nextTurn = sim.ProjectToNextPlayerTurn(state);

        // 3 hand cards -> 3 block absorbed part of the 10-damage attack.
        Assert.Equal(73, nextTurn.Player.Hp);
    }

    [Fact]
    public void KusarigamaDamagesAllEnemiesOnEveryThirdAttack()
    {
        var sim = new DeterministicSimulator();
        var enemyA = MakeEnemy("CULTIST:1", hp: 50);
        var enemyB = MakeEnemy("CULTIST:2", hp: 50);
        var snap = CombatSnapshot.Create("fp", MakePlayer(), [enemyA, enemyB],
            [MakeStrike("s1"), MakeStrike("s2"), MakeStrike("s3"), MakeStrike("s4"), MakeStrike("s5"), MakeStrike("s6")],
            relics: [Relic("KUSARIGAMA")]);
        var state = MutableCombatState.FromSnapshot(snap);

        for (var i = 0; i < 6; i++)
        {
            var strike = state.Hand.First(c => c.ModelId == "STRIKE_IRONCLAD");
            state = sim.PlayCard(state, strike, "CULTIST:1", null);
        }

        // 6 strikes hit CULTIST:1 (36) plus two Kusarigama pulses of 6 to ALL.
        Assert.Equal(50 - 36 - 12, state.Enemies.First(e => e.Id == "CULTIST:1").Hp);
        Assert.Equal(50 - 12, state.Enemies.First(e => e.Id == "CULTIST:2").Hp);
        // Kusarigama exports the per-turn attack count modulo 3.
        Assert.Equal(0, state.Relics.First(r => r.Id == "KUSARIGAMA").Counter);
    }

    [Fact]
    public void ParryingShieldStrikesWhenBlockAtLeastTen()
    {
        var sim = new DeterministicSimulator();
        var enemy = MakeEnemy("CULTIST:1", hp: 50);
        var snap = CombatSnapshot.Create("fp", MakePlayer(), [enemy],
            [MakeDefend("d1"), MakeDefend("d2")],
            relics: [Relic("PARRYING_SHIELD")]);
        var state = MutableCombatState.FromSnapshot(snap);

        var defend = state.Hand.First(c => c.InstanceId == "d1");
        state = sim.PlayCard(state, defend, null, null);
        var defend2 = state.Hand.First(c => c.InstanceId == "d2");
        state = sim.PlayCard(state, defend2, null, null);

        var nextTurn = sim.ProjectToNextPlayerTurn(state);

        // 10 block absorbed the enemy attack and Parrying Shield dealt 6.
        Assert.Equal(80, nextTurn.Player.Hp);
        Assert.Equal(44, nextTurn.Enemies.First(e => e.Id == "CULTIST:1").Hp);
    }

    [Fact]
    public void ParryingShieldBranchesOneRandomTargetWhenTargetRngIsUnknown()
    {
        var sim = new DeterministicSimulator();
        var enemies = new[] { MakeEnemy("CULTIST:1"), MakeEnemy("CULTIST:2") };
        var streams = new RngSnapshotSet(ImmutableDictionary<string, RngStreamSnapshot>.Empty.Add(
            RngSnapshotSet.CombatTargets,
            new RngStreamSnapshot(RngSnapshotSet.CombatTargets, 0, 0, 0, 0, IsKnown: false)));
        var snap = CombatSnapshot.Create("fp", MakePlayer(block: 10), enemies, [],
            rngStreams: streams, relics: [Relic("PARRYING_SHIELD")]);

        var branches = sim.ProjectToNextPlayerTurnOutcomes(MutableCombatState.FromSnapshot(snap));

        Assert.Equal(2, branches.Length);
        Assert.Equal(1m, branches.Sum(branch => branch.Probability));
        Assert.All(branches, branch =>
        {
            var damaged = branch.State.Enemies.Count(enemy => enemy.Hp == 44);
            Assert.Equal(1, damaged);
            Assert.Equal(1, branch.State.Enemies.Count(enemy => enemy.Hp == 50));
            Assert.Equal(OutcomeKind.Stochastic, branch.Kind);
        });
    }

    [Fact]
    public void UnceasingTopDrawsAfterTheHandBecomesEmpty()
    {
        var sim = new DeterministicSimulator();
        var strike = MakeStrike("last_card");
        var drawCard = MakeDefend("drawn_card");
        var snap = CombatSnapshot.Create("fp", MakePlayer(), [MakeEnemy("CULTIST:1")], [strike],
            drawPile: [drawCard], relics: [Relic("UNCEASING_TOP")]);

        var state = MutableCombatState.FromSnapshot(snap);
        state = sim.PlayCard(state, strike, "CULTIST:1", null);

        Assert.Single(state.Hand);
        Assert.Equal("drawn_card", state.Hand[0].InstanceId);
        Assert.Contains(state.DiscardPile, card => card.InstanceId == "last_card");
        Assert.DoesNotContain(state.Risks, risk => risk.Severity == PredictionRiskSeverity.Uncalculable);
    }

    [Fact]
    public void ScreamingFlagonStrikesWhenHandEmpty()
    {
        var sim = new DeterministicSimulator();
        var enemy = MakeEnemy("CULTIST:1", hp: 100);
        var snap = CombatSnapshot.Create("fp", MakePlayer(), [enemy],
            [MakeStrike("s1"), MakeStrike("s2"), MakeStrike("s3"), MakeStrike("s4"), MakeStrike("s5")],
            relics: [Relic("SCREAMING_FLAGON")]);
        var state = MutableCombatState.FromSnapshot(snap);

        while (state.Hand.Count > 0)
        {
            var card = state.Hand[0];
            state = sim.PlayCard(state, card, "CULTIST:1", null);
        }

        var nextTurn = sim.ProjectToNextPlayerTurn(state);

        // Strikes dealt 30 and Flagon dealt 20 (100 -> 50); no attack intent.
        Assert.Equal(50, nextTurn.Enemies.First(e => e.Id == "CULTIST:1").Hp);
        Assert.Equal(80, nextTurn.Player.Hp);
    }

    [Fact]
    public void RippleBasinGrantsBlockWhenNoAttacksPlayed()
    {
        var sim = new DeterministicSimulator();
        var state = MakeState(MakePlayer(), MakeEnemy("CULTIST:1", hp: 50),
            [MakeDefend("d1")],
            Relic("RIPPLE_BASIN"));

        var defend = state.Hand.First(c => c.InstanceId == "d1");
        state = sim.PlayCard(state, defend, null, null);
        var nextTurn = sim.ProjectToNextPlayerTurn(state);

        // Defend 5 + Ripple Basin 4 = 9 block absorbed the enemy attack.
        Assert.Equal(80, nextTurn.Player.Hp);
        Assert.Equal(0, nextTurn.Player.Block);
    }

    [Fact]
    public void RippleBasinDoesNothingAfterAttacks()
    {
        var sim = new DeterministicSimulator();
        var state = MakeState(MakePlayer(), AttackingEnemy(),
            [MakeStrike("s1"), MakeDefend("d1")],
            Relic("RIPPLE_BASIN"));

        var strike = state.Hand.First(c => c.InstanceId == "s1");
        state = sim.PlayCard(state, strike, "CULTIST:1", null);
        var nextTurn = sim.ProjectToNextPlayerTurn(state);

        // No Ripple Basin block: the 10-damage attack lands fully.
        Assert.Equal(70, nextTurn.Player.Hp);
    }

    [Fact]
    public void PaelsTearsGrantsBonusEnergyAfterUnspentTurn()
    {
        var sim = new DeterministicSimulator();
        var state = MakeState(MakePlayer(energy: 3), MakeEnemy("CULTIST:1", hp: 50),
            [MakeDefend("d1"), MakeDefend("d2")],
            Relic("PAELS_TEARS"));

        var defend = state.Hand.First(c => c.InstanceId == "d1");
        state = sim.PlayCard(state, defend, null, null);
        Assert.Equal(2, state.Player.Energy);

        var turn2 = sim.ProjectToNextPlayerTurn(state);
        Assert.Equal(5, turn2.Player.Energy);

        // Unspent energy again (5 left) -> another +2 next turn (3 max + 2).
        var turn3 = sim.ProjectToNextPlayerTurn(turn2);
        Assert.Equal(5, turn3.Player.Energy);
    }

    [Fact]
    public void PaelsTearsDoesNothingWhenEnergySpent()
    {
        var sim = new DeterministicSimulator();
        var state = MakeState(MakePlayer(energy: 2), MakeEnemy("CULTIST:1", hp: 50),
            [MakeDefend("d1"), MakeDefend("d2")],
            Relic("PAELS_TEARS"));

        var defend = state.Hand.First(c => c.InstanceId == "d1");
        state = sim.PlayCard(state, defend, null, null);
        Assert.Equal(1, state.Player.Energy);
        // Spend the last energy: PlayCard already deducted 1; end turn with 1
        // unspent would trigger, so use two defends instead.
        var defend2 = state.Hand.First(c => c.InstanceId == "d2");
        state = sim.PlayCard(state, defend2, null, null);
        Assert.Equal(0, state.Player.Energy);

        var turn2 = sim.ProjectToNextPlayerTurn(state);
        Assert.Equal(3, turn2.Player.Energy);
    }

    [Fact]
    public void SneckoEyeDrawsTwoAdditionalCardsPerTurn()
    {
        var sim = new DeterministicSimulator();
        var drawPile = Enumerable.Range(0, 9).Select(i => MakeStrike($"s{i}")).ToArray();
        var snap = CombatSnapshot.Create("fp", MakePlayer(), [MakeEnemy("CULTIST:1", hp: 50)],
            [MakeDefend("d1")],
            drawPile: drawPile,
            relics: [Relic("SNECKO_EYE")]);
        var state = MutableCombatState.FromSnapshot(snap);

        var nextTurn = sim.ProjectToNextPlayerTurn(state);

        // 7 cards drawn at turn-2 start (5 + Snecko Eye 2); the pre-turn hand
        // was discarded at the boundary.
        Assert.Equal(7, nextTurn.Hand.Count);
    }

    [Fact]
    public void WhisperingEarringGrantsEnergyEveryTurn()
    {
        var sim = new DeterministicSimulator();
        var state = MakeState(MakePlayer(), MakeEnemy("CULTIST:1", hp: 50), [],
            Relic("WHISPERING_EARRING"));

        // The engine raises MAX energy at combat start; the snapshot MaxEnergy
        // already carries it (unit-test state keeps the raw 3). No per-turn gain.
        var turn2 = sim.ProjectToNextPlayerTurn(state);
        Assert.Equal(3, turn2.Player.Energy);
        var turn3 = sim.ProjectToNextPlayerTurn(turn2);
        Assert.Equal(3, turn3.Player.Energy);
    }

    [Fact]
    public void StrikeDummiesAddDamageToStrikes()
    {
        var sim = new DeterministicSimulator();
        var enemy = MakeEnemy("CULTIST:1", hp: 100);
        var snap = CombatSnapshot.Create("fp", MakePlayer(), [enemy],
            [MakeStrike("s1"), MakeStrike("s2")],
            relics: [Relic("STRIKE_DUMMY"), Relic("FAKE_STRIKE_DUMMY")]);
        var state = MutableCombatState.FromSnapshot(snap);

        var strike = state.Hand.First(c => c.InstanceId == "s1");
        state = sim.PlayCard(state, strike, "CULTIST:1", null);
        // The dummies are additive display modifiers: the CLI preview already
        // includes them in stats.damage, so the shadow does NOT re-apply them.
        // A hand-built card keeps the raw base (6), unlike the CLI snapshot.
        Assert.Equal(94, state.Enemies.First(e => e.Id == "CULTIST:1").Hp);
    }

    [Fact]
    public void StrikeDummiesDoNotAffectNonStrikeAttacks()
    {
        var sim = new DeterministicSimulator();
        var bash = new CardState("bash_1", "BASH", "重击", 2, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 8)], CardType: "Attack");
        var snap = CombatSnapshot.Create("fp", MakePlayer(), [MakeEnemy("CULTIST:1", hp: 100)],
            [bash],
            relics: [Relic("STRIKE_DUMMY"), Relic("FAKE_STRIKE_DUMMY")]);
        var state = MutableCombatState.FromSnapshot(snap);

        state = sim.PlayCard(state, bash, "CULTIST:1", null);
        Assert.Equal(92, state.Enemies.First(e => e.Id == "CULTIST:1").Hp);
    }
}
