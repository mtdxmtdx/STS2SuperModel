using System.Collections.Immutable;
using STS2BestChoice.Core.Model;
using STS2BestChoice.Core.Semantics;
using STS2BestChoice.Core.Simulation;
using Xunit;

namespace STS2BestChoice.Tests;

public sealed class GrowthAndAutoplayTests
{
    [Theory]
    [InlineData("造成10点伤害。将这张牌在本场战斗中的伤害增加5。")]
    [InlineData("造成10点伤害。将这张牌在本场战斗中的伤害增加10。")]
    [InlineData("造成8点伤害。每当你抽到这张牌时，在这场战斗中其伤害增加4。")]
    [InlineData("造成10点伤害。每当你抽到这张牌时，在这场战斗中其伤害增加6。")]
    [InlineData("造成3点伤害。本场战斗中所有爪击卡牌的伤害增加2点。")]
    [InlineData("造成4点伤害。本场战斗中所有爪击卡牌的伤害增加3点。")]
    [InlineData("造成5点伤害两次。在这场战斗中，将所有“撕咬”牌的伤害增加1。")]
    [InlineData("造成6点伤害两次。在这场战斗中，将所有“撕咬”牌的伤害增加2。")]
    [InlineData("打出抽牌堆顶部的牌并将其消耗。")]
    [InlineData("打出你抽牌堆顶部的X张牌。")]
    [InlineData("打出你抽牌堆顶部的X+1张牌。")]
    [InlineData("在你的回合开始时，打出你抽牌堆顶部的牌。")]
    [InlineData("对所有敌人造成16点伤害。在你的回合结束时，如果这张牌在你的消耗牌堆中，则将其打出。")]
    [InlineData("对所有敌人造成21点伤害。在你的回合结束时，如果这张牌在你的消耗牌堆中，则将其打出。")]
    [InlineData("获得10点格挡。在你的回合结束时，如果这张牌位于抽牌堆顶部，则将其打出。")]
    [InlineData("获得13点格挡。在你的回合结束时，如果这张牌位于抽牌堆顶部，则将其打出。")]
    [InlineData("造成18点伤害。你的回合开始时，如果这张牌在你的消耗牌堆中，则将其打出。消耗。")]
    [InlineData("造成24点伤害。你的回合开始时，如果这张牌在你的消耗牌堆中，则将其打出。消耗。")]
    [InlineData("造成6点伤害两次。随机打出你的抽牌堆中的1张攻击牌。")]
    [InlineData("造成8点伤害两次。随机打出你的抽牌堆中的1张攻击牌。")]
    [InlineData("从你的抽牌堆中随机打出2张牌。")]
    [InlineData("从你的抽牌堆中随机打出3张牌。")]
    [InlineData("打出你消耗牌堆中的所有虚无牌。消耗。")]
    [InlineData("造成11点伤害。这张牌的耗能降为0能量。")]
    [InlineData("造成15点伤害。这张牌的耗能降为0能量。")]
    [InlineData("造成8点伤害X次。如果X的最终数值为4或以上，则将X的数值翻倍。")]
    [InlineData("造成10点伤害X次。如果X的最终数值为4或以上，则将X的数值翻倍。")]
    [InlineData("造成12点伤害。本回合，你每打出一张牌，该敌人失去6点生命。")]
    [InlineData("固有。造成12点伤害。本回合，你每打出一张牌，该敌人失去6点生命。")]
    [InlineData("将一张随机攻击牌加入你的手牌。那张牌在本回合内可以免费打出。消耗。")]
    [InlineData("将一张随机技能牌添加到你的手牌中。这张牌在本回合内可以免费打出。消耗。")]
    [InlineData("将一张随机能力牌加入你的手牌。这张牌在本回合内免费打出。消耗。")]
    [InlineData("获得8点格挡。将一张随机牌放入你的手牌，这张牌在本回合可以免费打出。")]
    [InlineData("造成4点伤害两次。消耗你的手牌中随机一张攻击牌，并将它的伤害添加给这张牌。")]
    [InlineData("造成6点伤害两次。消耗你的手牌中随机一张攻击牌，并将它的伤害添加给这张牌。")]
    [InlineData("随机给予敌人3层中毒3次。")]
    [InlineData("随机给予敌人3层中毒4次。")]
    [InlineData("在这个回合，你当前手牌中所有牌的耗能降低至1。消耗。")]
    [InlineData("在这场战斗，你当前手牌中所有牌的耗能降低至1。消耗。")]
    [InlineData("在你的抽牌堆中加入3张随机攻击牌。它们在本场战斗中可以被免费打出。消耗。")]
    [InlineData("在你的抽牌堆中加入5张随机攻击牌。它们在本场战斗中可以被免费打出。消耗。")]
    [InlineData("将你抽牌堆中的所有稀有牌放入你的手牌。消耗。")]
    [InlineData("保留。将你抽牌堆中的所有稀有牌放入你的手牌。消耗。")]
    [InlineData("在你的回合结束时，随机打出你手牌中的1张攻击牌攻击随机敌人。")]
    [InlineData("添加2张墨影小刀到你的手牌。")]
    [InlineData("添加3张墨影小刀到你的手牌。")]
    [InlineData("消耗所有手牌。每消耗一张牌，将1张随机牌加入你的手牌。")]
    [InlineData("消耗所有手牌。每消耗一张牌，将1张随机已升级的牌加入你的手牌。")]
    [InlineData("每当你抽到名字中有“打击”的牌时，对一名随机敌人打出这张牌。")]
    [InlineData("将你消耗牌堆中的所有小刀对一名敌人打出。")]
    [InlineData("将你消耗牌堆中的所有小刀升级然后对一名敌人打出。")]
    [InlineData("获得1点格挡。每打出一次，这张牌在本局游戏中的格挡值永久增加3点。消耗。")]
    [InlineData("获得1点格挡。每打出一次，这张牌在本局游戏中的格挡值永久增加4点。消耗。")]
    [InlineData("造成8点伤害。你在回合进行中每抽到一张牌，都会使其额外造成4点伤害。")]
    [InlineData("造成9点伤害。你在回合进行中每抽到一张牌，都会使其额外造成6点伤害。")]
    [InlineData("造成13点伤害。这张牌在本局游戏中的伤害永久性增加4。消耗。")]
    [InlineData("造成13点伤害。这张牌在本局游戏中的伤害永久性增加5。消耗。")]
    public void CurrentGrowthAndAutoplayTextsAreStructuredAndExecutable(string text)
    {
        var result = CardTextSemanticCompiler.Compile(text);

        Assert.True(result.IsFullyStructured, text);
        Assert.True(result.IsSimulatorExecutable, text);
    }

    [Fact]
    public void CompilerPreservesGrowthAutoplayTimingAndRandomSources()
    {
        var drawGrowth = CardTextSemanticCompiler.Compile(
            "造成8点伤害。每当你抽到这张牌时，在这场战斗中其伤害增加4。");
        var modelGrowth = CardTextSemanticCompiler.Compile(
            "造成5点伤害两次。在这场战斗中，将所有“撕咬”牌的伤害增加1。");
        var cascade = CardTextSemanticCompiler.Compile("打出你抽牌堆顶部的X+1张牌。");
        var uproar = CardTextSemanticCompiler.Compile("随机打出你的抽牌堆中的1张攻击牌。");
        var howl = CardTextSemanticCompiler.Compile(
            "在你的回合结束时，如果这张牌在你的消耗牌堆中，则将其打出。");
        var stampede = CardTextSemanticCompiler.Compile(
            "在你的回合结束时，随机打出你手牌中的1张攻击牌攻击随机敌人。");
        var bladeOfInk = CardTextSemanticCompiler.Compile("添加2张墨影小刀到你的手牌。");
        var stoke = CardTextSemanticCompiler.Compile(
            "消耗所有手牌。每消耗一张牌，将1张随机牌加入你的手牌。");
        var hellraiser = CardTextSemanticCompiler.Compile(
            "每当你抽到名字中有“打击”的牌时，对一名随机敌人打出这张牌。");
        var knifeTrap = CardTextSemanticCompiler.Compile(
            "将你消耗牌堆中的所有小刀对一名敌人打出。");
        var upgradedKnifeTrap = CardTextSemanticCompiler.Compile(
            "将你消耗牌堆中的所有小刀升级然后对一名敌人打出。");
        var genetic = CardTextSemanticCompiler.Compile(
            "获得1点格挡。每打出一次，这张牌在本局游戏中的格挡值永久增加3点。消耗。");
        var deathMarch = CardTextSemanticCompiler.Compile(
            "造成8点伤害。你在回合进行中每抽到一张牌，都会使其额外造成4点伤害。");
        var scythe = CardTextSemanticCompiler.Compile(
            "造成13点伤害。这张牌在本局游戏中的伤害永久性增加4。消耗。");

        Assert.Contains(drawGrowth.Operations, operation =>
            operation.Kind == CardSemanticKind.ModifyCardDamage && operation.Id == "SELF" &&
            operation.Trigger == "SELF_DRAWN" && operation.Amount == 4 && operation.Duration == "combat");
        Assert.Contains(modelGrowth.Operations, operation =>
            operation.Kind == CardSemanticKind.ModifyCardDamage && operation.Id == "MODEL_ALL" &&
            operation.Amount == 1 && operation.Duration == "combat");
        Assert.Contains(cascade.Operations, operation =>
            operation.Kind == CardSemanticKind.AutoPlayCard && operation.Id == "TOP" &&
            operation.Target == SemanticTarget.DrawPile && operation.RepeatByEnergySpent && operation.XBonus == 1);
        Assert.Contains(uproar.Operations, operation =>
            operation.Kind == CardSemanticKind.AutoPlayCard && operation.Id == "RANDOM_ATTACK" &&
            operation.RandomSource == RngSnapshotSet.Shuffle);
        Assert.Contains(howl.Operations, operation =>
            operation.Kind == CardSemanticKind.AutoPlayCard && operation.Id == "SELF" &&
            operation.Timing == "turn_end" && operation.Condition == "SELF_IN_EXHAUST" &&
            operation.Target == SemanticTarget.ExhaustPile);
        Assert.Contains(stampede.Operations, operation =>
            operation.Kind == CardSemanticKind.AutoPlayCard && operation.Id == "RANDOM_HAND_ATTACK" &&
            operation.Target == SemanticTarget.Hand && operation.Timing == "turn_end" &&
            operation.RandomSource == RngSnapshotSet.Shuffle);
        Assert.Contains(bladeOfInk.Operations, operation =>
            operation.Kind == CardSemanticKind.GenerateCard && operation.Id == "INKY_SHIV" &&
            operation.Target == SemanticTarget.Hand && operation.Amount == 2);
        Assert.Contains(stoke.Operations, operation =>
            operation.Kind == CardSemanticKind.GenerateCard && operation.Id == "随机牌" &&
            operation.RepeatByExhaustedCount && operation.RandomSource == RngSnapshotSet.CombatCardGeneration);
        Assert.Contains(hellraiser.Operations, operation =>
            operation.Kind == CardSemanticKind.ApplyStatus && operation.Id == "HELLRAISER" &&
            operation.Timing == "persistent_combat");
        Assert.Contains(knifeTrap.Operations, operation =>
            operation.Kind == CardSemanticKind.AutoPlayCard && operation.Id == "ALL_SHIV" &&
            operation.Target == SemanticTarget.ExhaustPile);
        Assert.Contains(upgradedKnifeTrap.Operations, operation =>
            operation.Kind == CardSemanticKind.AutoPlayCard && operation.Id == "ALL_SHIV_UPGRADE" &&
            operation.Target == SemanticTarget.ExhaustPile);
        Assert.Contains(genetic.Operations, operation =>
            operation.Kind == CardSemanticKind.ModifyCardBlock && operation.Id == "SELF" &&
            operation.Amount == 3 && operation.Duration == "combat");
        Assert.Contains(deathMarch.Operations, operation =>
            operation.Kind == CardSemanticKind.Damage && operation.Amount == 8 &&
            operation.AmountByCardsDrawnThisTurn && operation.XBonus == 4);
        Assert.Contains(scythe.Operations, operation =>
            operation.Kind == CardSemanticKind.ModifyCardDamage && operation.Id == "SELF" &&
            operation.Amount == 4 && operation.Duration == "combat");
    }

    [Fact]
    public void TheScytheGrowsItsPlayedInstanceAfterResolvingDamage()
    {
        var scythe = Attack("scythe", "THE_SCYTHE", 13, destination: CardDestination.Exhaust,
            extraEffects: [new EffectSpec(EffectKind.ModifyPlayedCardDamage, 4, "SELF")]);
        var simulator = new DeterministicSimulator();
        var first = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([scythe], energy: 1)),
            scythe,
            "enemy-0",
            null);

        Assert.Equal(87m, first.Enemies[0].Hp);
        var grown = Assert.Single(first.ExhaustPile);
        Assert.Equal(4m, grown.CombatDamageBonus);

        var second = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([grown], energy: 1)),
            grown,
            "enemy-0",
            null);
        Assert.Equal(83m, second.Enemies[0].Hp);
        Assert.Equal(8m, Assert.Single(second.ExhaustPile).CombatDamageBonus);
    }

    [Fact]
    public void DeathMarchUsesOnlyNonOpeningDrawsThisTurnForItsDamage()
    {
        var draw = Skill("draw", "DRAW", [new EffectSpec(EffectKind.Draw, 1)]);
        var deathMarch = Attack("march", "DEATH_MARCH", 8) with
        {
            Effects = [new EffectSpec(
                EffectKind.Damage,
                8,
                TargetOverride: TargetKind.Enemy,
                AmountByCardsDrawnThisTurn: true,
                XBonus: 4)]
        };
        var filler = Skill("filler", "FILLER", []);
        var simulator = new DeterministicSimulator();
        var afterDraw = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(
                [draw, deathMarch],
                drawPile: [filler],
                energy: 2)),
            draw,
            null,
            null);

        Assert.Equal(1, afterDraw.CardsDrawnThisTurn);
        var result = simulator.PlayCard(
            afterDraw,
            afterDraw.Hand.Single(card => card.InstanceId == "march"),
            "enemy-0",
            null);
        Assert.Equal(88m, result.Enemies[0].Hp);
    }

    [Fact]
    public void GeneticAlgorithmGainsCurrentBlockAndGrowsItsPlayedInstance()
    {
        var genetic = Skill("genetic", "GENETIC_ALGORITHM", [
            new EffectSpec(EffectKind.Block, 1),
            new EffectSpec(EffectKind.ModifyPlayedCardBlock, 3, "SELF")]) with
        { Destination = CardDestination.Exhaust };
        var simulator = new DeterministicSimulator();
        var first = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([genetic], energy: 1)),
            genetic,
            null,
            null);

        Assert.Equal(1m, first.Player.Block);
        var grown = Assert.Single(first.ExhaustPile);
        Assert.Equal(3m, grown.CombatBlockBonus);

        var second = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([grown], energy: 1)),
            grown,
            null,
            null);
        Assert.Equal(4m, second.Player.Block);
        Assert.Equal(6m, Assert.Single(second.ExhaustPile).CombatBlockBonus);
        Assert.NotEqual(
            MutableCombatState.FromSnapshot(Snapshot([grown])).ExactKey(),
            MutableCombatState.FromSnapshot(Snapshot([grown with { CombatBlockBonus = 6 }])).ExactKey());
    }

    [Fact]
    public void KnifeTrapAutoplaysAllExhaustedShivsAtTheChosenTarget()
    {
        var trap = Skill("trap", "KNIFE_TRAP", [new EffectSpec(
            EffectKind.AutoPlayShivsFromExhaust,
            1,
            "ALL_SHIV",
            TargetOverride: TargetKind.Enemy)]);
        var shivA = Attack("shiv-a", "SHIV", 4, destination: CardDestination.Exhaust);
        var shivB = Attack("shiv-b", "SHIV", 4, destination: CardDestination.Exhaust);
        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(
                [trap],
                exhaustPile: [shivA, shivB],
                energy: 1,
                enemyCount: 2)),
            trap,
            "enemy-1",
            null);

        Assert.Equal(92m, result.Enemies.Single(enemy => enemy.Id == "enemy-1").Hp);
        Assert.Equal(100m, result.Enemies.Single(enemy => enemy.Id == "enemy-0").Hp);
        Assert.Equal(2, result.ExhaustPile.Count(card => card.InstanceId is "shiv-a" or "shiv-b"));
    }

    [Fact]
    public void UpgradedKnifeTrapUpgradesEachShivBeforePlayingIt()
    {
        var trap = Skill("trap", "KNIFE_TRAP_UPGRADE", [new EffectSpec(
            EffectKind.AutoPlayShivsFromExhaust,
            1,
            "ALL_SHIV_UPGRADE",
            TargetOverride: TargetKind.Enemy)]);
        var shiv = Attack("shiv", "SHIV", 4, destination: CardDestination.Exhaust);
        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([trap], exhaustPile: [shiv], energy: 1)),
            trap,
            "enemy-0",
            null);

        Assert.Equal(94m, result.Enemies[0].Hp);
        Assert.Equal("SHIV_UPGRADE", Assert.Single(result.ExhaustPile).ModelId);
    }

    [Fact]
    public void HellraiserAutoplaysARecentlyDrawnStrikeWithCombatTargetRng()
    {
        var draw = Skill("draw", "DRAW", [new EffectSpec(EffectKind.Draw, 1)]);
        var strike = Attack("strike", "STRIKE", 6);
        var statuses = EmptyStatuses.Add("HELLRAISER", new StatusState("HELLRAISER", 1));
        var streams = KnownRng();
        var beforeTargets = streams.Get(RngSnapshotSet.CombatTargets);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(
                [draw],
                drawPile: [strike],
                playerStatuses: statuses,
                energy: 0,
                rngStreams: streams,
                enemyCount: 2)),
            draw,
            null,
            null);

        Assert.Equal(94m, result.Enemies.Min(static enemy => enemy.Hp));
        Assert.Equal(100m, result.Enemies.Max(static enemy => enemy.Hp));
        Assert.NotEqual(beforeTargets, result.RngStreams.Get(RngSnapshotSet.CombatTargets));
        Assert.Equal(1, result.Player.Statuses["HELLRAISER_AUTOPLAYS_THIS_TURN"].Amount);
    }

    [Fact]
    public void StokeGeneratesOneDistinctCardPerExhaustedHandCard()
    {
        var generatedAttack = Attack("generated-attack", "GENERATED_ATTACK", 4);
        var generatedSkill = Skill("generated-skill", "GENERATED_SKILL", [new EffectSpec(EffectKind.Block, 3)]);
        var stoke = Skill("stoke", "STOKE", [
            new EffectSpec(EffectKind.ExhaustHand),
            new EffectSpec(
                EffectKind.GenerateRandomCards,
                1,
                GeneratedCardPool: [generatedAttack, generatedSkill],
                RandomSource: RngSnapshotSet.CombatCardGeneration,
                RepeatByExhaustedCount: true)]);
        var fillerA = Skill("filler-a", "FILLER_A", []);
        var fillerB = Attack("filler-b", "FILLER_B", 1);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(
                [stoke, fillerA, fillerB],
                energy: 0,
                rngStreams: KnownRngWithCardGeneration())),
            stoke,
            null,
            null);

        Assert.Equal(2, result.ExhaustPile.Count(card => card.InstanceId is "filler-a" or "filler-b"));
        Assert.Equal(2, result.Hand.Count(card => card.ModelId is "GENERATED_ATTACK" or "GENERATED_SKILL"));
        Assert.Equal(2, result.CardsExhaustedSinceSnapshot);
    }

    [Fact]
    public void InkyShivUsesShivBonusesAndAppliesWeakToItsTargets()
    {
        var inkyShiv = Attack(
            "inky", "INKY_SHIV", 4,
            extraEffects: [new EffectSpec(
                EffectKind.ApplyStatus,
                1,
                "WEAK",
                Duration: 1,
                IsDebuff: true)]);
        var statuses = EmptyStatuses
            .Add("SHIV_DAMAGE_BONUS", new StatusState("SHIV_DAMAGE_BONUS", 3))
            .Add("SHIV_ALL_ENEMIES", new StatusState("SHIV_ALL_ENEMIES", 1));

        var state = MutableCombatState.FromSnapshot(Snapshot(
            [inkyShiv],
            playerStatuses: statuses,
            enemyCount: 2));
        state.Hand[0] = state.Hand[0] with { Target = TargetKind.AllEnemies };
        var result = new DeterministicSimulator().PlayCard(state, state.Hand[0], null, null);

        Assert.All(result.Enemies, enemy =>
        {
            Assert.Equal(93m, enemy.Hp);
            Assert.Equal(1, enemy.Statuses["WEAK"].Amount);
        });
    }

    [Fact]
    public void StampedeAutoplaysOneRandomNonEtherealHandAttackAtTurnEnd()
    {
        var attackA = Attack("attack-a", "ATTACK_A", 4);
        var attackB = Attack("attack-b", "ATTACK_B", 7);
        var ethereal = Attack("ethereal", "ETHEREAL", 99) with { ExhaustAtTurnEnd = true };
        var streams = KnownRng();
        var beforeShuffle = streams.Get(RngSnapshotSet.Shuffle);

        var result = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(Snapshot(
                [attackA, attackB, ethereal],
                energy: 0,
                playerStatuses: EmptyStatuses.Add("TURN_END_RANDOM_HAND_ATTACK", new StatusState(
                    "TURN_END_RANDOM_HAND_ATTACK", 1, RandomSource: RngSnapshotSet.Shuffle)),
                rngStreams: streams)));

        Assert.Equal(2, result.DiscardPile.Count(card => card.InstanceId is "attack-a" or "attack-b"));
        Assert.Contains(result.ExhaustPile, card => card.InstanceId == "ethereal");
        Assert.InRange(result.Enemies[0].Hp, 93m, 96m);
        Assert.NotEqual(beforeShuffle, result.RngStreams.Get(RngSnapshotSet.Shuffle));
    }

    [Fact]
    public void StampedeUnknownShuffleIsExplicitlyUncalculable()
    {
        var attack = Attack("attack", "ATTACK", 6);

        var result = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(Snapshot(
                [attack],
                energy: 0,
                playerStatuses: EmptyStatuses.Add("TURN_END_RANDOM_HAND_ATTACK", new StatusState(
                    "TURN_END_RANDOM_HAND_ATTACK", 1, RandomSource: RngSnapshotSet.Shuffle)),
                rngStreams: RngSnapshotSet.Empty)));

        Assert.Equal(PredictionConfidence.Uncalculable, result.Confidence);
        Assert.Contains(result.Restrictions, reason => reason.Code == "uncalculable_autoplay_selection");
        Assert.Equal(100m, result.Enemies[0].Hp);
    }

    [Fact]
    public void RampageGrowsOnlyItsPlayedInstanceAndChangesSearchKeys()
    {
        var rampage = Attack(
            "rampage", "RAMPAGE", 10,
            extraEffects: [new EffectSpec(EffectKind.ModifyPlayedCardDamage, 5, "SELF")]);
        var other = Attack("other-rampage", "RAMPAGE", 10);
        var simulator = new DeterministicSimulator();

        var result = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([rampage], drawPile: [other], energy: 1)),
            rampage,
            "enemy-0",
            null);

        var grown = Assert.Single(result.DiscardPile);
        Assert.Equal(5m, grown.CombatDamageBonus);
        Assert.Equal(0m, Assert.Single(result.DrawPile).CombatDamageBonus);
        Assert.Equal(90m, result.Enemies[0].Hp);

        var unchanged = MutableCombatState.FromSnapshot(Snapshot([other]));
        var changed = MutableCombatState.FromSnapshot(Snapshot([other with { CombatDamageBonus = 5 }]));
        Assert.NotEqual(unchanged.ExactKey(), changed.ExactKey());
        Assert.NotEqual(unchanged.CycleKeyWithoutProgress(), changed.CycleKeyWithoutProgress());
    }

    [Fact]
    public void KinglyPunchGrowsWhenActuallyDrawnAndUsesTheNewDamage()
    {
        var draw = Skill("draw", "DRAW", [new EffectSpec(EffectKind.Draw, 1)]);
        var punch = Attack("punch", "KINGLY_PUNCH", 8) with { EnergyCost = 1, DamageChangeOnDraw = 4 };
        var simulator = new DeterministicSimulator();
        var afterDraw = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([draw], drawPile: [punch], energy: 2)),
            draw,
            null,
            null);

        var grown = Assert.Single(afterDraw.Hand);
        Assert.Equal(4m, grown.CombatDamageBonus);

        var afterPunch = simulator.PlayCard(afterDraw, grown, "enemy-0", null);
        Assert.Equal(88m, afterPunch.Enemies[0].Hp);
    }

    [Fact]
    public void ClawGrowthUpdatesMatchingInstancesAcrossEveryPile()
    {
        var claw = Attack(
            "claw-hand", "CLAW", 3,
            extraEffects: [new EffectSpec(EffectKind.ModifyPlayedCardDamage, 2, "MODEL_ALL", SourceId: "CLAW")]);
        var draw = Attack("claw-draw", "CLAW", 3);
        var discard = Attack("claw-discard", "CLAW", 3);
        var exhaust = Attack("claw-exhaust", "CLAW", 3);
        var unrelated = Attack("strike", "STRIKE", 6);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(
                [claw],
                drawPile: [draw, unrelated],
                discardPile: [discard],
                exhaustPile: [exhaust],
                energy: 0)),
            claw,
            "enemy-0",
            null);

        Assert.Equal(2m, Assert.Single(result.DiscardPile, card => card.InstanceId == "claw-hand").CombatDamageBonus);
        Assert.Equal(2m, Assert.Single(result.DrawPile, card => card.InstanceId == "claw-draw").CombatDamageBonus);
        Assert.Equal(2m, Assert.Single(result.DiscardPile, card => card.InstanceId == "claw-discard").CombatDamageBonus);
        Assert.Equal(2m, Assert.Single(result.ExhaustPile, card => card.InstanceId == "claw-exhaust").CombatDamageBonus);
        Assert.Equal(0m, Assert.Single(result.DrawPile, card => card.InstanceId == "strike").CombatDamageBonus);
    }

    [Fact]
    public void MaulCombatBonusAppliesToEveryHitBeforeGrowingAgain()
    {
        var maul = Attack(
            "maul", "MAUL", 5,
            repeat: 2,
            extraEffects: [new EffectSpec(EffectKind.ModifyPlayedCardDamage, 1, "MODEL_ALL", SourceId: "MAUL")]) with
        {
            CombatDamageBonus = 2
        };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([maul], energy: 0)),
            maul,
            "enemy-0",
            null);

        Assert.Equal(86m, result.Enemies[0].Hp);
        Assert.Equal(3m, Assert.Single(result.DiscardPile).CombatDamageBonus);
    }

    [Fact]
    public void HavocForcesExhaustAndNestedCardsUseTheirOwnEnergyValueWithoutSpendingIt()
    {
        var havoc = Skill(
            "havoc", "HAVOC",
            [new EffectSpec(EffectKind.AutoPlayFromDrawPile, 1, "TOP_FORCE_EXHAUST")]) with { EnergyCost = 1 };
        var nested = Attack("nested", "NESTED", 3, repeatByEnergy: true) with { EnergyCost = 2 };
        var statuses = EmptyStatuses.Add("TRIGGER_CARD_PLAYED_BLOCK", new StatusState("TRIGGER_CARD_PLAYED_BLOCK", 1));
        var streams = KnownRng();
        var beforeTargets = streams.Get(RngSnapshotSet.CombatTargets);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(
                [havoc],
                drawPile: [nested],
                playerStatuses: statuses,
                energy: 1,
                rngStreams: streams)),
            havoc,
            null,
            null);

        Assert.Equal(94m, result.Enemies[0].Hp);
        Assert.Equal(0, result.Player.Energy);
        Assert.Contains(result.ExhaustPile, card => card.InstanceId == "nested");
        Assert.Contains(result.DiscardPile, card => card.InstanceId == "havoc");
        Assert.Equal(2m, result.Player.Block);
        Assert.NotEqual(beforeTargets, result.RngStreams.Get(RngSnapshotSet.CombatTargets));
    }

    [Fact]
    public void CascadeUsesXCountAndAutoplayDoesNotConsumeNestedCardEnergy()
    {
        var cascade = Skill(
            "cascade", "CASCADE",
            [new EffectSpec(EffectKind.AutoPlayFromDrawPile, 1, "TOP", RepeatByEnergySpent: true, XBonus: 1)]) with
        {
            CostsX = true
        };
        var first = Attack("first", "FIRST", 4) with { EnergyCost = 3 };
        var second = Attack("second", "SECOND", 5) with { EnergyCost = 2 };
        var third = Skill("third", "THIRD", [new EffectSpec(EffectKind.Block, 2)]) with { EnergyCost = 1 };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(
                [cascade],
                drawPile: [first, second, third],
                energy: 2,
                rngStreams: KnownRng())),
            cascade,
            null,
            null);

        Assert.Equal(91m, result.Enemies[0].Hp);
        Assert.Equal(2m, result.Player.Block);
        Assert.Equal(0, result.Player.Energy);
        Assert.Empty(result.DrawPile);
        Assert.Equal(4, result.DiscardPile.Count);
    }

    [Fact]
    public void TurnBoundaryAutoplayTriggersOnlyFromTheVerifiedPileAndTiming()
    {
        var howl = Attack(
            "howl", "HOWL_FROM_BEYOND", 8,
            target: TargetKind.AllEnemies,
            extraEffects: [new EffectSpec(EffectKind.AutoPlaySelfFromPile, 1, "TURN_END_SELF_IN_EXHAUST")]);
        var invincible = Skill(
            "invincible", "I_AM_INVINCIBLE",
            [
                new EffectSpec(EffectKind.Block, 10),
                new EffectSpec(EffectKind.AutoPlaySelfFromPile, 1, "TURN_END_SELF_DRAW_TOP")
            ]);
        var bombardment = Attack(
            "bombardment", "BOMBARDMENT", 9,
            destination: CardDestination.Exhaust,
            extraEffects: [new EffectSpec(EffectKind.AutoPlaySelfFromPile, 1, "TURN_START_SELF_IN_EXHAUST")]);
        var simulator = new DeterministicSimulator();

        var howlResult = simulator.ProjectToNextPlayerTurn(MutableCombatState.FromSnapshot(Snapshot(
            [],
            exhaustPile: [howl],
            rngStreams: KnownRng())));
        Assert.Equal(92m, howlResult.Enemies[0].Hp);
        Assert.Contains(howlResult.DiscardPile, card => card.InstanceId == "howl");

        var invincibleResult = simulator.ProjectToNextPlayerTurn(MutableCombatState.FromSnapshot(Snapshot(
            [],
            drawPile: [invincible],
            enemyIntents: [new IntentState("Attack", 7, 1)],
            rngStreams: KnownRng())));
        Assert.Equal(30m, invincibleResult.Player.Hp);
        Assert.Contains(invincibleResult.DiscardPile, card => card.InstanceId == "invincible");

        var notTop = Skill("not-top", "NOT_TOP", []);
        var notTopResult = simulator.ProjectToNextPlayerTurn(MutableCombatState.FromSnapshot(Snapshot(
            [],
            drawPile: [notTop, invincible],
            enemyIntents: [new IntentState("Attack", 7, 1)],
            rngStreams: KnownRng())));
        Assert.Equal(23m, notTopResult.Player.Hp);
        Assert.Contains(notTopResult.DrawPile, card => card.InstanceId == "invincible");

        var bombardmentResult = simulator.ProjectToNextPlayerTurn(MutableCombatState.FromSnapshot(Snapshot(
            [],
            exhaustPile: [bombardment],
            rngStreams: KnownRng())));
        Assert.Equal(91m, bombardmentResult.Enemies[0].Hp);
        Assert.Contains(bombardmentResult.ExhaustPile, card => card.InstanceId == "bombardment");
    }

    [Fact]
    public void MayhemAutoplaysTheDrawTopAtTurnStart()
    {
        var statuses = EmptyStatuses.Add(
            "TURN_START_AUTOPLAY_TOP",
            new StatusState("TURN_START_AUTOPLAY_TOP", 1));
        var top = Attack("top", "TOP", 6);

        var result = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(Snapshot(
                [],
                drawPile: [top],
                playerStatuses: statuses,
                rngStreams: KnownRng())));

        Assert.Equal(94m, result.Enemies[0].Hp);
        Assert.Empty(result.DrawPile);
        Assert.Contains(result.DiscardPile, card => card.InstanceId == "top");
    }

    [Fact]
    public void UproarUsesShuffleForAttackSelectionAndCombatTargetsForItsTarget()
    {
        var uproar = Skill(
            "uproar", "UPROAR",
            [new EffectSpec(
                EffectKind.AutoPlayFromDrawPile,
                1,
                "RANDOM_ATTACK",
                RandomSource: RngSnapshotSet.Shuffle)]);
        var attackA = Attack("attack-a", "ATTACK_A", 4);
        var skill = Skill("skill", "SKILL", [new EffectSpec(EffectKind.Block, 99)]);
        var attackB = Attack("attack-b", "ATTACK_B", 7);
        var streams = KnownRng();
        var beforeShuffle = streams.Get(RngSnapshotSet.Shuffle);
        var beforeTargets = streams.Get(RngSnapshotSet.CombatTargets);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(
                [uproar],
                drawPile: [attackA, skill, attackB],
                energy: 0,
                rngStreams: streams,
                enemyCount: 2)),
            uproar,
            null,
            null);

        Assert.Contains(result.DrawPile, card => card.InstanceId == "skill");
        Assert.Equal(2, result.DrawPile.Count);
        Assert.Equal(1, result.DiscardPile.Count(card => card.InstanceId is "attack-a" or "attack-b"));
        Assert.Equal(200m - result.Enemies.Sum(static enemy => enemy.Hp), result.DamageDealt);
        Assert.InRange(result.DamageDealt, 4m, 7m);
        Assert.NotEqual(beforeShuffle, result.RngStreams.Get(RngSnapshotSet.Shuffle));
        Assert.NotEqual(beforeTargets, result.RngStreams.Get(RngSnapshotSet.CombatTargets));
    }

    [Fact]
    public void CatastropheSelectsDistinctCardsSequentially()
    {
        var catastrophe = Skill(
            "catastrophe", "CATASTROPHE",
            [new EffectSpec(
                EffectKind.AutoPlayFromDrawPile,
                2,
                "RANDOM_ANY",
                RandomSource: RngSnapshotSet.Shuffle)]);
        var first = Skill("first", "FIRST", [new EffectSpec(EffectKind.Block, 1)]);
        var second = Skill("second", "SECOND", [new EffectSpec(EffectKind.Block, 2)]);
        var third = Skill("third", "THIRD", [new EffectSpec(EffectKind.Block, 4)]);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(
                [catastrophe],
                drawPile: [first, second, third],
                energy: 0,
                rngStreams: KnownRng())),
            catastrophe,
            null,
            null);

        Assert.Single(result.DrawPile);
        Assert.Equal(3, result.DiscardPile.Count);
        Assert.Equal(2, result.DiscardPile.Select(static card => card.InstanceId)
            .Count(static id => id is "first" or "second" or "third"));
        Assert.InRange(result.Player.Block, 3m, 6m);
    }

    [Fact]
    public void UnknownAutoplaySelectionIsExplicitlyUncalculableAndDoesNotGuess()
    {
        var uproar = Skill(
            "uproar", "UPROAR",
            [new EffectSpec(
                EffectKind.AutoPlayFromDrawPile,
                1,
                "RANDOM_ATTACK",
                RandomSource: RngSnapshotSet.Shuffle)]);
        var attackA = Attack("attack-a", "ATTACK_A", 4);
        var attackB = Attack("attack-b", "ATTACK_B", 7);

        var simulator = new DeterministicSimulator();
        var outcome = Assert.Single(simulator.PlayCardOutcomes(
            MutableCombatState.FromSnapshot(Snapshot(
                [uproar],
                drawPile: [attackA, attackB],
                energy: 0,
                rngStreams: RngSnapshotSet.Empty)),
            uproar,
            null,
            null));
        var result = outcome.State;

        Assert.Equal(PredictionConfidence.Uncalculable, result.Confidence);
        Assert.Contains(result.Restrictions, reason => reason.Code == "uncalculable_autoplay_selection");
        Assert.Equal(new[] { "attack-a", "attack-b" }, result.DrawPile.Select(static card => card.InstanceId));
        Assert.Equal(100m, result.Enemies[0].Hp);

        var havoc = Skill(
            "havoc", "HAVOC",
            [new EffectSpec(EffectKind.AutoPlayFromDrawPile, 1, "TOP")]);
        var unknownTarget = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(
                [havoc],
                drawPile: [attackA],
                energy: 0,
                rngStreams: RngSnapshotSet.Empty,
                enemyCount: 2)),
            havoc,
            null,
            null);

        Assert.Equal(PredictionConfidence.Uncalculable, unknownTarget.Confidence);
        Assert.Contains(unknownTarget.Restrictions, reason => reason.Code == "uncalculable_autoplay_target");
        Assert.All(unknownTarget.Enemies, enemy => Assert.Equal(100m, enemy.Hp));
    }

    [Fact]
    public void CompilerPreservesTheNewAutoplayCostThresholdAndChokingSemantics()
    {
        var eidolon = CardTextSemanticCompiler.Compile("打出你消耗牌堆中的所有虚无牌。消耗。");
        var momentum = CardTextSemanticCompiler.Compile("造成11点伤害。这张牌的耗能降为0能量。");
        var drill = CardTextSemanticCompiler.Compile(
            "造成8点伤害X次。如果X的最终数值为4或以上，则将X的数值翻倍。");
        var choking = CardTextSemanticCompiler.Compile(
            "造成12点伤害。本回合，你每打出一张牌，该敌人失去6点生命。");

        Assert.Contains(eidolon.Operations, operation =>
            operation.Kind == CardSemanticKind.AutoPlayCard && operation.Target == SemanticTarget.ExhaustPile &&
            operation.Id == "ALL_ETHEREAL");
        Assert.Contains(momentum.Operations, operation =>
            operation.Kind == CardSemanticKind.ModifyCost && operation.Id == "SELF_SET_ZERO");
        Assert.Contains(drill.Operations, operation =>
            operation.Kind == CardSemanticKind.Damage && operation.RepeatByEnergySpent &&
            operation.Condition == "ENERGY_SPENT_AT_LEAST:4");
        Assert.Contains(choking.Operations, operation =>
            operation.Kind == CardSemanticKind.LoseEnemyHp && operation.Trigger == "CARD_PLAYED" &&
            operation.Target == SemanticTarget.SelectedEnemy && operation.Amount == 6);

        var curious = CardTextSemanticCompiler.Compile("能力牌的耗能减少1能量。");
        Assert.True(curious.IsFullyStructured);
        Assert.Contains(curious.Operations, operation => operation.Id == "POWERS_COST_DELTA" && operation.Amount == 1);
    }

    [Fact]
    public void EidolonAutoplaysOnlyEtherealCardsAlreadyInTheExhaustPile()
    {
        var eidolon = Skill(
            "eidolon", "EIDOLON",
            [new EffectSpec(EffectKind.AutoPlayEtherealFromExhaust, 1, "ALL_ETHEREAL")]) with
        {
            EnergyCost = 2,
            Destination = CardDestination.Exhaust
        };
        var ethereal = Attack("ethereal", "ETHEREAL_ATTACK", 7) with { ExhaustAtTurnEnd = true };
        var ordinary = Attack("ordinary", "ORDINARY_ATTACK", 20);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(
                [eidolon],
                exhaustPile: [ethereal, ordinary],
                energy: 2,
                rngStreams: KnownRng())),
            eidolon,
            null,
            null);

        Assert.Equal(93m, result.Enemies[0].Hp);
        Assert.Equal(0, result.Player.Energy);
        Assert.Contains(result.DiscardPile, card => card.InstanceId == "ethereal");
        Assert.Contains(result.ExhaustPile, card => card.InstanceId == "ordinary");
        Assert.Contains(result.ExhaustPile, card => card.InstanceId == "eidolon");
        Assert.DoesNotContain(result.ExhaustPile, card => card.InstanceId == "ethereal");
    }

    [Fact]
    public void MomentumStrikePaysItsCurrentCostThenSetsThatInstanceToZero()
    {
        var momentum = Attack(
            "momentum", "MOMENTUM_STRIKE", 11,
            extraEffects: [new EffectSpec(EffectKind.ModifyPlayedCardCost, 0, "SELF_SET_ZERO")]) with
        {
            EnergyCost = 1
        };

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([momentum], energy: 1)),
            momentum,
            "enemy-0",
            null);

        Assert.Equal(89m, result.Enemies[0].Hp);
        Assert.Equal(0, result.Player.Energy);
        Assert.Equal(0, Assert.Single(result.DiscardPile).EnergyCost);
    }

    [Fact]
    public void HeavenlyDrillDoublesXOnlyAtFourOrMoreEnergy()
    {
        var drill = Attack(
            "drill", "HEAVENLY_DRILL", 8,
            repeatByEnergy: true) with
        {
            CostsX = true,
            Effects = [new EffectSpec(
                EffectKind.Damage,
                8,
                Condition: "ENERGY_SPENT_AT_LEAST:4",
                RepeatByEnergySpent: true)]
        };
        var simulator = new DeterministicSimulator();

        var atThree = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([drill], energy: 3)),
            drill,
            "enemy-0",
            null);
        var atFour = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([drill], energy: 4)),
            drill,
            "enemy-0",
            null);

        Assert.Equal(76m, atThree.Enemies[0].Hp);
        Assert.Equal(36m, atFour.Enemies[0].Hp);
        Assert.Equal(0, atThree.Player.Energy);
        Assert.Equal(0, atFour.Player.Energy);
    }

    [Fact]
    public void ChokingDoesNotTriggerItselfAndLaterCardsCauseDirectHpLoss()
    {
        var choking = Attack(
            "choking", "MAD_SCIENCE-CHOKING", 12,
            extraEffects: [new EffectSpec(
                EffectKind.ApplyStatus,
                6,
                "TRIGGER_CARD_PLAYED_HP_LOSS",
                Duration: 1,
                IsDebuff: true,
                TargetOverride: TargetKind.Enemy)]);
        var followUp = Skill("follow-up", "FOLLOW_UP", []);
        var simulator = new DeterministicSimulator();

        var afterChoking = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([choking, followUp], energy: 0)),
            choking,
            "enemy-0",
            null);
        var afterFollowUp = simulator.PlayCard(afterChoking, followUp, null, null);

        Assert.Equal(88m, afterChoking.Enemies[0].Hp);
        Assert.Equal(82m, afterFollowUp.Enemies[0].Hp);
        Assert.Equal(0m, afterFollowUp.Enemies[0].Block);
    }

    [Fact]
    public void CompilerMarksRandomGeneratedCardsAsFreeInstances()
    {
        var infernal = CardTextSemanticCompiler.Compile(
            "将一张随机攻击牌加入你的手牌。那张牌在本回合内可以免费打出。消耗。");
        var chaos = CardTextSemanticCompiler.Compile(
            "获得8点格挡。将一张随机牌放入你的手牌，这张牌在本回合可以免费打出。");

        Assert.Contains(infernal.Operations, operation =>
            operation.Kind == CardSemanticKind.GenerateCard && operation.Id == "随机攻击牌");
        Assert.Contains(infernal.Operations, operation =>
            operation.Kind == CardSemanticKind.Keyword && operation.Id == "GENERATED_CARD_FREE_THIS_TURN");
        Assert.Contains(chaos.Operations, operation =>
            operation.Kind == CardSemanticKind.GenerateCard && operation.Id == "随机牌");
        Assert.Contains(chaos.Operations, operation =>
            operation.Kind == CardSemanticKind.Keyword && operation.Id == "GENERATED_CARD_FREE_THIS_TURN");
    }

    [Fact]
    public void RandomGeneratedCardsUseTheCapturedGenerationStreamAndBecomeFree()
    {
        var generator = Skill(
            "generator", "INFERNAL_BLADE",
            [new EffectSpec(
                EffectKind.GenerateRandomCards,
                2,
                "FREE_THIS_TURN",
                GeneratedCardPool: [
                    Attack("generated-a", "GENERATED_A", 4) with { EnergyCost = 2 },
                    Attack("generated-x", "GENERATED_X", 5, repeatByEnergy: true) with { EnergyCost = 0, CostsX = true }
                ],
                RandomSource: RngSnapshotSet.CombatCardGeneration)]);
        var streams = KnownRngWithCardGeneration();
        var before = streams.Get(RngSnapshotSet.CombatCardGeneration);
        var simulator = new DeterministicSimulator();

        var generated = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([generator], energy: 0, rngStreams: streams)),
            generator,
            null,
            null);

        Assert.Equal(2, generated.Hand.Count);
        Assert.All(generated.Hand, card =>
        {
            Assert.Equal(0, card.EnergyCost);
            Assert.False(card.CostsX);
        });
        Assert.NotEqual(before, generated.RngStreams.Get(RngSnapshotSet.CombatCardGeneration));
        Assert.Equal(new[] { "GENERATED_A", "GENERATED_X" }, generated.Hand.Select(card => card.ModelId).Order());

        var afterPlayingGeneratedX = simulator.PlayCard(
            generated,
            generated.Hand.Single(card => card.ModelId == "GENERATED_X"),
            "enemy-0",
            null);
        Assert.Equal(100m, afterPlayingGeneratedX.Enemies[0].Hp);
        Assert.Equal(0, afterPlayingGeneratedX.Player.Energy);
        Assert.Equal(0, afterPlayingGeneratedX.DiscardPile.Single(card => card.ModelId == "GENERATED_X").EnergyCost);
        Assert.True(afterPlayingGeneratedX.DiscardPile.Single(card => card.ModelId == "GENERATED_X").CostsX);
        Assert.Null(afterPlayingGeneratedX.DiscardPile.Single(card => card.ModelId == "GENERATED_X").TemporaryEnergyCostBeforeCap);

        var unknown = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([generator], energy: 0, rngStreams: RngSnapshotSet.Empty)),
            generator,
            null,
            null);
        Assert.Empty(unknown.Hand);
        Assert.Equal(PredictionConfidence.Uncalculable, unknown.Confidence);
        Assert.Contains(unknown.Restrictions, reason => reason.Code == "uncalculable_random_card_generation");
    }

    [Fact]
    public void UnknownRandomGeneratedCardsExpandAsExactBeliefBranches()
    {
        var generator = Skill(
            "generator-belief", "INFERNAL_BLADE",
            [new EffectSpec(
                EffectKind.GenerateRandomCards,
                1,
                GeneratedCardPool: [
                    Attack("generated-a-belief", "GENERATED_A", 4),
                    Attack("generated-x-belief", "GENERATED_X", 5)],
                RandomSource: RngSnapshotSet.CombatCardGeneration)]);
        var snapshot = Snapshot([generator], energy: 0, rngStreams: RngSnapshotSet.Empty) with { RngState = 0 };
        var outcomes = new DeterministicSimulator().PlayCardOutcomes(
            MutableCombatState.FromSnapshot(snapshot), generator, null, null,
            maximumExactBranches: 8,
            sampleCount: 2);

        Assert.Equal(2, outcomes.Length);
        Assert.All(outcomes, outcome => Assert.Equal(OutcomeKind.Stochastic, outcome.Kind));
        Assert.All(outcomes, outcome => Assert.Equal(0.5m, outcome.Probability));
        Assert.All(outcomes, outcome => Assert.Equal(PredictionConfidence.Reliable, outcome.State.Confidence));
        Assert.Contains(outcomes, outcome => outcome.State.Hand.Any(card => card.ModelId == "GENERATED_A"));
        Assert.Contains(outcomes, outcome => outcome.State.Hand.Any(card => card.ModelId == "GENERATED_X"));
    }

    [Fact]
    public void UnknownRandomGeneratedDuplicatePoolUsesMultiplicityWeights()
    {
        var generator = Skill(
            "generator-belief-duplicates", "INFERNAL_BLADE",
            [new EffectSpec(
                EffectKind.GenerateRandomCards,
                1,
                GeneratedCardPool: [
                    Attack("generated-a1", "GENERATED_A", 4),
                    Attack("generated-a2", "GENERATED_A", 4),
                    Attack("generated-b", "GENERATED_B", 5)],
                RandomSource: RngSnapshotSet.CombatCardGeneration)]);
        var snapshot = Snapshot([generator], energy: 0, rngStreams: RngSnapshotSet.Empty) with { RngState = 0 };
        var outcomes = new DeterministicSimulator().PlayCardOutcomes(
            MutableCombatState.FromSnapshot(snapshot), generator, null, null,
            maximumExactBranches: 8, sampleCount: 2);

        Assert.Equal(2, outcomes.Length);
        Assert.Contains(outcomes, outcome => outcome.State.Hand.Any(card => card.ModelId == "GENERATED_A") && outcome.Probability == 2m / 3m);
        Assert.Contains(outcomes, outcome => outcome.State.Hand.Any(card => card.ModelId == "GENERATED_B") && outcome.Probability == 1m / 3m);
    }

    [Fact]
    public void RandomXAttacksConsumeCombatTargetsInsteadOfBecomingUncalculable()
    {
        var volley = Attack(
            "volley", "VOLLEY", 10,
            repeatByEnergy: true) with
        {
            CostsX = true,
            Effects = [new EffectSpec(
                EffectKind.RandomEnemyDamage,
                10,
                RepeatByEnergySpent: true,
                RandomSource: RngSnapshotSet.CombatTargets)]
        };
        var streams = KnownRng();
        var before = streams.Get(RngSnapshotSet.CombatTargets);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(
                [volley],
                energy: 3,
                rngStreams: streams,
                enemyCount: 2)),
            volley,
            null,
            null);

        Assert.Equal(30m, result.DamageDealt);
        Assert.Equal(0, result.Player.Energy);
        Assert.Equal(PredictionConfidence.Reliable, result.Confidence);
        Assert.NotEqual(before, result.RngStreams.Get(RngSnapshotSet.CombatTargets));
    }

    [Fact]
    public void ThrashExhaustsOneRandomAttackAndGrowsOnlyItsPlayedInstance()
    {
        var thrash = Attack(
            "thrash", "THRASH", 4,
            repeat: 2,
            extraEffects: [new EffectSpec(
                EffectKind.RandomExhaustAttackAndGrow,
                1,
                RandomSource: RngSnapshotSet.CombatCardSelection)]);
        var selected = Attack("selected", "SELECTED_ATTACK", 7);
        var streams = KnownRngWithCardSelection();
        var before = streams.Get(RngSnapshotSet.CombatCardSelection);
        var simulator = new DeterministicSimulator();

        var result = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(
                [thrash, selected],
                energy: 0,
                rngStreams: streams)),
            thrash,
            "enemy-0",
            null);

        Assert.Equal(92m, result.Enemies[0].Hp);
        Assert.Equal(7m, Assert.Single(result.DiscardPile).CombatDamageBonus);
        Assert.Contains(result.ExhaustPile, card => card.InstanceId == "selected");
        Assert.NotEqual(before, result.RngStreams.Get(RngSnapshotSet.CombatCardSelection));

        var unknown = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([thrash, selected], energy: 0, rngStreams: KnownRng())),
            thrash,
            "enemy-0",
            null);
        Assert.Equal(92m, unknown.Enemies[0].Hp);
        Assert.Empty(unknown.ExhaustPile);
        Assert.Equal(PredictionConfidence.Uncalculable, unknown.Confidence);
        Assert.Contains(unknown.Restrictions, reason => reason.Code == "uncalculable_random_attack_exhaust");
    }

    [Fact]
    public void BouncingFlaskAppliesOneRandomPoisonEventPerHit()
    {
        var flask = Skill(
            "flask", "BOUNCING_FLASK",
            [new EffectSpec(
                EffectKind.RandomEnemyStatus,
                3,
                "POISON",
                IsDebuff: true,
                Repeat: 3,
                RandomSource: RngSnapshotSet.CombatTargets)]);
        var streams = KnownRng();
        var before = streams.Get(RngSnapshotSet.CombatTargets);
        var simulator = new DeterministicSimulator();

        var result = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(
                [flask],
                energy: 0,
                rngStreams: streams,
                enemyCount: 2)),
            flask,
            null,
            null);

        Assert.Equal(9, result.Enemies.Sum(enemy => enemy.Statuses.TryGetValue("POISON", out var poison) ? poison.Amount : 0));
        Assert.Equal(PredictionConfidence.Reliable, result.Confidence);
        Assert.NotEqual(before, result.RngStreams.Get(RngSnapshotSet.CombatTargets));

        var artifact = EmptyStatuses.Add("ARTIFACT", new StatusState("ARTIFACT", 1));
        var artifactSnapshot = Snapshot([flask], energy: 0, rngStreams: streams) with
        {
            Enemies = [new CreatureState("enemy-0", "Enemy 0", 100, 100, 0, artifact, [], 0)]
        };
        var afterArtifact = simulator.PlayCard(
            MutableCombatState.FromSnapshot(artifactSnapshot), flask, null, null);
        Assert.Equal(6, afterArtifact.Enemies[0].Statuses["POISON"].Amount);
        Assert.False(afterArtifact.Enemies[0].Statuses.ContainsKey("ARTIFACT"));
    }

    [Fact]
    public void EnlightenmentCapsOnlyExpensiveNonXCardsAndHonorsItsLifetime()
    {
        var currentTurn = Skill(
            "enlightenment", "ENLIGHTENMENT",
            [new EffectSpec(EffectKind.CapHandCosts, 1, "UNTIL_TURN_END")]);
        var expensive = Attack("expensive", "EXPENSIVE", 8) with { EnergyCost = 3, BaseEnergyCost = 3 };
        var free = Attack("free", "FREE", 2) with { EnergyCost = 0, BaseEnergyCost = 0 };
        var xCard = Attack("x-card", "X_CARD", 3, repeatByEnergy: true) with
        {
            EnergyCost = 0,
            CostsX = true
        };
        var simulator = new DeterministicSimulator();

        var capped = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([currentTurn, expensive, free, xCard], energy: 2)),
            currentTurn,
            null,
            null);
        Assert.Equal(1, capped.Hand.Single(card => card.InstanceId == "expensive").EnergyCost);
        Assert.Equal(3, capped.Hand.Single(card => card.InstanceId == "expensive").TemporaryEnergyCostBeforeCap);
        Assert.Equal(0, capped.Hand.Single(card => card.InstanceId == "free").EnergyCost);
        Assert.True(capped.Hand.Single(card => card.InstanceId == "x-card").CostsX);

        var played = simulator.PlayCard(
            capped,
            capped.Hand.Single(card => card.InstanceId == "expensive"),
            "enemy-0",
            null);
        Assert.Equal(1, played.Player.Energy);
        Assert.Equal(3, played.DiscardPile.Single(card => card.InstanceId == "expensive").EnergyCost);
        Assert.Null(played.DiscardPile.Single(card => card.InstanceId == "expensive").TemporaryEnergyCostBeforeCap);

        var retained = expensive with { RetainAtTurnEnd = true };
        var cappedRetained = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([currentTurn, retained], energy: 0)),
            currentTurn,
            null,
            null);
        var nextTurn = simulator.ProjectToNextPlayerTurn(cappedRetained);
        Assert.Equal(3, nextTurn.Hand.Single(card => card.InstanceId == "expensive").EnergyCost);

        var combatLong = Skill(
            "enlightenment-plus", "ENLIGHTENMENT_UPGRADE",
            [new EffectSpec(EffectKind.CapHandCosts, 1)]);
        var persistentCapped = simulator.PlayCard(
            MutableCombatState.FromSnapshot(Snapshot([combatLong, retained], energy: 0)),
            combatLong,
            null,
            null);
        var persistentNextTurn = simulator.ProjectToNextPlayerTurn(persistentCapped);
        Assert.Equal(1, persistentNextTurn.Hand.Single(card => card.InstanceId == "expensive").EnergyCost);
        Assert.Null(persistentNextTurn.Hand.Single(card => card.InstanceId == "expensive").TemporaryEnergyCostBeforeCap);
    }

    [Fact]
    public void MetamorphosisGeneratesWithReplacementAtRandomDrawPositionsForTheCombat()
    {
        var metamorphosis = Skill(
            "metamorphosis", "METAMORPHOSIS",
            [new EffectSpec(
                EffectKind.GenerateRandomCards,
                3,
                "FREE_THIS_COMBAT",
                GeneratedDestination: GeneratedCardDestination.DrawPile,
                GeneratedCardPool: [
                    Attack("pool-a", "POOL_A", 4) with { EnergyCost = 2, BaseEnergyCost = 2 },
                    Attack("pool-b", "POOL_B", 6) with { EnergyCost = 3, BaseEnergyCost = 3 }
                ],
                RandomSource: RngSnapshotSet.CombatCardGeneration,
                RandomizeGeneratedPosition: true,
                RandomSelectionWithReplacement: true)]);
        var existing = Attack("existing", "EXISTING", 1);
        var streams = KnownRngWithCardGeneration();
        var beforeGeneration = streams.Get(RngSnapshotSet.CombatCardGeneration);
        var beforeShuffle = streams.Get(RngSnapshotSet.Shuffle);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(
                [metamorphosis],
                drawPile: [existing],
                energy: 0,
                rngStreams: streams)),
            metamorphosis,
            null,
            null);

        var generated = result.DrawPile.Where(card => card.ModelId is "POOL_A" or "POOL_B").ToArray();
        Assert.Equal(3, generated.Length);
        Assert.Equal(4, result.DrawPile.Count);
        Assert.Contains(generated.GroupBy(card => card.ModelId), group => group.Count() > 1);
        Assert.All(generated, card =>
        {
            Assert.Equal(0, card.EnergyCost);
            Assert.False(card.CostsX);
            Assert.True(card.FreeThisCombat);
        });
        Assert.NotEqual(beforeGeneration, result.RngStreams.Get(RngSnapshotSet.CombatCardGeneration));
        Assert.NotEqual(beforeShuffle, result.RngStreams.Get(RngSnapshotSet.Shuffle));
    }

    [Fact]
    public void AnointedUsesPostPlayHandCapacityAndRandomRareSelection()
    {
        var anointed = Skill(
            "anointed", "ANOINTED",
            [new EffectSpec(
                EffectKind.MoveRandomRareDrawToHand,
                RandomSource: RngSnapshotSet.CombatCardSelection)]);
        var fillers = Enumerable.Range(0, 8)
            .Select(index => Skill($"filler-{index}", $"FILLER_{index}", []))
            .ToArray();
        var rareA = Attack("rare-a", "RARE_A", 4) with { Rarity = "稀有" };
        var rareB = Attack("rare-b", "RARE_B", 5) with { Rarity = "Rare" };
        var rareC = Attack("rare-c", "RARE_C", 6) with { Rarity = "稀有" };
        var common = Attack("common", "COMMON", 7) with { Rarity = "普通" };
        var streams = KnownRngWithCardSelection();
        var before = streams.Get(RngSnapshotSet.CombatCardSelection);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(
                [anointed, .. fillers],
                drawPile: [rareA, common, rareB, rareC],
                energy: 0,
                rngStreams: streams)),
            anointed,
            null,
            null);

        Assert.Equal(10, result.Hand.Count);
        Assert.Equal(2, result.Hand.Count(card => card.Rarity is "稀有" or "Rare"));
        Assert.Contains(result.DrawPile, card => card.InstanceId == "common");
        Assert.Single(result.DrawPile, card => card.Rarity is "稀有" or "Rare");
        Assert.NotEqual(before, result.RngStreams.Get(RngSnapshotSet.CombatCardSelection));

        var unknown = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(Snapshot(
                [anointed, .. fillers],
                drawPile: [rareA, rareB],
                energy: 0,
                rngStreams: KnownRng())),
            anointed,
            null,
            null);
        Assert.Equal(8, unknown.Hand.Count);
        Assert.Equal(2, unknown.DrawPile.Count);
        Assert.Equal(PredictionConfidence.Uncalculable, unknown.Confidence);
        Assert.Contains(unknown.Restrictions, reason => reason.Code == "uncalculable_random_rare_selection");
    }

    private static CardState Attack(
        string instanceId,
        string modelId,
        decimal damage,
        int repeat = 1,
        bool repeatByEnergy = false,
        TargetKind target = TargetKind.Enemy,
        CardDestination destination = CardDestination.Discard,
        IEnumerable<EffectSpec>? extraEffects = null) => new(
        instanceId,
        modelId,
        modelId,
        0,
        target,
        [new EffectSpec(EffectKind.Damage, damage, Repeat: repeat, RepeatByEnergySpent: repeatByEnergy), .. extraEffects ?? []],
        destination,
        CardType: "Attack");

    private static CardState Skill(string instanceId, string modelId, IEnumerable<EffectSpec> effects) => new(
        instanceId,
        modelId,
        modelId,
        0,
        TargetKind.Self,
        [.. effects],
        CardType: "Skill");

    private static CombatSnapshot Snapshot(
        IEnumerable<CardState> hand,
        IEnumerable<CardState>? drawPile = null,
        IEnumerable<CardState>? discardPile = null,
        IEnumerable<CardState>? exhaustPile = null,
        ImmutableDictionary<string, StatusState>? playerStatuses = null,
        IEnumerable<IntentState>? enemyIntents = null,
        int energy = 3,
        RngSnapshotSet? rngStreams = null,
        int enemyCount = 1) => CombatSnapshot.Create(
        "growth-autoplay-fixture",
        new PlayerState(
            30,
            30,
            0,
            energy,
            energy,
            playerStatuses ?? EmptyStatuses,
            CardsPerTurn: 0),
        Enumerable.Range(0, enemyCount).Select(index => new CreatureState(
            $"enemy-{index}",
            $"Enemy {index}",
            100,
            100,
            0,
            EmptyStatuses,
            (enemyIntents ?? []).ToImmutableArray(),
            0)),
        hand,
        drawPile,
        discardPile,
        exhaustPile,
        rngState: 42,
        rngStreams: rngStreams ?? KnownRng());

    private static RngSnapshotSet KnownRng()
    {
        var targets = new RngStreamSnapshot(RngSnapshotSet.CombatTargets, 1, 2, 3, 4);
        var shuffle = new RngStreamSnapshot(RngSnapshotSet.Shuffle, 11, 22, 33, 44);
        return new RngSnapshotSet(ImmutableDictionary<string, RngStreamSnapshot>.Empty
            .Add(targets.Name, targets)
            .Add(shuffle.Name, shuffle));
    }

    private static RngSnapshotSet KnownRngWithCardGeneration()
    {
        var streams = KnownRng().Streams;
        var generation = new RngStreamSnapshot(RngSnapshotSet.CombatCardGeneration, 51, 52, 53, 54);
        return new RngSnapshotSet(streams.Add(generation.Name, generation));
    }

    private static RngSnapshotSet KnownRngWithCardSelection()
    {
        var streams = KnownRng().Streams;
        var selection = new RngStreamSnapshot(RngSnapshotSet.CombatCardSelection, 61, 62, 63, 64);
        return new RngSnapshotSet(streams.Add(selection.Name, selection));
    }

    private static ImmutableDictionary<string, StatusState> EmptyStatuses { get; } =
        ImmutableDictionary<string, StatusState>.Empty;
}
