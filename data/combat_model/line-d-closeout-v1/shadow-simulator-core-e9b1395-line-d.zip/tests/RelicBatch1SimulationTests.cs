using System.Collections.Immutable;
using STS2BestChoice.Core.Model;
using STS2BestChoice.Core.Simulation;
using Xunit;

namespace STS2BestChoice.Tests;

/// <summary>
/// Batch 1 relic handlers (v0.111.0): attack/skill counter relics,
/// turn-start energy/block/damage relics, and the turn-end Fake Orichalcum.
/// Semantics confirmed against v0.111 IL (commit 41cef1ea) and validated
/// against the live CLI via ShadowDiff fixtures.
/// </summary>
public sealed class RelicBatch1SimulationTests
{
    private static PlayerState MakePlayer(int hp = 80, int maxHp = 80, int block = 0, int energy = 9, int maxEnergy = 3) =>
        new(hp, maxHp, block, energy, maxEnergy, ImmutableDictionary<string, StatusState>.Empty);

    private static CreatureState MakeEnemy(string id = "CULTIST:1", int hp = 50, int maxHp = 50, int block = 0) =>
        new(id, "Cultist", hp, maxHp, block, ImmutableDictionary<string, StatusState>.Empty, []);

    private static CardState MakeStrike(string instanceId = "strike_1") =>
        new(instanceId, "STRIKE_IRONCLAD", "打击", 1, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 6)], CardType: "Attack");

    private static CardState MakeDefend(string instanceId = "defend_1") =>
        new(instanceId, "DEFEND_IRONCLAD", "防御", 1, TargetKind.Self,
            [new EffectSpec(EffectKind.Block, 5)], CardType: "Skill");

    private static CardState MakePower(string instanceId = "power_1") =>
        new(instanceId, "INFLOW", "注入", 1, TargetKind.Self,
            [new EffectSpec(EffectKind.ApplyStatus, 2, "STRENGTH")], CardType: "Power");

    private static RelicState Relic(string id) =>
        new(id, SupportStatus: RelicEffectSupportStatus.SimulatorSupported);

    private static MutableCombatState MakeState(
        PlayerState player,
        CreatureState enemy,
        CardState[] hand,
        params RelicState[] relics)
    {
        var snap = CombatSnapshot.Create("fp", player, [enemy], hand, relics: relics);
        return MutableCombatState.FromSnapshot(snap);
    }

    [Fact]
    public void ShurikenGrantsStrengthOnEveryThirdAttack()
    {
        var sim = new DeterministicSimulator();
        var state = MakeState(MakePlayer(), MakeEnemy(hp: 100),
            [MakeStrike("s1"), MakeStrike("s2"), MakeStrike("s3"), MakeStrike("s4"), MakeStrike("s5"), MakeStrike("s6")],
            Relic("SHURIKEN"));

        for (var i = 0; i < 6; i++)
        {
            var strike = state.Hand.First(c => c.ModelId == "STRIKE_IRONCLAD");
            state = sim.PlayCard(state, strike, "CULTIST:1", null);
            var shuriken = state.Relics.First(r => r.Id == "SHURIKEN");
            var expectedStrength = (i + 1) / 3;
            var strength = state.Player.Statuses.TryGetValue("STRENGTH", out var s) ? s.Amount : 0m;
            Assert.Equal(expectedStrength, strength);
            Assert.Equal((i + 1) % 3, shuriken.Counter);
        }
    }

    [Fact]
    public void ShurikenCounterIgnoresSkills()
    {
        var sim = new DeterministicSimulator();
        var state = MakeState(MakePlayer(), MakeEnemy(hp: 100),
            [MakeStrike("s1"), MakeStrike("s2"), MakeDefend("d1"), MakeStrike("s3")],
            Relic("SHURIKEN"));

        var strike1 = state.Hand.First(c => c.InstanceId == "s1");
        state = sim.PlayCard(state, strike1, "CULTIST:1", null);
        var defend = state.Hand.First(c => c.InstanceId == "d1");
        state = sim.PlayCard(state, defend, null, null);
        var strike2 = state.Hand.First(c => c.InstanceId == "s2");
        state = sim.PlayCard(state, strike2, "CULTIST:1", null);

        var shuriken = state.Relics.First(r => r.Id == "SHURIKEN");
        Assert.Equal(2, shuriken.Counter);
        Assert.False(state.Player.Statuses.ContainsKey("STRENGTH"));
    }

    [Fact]
    public void KunaiGrantsDexterityOnEveryThirdAttack()
    {
        var sim = new DeterministicSimulator();
        var state = MakeState(MakePlayer(), MakeEnemy(hp: 100),
            [MakeStrike("s1"), MakeStrike("s2"), MakeStrike("s3")],
            Relic("KUNAI"));

        while (state.Hand.Any(c => c.ModelId == "STRIKE_IRONCLAD"))
        {
            var strike = state.Hand.First(c => c.ModelId == "STRIKE_IRONCLAD");
            state = sim.PlayCard(state, strike, "CULTIST:1", null);
        }

        var dexterity = state.Player.Statuses.TryGetValue("DEXTERITY", out var d) ? d.Amount : 0m;
        Assert.Equal(1, dexterity);
        Assert.Equal(0, state.Relics.First(r => r.Id == "KUNAI").Counter);
    }

    [Fact]
    public void OrnamentalFanGrantsBlockOnEveryThirdAttack()
    {
        var sim = new DeterministicSimulator();
        var state = MakeState(MakePlayer(), MakeEnemy(hp: 100),
            [MakeStrike("s1"), MakeStrike("s2"), MakeStrike("s3")],
            Relic("ORNAMENTAL_FAN"));

        while (state.Hand.Any(c => c.ModelId == "STRIKE_IRONCLAD"))
        {
            var strike = state.Hand.First(c => c.ModelId == "STRIKE_IRONCLAD");
            state = sim.PlayCard(state, strike, "CULTIST:1", null);
        }

        Assert.Equal(4, state.Player.Block);
        Assert.Equal(0, state.Relics.First(r => r.Id == "ORNAMENTAL_FAN").Counter);
    }

    [Fact]
    public void LetterOpenerDamagesAllEnemiesOnEveryThirdSkill()
    {
        var sim = new DeterministicSimulator();
        var enemyA = MakeEnemy("CULTIST:1", hp: 50);
        var enemyB = MakeEnemy("CULTIST:2", hp: 50);
        var snap = CombatSnapshot.Create("fp", MakePlayer(), [enemyA, enemyB],
            [MakeDefend("d1"), MakeDefend("d2"), MakeDefend("d3")],
            relics: [Relic("LETTER_OPENER")]);
        var state = MutableCombatState.FromSnapshot(snap);

        var beforeA = state.Enemies.First(e => e.Id == "CULTIST:1").Hp;
        var beforeB = state.Enemies.First(e => e.Id == "CULTIST:2").Hp;
        for (var i = 0; i < 3; i++)
        {
            var defend = state.Hand.First(c => c.ModelId == "DEFEND_IRONCLAD");
            state = sim.PlayCard(state, defend, null, null);
        }

        // Letter Opener dealt 5 to ALL enemies regardless of block gained.
        Assert.Equal(beforeA - 5, state.Enemies.First(e => e.Id == "CULTIST:1").Hp);
        Assert.Equal(beforeB - 5, state.Enemies.First(e => e.Id == "CULTIST:2").Hp);
        Assert.Equal(0, state.Relics.First(r => r.Id == "LETTER_OPENER").Counter);
    }

    [Fact]
    public void RainbowRingGrantsStrengthAndDexterityOncePerTurn()
    {
        var sim = new DeterministicSimulator();
        var enemy = MakeEnemy("CULTIST:1", hp: 100);
        var snap = CombatSnapshot.Create("fp", MakePlayer(), [enemy],
            [MakeStrike("s1"), MakeDefend("d1"), MakePower("p1")],
            relics: [Relic("RAINBOW_RING")]);
        var state = MutableCombatState.FromSnapshot(snap);

        var strike = state.Hand.First(c => c.InstanceId == "s1");
        state = sim.PlayCard(state, strike, "CULTIST:1", null);
        Assert.Equal(0, StatusAmount(state, "STRENGTH"));
        Assert.Equal(0, StatusAmount(state, "DEXTERITY"));

        var defend = state.Hand.First(c => c.InstanceId == "d1");
        state = sim.PlayCard(state, defend, null, null);
        Assert.Equal(0, StatusAmount(state, "STRENGTH"));

        var power = state.Hand.First(c => c.InstanceId == "p1");
        state = sim.PlayCard(state, power, null, null);
        // Rainbow Ring bonus (+1) plus the power's own Strength (+2).
        Assert.Equal(3, StatusAmount(state, "STRENGTH"));
        Assert.Equal(1, StatusAmount(state, "DEXTERITY"));
    }

    private static decimal StatusAmount(MutableCombatState state, string statusId) =>
        state.Player.Statuses.TryGetValue(statusId, out var status) ? status.Amount : 0m;

    [Fact]
    public void MercuryHourglassDealsThreeDamageToAllEnemiesOnTurnStart()
    {
        var sim = new DeterministicSimulator();
        var enemyA = MakeEnemy("CULTIST:1", hp: 50);
        var enemyB = MakeEnemy("CULTIST:2", hp: 50);
        var snap = CombatSnapshot.Create("fp", MakePlayer(), [enemyA, enemyB], [],
            relics: [Relic("MERCURY_HOURGLASS")]);
        var state = MutableCombatState.FromSnapshot(snap);

        var nextTurn = sim.ProjectToNextPlayerTurn(state);

        Assert.Equal(47, nextTurn.Enemies.First(e => e.Id == "CULTIST:1").Hp);
        Assert.Equal(47, nextTurn.Enemies.First(e => e.Id == "CULTIST:2").Hp);
        Assert.Equal(2, nextTurn.Round);
    }

    [Fact]
    public void MrStrugglesDealsTurnNumberDamageOnTurnStart()
    {
        var sim = new DeterministicSimulator();
        var enemy = MakeEnemy("CULTIST:1", hp: 50);
        var snap = CombatSnapshot.Create("fp", MakePlayer(), [enemy], [],
            relics: [Relic("MR_STRUGGLES")]);
        var state = MutableCombatState.FromSnapshot(snap);

        var turn2 = sim.ProjectToNextPlayerTurn(state);
        Assert.Equal(48, turn2.Enemies.First(e => e.Id == "CULTIST:1").Hp);

        var turn3 = sim.ProjectToNextPlayerTurn(turn2);
        Assert.Equal(45, turn3.Enemies.First(e => e.Id == "CULTIST:1").Hp);
    }

    [Fact]
    public void CandelabraGrantsEnergyOnSecondTurnOnly()
    {
        var sim = new DeterministicSimulator();
        var enemy = MakeEnemy("CULTIST:1", hp: 50);
        var snap = CombatSnapshot.Create("fp", MakePlayer(), [enemy], [],
            relics: [Relic("CANDELABRA")]);
        var state = MutableCombatState.FromSnapshot(snap);

        var turn2 = sim.ProjectToNextPlayerTurn(state);
        Assert.Equal(5, turn2.Player.Energy);

        var turn3 = sim.ProjectToNextPlayerTurn(turn2);
        Assert.Equal(3, turn3.Player.Energy);
    }

    [Fact]
    public void ChandelierGrantsEnergyOnThirdTurnOnly()
    {
        var sim = new DeterministicSimulator();
        var enemy = MakeEnemy("CULTIST:1", hp: 50);
        var snap = CombatSnapshot.Create("fp", MakePlayer(), [enemy], [],
            relics: [Relic("CHANDELIER")]);
        var state = MutableCombatState.FromSnapshot(snap);

        var turn2 = sim.ProjectToNextPlayerTurn(state);
        Assert.Equal(3, turn2.Player.Energy);

        var turn3 = sim.ProjectToNextPlayerTurn(turn2);
        Assert.Equal(6, turn3.Player.Energy);
    }

    [Fact]
    public void SaiGrantsSevenBlockOnTurnStart()
    {
        var sim = new DeterministicSimulator();
        var enemy = MakeEnemy("CULTIST:1", hp: 50);
        var snap = CombatSnapshot.Create("fp", MakePlayer(), [enemy], [],
            relics: [Relic("SAI")]);
        var state = MutableCombatState.FromSnapshot(snap);

        var turn2 = sim.ProjectToNextPlayerTurn(state);
        Assert.Equal(7, turn2.Player.Block);

        var turn3 = sim.ProjectToNextPlayerTurn(turn2);
        Assert.Equal(7, turn3.Player.Block);
    }

    [Fact]
    public void FakeHappyFlowerGrantsEnergyEveryFiveTurns()
    {
        var sim = new DeterministicSimulator();
        var enemy = MakeEnemy("CULTIST:1", hp: 50);
        var snap = CombatSnapshot.Create("fp", MakePlayer(), [enemy], [],
            relics: [Relic("FAKE_HAPPY_FLOWER")]);
        var state = MutableCombatState.FromSnapshot(snap);

        var energies = new List<int>();
        var flowerCounters = new List<int?>();
        for (var i = 0; i < 5; i++)
        {
            state = sim.ProjectToNextPlayerTurn(state);
            energies.Add(state.Player.Energy);
            flowerCounters.Add(state.Relics.First(r => r.Id == "FAKE_HAPPY_FLOWER").Counter);
        }

        // Turns 2..6: the counter increments each side turn start and wraps to 0
        // on the 5th increment, where the energy bonus applies.
        Assert.Equal(new[] { 3, 3, 3, 3, 4 }, energies);
        Assert.Equal(new[] { 1, 2, 3, 4, 0 }, flowerCounters.Select(c => c ?? -1).ToArray());
    }

    [Fact]
    public void FakeOrichalcumGrantsBlockAtTurnEndBeforeEnemyAttack()
    {
        var sim = new DeterministicSimulator();
        var enemy = MakeEnemy("CULTIST:1", hp: 50) with
        {
            Intents = [new IntentState("Attack", 10, 1)]
        };
        var snap = CombatSnapshot.Create("fp", MakePlayer(hp: 80, block: 0), [enemy], [],
            relics: [Relic("FAKE_ORICHALCUM")]);
        var state = MutableCombatState.FromSnapshot(snap);

        var nextTurn = sim.ProjectToNextPlayerTurn(state);

        // 3 block absorbed part of the 10-damage attack; block resets to 0 at
        // the start of the next player turn.
        Assert.Equal(73, nextTurn.Player.Hp);
        Assert.Equal(0, nextTurn.Player.Block);
    }

    [Fact]
    public void AttackCounterRelicsResetCountersAtTurnStart()
    {
        var sim = new DeterministicSimulator();
        var enemy = MakeEnemy("CULTIST:1", hp: 100);
        var snap = CombatSnapshot.Create("fp", MakePlayer(), [enemy],
            [MakeStrike("s1"), MakeStrike("s2"), MakeStrike("s3"), MakeStrike("s4")],
            relics: [Relic("SHURIKEN"), Relic("KUNAI"), Relic("ORNAMENTAL_FAN"), Relic("LETTER_OPENER")]);
        var state = MutableCombatState.FromSnapshot(snap);

        while (state.Hand.Any(c => c.ModelId == "STRIKE_IRONCLAD"))
        {
            var strike = state.Hand.First(c => c.ModelId == "STRIKE_IRONCLAD");
            state = sim.PlayCard(state, strike, "CULTIST:1", null);
        }
        // 4 attacks: SHURIKEN triggered once (3rd) then counted 1.
        Assert.Equal(1, state.Relics.First(r => r.Id == "SHURIKEN").Counter);

        var nextTurn = sim.ProjectToNextPlayerTurn(state);
        foreach (var id in new[] { "SHURIKEN", "KUNAI", "ORNAMENTAL_FAN", "LETTER_OPENER" })
            Assert.Equal(0, nextTurn.Relics.First(r => r.Id == id).Counter);
    }
}
