using System.Collections.Immutable;
using System.Globalization;
using STS2BestChoice.Core.Model;
using STS2BestChoice.Core.Search;
using STS2BestChoice.Core.Simulation;
using Xunit;

namespace STS2BestChoice.Tests;

public sealed class NoslExpectimaxTeacherTests
{
    [Fact]
    public void PublicBeliefExcludesExhaustPileAndDefaultsToMaskedRng()
    {
        var card = new CardState("hand", "STRIKE", "Strike", 1, TargetKind.Enemy, [], CardType: "Attack");
        var snapshot = CombatSnapshot.Create(
            "fp", new PlayerState(50, 50, 0, 3, 3, ImmutableDictionary<string, StatusState>.Empty),
            [], [card], drawPile: [card with { InstanceId = "draw" }],
            exhaustPile: [card with { InstanceId = "exhaust" }]);

        Assert.Equal(ObservationView.Public, snapshot.View);
        Assert.Equal(RngAvailability.MaskedUnknown, snapshot.RngAvailability);
        var belief = NoslBeliefState.FromPublicSnapshot(snapshot);
        Assert.Equal(2, belief.KnownDeckComposition.Single(item => item.ModelId == "STRIKE").Count);
    }

    [Fact]
    public void UnknownShuffleUsesUniqueMultisetBranches()
    {
        static CardState C(string id, string model) =>
            new(id, model, model, 0, TargetKind.None, []);
        var snapshot = CombatSnapshot.Create(
            "fp", new PlayerState(50, 50, 0, 0, 0, ImmutableDictionary<string, StatusState>.Empty)
                with { CardsPerTurn = 1 }, [], [],
            discardPile: [C("a1", "A"), C("a2", "A"), C("b", "B")], rngState: 0);
        var outcomes = new DeterministicSimulator()
            .ProjectToNextPlayerTurnOutcomes(MutableCombatState.FromSnapshot(snapshot), 16, 16);

        Assert.Equal(2, outcomes.Length);
        Assert.InRange(outcomes.Sum(static outcome => outcome.Probability), 0.999999m, 1.000001m);
        Assert.Equal(2m / 3m, outcomes.Single(outcome => outcome.State.Hand[0].ModelId == "A").Probability);
        Assert.Equal(1m / 3m, outcomes.Single(outcome => outcome.State.Hand[0].ModelId == "B").Probability);
    }

    [Fact]
    public void UnknownShuffleKeepsSemanticallyDifferentSameModelCardsSeparate()
    {
        static CardState C(string id, decimal damage) =>
            new(id, "A", "A", 0, TargetKind.Enemy,
                [new EffectSpec(EffectKind.Damage, damage)]);
        var snapshot = CombatSnapshot.Create(
            "fp", new PlayerState(50, 50, 0, 0, 0, ImmutableDictionary<string, StatusState>.Empty)
                with { CardsPerTurn = 1 }, [], [],
            discardPile: [C("a1", 4), C("a2", 7)], rngState: 0);

        var outcomes = new DeterministicSimulator()
            .ProjectToNextPlayerTurnOutcomes(MutableCombatState.FromSnapshot(snapshot), 16, 16);

        Assert.Equal(2, outcomes.Length);
        Assert.All(outcomes, outcome => Assert.Equal(1m / 2m, outcome.Probability));
        Assert.Equal(new[] { 4m, 7m }, outcomes
            .Select(static outcome => outcome.State.Hand[0].Effects[0].Amount)
            .Order());
    }

    [Fact]
    public void HandOnlyUnknownShuffleCollapsesEquivalentOrdersToExactMultisetBranch()
    {
        static CardState C(string id, string model) =>
            new(id, model, model, 0, TargetKind.None, []);
        var snapshot = CombatSnapshot.Create(
            "fp", new PlayerState(50, 50, 0, 0, 0, ImmutableDictionary<string, StatusState>.Empty)
                with { CardsPerTurn = 2 }, [], [C("a", "A"), C("b", "B")],
            drawPile: [], discardPile: [], rngState: 0);
        var state = MutableCombatState.FromSnapshot(snapshot);
        var outcomes = new DeterministicSimulator()
            .ProjectToNextPlayerTurnOutcomes(state, 16, 16);

        Assert.Single(outcomes);
        Assert.All(outcomes, outcome =>
        {
            Assert.Equal("Exact", outcome.OutcomeQuality);
            Assert.Equal(RngSnapshotSet.Shuffle, outcome.RngSource);
            Assert.Equal(1m, outcome.ProbabilityMassCovered);
            Assert.DoesNotContain(outcome.State.Restrictions, item => item.Code == "estimated_hand_shuffle");
        });
    }

    [Fact]
    public void UnorderedDrawPoolMarkerDoesNotCreateSnapshotRestriction()
    {
        static CardState C(string id, string model) =>
            new(id, model, model, 0, TargetKind.None, []);
        var snapshot = CombatSnapshot.Create(
            "fp", new PlayerState(50, 50, 0, 0, 0, ImmutableDictionary<string, StatusState>.Empty)
                with { CardsPerTurn = 1 }, [], [C("hand", "A")],
            drawPile: [C("draw-a", "A"), C("draw-b", "B")],
            discardPile: [C("discard", "C")],
            globalRestrictions: ["nosl_unordered_draw_pool"], rngState: 0);
        var state = MutableCombatState.FromSnapshot(snapshot);

        Assert.Equal(2, state.UnorderedDrawPool.Count);
        Assert.Equal("discard", Assert.Single(state.DiscardPile).InstanceId);
        Assert.Empty(state.Restrictions);
        Assert.Empty(state.Risks);

        var outcomes = new DeterministicSimulator()
            .ProjectToNextPlayerTurnOutcomes(state, 16, 16);
        Assert.Equal(2, outcomes.Length);
        Assert.All(outcomes, outcome =>
        {
            Assert.Equal("Exact", outcome.OutcomeQuality);
            Assert.Equal(1m / 2m, outcome.Probability);
            Assert.Empty(outcome.State.Restrictions);
            Assert.Empty(outcome.State.Risks);
            Assert.Empty(outcome.RngConsumptionVector!);
        });
    }

    [Fact]
    public void MaskedDrawPoolDoesNotLeakIntoDiscardChoices()
    {
        var recover = new CardState("recover", "RECOVER", "Recover", 0, TargetKind.None,
            [new EffectSpec(EffectKind.ChooseDiscardToHand, StatusId: "SKILL")], CardType: "Skill");
        var hiddenDrawSkill = new CardState("hidden-draw", "HIDDEN", "Hidden", 1, TargetKind.None, [], CardType: "Skill");
        var visibleDiscardSkill = new CardState("visible-discard", "VISIBLE", "Visible", 1, TargetKind.None, [], CardType: "Skill");
        var exhaustedSkill = new CardState("exhausted", "EXHAUSTED", "Exhausted", 1, TargetKind.None, [], CardType: "Skill");
        var source = CombatSnapshot.Create(
            "mask-discard",
            new PlayerState(40, 40, 0, 0, 0, ImmutableDictionary<string, StatusState>.Empty),
            [], [recover],
            drawPile: [hiddenDrawSkill],
            discardPile: [visibleDiscardSkill],
            exhaustPile: [exhaustedSkill],
            view: ObservationView.Public);

        var masked = NoslExpectimaxTeacher.MaskHiddenState(source);
        var state = MutableCombatState.FromSnapshot(masked);
        var choices = CombatSearchSession.BuildDynamicChoices(state, recover);

        Assert.Empty(state.DrawPile);
        Assert.Equal("hidden-draw", Assert.Single(state.UnorderedDrawPool).InstanceId);
        Assert.Equal("visible-discard", Assert.Single(state.DiscardPile).InstanceId);
        Assert.Empty(state.ExhaustPile);
        Assert.Equal("visible-discard", Assert.Single(choices).CardInstanceId);
    }

    [Fact]
    public void UnorderedDrawPoolFeedsCardDrawAsExactChance()
    {
        static CardState C(string id, string model, ImmutableArray<EffectSpec> effects) =>
            new(id, model, model, 0, TargetKind.None, effects, CardType: "Skill");
        var drawCard = C("draw", "DRAW", [new EffectSpec(EffectKind.Draw, Amount: 1)]);
        var snapshot = CombatSnapshot.Create(
            "fp", new PlayerState(50, 50, 0, 1, 1, ImmutableDictionary<string, StatusState>.Empty),
            [], [drawCard], drawPile: [C("a", "A", []), C("b", "B", [])],
            globalRestrictions: ["nosl_unordered_draw_pool"], rngState: 0);
        var outcomes = new DeterministicSimulator()
            .PlayCardOutcomes(MutableCombatState.FromSnapshot(snapshot), drawCard, null, null, 16, 16);

        Assert.Equal(2, outcomes.Length);
        Assert.All(outcomes, outcome =>
        {
            Assert.Equal("Exact", outcome.OutcomeQuality);
            Assert.Equal(1m / 2m, outcome.Probability);
            Assert.Empty(outcome.RngConsumptionVector!);
            Assert.DoesNotContain(outcome.State.Restrictions, item => item.Code.StartsWith("uncalculable", StringComparison.Ordinal));
        });
    }

    [Fact]
    public void UnorderedDrawTransitionUsesDeterministicProbabilityTruncation()
    {
        static CardState C(string id, string model, ImmutableArray<EffectSpec> effects) =>
            new(id, model, model, 0, TargetKind.None, effects, CardType: "Skill");
        var drawCard = C("draw", "DRAW_FIVE", [new EffectSpec(EffectKind.Draw, Amount: 5)]);
        var counts = new[] { 6, 5, 4, 2, 2, 1 };
        var pool = counts.SelectMany((count, group) => Enumerable.Range(0, count)
            .Select(index => C($"{group}:{index}", $"T{group}", []))).ToImmutableArray();
        var snapshot = CombatSnapshot.Create(
            "fp", new PlayerState(50, 50, 0, 1, 1, ImmutableDictionary<string, StatusState>.Empty),
            [], [drawCard], drawPile: pool,
            globalRestrictions: ["nosl_unordered_draw_pool"], rngState: 0);

        var outcomes = new DeterministicSimulator().PlayCardOutcomes(
            MutableCombatState.FromSnapshot(snapshot), drawCard, null, null, 10, 10);

        Assert.Equal(10, outcomes.Length);
        Assert.All(outcomes, outcome =>
        {
            Assert.Equal("Estimated", outcome.OutcomeQuality);
            Assert.NotNull(outcome.ProbabilityMassCovered);
            Assert.True(outcome.ProbabilityMassCovered < 1m);
            Assert.Null(outcome.EffectiveSampleSize);
            Assert.Contains(outcome.State.Restrictions, item => item.Code == "truncated_draw_distribution");
        });
        Assert.Equal(outcomes[0].ProbabilityMassCovered, outcomes.Sum(static outcome => outcome.Probability));
        Assert.All(outcomes.Zip(outcomes.Skip(1)), pair =>
            Assert.True(pair.First.Probability >= pair.Second.Probability));
    }

    [Fact]
    public void PostDrawCannotDrawStatusIsAppliedAfterExactUnorderedDraw()
    {
        static CardState C(string id, string model, ImmutableArray<EffectSpec> effects) =>
            new(id, model, model, 0, TargetKind.None, effects, CardType: "Skill");
        var battleTrance = C("battle-trance", "BATTLE_TRANCE",
        [
            new EffectSpec(EffectKind.Draw, Amount: 1),
            new EffectSpec(EffectKind.ApplyStatus, Amount: 1, StatusId: "CANNOT_DRAW", Duration: 1)
        ]);
        var snapshot = CombatSnapshot.Create(
            "fp", new PlayerState(50, 50, 0, 1, 1, ImmutableDictionary<string, StatusState>.Empty),
            [], [battleTrance], discardPile: [C("a", "A", []), C("b", "B", [])],
            globalRestrictions: ["nosl_unordered_draw_pool"], rngState: 0);

        var outcomes = new DeterministicSimulator().PlayCardOutcomes(
            MutableCombatState.FromSnapshot(snapshot), battleTrance, null, null, 16, 16);

        Assert.Equal(2, outcomes.Length);
        Assert.All(outcomes, outcome =>
        {
            Assert.Equal("Exact", outcome.OutcomeQuality);
            Assert.Equal(1m / 2m, outcome.Probability);
            Assert.Single(outcome.State.Hand);
            Assert.Equal(1, outcome.State.Player.Statuses["CANNOT_DRAW"].Amount);
            Assert.DoesNotContain(outcome.State.Risks,
                risk => risk.Reason == PredictionRiskReason.MethodMirrorIncomplete);
        });
    }

    [Fact]
    public void RandomOperatorRegistryCoversEveryCombatStream()
    {
        var streams = new[]
        {
            RngSnapshotSet.Shuffle,
            RngSnapshotSet.CombatCardGeneration,
            RngSnapshotSet.CombatPotionGeneration,
            RngSnapshotSet.CombatCardSelection,
            RngSnapshotSet.CombatEnergyCosts,
            RngSnapshotSet.CombatTargets,
            RngSnapshotSet.CombatOrbGeneration
        };
        Assert.All(streams, stream =>
        {
            var spec = RandomOperatorRegistry.Require(stream);
            Assert.Equal("v0.111.0", spec.Version);
            Assert.True(spec.ProbabilityKnown);
        });
    }

    [Fact]
    public void NoslBeliefKeyIgnoresHiddenRngAndFutureOrder()
    {
        var a = new CardState("a", "A", "A", 0, TargetKind.None, []);
        var b = new CardState("b", "B", "B", 0, TargetKind.None, []);
        var snapshot = CombatSnapshot.Create(
            "fp", new PlayerState(50, 50, 0, 3, 3, ImmutableDictionary<string, StatusState>.Empty),
            [], [], drawPile: [a, b], discardPile: [], rngState: 1);
        var first = MutableCombatState.FromSnapshot(snapshot);
        var second = MutableCombatState.FromSnapshot(snapshot with
        {
            RngState = 99,
            DrawPile = [b, a]
        });

        Assert.Equal(first.NoslBeliefKey(), second.NoslBeliefKey());
        Assert.Equal(first.PublicObservationKey(), second.PublicObservationKey());
    }

    [Fact]
    public void SearchBehaviorKeyIncludesCardEffectParameters()
    {
        static CardState C(decimal damage) => new(
            "a", "A", "A", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, damage)]);
        var baseSnapshot = CombatSnapshot.Create(
            "fp", new PlayerState(50, 50, 0, 1, 1, ImmutableDictionary<string, StatusState>.Empty),
            [], [C(4)], drawPile: [], discardPile: []);
        var changedSnapshot = baseSnapshot with { Hand = [C(7)] };

        var first = MutableCombatState.FromSnapshot(baseSnapshot);
        var second = MutableCombatState.FromSnapshot(changedSnapshot);

        Assert.NotEqual(first.SearchBehaviorKey(), second.SearchBehaviorKey());
        Assert.NotEqual(first.AuditExactKey(), second.AuditExactKey());
    }

    [Fact]
    public void CanonicalKeysUseInvariantDecimalFormatting()
    {
        var previous = CultureInfo.CurrentCulture;
        try
        {
            CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo("fr-FR");
            var card = new CardState("a", "A", "A", 0, TargetKind.Self,
                [new EffectSpec(EffectKind.Block, 4.5m)]);
            var snapshot = CombatSnapshot.Create(
                "fp", new PlayerState(50, 50, 0, 1, 1, ImmutableDictionary<string, StatusState>.Empty),
                [], [card], drawPile: [], discardPile: []);
            var key = MutableCombatState.FromSnapshot(snapshot).SearchBehaviorKey();
            Assert.Contains("4.5", key, StringComparison.Ordinal);
            Assert.DoesNotContain("4,5", key, StringComparison.Ordinal);
        }
        finally
        {
            CultureInfo.CurrentCulture = previous;
        }
    }

    [Fact]
    public void NoslBeliefKeySortsSameModelSemanticVariantsCanonically()
    {
        static CardState C(string id, decimal amount) => new(
            id, "A", "A", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.Block, amount)]);
        var first = CombatSnapshot.Create(
            "fp", new PlayerState(50, 50, 0, 1, 1, ImmutableDictionary<string, StatusState>.Empty),
            [], [], drawPile: [C("a", 4), C("b", 7)], discardPile: []);
        var second = first with { DrawPile = [C("b", 7), C("a", 4)] };

        Assert.Equal(
            MutableCombatState.FromSnapshot(first).NoslBeliefKey(),
            MutableCombatState.FromSnapshot(second).NoslBeliefKey());
    }

    [Fact]
    public void ActionStepExposesCliCompatibleStableActionId()
    {
        Assert.Equal(
            "play:card:STRIKE:000:enemy:SLIME:0",
            new ActionStep(ActionKind.PlayCard, "card:STRIKE:000", "STRIKE", "Strike", "enemy:SLIME:0").ActionId);
        Assert.Equal(
            "potion:potion:FIRE_POTION:000",
            new ActionStep(ActionKind.UsePotion, "potion:FIRE_POTION:000", "FIRE_POTION", "Fire Potion").ActionId);
        Assert.Equal("end_turn", new ActionStep(ActionKind.EndTurn, "END_TURN", "END_TURN", "End Turn").ActionId);
    }

    [Fact]
    public void MaskHiddenStateRemovesOrderAndRngWords()
    {
        var card = new CardState("draw-1", "STRIKE", "Strike", 1, TargetKind.Enemy, [], CardType: "Attack");
        var stream = new RngStreamSnapshot(RngSnapshotSet.Shuffle, 1, 2, 3, 4, 7);
        var snapshot = CombatSnapshot.Create(
            "public", new PlayerState(50, 50, 0, 3, 3, ImmutableDictionary<string, StatusState>.Empty),
            [], [], [card], [], [], rngStreams: new RngSnapshotSet(
                ImmutableDictionary<string, RngStreamSnapshot>.Empty.Add(stream.Name, stream)),
            view: ObservationView.Public);

        var masked = NoslExpectimaxTeacher.MaskHiddenState(snapshot);

        Assert.Single(masked.DrawPile);
        Assert.Equal("STRIKE", masked.DrawPile[0].ModelId);
        Assert.Empty(masked.DiscardPile);
        Assert.Null(masked.RngStreams);
        Assert.Contains("nosl_unordered_draw_pool", masked.GlobalRestrictions);
        Assert.Equal(RngAvailability.MaskedUnknown, masked.RngAvailability);
        Assert.NotNull(masked.NoslBelief);
        Assert.Equal(masked.NoslBelief!.BeliefSignature, masked.Fingerprint);
    }

    [Fact]
    public void PublicBeliefAndLabelsIgnoreHiddenRngAndFutureOrder()
    {
        var strike = new CardState("strike", "STRIKE", "Strike", 1, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, Amount: 6)], CardType: "Attack");
        var defend = new CardState("defend", "DEFEND", "Defend", 1, TargetKind.Self,
            [new EffectSpec(EffectKind.Block, Amount: 5)], CardType: "Skill");
        var enemy = new CreatureState(
            "enemy-0", "Training Dummy", 20, 20, 0,
            ImmutableDictionary<string, StatusState>.Empty,
            [new IntentState("Sleep")]);
        var player = new PlayerState(50, 50, 0, 1, 1, ImmutableDictionary<string, StatusState>.Empty);
        var first = CombatSnapshot.Create(
            "teacher-fingerprint-a", player, [enemy], [strike], [defend, strike], [],
            rngState: 10, view: ObservationView.Public);
        var second = first with
        {
            Fingerprint = "teacher-fingerprint-b",
            DrawPile = [strike, defend],
            RngState = 99,
            RngStreams = new RngSnapshotSet(ImmutableDictionary<string, RngStreamSnapshot>.Empty.Add(
                RngSnapshotSet.Shuffle, new RngStreamSnapshot(RngSnapshotSet.Shuffle, 101, 102, 103, 104, 2)))
        };

        var firstMasked = NoslExpectimaxTeacher.MaskHiddenState(first);
        var secondMasked = NoslExpectimaxTeacher.MaskHiddenState(second);
        Assert.Equal(firstMasked.Fingerprint, secondMasked.Fingerprint);
        Assert.Equal(firstMasked.NoslBelief!.BeliefSignature, secondMasked.NoslBelief!.BeliefSignature);
        Assert.True(firstMasked.NoslBelief.KnownDeckComposition
            .Select(static item => $"{item.ModelId}:{item.Count}")
            .SequenceEqual(secondMasked.NoslBelief.KnownDeckComposition.Select(static item => $"{item.ModelId}:{item.Count}")));
        Assert.True(firstMasked.NoslBelief.RemainingCardMultiset
            .Select(static item => $"{item.ModelId}:{item.Count}")
            .SequenceEqual(secondMasked.NoslBelief.RemainingCardMultiset.Select(static item => $"{item.ModelId}:{item.Count}")));
        Assert.True(firstMasked.NoslBelief.KnownHandInstanceIds.SequenceEqual(secondMasked.NoslBelief.KnownHandInstanceIds));
        Assert.True(firstMasked.DiscardPile.Select(static card => card.ModelId)
            .SequenceEqual(secondMasked.DiscardPile.Select(static card => card.ModelId)));

        var firstResult = new NoslExpectimaxTeacher().Search(first, new NoslExpectimaxOptions(
            TopK: 3, MaximumExpandedNodes: 10_000, OfflineBudget: TimeSpan.FromSeconds(5), MaximumActions: 4));
        var secondResult = new NoslExpectimaxTeacher().Search(second, new NoslExpectimaxOptions(
            TopK: 3, MaximumExpandedNodes: 10_000, OfflineBudget: TimeSpan.FromSeconds(5), MaximumActions: 4));
        Assert.Equal(
            firstResult.Balanced.Select(static line => string.Join(">", line.Steps.Select(static step => step.SourceInstanceId))),
            secondResult.Balanced.Select(static line => string.Join(">", line.Steps.Select(static step => step.SourceInstanceId))));
        Assert.Equal(firstResult.Progress.SnapshotFingerprint, secondResult.Progress.SnapshotFingerprint);
        var firstPolicies = firstResult.Policies
            .OrderBy(static policy => policy.Objective)
            .Select(static policy => $"{policy.Objective}:{string.Join(">", policy.DeterministicPrefix.Select(static step => step.SourceInstanceId))}:{policy.Confidence}:{policy.BalancedDistribution?.Expected}");
        var secondPolicies = secondResult.Policies
            .OrderBy(static policy => policy.Objective)
            .Select(static policy => $"{policy.Objective}:{string.Join(">", policy.DeterministicPrefix.Select(static step => step.SourceInstanceId))}:{policy.Confidence}:{policy.BalancedDistribution?.Expected}");
        Assert.True(firstPolicies.SequenceEqual(secondPolicies));
    }

    [Fact]
    public void EnemyAiBeliefSeparatesVisibleIntentFromFutureOutcomes()
    {
        var enemy = new CreatureState(
            "enemy-0", "Enemy", 20m, 20m, 0m,
            ImmutableDictionary<string, StatusState>.Empty,
            [new IntentState("Attack", 6m, 1)]);
        var first = new EnemyAiBelief(
            [enemy],
            [new EnemyIntentForecastOutcome(
                "attack", 0.5m,
                new EnemyIntentForecast([enemy], PredictionConfidence.Estimated))],
            RngAvailability.MaskedUnknown,
            PredictionConfidence.Estimated);
        var second = first with
        {
            FutureOutcomes = [new EnemyIntentForecastOutcome(
                "defend", 0.5m,
                new EnemyIntentForecast([enemy], PredictionConfidence.Estimated))]
        };

        Assert.Equal(enemy.Intents[0].Type, first.SafeVisibleEnemies[0].Intents[0].Type);
        Assert.NotEqual(first.BeliefSignature(), second.BeliefSignature());
        Assert.Equal(RngAvailability.MaskedUnknown, first.RngAvailability);
    }

    [Fact]
    public void EnemyTargetRulesParticipateInNoslAndExactKeys()
    {
        var enemy = new CreatureState(
            "enemy-0", "Enemy", 20m, 20m, 0m,
            ImmutableDictionary<string, StatusState>.Empty,
            [new IntentState("Attack", 6m, 1)]);
        var player = new PlayerState(40m, 40m, 0m, 0, 0,
            ImmutableDictionary<string, StatusState>.Empty);
        var hittable = MutableCombatState.FromSnapshot(CombatSnapshot.Create("a", player, [enemy], []));
        var hidden = MutableCombatState.FromSnapshot(CombatSnapshot.Create(
            "b", player,
            [enemy with { IsHittable = false, TargetRestrictions = ["not_hittable"] }], []));

        Assert.NotEqual(hittable.ExactKey(), hidden.ExactKey());
        Assert.NotEqual(hittable.NoslBeliefKey(), hidden.NoslBeliefKey());
    }

    [Fact]
    public void PublicEnemyAiHistoryParticipatesInBeliefAndAdvancesAtTurnBoundary()
    {
        var publicAi = new EnemyAiPublicState(1, 1, 1, "initial", ["Sleep:1"]);
        var enemy = new CreatureState(
            "enemy-0", "Enemy", 20m, 20m, 0m,
            ImmutableDictionary<string, StatusState>.Empty,
            [new IntentState("Sleep", Hits: 1)],
            PublicAi: publicAi);
        var player = new PlayerState(40m, 40m, 0m, 0, 0,
            ImmutableDictionary<string, StatusState>.Empty, CardsPerTurn: 0);
        var snapshot = CombatSnapshot.Create("public", player, [enemy], [], round: 1);
        var differentHistory = snapshot with
        {
            Enemies = [enemy with
            {
                PublicAi = publicAi with { IntentHistory = ["Attack:1"] }
            }]
        };

        Assert.NotEqual(
            NoslBeliefState.FromPublicSnapshot(snapshot).BeliefSignature,
            NoslBeliefState.FromPublicSnapshot(differentHistory).BeliefSignature);
        var projected = new DeterministicSimulator()
            .ProjectToNextPlayerTurn(MutableCombatState.FromSnapshot(snapshot));
        var projectedAi = Assert.IsType<EnemyAiPublicState>(Assert.Single(projected.Enemies).PublicAi);
        Assert.Equal(2, projectedAi.LastObservedRound);
        Assert.Equal(2, projectedAi.ObservedTurns);
        Assert.Equal("active", projectedAi.Phase);
        Assert.Equal(new[] { "Sleep:1", "Sleep:1" }, projectedAi.SafeIntentHistory);
    }

    [Fact]
    public void EnemyAiBeliefPreservesIncompleteProbabilityMassAndTargetRules()
    {
        var enemy = new CreatureState(
            "enemy-0", "Enemy", 20m, 20m, 0m,
            ImmutableDictionary<string, StatusState>.Empty,
            [new IntentState("Attack", 6m, 1)]);
        IEnemyIntentForecastProvider provider = new ProbabilisticEnemyIntentForecastProvider([
            (1, "attack", 0.6m, ImmutableArray.Create(enemy))
        ]);

        var belief = provider.BuildBelief([enemy], 1);
        var restricted = belief with
        {
            VisibleEnemies = [enemy with { IsHittable = false, TargetRestrictions = ["not_hittable"] }]
        };

        Assert.Equal(0.6m, Assert.Single(belief.SafeFutureOutcomes).Probability);
        Assert.Equal(PredictionConfidence.Estimated, belief.Confidence);
        Assert.Contains(belief.SafeRestrictions,
            static reason => reason.Code == "incomplete_future_intent_probability");
        Assert.NotEqual(belief.BeliefSignature(), restricted.BeliefSignature());
    }

    [Fact]
    public void TeacherBuildsConditionalPolicyAcrossUnknownDrawBranches()
    {
        var draw = new CardState("draw", "DRAW", "Draw", 0, TargetKind.None,
            [new EffectSpec(EffectKind.Draw, Amount: 1)], CardType: "Skill");
        var strike = new CardState("strike-next", "STRIKE", "Strike", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, Amount: 8)], CardType: "Attack");
        var defend = new CardState("defend-next", "DEFEND", "Defend", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.Block, Amount: 7)], CardType: "Skill");
        var enemy = new CreatureState("enemy-0", "Dummy", 30, 30, 0,
            ImmutableDictionary<string, StatusState>.Empty,
            [new IntentState("Sleep")]);
        var player = new PlayerState(40, 40, 0, 0, 0,
            ImmutableDictionary<string, StatusState>.Empty, CardsPerTurn: 0);
        var snapshot = CombatSnapshot.Create(
            "public", player, [enemy], [draw], [], [strike, defend], [], [],
            rngState: 0, view: ObservationView.Public);

        var result = new NoslExpectimaxTeacher().Search(snapshot, new NoslExpectimaxOptions(
            TopK: 3, MaximumExpandedNodes: 10_000, MaximumActions: 3,
            OfflineBudget: TimeSpan.FromSeconds(5), MaximumChanceBranches: 16));

        var policy = Assert.Single(result.Policies.Where(item =>
            item.Objective == ObjectiveKind.Balanced &&
            item.DeterministicPrefix.Any(step => step.SourceInstanceId == "draw")));
        Assert.True(policy.BalancedDistribution?.IsExact);
        Assert.Equal(2, policy.BalancedDistribution?.SampleCount);
        Assert.Equal(1m, policy.BalancedDistribution?.ProbabilityMass);
    }

    [Fact]
    public void SearchMetricsExposeDeterministicCountersAndResourceMeasurements()
    {
        var strike = new CardState("strike", "STRIKE", "Strike", 1, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, Amount: 6)], CardType: "Attack");
        var enemy = new CreatureState("enemy-0", "Dummy", 20, 20, 0,
            ImmutableDictionary<string, StatusState>.Empty,
            [new IntentState("Sleep")]);
        var snapshot = CombatSnapshot.Create(
            "metrics", new PlayerState(40, 40, 0, 1, 1,
                ImmutableDictionary<string, StatusState>.Empty, CardsPerTurn: 0),
            [enemy], [strike]);
        var options = SearchOptions.Default with
        {
            MaximumActions = 2,
            MaximumExpandedNodes = 100,
            InitialBudget = TimeSpan.FromSeconds(2)
        };

        static SearchMetrics Run(CombatSnapshot input, SearchOptions searchOptions) =>
            new CombatSearchSession(input, searchOptions)
                .Continue(TimeSpan.FromSeconds(2)).Progress.Metrics;

        _ = Run(snapshot, options); // JIT warm-up is outside the compared runs.
        var first = Run(snapshot, options);
        var second = Run(snapshot, options);

        Assert.True(first.ExpandedNodes > 0);
        Assert.True(first.StatesCloned > 0);
        Assert.True(first.StateKeysBuilt > 0);
        Assert.True(first.EnemyTurnProjections > 0);
        Assert.True(first.AllocatedBytes > 0);
        Assert.True(first.BytesPerNode > 0);
        Assert.Equal(first.ExpandedNodes, second.ExpandedNodes);
        Assert.Equal(first.ChanceBranchesGenerated, second.ChanceBranchesGenerated);
        Assert.Equal(first.ChanceBranchesPruned, second.ChanceBranchesPruned);
        Assert.Equal(first.TranspositionHits, second.TranspositionHits);
        Assert.Equal(first.TranspositionMisses, second.TranspositionMisses);
        Assert.Equal(first.StatesCloned, second.StatesCloned);
        Assert.Equal(first.StateKeysBuilt, second.StateKeysBuilt);
        Assert.Equal(first.EnemyTurnProjections, second.EnemyTurnProjections);
    }

    [Fact]
    public void DeadSelectedTargetDropsRemainingHitsWithoutConfidenceDowngrade()
    {
        var multiHit = new CardState("multi", "MULTI", "Multi", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, Amount: 5, Repeat: 2)], CardType: "Attack");
        var target = new CreatureState("target", "Target", 5, 5, 0,
            ImmutableDictionary<string, StatusState>.Empty, [new IntentState("Sleep")]);
        var other = new CreatureState("other", "Other", 20, 20, 0,
            ImmutableDictionary<string, StatusState>.Empty, [new IntentState("Sleep")]);
        var snapshot = CombatSnapshot.Create(
            "dead-target",
            new PlayerState(40, 40, 0, 0, 0, ImmutableDictionary<string, StatusState>.Empty),
            [target, other], [multiHit]);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), multiHit, target.Id, null);

        Assert.Equal(0m, result.Enemies.Single(enemy => enemy.Id == target.Id).Hp);
        Assert.Equal(20m, result.Enemies.Single(enemy => enemy.Id == other.Id).Hp);
        Assert.DoesNotContain(result.Restrictions, reason => reason.Code == "uncalculable_target");
        Assert.Contains(result.Risks, risk =>
            risk.Reason == PredictionRiskReason.TargetUnavailable &&
            risk.Severity == PredictionRiskSeverity.Informational);
        Assert.Equal(PredictionConfidence.Reliable,
            new RiskTimeline(result.Risks.ToImmutableArray()).Confidence);

        var randomAttack = new CardState("random", "RANDOM", "Random", 0, TargetKind.None,
            [new EffectSpec(
                EffectKind.CompanionDamage,
                Amount: 1,
                Repeat: 1,
                RandomSource: RngSnapshotSet.CombatTargets)],
            CardType: "Attack");
        var ostyPlayer = snapshot.Player with
        {
            Statuses = snapshot.Player.Statuses.Add("OSTY_ALIVE", new StatusState("OSTY_ALIVE", 1))
        };
        var randomResult = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot with { Player = ostyPlayer, Hand = [randomAttack] }),
            randomAttack,
            null,
            null);
        Assert.Contains(randomResult.Restrictions,
            reason => reason.Code == "uncalculable_random_target");
    }

    [Fact]
    public void ReliableSemanticsRemainReliableWhenSearchBudgetStopsExpansion()
    {
        var strike = new CardState("strike", "STRIKE", "Strike", 1, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, Amount: 6)], CardType: "Attack");
        var enemy = new CreatureState("enemy", "Enemy", 20, 20, 0,
            ImmutableDictionary<string, StatusState>.Empty, [new IntentState("Sleep")]);
        var snapshot = CombatSnapshot.Create(
            "budget-confidence",
            new PlayerState(40, 40, 0, 1, 1,
                ImmutableDictionary<string, StatusState>.Empty, CardsPerTurn: 0),
            [enemy], [strike]);

        var result = new NoslExpectimaxTeacher().Solve(snapshot, new NoslExpectimaxOptions(
            TopK: 1,
            MaximumExpandedNodes: 1,
            OfflineBudget: TimeSpan.FromSeconds(1),
            MaximumActions: 2));

        Assert.False(result.IsComplete);
        Assert.Equal(SearchStopReason.ExpandedNodeLimit, result.Search.Progress.StopReason);
        Assert.Equal(PredictionConfidence.Reliable, result.Confidence);
        Assert.Equal(PredictionConfidence.Reliable, Assert.Single(result.TopBalanced).Confidence);
    }
}
