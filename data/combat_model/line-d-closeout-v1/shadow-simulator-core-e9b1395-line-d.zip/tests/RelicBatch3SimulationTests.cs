using System.Collections.Immutable;
using STS2BestChoice.Core.Model;
using STS2BestChoice.Core.Simulation;
using Xunit;

namespace STS2BestChoice.Tests;

/// <summary>
/// Batch 3 relic handlers (v0.111.0): Self-Forming Clay (unblocked damage
/// schedules Block), Stone Calendar (turn-7 strike), Joss Paper (exhaust
/// counter draw), Pocketwatch (quiet-turn bonus draw), Ice Cream (energy
/// carry-over).
/// </summary>
public sealed class RelicBatch3SimulationTests
{
    private static PlayerState MakePlayer(int hp = 200, int maxHp = 200, int block = 0, int energy = 9, int maxEnergy = 3) =>
        new(hp, maxHp, block, energy, maxEnergy, ImmutableDictionary<string, StatusState>.Empty);

    private static CreatureState MakeEnemy(string id = "CULTIST:1", int hp = 300, int maxHp = 300, int block = 0) =>
        new(id, "Cultist", hp, maxHp, block, ImmutableDictionary<string, StatusState>.Empty, []);

    private static CardState MakeStrike(string instanceId = "strike_1") =>
        new(instanceId, "STRIKE_IRONCLAD", "打击", 1, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 6)], CardType: "Attack");

    private static CardState MakeDefend(string instanceId = "defend_1") =>
        new(instanceId, "DEFEND_IRONCLAD", "防御", 1, TargetKind.Self,
            [new EffectSpec(EffectKind.Block, 5)], CardType: "Skill");

    private static RelicState Relic(string id) =>
        new(id, SupportStatus: RelicEffectSupportStatus.SimulatorSupported);

    private static MutableCombatState MakeState(
        PlayerState player,
        CreatureState enemy,
        CardState[] hand,
        params RelicState[] relics)
    {
        var snap = CombatSnapshot.Create("fp", player, [enemy], hand, relics: relics);
        return MutableCombatState.FromSnapshot(snap);
    }

    private static CreatureState AttackingEnemy(int damage = 10) => MakeEnemy("CULTIST:1", hp: 300) with
    {
        Intents = [new IntentState("Attack", damage, 1)]
    };

    [Fact]
    public void SelfFormingClaySchedulesBlockAfterUnblockedDamage()
    {
        var sim = new DeterministicSimulator();
        var state = MakeState(MakePlayer(), AttackingEnemy(10), [], Relic("SELF_FORMING_CLAY"));

        var nextTurn = sim.ProjectToNextPlayerTurn(state);

        // The 10-damage attack was unblocked; 3 Block is scheduled and granted
        // at the start of the next player turn (block reset happens first).
        Assert.Equal(190, nextTurn.Player.Hp);
        Assert.Equal(3, nextTurn.Player.Block);
    }

    [Fact]
    public void SelfFormingClayDoesNotTriggerOnBlockedDamage()
    {
        var sim = new DeterministicSimulator();
        var state = MakeState(MakePlayer(block: 10), AttackingEnemy(10), [], Relic("SELF_FORMING_CLAY"));

        var nextTurn = sim.ProjectToNextPlayerTurn(state);

        // Fully blocked attack: no pending block at the next turn start.
        Assert.Equal(200, nextTurn.Player.Hp);
        Assert.Equal(0, nextTurn.Player.Block);
    }

    [Fact]
    public void PocketwatchDrawsThreeAfterQuietTurn()
    {
        var sim = new DeterministicSimulator();
        var drawPile = Enumerable.Range(0, 8).Select(i => MakeStrike($"s{i}")).ToArray();
        var snap = CombatSnapshot.Create("fp", MakePlayer(), [MakeEnemy("CULTIST:1", hp: 300)],
            [], drawPile: drawPile, relics: [Relic("POCKETWATCH")]);
        var state = MutableCombatState.FromSnapshot(snap);

        var nextTurn = sim.ProjectToNextPlayerTurn(state);

        // 0 cards played -> +3 draw at the next turn start.
        Assert.Equal(8, nextTurn.Hand.Count);
    }

    [Fact]
    public void PocketwatchDoesNotDrawAfterFourPlays()
    {
        var sim = new DeterministicSimulator();
        var hand = new[] { MakeStrike("s1"), MakeStrike("s2"), MakeStrike("s3"), MakeStrike("s4") };
        var snap = CombatSnapshot.Create("fp", MakePlayer(), [MakeEnemy("CULTIST:1", hp: 300)],
            hand, relics: [Relic("POCKETWATCH")]);
        var state = MutableCombatState.FromSnapshot(snap);

        while (state.Hand.Any(c => c.ModelId == "STRIKE_IRONCLAD"))
        {
            var strike = state.Hand.First(c => c.ModelId == "STRIKE_IRONCLAD");
            state = sim.PlayCard(state, strike, "CULTIST:1", null);
        }
        var nextTurn = sim.ProjectToNextPlayerTurn(state);

        // 4 cards played exceeds the threshold of 3. The played strikes were
        // shuffled back as the turn-start draw source (no pending bonus).
        Assert.Equal(4, nextTurn.Hand.Count);
    }

    [Fact]
    public void StoneCalendarStrikesAtEndOfTurnSeven()
    {
        var sim = new DeterministicSimulator();
        var enemy = MakeEnemy("CULTIST:1", hp: 300);
        var snap = CombatSnapshot.Create("fp", MakePlayer(), [enemy], [], relics: [Relic("STONE_CALENDAR")]);
        var state = MutableCombatState.FromSnapshot(snap);

        for (var i = 0; i < 6; i++)
        {
            state = sim.ProjectToNextPlayerTurn(state);
            Assert.Equal(300, state.Enemies.First(e => e.Id == "CULTIST:1").Hp);
        }
        var afterTurn7 = sim.ProjectToNextPlayerTurn(state);
        Assert.Equal(248, afterTurn7.Enemies.First(e => e.Id == "CULTIST:1").Hp);
    }

    [Fact]
    public void JossPaperDrawsOnFifthExhaust()
    {
        var sim = new DeterministicSimulator();
        var ethereal = Enumerable.Range(0, 5).Select(i => new CardState(
            $"eth_{i}", "ETH_TEST", "虚无测试", 1, TargetKind.None,
            [], CardType: "Skill", ExhaustAtTurnEnd: true)).ToArray();
        var drawPile = new[] { MakeStrike("draw1") };
        var snap = CombatSnapshot.Create("fp", MakePlayer(), [MakeEnemy("CULTIST:1", hp: 300)],
            ethereal, drawPile: drawPile, relics: [Relic("JOSS_PAPER")]);
        var state = MutableCombatState.FromSnapshot(snap);

        var nextTurn = sim.ProjectToNextPlayerTurn(state);

        // 5 ethereal cards exhausted at the turn boundary; the 5th exhaust
        // draws 1 card into the (otherwise empty) hand.
        Assert.Equal(0, nextTurn.Relics.First(r => r.Id == "JOSS_PAPER").Counter);
        Assert.Single(nextTurn.Hand);
        Assert.Equal(5, nextTurn.ExhaustPile.Count);
    }

    [Fact]
    public void IceCreamCarriesUnspentEnergy()
    {
        var sim = new DeterministicSimulator();
        var state = MakeState(MakePlayer(energy: 2), MakeEnemy("CULTIST:1", hp: 300),
            [MakeDefend("d1")], Relic("ICE_CREAM"));

        var defend = state.Hand.First(c => c.InstanceId == "d1");
        state = sim.PlayCard(state, defend, null, null);
        Assert.Equal(1, state.Player.Energy);

        var turn2 = sim.ProjectToNextPlayerTurn(state);
        Assert.Equal(4, turn2.Player.Energy);

        var turn3 = sim.ProjectToNextPlayerTurn(turn2);
        Assert.Equal(7, turn3.Player.Energy);
    }
}
