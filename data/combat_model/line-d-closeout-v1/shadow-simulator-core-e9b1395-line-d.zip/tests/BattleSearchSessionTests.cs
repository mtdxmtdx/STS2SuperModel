using System.Collections.Immutable;
using STS2BestChoice.Core.Model;
using STS2BestChoice.Core.Scoring;
using STS2BestChoice.Core.Search;
using STS2BestChoice.Core.Simulation;
using Xunit;

namespace STS2BestChoice.Tests;

public sealed class BattleSearchSessionTests
{
    [Fact]
    public void FiniteHorizonCarriesAProjectedHandIntoTheNextTurn()
    {
        var first = Attack("first", 10, 1);
        var second = Attack("second", 10, 1);
        var snapshot = CombatSnapshot.Create(
            "battle-fixture",
            new PlayerState(30, 30, 0, 1, 1, ImmutableDictionary<string, StatusState>.Empty, CardsPerTurn: 1),
            [new CreatureState("enemy", "Enemy", 20, 20, 0,
                ImmutableDictionary<string, StatusState>.Empty, [], 0)],
            [first],
            drawPile: [second],
            rngState: 42);
        var options = new SearchOptions(
            TimeSpan.FromMilliseconds(500),
            5,
            new ScoreWeights(),
            MaximumFutureTurns: 2,
            MaximumActions: 4)
        {
            MaximumExpandedNodes = 100_000
        };

        var result = new BattleSearchSession(snapshot, options).Search();

        Assert.NotEmpty(result.Plans);
        var best = result.Plans[0];
        Assert.Equal(1m, best.WinProbability);
        Assert.True(best.TurnsEvaluated >= 2);
        Assert.Contains(best.CurrentTurn, step => step.SourceInstanceId == "first");
        Assert.Contains(best.SafeFutureTurns, turn => turn.Any(step => step.SourceInstanceId == "second"));
        Assert.Equal(PredictionConfidence.Estimated, best.Confidence);
        Assert.Contains(best.SafeRestrictions, restriction => restriction.Code == "estimated_future_intent");
    }

    [Fact]
    public void OneTurnHorizonDoesNotInventFutureTurnPlans()
    {
        var strike = Attack("strike", 6, 1);
        var snapshot = CombatSnapshot.Create(
            "battle-one-turn",
            new PlayerState(30, 30, 0, 1, 1, ImmutableDictionary<string, StatusState>.Empty, CardsPerTurn: 0),
            [new CreatureState("enemy", "Enemy", 20, 20, 0,
                ImmutableDictionary<string, StatusState>.Empty, [], 0)],
            [strike],
            rngState: 42);
        var options = new SearchOptions(
            TimeSpan.FromMilliseconds(500),
            5,
            new ScoreWeights(),
            MaximumFutureTurns: 1,
            MaximumActions: 4)
        {
            MaximumExpandedNodes = 100_000
        };

        var result = new BattleSearchSession(snapshot, options).Search();

        Assert.NotEmpty(result.Plans);
        Assert.All(result.Plans, plan => Assert.Empty(plan.SafeFutureTurns));
        Assert.DoesNotContain(result.Plans, plan =>
            plan.SafeRestrictions.Any(restriction => restriction.Code == "estimated_future_intent"));
    }

    [Fact]
    public void ExactIntentProviderRemovesTheDefaultFutureIntentEstimate()
    {
        var first = Attack("first", 10, 1);
        var second = Attack("second", 10, 1);
        var snapshot = CombatSnapshot.Create(
            "battle-provider",
            new PlayerState(30, 30, 0, 1, 1, ImmutableDictionary<string, StatusState>.Empty, CardsPerTurn: 1),
            [new CreatureState("enemy", "Enemy", 20, 20, 0,
                ImmutableDictionary<string, StatusState>.Empty, [], 0)],
            [first],
            drawPile: [second],
            rngState: 42);
        var options = new SearchOptions(
            TimeSpan.FromMilliseconds(500),
            5,
            new ScoreWeights(),
            MaximumFutureTurns: 2,
            MaximumActions: 4)
        {
            MaximumExpandedNodes = 100_000
        };

        var result = new BattleSearchSession(snapshot, options, new ExactIntentProvider()).Search();

        Assert.NotEmpty(result.Plans);
        Assert.DoesNotContain(result.Plans[0].SafeRestrictions,
            restriction => restriction.Code == "estimated_future_intent");
        Assert.Equal(PredictionConfidence.Reliable, result.Plans[0].Confidence);
    }

    [Fact]
    public void ScheduledIntentProviderUsesOnlyTheRequestedFutureTurn()
    {
        var current = ImmutableArray.Create(
            new CreatureState("enemy", "Enemy", 20, 20, 0,
                ImmutableDictionary<string, StatusState>.Empty, [], 0));
        var scheduled = new ScheduledEnemyIntentForecastProvider(
            [
                (1, ImmutableArray.Create(current[0] with
                {
                    Intents = [new IntentState("ATTACK", 7, 1)]
                }))
            ]);

        var exact = scheduled.Forecast(current, 1);
        Assert.Equal(PredictionConfidence.Reliable, exact.Confidence);
        Assert.Equal(7m, exact.Enemies[0].Intents[0].DamagePerHit);

        var fallback = scheduled.Forecast(current, 2);
        Assert.Equal(PredictionConfidence.Estimated, fallback.Confidence);
        Assert.Contains(fallback.SafeRestrictions,
            restriction => restriction.Code == "estimated_future_intent");
    }

    [Fact]
    public void UnknownEndTurnShuffleContributesToBattleExpectedDamage()
    {
        var attack = Attack("draw-attack", 10, 1);
        var defend = new CardState(
            "draw-defend",
            "SKILL",
            "draw-defend",
            1,
            TargetKind.Self,
            [new EffectSpec(EffectKind.Block, 5)],
            CardType: "Skill");
        var snapshot = CombatSnapshot.Create(
            "battle-end-turn-shuffle",
            new PlayerState(30, 30, 0, 1, 1,
                ImmutableDictionary<string, StatusState>.Empty,
                CardsPerTurn: 1),
            [new CreatureState("enemy", "Enemy", 100, 100, 0,
                ImmutableDictionary<string, StatusState>.Empty, [], 0)],
            hand: [],
            discardPile: [attack, defend],
            rngState: 0);
        var options = new SearchOptions(
            TimeSpan.FromMilliseconds(500),
            5,
            new ScoreWeights(),
            MaximumFutureTurns: 2,
            MaximumActions: 3)
        {
            MaximumExpandedNodes = 100_000
        };

        var result = new BattleSearchSession(snapshot, options).Search();

        Assert.NotEmpty(result.Plans);
        var best = result.Plans[0];
        Assert.Equal(PredictionConfidence.Estimated, best.Confidence);
        Assert.DoesNotContain(best.SafeRestrictions,
            restriction => restriction.Code == "unknown_shuffle_rng_state");
        Assert.InRange(best.ExpectedDamage, 4.9m, 5.1m);
        Assert.Contains(best.SafeFutureTurns,
            turn => turn.Any(step => step.SourceInstanceId == "draw-attack"));
    }

    [Fact]
    public void ProbabilisticIntentForecastIsWeightedAcrossFuturePlans()
    {
        var enemy = new CreatureState(
            "enemy",
            "Enemy",
            100,
            100,
            0,
            ImmutableDictionary<string, StatusState>.Empty,
            [],
            0);
        var attackingEnemy = enemy with
        {
            Intents = [new IntentState("ATTACK", 10, 1)]
        };
        var provider = new ProbabilisticEnemyIntentForecastProvider(
            [
                (1, "不攻击", 0.5m, ImmutableArray.Create(enemy)),
                (1, "攻击", 0.5m, ImmutableArray.Create(attackingEnemy))
            ]);
        var snapshot = CombatSnapshot.Create(
            "battle-intent-chance",
            new PlayerState(30, 30, 0, 1, 1,
                ImmutableDictionary<string, StatusState>.Empty,
                CardsPerTurn: 0),
            [enemy],
            hand: [],
            rngState: 42);
        var options = new SearchOptions(
            TimeSpan.FromMilliseconds(500),
            5,
            new ScoreWeights(),
            MaximumFutureTurns: 2,
            MaximumActions: 2)
        {
            MaximumExpandedNodes = 100_000
        };

        var directState = MutableCombatState.FromSnapshot(snapshot);
        directState.Enemies[0] = attackingEnemy;
        var directProjection = new STS2BestChoice.Core.Simulation.DeterministicSimulator()
            .ProjectToNextPlayerTurn(directState);
        Assert.Equal(20m, directProjection.Player.Hp);
        var futureSession = new CombatSearchSession(snapshot, directState, options);
        futureSession.Continue(TimeSpan.FromMilliseconds(500));
        Assert.Contains(futureSession.GetTerminalCandidates(),
            candidate => candidate.State.Player.Hp == 20m);

        var result = new BattleSearchSession(snapshot, options, provider).Search();
        var deterministicProvider = new ProbabilisticEnemyIntentForecastProvider(
            [(1, "攻击", 1m, ImmutableArray.Create(attackingEnemy))]);
        var deterministicResult = new BattleSearchSession(snapshot, options, deterministicProvider).Search();
        Assert.True(deterministicResult.Plans[0].ExpectedHpLoss > 9m,
            $"deterministic={deterministicResult.Plans[0]}");

        Assert.NotEmpty(result.Plans);
        Assert.Equal(PredictionConfidence.Reliable, result.Plans[0].Confidence);
        Assert.True(result.Plans[0].ExpectedHpLoss is >= 4.9m and <= 5.1m,
            $"{result.Plans[0]} current={string.Join(',', result.Plans[0].CurrentTurn.Select(step => step.Label))} future={string.Join('|', result.Plans[0].SafeFutureTurns.Select(turn => string.Join(',', turn.Select(step => step.Label))))}");
        Assert.DoesNotContain(result.Plans[0].SafeRestrictions,
            restriction => restriction.Code == "estimated_future_intent");
    }

    [Fact]
    public void IntentStateKeyIncludesEffectsWithTheSameAttackDamage()
    {
        var enemy = new CreatureState(
            "enemy",
            "Enemy",
            30,
            30,
            0,
            ImmutableDictionary<string, StatusState>.Empty,
            [new IntentState("ATTACK", 8, 1,
                [new EffectSpec(EffectKind.ApplyStatus, 2, "STRENGTH")])]);
        var alternate = enemy with
        {
            Intents = [new IntentState("ATTACK", 8, 1,
                [new EffectSpec(EffectKind.ApplyStatus, 2, "WEAK", IsDebuff: true)])]
        };
        var first = CombatSnapshot.Create(
            "intent-key-a",
            new PlayerState(30, 30, 0, 1, 1,
                ImmutableDictionary<string, StatusState>.Empty,
                CardsPerTurn: 0),
            [enemy],
            hand: [],
            rngState: 42);
        var second = first with { Enemies = [alternate] };

        Assert.NotEqual(
            MutableCombatState.FromSnapshot(first).ExactKey(),
            MutableCombatState.FromSnapshot(second).ExactKey());
    }

    [Fact]
    public void EnemyDebuffValuationUsesTheEnemyOwnerPerspective()
    {
        var enemy = new CreatureState(
            "enemy",
            "Enemy",
            40,
            40,
            0,
            ImmutableDictionary<string, StatusState>.Empty,
            [],
            0);
        var snapshot = CombatSnapshot.Create(
            "status-score-direction",
            new PlayerState(30, 30, 0, 1, 1,
                ImmutableDictionary<string, StatusState>.Empty,
                CardsPerTurn: 0),
            [enemy],
            hand: [],
            rngState: 42);
        var scorer = new CombatScorer(snapshot, SearchOptions.Default);

        var weak = MutableCombatState.FromSnapshot(snapshot);
        weak.Enemies[0] = weak.Enemies[0] with
        {
            Statuses = ImmutableDictionary<string, StatusState>.Empty.Add(
                "WEAK",
                new StatusState("WEAK", 2, Duration: 1, IsDebuff: true,
                    FutureValuePerTurn: -3m))
        };
        var vulnerable = MutableCombatState.FromSnapshot(snapshot);
        vulnerable.Enemies[0] = vulnerable.Enemies[0] with
        {
            Statuses = ImmutableDictionary<string, StatusState>.Empty.Add(
                "VULNERABLE",
                new StatusState("VULNERABLE", 2, Duration: 1, IsDebuff: true,
                    FutureValuePerTurn: -4m))
        };
        var strength = MutableCombatState.FromSnapshot(snapshot);
        strength.Enemies[0] = strength.Enemies[0] with
        {
            Statuses = ImmutableDictionary<string, StatusState>.Empty.Add(
                "STRENGTH",
                new StatusState("STRENGTH", 2, Duration: 1,
                    FutureValuePerTurn: 3m))
        };

        Assert.True(scorer.Score(weak).LongTermValue > 0m);
        Assert.True(scorer.Score(vulnerable).LongTermValue > 0m);
        Assert.True(scorer.Score(strength).LongTermValue < 0m);
    }

    [Fact]
    public void BattleBalancedObjectiveCarriesAndSortsTheCombatBalancedScore()
    {
        var enemyWeak = new CardState(
            "enemy-weak",
            "WEAKEN",
            "Enemy Weak",
            0,
            TargetKind.Enemy,
            [new EffectSpec(EffectKind.ApplyStatus, 2, "WEAK", Duration: 2, IsDebuff: true)],
            CardType: "Skill");
        var enemyStrength = new CardState(
            "enemy-strength",
            "STRENGTHEN_ENEMY",
            "Enemy Strength",
            0,
            TargetKind.Enemy,
            [new EffectSpec(EffectKind.ApplyStatus, 2, "STRENGTH", Duration: 2)],
            CardType: "Skill");
        var enemy = new CreatureState(
            "enemy",
            "Enemy",
            100,
            100,
            0,
            ImmutableDictionary<string, StatusState>.Empty,
            [],
            0);
        var snapshot = CombatSnapshot.Create(
            "battle-balanced-score",
            new PlayerState(30, 30, 0, 0, 0,
                ImmutableDictionary<string, StatusState>.Empty,
                CardsPerTurn: 0),
            [enemy],
            [enemyWeak, enemyStrength],
            rngState: 42);
        var options = new SearchOptions(
            TimeSpan.FromMilliseconds(500),
            5,
            new ScoreWeights(),
            MaximumFutureTurns: 1,
            MaximumActions: 1)
        {
            MaximumExpandedNodes = 100_000
        };

        var result = new BattleSearchSession(snapshot, options).Search(ObjectiveKind.Balanced);

        Assert.NotEmpty(result.Plans);
        var weakPlan = Assert.Single(result.Plans, plan =>
            plan.CurrentTurn.Any(step => step.SourceInstanceId == "enemy-weak"));
        var strengthPlan = Assert.Single(result.Plans, plan =>
            plan.CurrentTurn.Any(step => step.SourceInstanceId == "enemy-strength"));
        Assert.True(weakPlan.ExpectedBalancedScore > strengthPlan.ExpectedBalancedScore);
        Assert.Equal(
            result.Plans.Max(static plan => plan.ExpectedBalancedScore),
            result.Plans[0].ExpectedBalancedScore);
    }

    [Fact]
    public void BattleDamageAndLossObjectivesChooseDifferentFirstTurnPolicies()
    {
        var attack = Attack("battle-attack", 18, 1);
        var defend = new CardState(
            "battle-defend",
            "DEFEND",
            "Battle Defend",
            1,
            TargetKind.Self,
            [new EffectSpec(EffectKind.Block, 10)],
            CardType: "Skill");
        var enemy = new CreatureState(
            "enemy",
            "Enemy",
            40,
            40,
            0,
            ImmutableDictionary<string, StatusState>.Empty,
            [new IntentState("ATTACK", 10, 1)],
            0);
        var snapshot = CombatSnapshot.Create(
            "battle-objectives",
            new PlayerState(30, 30, 0, 1, 1,
                ImmutableDictionary<string, StatusState>.Empty,
                CardsPerTurn: 0),
            [enemy],
            [attack, defend],
            rngState: 42);
        var options = new SearchOptions(
            TimeSpan.FromMilliseconds(500),
            5,
            new ScoreWeights(),
            MaximumFutureTurns: 1,
            MaximumActions: 1)
        {
            MaximumExpandedNodes = 100_000
        };

        var damage = new BattleSearchSession(snapshot, options)
            .Search(ObjectiveKind.HighestDamage);
        var loss = new BattleSearchSession(snapshot, options)
            .Search(ObjectiveKind.MinimumLoss);

        Assert.Contains(damage.Plans[0].CurrentTurn,
            step => step.SourceInstanceId == "battle-attack");
        Assert.Contains(loss.Plans[0].CurrentTurn,
            step => step.SourceInstanceId == "battle-defend");
        Assert.True(damage.Plans[0].ExpectedDamage > loss.Plans[0].ExpectedDamage);
        Assert.True(loss.Plans[0].ExpectedHpLoss < damage.Plans[0].ExpectedHpLoss);
    }

    [Fact]
    public async Task BattleSearchCoordinatorRunsAllObjectivesOnIndependentSessions()
    {
        var attack = Attack("parallel-attack", 18, 1);
        var defend = new CardState(
            "parallel-defend",
            "DEFEND",
            "Parallel Defend",
            1,
            TargetKind.Self,
            [new EffectSpec(EffectKind.Block, 10)],
            CardType: "Skill");
        var snapshot = CombatSnapshot.Create(
            "battle-parallel",
            new PlayerState(30, 30, 0, 1, 1,
                ImmutableDictionary<string, StatusState>.Empty,
                CardsPerTurn: 0),
            [new CreatureState(
                "enemy",
                "Enemy",
                40,
                40,
                0,
                ImmutableDictionary<string, StatusState>.Empty,
                [new IntentState("ATTACK", 10, 1)],
                0)],
            [attack, defend],
            rngState: 42);
        var options = new SearchOptions(
            TimeSpan.FromMilliseconds(250),
            5,
            new ScoreWeights(),
            MaximumFutureTurns: 1,
            MaximumActions: 1)
        {
            MaximumExpandedNodes = 100_000
        };

        var parallel = await BattleSearchCoordinator.SearchAllObjectivesAsync(snapshot, options);

        Assert.Equal(
            Enum.GetValues<ObjectiveKind>().OrderBy(static objective => objective),
            parallel.Results.Select(static result => result.Objective).OrderBy(static objective => objective));
        Assert.All(parallel.Results, result => Assert.NotEmpty(result.Plans));
        Assert.Contains(parallel.Results.Single(result => result.Objective == ObjectiveKind.HighestDamage).Plans[0].CurrentTurn,
            step => step.SourceInstanceId == "parallel-attack");
        Assert.Contains(parallel.Results.Single(result => result.Objective == ObjectiveKind.MinimumLoss).Plans[0].CurrentTurn,
            step => step.SourceInstanceId == "parallel-defend");
        Assert.Same(
            parallel.Results.Single(result => result.Objective == ObjectiveKind.Balanced),
            parallel.For(ObjectiveKind.Balanced));
    }

    private static CardState Attack(string id, decimal damage, int cost) => new(
        id,
        "ATTACK",
        id,
        cost,
        TargetKind.Enemy,
        [new EffectSpec(EffectKind.Damage, damage)],
        CardType: "Attack");

    private sealed class ExactIntentProvider : IEnemyIntentForecastProvider
    {
        public EnemyIntentForecast Forecast(
            ImmutableArray<CreatureState> currentEnemies,
            int futureTurn) => new(currentEnemies, PredictionConfidence.Reliable);
    }
}
