using System.Collections.Immutable;
using STS2BestChoice.Core.Model;
using STS2BestChoice.Core.Simulation;
using Xunit;

namespace STS2BestChoice.Tests;

public sealed class D2RelicSemanticTests
{
    private static readonly ImmutableDictionary<string, StatusState> EmptyStatuses =
        ImmutableDictionary<string, StatusState>.Empty;

    private static RelicState Relic(string id, params (string Name, decimal Value)[] vars) =>
        new(id, DynamicVars: vars.ToImmutableDictionary(item => item.Name, item => item.Value));

    private static CreatureState Enemy(
        decimal hp = 50m,
        ImmutableDictionary<string, StatusState>? statuses = null,
        params IntentState[] intents) =>
        new("enemy", "Enemy", hp, hp, 0m, statuses ?? EmptyStatuses, [.. intents], 0m);

    private static CombatSnapshot Snapshot(
        PlayerState player,
        ImmutableArray<CreatureState> enemies,
        ImmutableArray<CardState> hand = default,
        ImmutableArray<CardState> draw = default,
        ImmutableArray<CardState> discard = default,
        ImmutableArray<RelicState> relics = default,
        int round = 1) =>
        CombatSnapshot.Create(
            "d2-relic-test", player, enemies,
            hand.IsDefault ? [] : hand,
            drawPile: draw.IsDefault ? [] : draw,
            discardPile: discard.IsDefault ? [] : discard,
            relics: relics.IsDefault ? [] : relics,
            round: round);

    [Fact]
    public void PaperPhrogRaisesVulnerableMultiplierToOnePointSevenFive()
    {
        var attack = new CardState("attack", "ATTACK", "Attack", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 10m)], CardType: "Attack");
        var vulnerable = EmptyStatuses.Add("VULNERABLE", new StatusState("VULNERABLE", 2));
        var snapshot = Snapshot(
            new PlayerState(50m, 50m, 0m, 0, 0, EmptyStatuses),
            [Enemy(statuses: vulnerable)], [attack], relics: [Relic("PAPER_PHROG")]);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), attack, "enemy", null);

        Assert.Equal(33m, result.Enemies[0].Hp);
    }

    [Fact]
    public void PaperKraneReducesWeakEnemyAttackToSixtyPercent()
    {
        var weak = EmptyStatuses.Add("WEAK", new StatusState("WEAK", 2, Duration: 2));
        var snapshot = Snapshot(
            new PlayerState(50m, 50m, 0m, 0, 0, EmptyStatuses, CardsPerTurn: 0),
            [Enemy(50m, weak, new IntentState("Attack", 10m, 1))],
            relics: [Relic("PAPER_KRANE")]);

        var result = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(snapshot));

        Assert.Equal(44m, result.Player.Hp);
        Assert.Equal(1m, result.Enemies[0].Statuses["WEAK"].Amount);
    }

    [Fact]
    public void GremlinHornGainsEnergyAndDrawsOnEnemyDeath()
    {
        var attack = new CardState("attack", "ATTACK", "Attack", 0, TargetKind.Enemy,
            [new EffectSpec(EffectKind.Damage, 10m)], CardType: "Attack");
        var draw = new CardState("drawn", "DRAWN", "Drawn", 1, TargetKind.None, []);
        var snapshot = Snapshot(
            new PlayerState(50m, 50m, 0m, 0, 3, EmptyStatuses),
            [Enemy(hp: 5m)], [attack], draw: [draw],
            relics: [Relic("GREMLIN_HORN", ("Cards", 1m), ("Energy", 1m))]);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), attack, "enemy", null);

        Assert.Equal(1, result.Player.Energy);
        Assert.Contains(result.Hand, card => card.InstanceId == "drawn");
    }

    [Fact]
    public void BookRepairKnifeHealsOnlyDoomDeath()
    {
        var doom = EmptyStatuses.Add("DOOM", new StatusState("DOOM", 10));
        var snapshot = Snapshot(
            new PlayerState(40m, 50m, 0m, 0, 0, EmptyStatuses, CardsPerTurn: 0),
            [Enemy(hp: 5m, statuses: doom)],
            relics: [Relic("BOOK_REPAIR_KNIFE", ("Heal", 3m))]);

        var result = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(snapshot));

        Assert.Equal(43m, result.Player.Hp);
    }

    [Fact]
    public void LizardTailRevivesOnceAtConfiguredPercentage()
    {
        var snapshot = Snapshot(
            new PlayerState(10m, 80m, 0m, 0, 0, EmptyStatuses, CardsPerTurn: 0),
            [Enemy(intents: new IntentState("Attack", 20m, 1))],
            relics: [Relic("LIZARD_TAIL", ("Heal", 50m))]);

        var result = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(snapshot));

        Assert.Equal(40m, result.Player.Hp);
        Assert.True(Assert.Single(result.Relics).IsUsedUp);
    }

    [Theory]
    [InlineData("RUNIC_PYRAMID", 2, 1)]
    [InlineData("RINGING_TRIANGLE", 1, 1)]
    [InlineData("RINGING_TRIANGLE", 2, 0)]
    public void RetainRelicsKeepTheExpectedWholeHand(string relicId, int round, int expectedRetained)
    {
        var card = new CardState("card", "CARD", "Card", 1, TargetKind.None, []);
        var snapshot = Snapshot(
            new PlayerState(50m, 50m, 0m, 0, 0, EmptyStatuses, CardsPerTurn: 0),
            [Enemy()], [card], relics: [Relic(relicId)], round: round);

        var result = new DeterministicSimulator().ProjectToNextPlayerTurn(
            MutableCombatState.FromSnapshot(snapshot));

        Assert.Equal(expectedRetained, result.Hand.Count);
    }

    [Fact]
    public void AbacusGainsBlockWheneverDiscardPileIsShuffled()
    {
        var drawCard = new CardState("draw", "DRAW", "Draw", 0, TargetKind.Self,
            [new EffectSpec(EffectKind.Draw, 1)]);
        var discarded = new CardState("discarded", "DISCARDED", "Discarded", 1, TargetKind.None, []);
        var snapshot = Snapshot(
            new PlayerState(50m, 50m, 0m, 0, 0, EmptyStatuses),
            [Enemy()], [drawCard], discard: [discarded],
            relics: [Relic("THE_ABACUS", ("Block", 6m))]);

        var result = new DeterministicSimulator().PlayCard(
            MutableCombatState.FromSnapshot(snapshot), drawCard, null, null);

        Assert.Equal(6m, result.Player.Block);
    }
}
